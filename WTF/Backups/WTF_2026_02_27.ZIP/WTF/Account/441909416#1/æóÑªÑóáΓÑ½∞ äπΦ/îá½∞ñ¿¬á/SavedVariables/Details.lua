
_detalhes_database = {
["savedbuffs"] = {
},
["mythic_dungeon_id"] = 0,
["tabela_historico"] = {
["tabelas"] = {
},
},
["ocd_tracker"] = {
["enabled"] = false,
["current_cooldowns"] = {
},
["lines_per_column"] = 12,
["group_frames"] = true,
["width"] = 120,
["frames"] = {
["defensive-raid"] = {
},
["main"] = {
},
["ofensive"] = {
},
["defensive-target"] = {
},
["utility"] = {
},
["defensive-personal"] = {
},
},
["show_options"] = false,
["ignored_cooldowns"] = {
},
["framme_locked"] = false,
["cooldowns"] = {
},
["own_frame"] = {
["defensive-raid"] = false,
["ofensive"] = false,
["defensive-target"] = false,
["utility"] = false,
["defensive-personal"] = false,
},
["height"] = 18,
["show_conditions"] = {
["only_inside_instance"] = true,
["only_in_group"] = true,
},
["show_title"] = true,
["filters"] = {
["itemutil"] = false,
["itempower"] = false,
["defensive-target"] = false,
["itemheal"] = false,
["defensive-personal"] = false,
["defensive-raid"] = false,
["ofensive"] = true,
["crowdcontrol"] = false,
["utility"] = false,
},
},
["combat_counter"] = 27,
["damage_meter_sessions"] = {
},
["force_font_outline"] = "",
["tabela_instancias"] = {
},
["arena_data_compressed"] = {
},
["arena_data_index_selected"] = 1,
["local_instances_config"] = {
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -294.0887145996094,
["x"] = 905.923095703125,
["w"] = 285.384033203125,
["h"] = 53.76954650878906,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
[2] = 3,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -387.1405487060547,
["x"] = 905.9241943359375,
["w"] = 285.384033203125,
["h"] = 121.8720397949219,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
[4] = 2,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -529.0125961303711,
["x"] = 905.9241943359375,
["w"] = 285.384033203125,
["h"] = 121.8720474243164,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
},
["mythic_dungeon_currentsaved"] = {
["dungeon_name"] = "",
["started"] = false,
["segment_id"] = 0,
["ej_id"] = 0,
["started_at"] = 0,
["run_id"] = 0,
["level"] = 0,
["dungeon_zone_id"] = 0,
["previous_boss_killed_at"] = 0,
},
["nick_tag_cache"] = {
["nextreset"] = 1773427986,
["last_version"] = 16,
},
["last_instance_id"] = 2648,
["data_harvest_for_charsts"] = {
["players"] = {
{
["name"] = "Damage of Each Individual Player",
["playerOnly"] = true,
["playerKey"] = "total",
["combatObjectContainer"] = 1,
},
},
["totals"] = {
{
["combatObjectSubTableKey"] = 1,
["name"] = "Damage of All Player Combined",
["combatObjectSubTableName"] = "totals",
},
},
},
["announce_interrupts"] = {
["enabled"] = false,
["whisper"] = "",
["channel"] = "SAY",
["custom"] = "",
["next"] = "",
},
["announce_prepots"] = {
["enabled"] = false,
["channel"] = "SELF",
["reverse"] = false,
},
["active_profile"] = "All classes",
["last_realversion"] = 170,
["on_death_menu"] = false,
["ignore_nicktag"] = false,
["cached_roles"] = {
},
["cached_talents"] = {
["Player-1604-0AA7EF3A"] = "CAQA4VPTJ8eQb8/qEm8PyGu4yAgtZGDGjxMjZ2MbzMzMDAAAAAAAAAAAAAgxAEBMzAgAY2mtNwYzAAAAAAgA",
},
["combat_log"] = {
["inverse_deathlog_overalldata"] = false,
["track_hunter_frenzy"] = false,
["merge_gemstones_1007"] = false,
["merge_critical_heals"] = false,
["inverse_deathlog_raid"] = false,
["calc_evoker_damage"] = true,
["evoker_show_realtimedps"] = false,
["inverse_deathlog_mplus"] = false,
},
["character_data"] = {
["logons"] = 11,
},
["plugin_database"] = {
["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
["enabled"] = true,
["author"] = "Terciob",
["max_compares"] = 4,
["compare_type"] = 1,
},
["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
["use_square_mode"] = false,
["is_first_run"] = false,
["arrow_color"] = {
1,
1,
1,
0.5,
},
["scale"] = 1,
["main_frame_size"] = {
300.0000915527344,
500.0000305175781,
},
["minimap"] = {
["minimapPos"] = 160,
["radius"] = 160,
["hide"] = false,
},
["point"] = "CENTER",
["arrow_anchor_x"] = 0,
["y"] = 1.52587890625e-05,
["row_texture"] = "Details Serenity",
["square_grow_direction"] = "right",
["font_color"] = {
1,
1,
1,
1,
},
["row_height"] = 20,
["square_amount"] = 5,
["enabled"] = false,
["arrow_size"] = 10,
["use_spark"] = true,
["row_spacement"] = 21,
["main_frame_color"] = {
0,
0,
0,
0.2,
},
["main_frame_strata"] = "LOW",
["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
["row_color"] = {
0.1,
0.1,
0.1,
0.4,
},
["per_second"] = {
["enabled"] = false,
["point"] = "CENTER",
["scale"] = 1,
["font_shadow"] = true,
["y"] = 0,
["x"] = 0,
["update_speed"] = 0.05,
["size"] = 32,
["attribute_type"] = 1,
},
["x"] = 3.0517578125e-05,
["font_face"] = "Friz Quadrata TT",
["square_size"] = 32,
["arrow_anchor_y"] = 0,
["font_size"] = 10,
["main_frame_locked"] = false,
["author"] = "Terciob",
},
},
["SoloTablesSaved"] = {
["Mode"] = 1,
},
["mythic_plus_log"] = {
},
["last_day"] = "27",
["announce_damagerecord"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["benchmark_db"] = {
["frame"] = {
},
},
["player_stats"] = {
},
["last_version"] = "12.0.1 14655",
["combat_id"] = 2,
["savedStyles"] = {
},
["announce_firsthit"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["coach"] = {
["enabled"] = false,
["welcome_panel_pos"] = {
},
["last_coach_name"] = false,
},
["announce_deaths"] = {
["enabled"] = false,
["last_hits"] = 1,
["only_first"] = 5,
["where"] = 1,
},
["tabela_overall"] = {
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
{
["tipo"] = 3,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["tempo_start"] = 13295.067,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["totals_grupo"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["bossTimers"] = {
},
["trinketProcs"] = {
},
["playerTalents"] = {
},
["totals"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["frags_need_refresh"] = false,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = 0,
["amountCasts"] = {
},
["mapId"] = 2552,
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["boss_hp"] = 1,
["is_challenge"] = false,
["frags"] = {
},
["data_fim"] = 0,
["cleu_timeline"] = {
},
["spells_cast_timeline"] = {
},
["PhaseData"] = {
{
1,
1,
},
["heal_section"] = {
},
["heal"] = {
},
["damage_section"] = {
},
["damage"] = {
},
},
["start_time"] = 0,
["TimeData"] = {
},
["combat_counter"] = 26,
},
["data_harvested_for_charts"] = {
},
["arena_data_headers"] = {
},
["last_instance_time"] = 1772150764,
["announce_cooldowns"] = {
["enabled"] = false,
["ignored_cooldowns"] = {
},
["custom"] = "",
["channel"] = "RAID",
},
["rank_window"] = {
["last_difficulty"] = 15,
["last_raid"] = "",
},
["damage_meter_session_info"] = {
},
["cached_specs"] = {
["Player-1604-0AA7EF3A"] = 256,
},
}
