
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[263] = 40,
[264] = 40,
[262] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA824D2"] = true,
},
["minimap"] = {
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[263] = 40,
[264] = 40,
[262] = 40,
},
}
