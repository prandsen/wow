
_detalhes_database = {
["savedbuffs"] = {
},
["mythic_dungeon_id"] = 2,
["tabela_historico"] = {
["tabelas"] = {
{
{
["combatId"] = 102,
["tipo"] = 2,
["_ActorTable"] = {
},
},
{
["combatId"] = 102,
["tipo"] = 3,
["_ActorTable"] = {
},
},
{
["combatId"] = 102,
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["combatId"] = 102,
["tipo"] = 9,
["_ActorTable"] = {
},
},
{
["combatId"] = 102,
["tipo"] = 2,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772213921,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 166,
["playerTalents"] = {
},
["totals"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар",
["run_time"] = 0,
["data_fim"] = "21:38:42",
["timeEnd"] = 1772213922,
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["is_mythic_dungeon"] = {
["EndedAt"] = 1772213920.1,
["OverallSegment"] = true,
["SegmentType"] = 12,
["StartedAt"] = 1772213859.7,
["EJID"] = 0,
["Level"] = 2,
["TimeInCombat"] = 0,
["RunID"] = 2,
["ZoneName"] = "\"Сияющий Рассвет\"",
["SegmentID"] = "overall",
["SegmentName"] = "\"Сияющий Рассвет\" +2",
["WorldStateTimerStart"] = 1772213850,
},
["total_segments_added"] = 0,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage_section"] = {
},
["damage"] = {
{
},
},
},
["end_time"] = 36773.968,
["mapId"] = 2601,
["combat_id"] = 102,
["timeStart"] = 1772213922,
["data_inicio"] = "",
["is_mythic_dungeon_segment"] = true,
["is_challenge"] = true,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["totals_grupo"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["is_mythic_dungeon_run_id"] = 2,
["start_time"] = 36773.968,
["TimeData"] = {
},
["frags"] = {
},
},
{
{
["tipo"] = 2,
["combatId"] = 100,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005894,
["pets"] = {
},
["role"] = "HEALER",
["classe"] = "DRUID",
["total_without_pet"] = 0.005894,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 4923,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["mrating"] = 3925,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["fight_component"] = true,
["end_time"] = 1772208937,
["tipo"] = 1,
["aID"] = "1615-0B536A51",
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 4923,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["specIcon"] = 136041,
["last_dps"] = 4923,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005894,
["start_time"] = 1772208937,
["delay"] = 0,
["friendlyfire"] = {
},
},
},
},
{
["tipo"] = 3,
["combatId"] = 100,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 100,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 100,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 100,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 36708.65,
["tempo_start"] = 1772208937,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 160,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNmhxsgFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
4923,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
4923,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "party",
["zoneName"] = "\"Сияющий Рассвет\"",
["data_fim"] = "20:15:37",
["timeEnd"] = 1772208937,
["combatSessionId"] = "Сумеречный проклятый клинок3",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["playing_solo"] = true,
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["is_mythic_dungeon"] = {
["MapID"] = 2662,
["RunID"] = 1,
["ZoneName"] = "\"Сияющий Рассвет\"",
["SegmentID"] = 1,
["SegmentType"] = 11,
["StartedAt"] = 1772208923.552,
["EJID"] = 0,
["Level"] = 20,
["SegmentName"] = "Trash #1",
["EndedAt"] = 1772208937,
},
["data_inicio"] = "20:15:24",
["TotalElapsedCombatTime"] = 1.165999999997439,
["overall_added"] = true,
["CombatEndedAt"] = 36566.88,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 4923,
},
},
},
["end_time"] = 31789.381,
["mapId"] = 2662,
["combat_id"] = 100,
["timeStart"] = 1772208937,
["resincked"] = true,
["is_mythic_dungeon_segment"] = true,
["is_challenge"] = true,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["frags"] = {
},
["is_mythic_dungeon_run_id"] = 1,
["start_time"] = 31775.933,
["TimeData"] = {
},
["player_last_events"] = {
},
},
{
{
["tipo"] = 2,
["combatId"] = 99,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.006533,
["pets"] = {
},
["role"] = "HEALER",
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.006533,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 4462,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["mrating"] = 3925,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 56395.4,
["fight_component"] = true,
["end_time"] = 1772208823,
["specIcon"] = 136041,
["classe"] = "DRUID",
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 4462,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["last_dps"] = 892.4,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 281977,
["start_time"] = 1772208823,
["delay"] = 0,
["friendlyfire"] = {
},
},
},
},
{
["tipo"] = 3,
["combatId"] = 99,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.002655,
["total_without_pet"] = 0.002655,
["total"] = 130957,
["spec"] = 105,
["heal_enemy"] = {
},
["totalabsorb_ps"] = 8318.6,
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 41593,
["last_hps"] = 26191.4,
["specIcon"] = 136041,
["targets"] = {
},
["last_event"] = 0,
["totalover_without_pet"] = 0.002655,
["healing_taken"] = 0.002655,
["fight_component"] = true,
["end_time"] = 1772208823,
["heal_enemy_amt"] = 0,
["aID"] = "1615-0B536A51",
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[33763] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 1015,
["c_max"] = 0,
["id"] = 33763,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2585,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[774] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2762,
["c_max"] = 0,
["id"] = 774,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[1217091] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 60476,
["c_max"] = 0,
["id"] = 1217091,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[474683] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 15102,
["c_max"] = 0,
["id"] = 474683,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[81269] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 6687,
["c_max"] = 0,
["id"] = 81269,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[8936] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 42330,
["c_max"] = 0,
["id"] = 8936,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["start_time"] = 1772208823,
["targets_overheal"] = {
},
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002655,
["delay"] = 0,
["targets_absorbs"] = {
},
},
},
},
{
["tipo"] = 7,
["combatId"] = 99,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 99,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 99,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 31784.871,
["tempo_start"] = 1772208823,
["last_events_tables"] = {
{
{
{
"SPELL_DAMAGE",
431303,
102389,
1772208369.534,
0.5238312806250828,
"Сумеречный маг тени",
nil,
32,
0,
23280,
false,
false,
},
{
"SWING_DAMAGE",
nil,
71911,
1772208369.444,
1,
"Сумеречный проклятый клинок",
[11] = false,
[10] = -1,
[9] = 0,
[12] = false,
},
{
"SWING_DAMAGE",
nil,
45704,
1772208368.014,
1,
"Сумеречный проклятый клинок",
21162,
[9] = 0,
[10] = -1,
[11] = false,
[12] = false,
},
{
"SWING_DAMAGE",
nil,
43660,
1772208366.514,
1,
"Сумеречный проклятый клинок",
20431,
[9] = 0,
[10] = -1,
[11] = false,
[12] = false,
},
},
1772208369.534,
"Бимладен",
"DRUID",
151020,
"29536806m 9s",
["dead_at"] = 1772208369.534,
["spec"] = 105,
["dead"] = true,
},
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 158,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNmhxsgFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
4462,
130957,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
4462,
130957,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "party",
["zoneName"] = "\"Сияющий Рассвет\"",
["data_fim"] = "20:13:44",
["timeEnd"] = 1772208824,
["combatSessionId"] = "Сумеречный проклятый клинок1",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["playing_solo"] = true,
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["player_last_events"] = {
},
["is_mythic_dungeon"] = {
["MapID"] = 2662,
["RunID"] = 1,
["ZoneName"] = "\"Сияющий Рассвет\"",
["SegmentID"] = 1,
["SegmentType"] = 11,
["StartedAt"] = 1772208366.457,
["EJID"] = 0,
["Level"] = 20,
["SegmentName"] = "Trash #1",
["EndedAt"] = 1772208824,
},
["TotalElapsedCombatTime"] = 1.28099999999904,
["overall_added"] = true,
["CombatEndedAt"] = 31777.214,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "20:06:06",
["end_time"] = 31675.983,
["mapId"] = 2662,
["combat_id"] = 99,
["timeStart"] = 1772208824,
["resincked"] = true,
["is_mythic_dungeon_segment"] = true,
["is_challenge"] = true,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["frags"] = {
},
["is_mythic_dungeon_run_id"] = 1,
["start_time"] = 31218.44,
["TimeData"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 130957,
},
},
["damage"] = {
{
["Бимладен"] = 4462,
},
},
},
},
{
{
["tipo"] = 2,
["combatId"] = 98,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008452,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008452,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 379,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772200732,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 379,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008452,
["start_time"] = 1772200732,
["delay"] = 0,
["last_dps"] = 54.14285714285715,
},
},
},
{
["tipo"] = 3,
["combatId"] = 98,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 98,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 98,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 98,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 31658.197,
["tempo_start"] = 1772200732,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
379,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
379,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:58:53",
["timeEnd"] = 1772200733,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов20",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["playing_solo"] = true,
["TotalElapsedCombatTime"] = 5.438000000001921,
["overall_added"] = true,
["CombatEndedAt"] = 31222.029,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:58:47",
["end_time"] = 23585.644,
["mapId"] = 2552,
["combat_id"] = 98,
["timeStart"] = 1772200733,
["resincked"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 379,
},
},
},
["combat_counter"] = 154,
["start_time"] = 23579.098,
["TimeData"] = {
},
["training_dummy"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 97,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005195,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.005195,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 35349,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199273,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 26016,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1672,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[409311] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 73,
["c_max"] = 0,
["id"] = 409311,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7588,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005195,
["start_time"] = 1772199273,
["delay"] = 0,
["last_dps"] = 3213.545454545455,
},
},
},
{
["tipo"] = 3,
["combatId"] = 97,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 97,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 97,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 97,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 23578.092,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
35349,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
35349,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:34:34",
["timeEnd"] = 1772199274,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов19",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 22126.199,
["playing_solo"] = true,
["CombatEndedAt"] = 22126.199,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:34:22",
["end_time"] = 22126.199,
["mapId"] = 2552,
["combat_id"] = 97,
["timeStart"] = 1772199274,
["tempo_start"] = 1772199273,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 35349,
},
},
},
["combat_counter"] = 153,
["start_time"] = 22114.498,
["TimeData"] = {
},
["training_dummy"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 96,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.002087,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.002087,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 280960,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199253,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 17015,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 168519,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 28548,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[409311] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1610,
["c_max"] = 0,
["id"] = 409311,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 15482,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 13431,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 36355,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.002087,
["start_time"] = 1772199253,
["delay"] = 0,
["last_dps"] = 5202.962962962963,
},
},
},
{
["tipo"] = 3,
["combatId"] = 96,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.006615,
["total_without_pet"] = 0.006615,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.006615,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.006615,
["spec"] = 105,
["healing_taken"] = 0.006615,
["end_time"] = 1772199253,
["start_time"] = 1772199253,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.006615,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 96,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 96,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 96,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 22114.498,
["tempo_start"] = 1772199253,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
280960,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
280960,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:34:14",
["timeEnd"] = 1772199254,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов18",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 22106.172,
["playing_solo"] = true,
["CombatEndedAt"] = 22106.172,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:33:19",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 96,
["timeStart"] = 1772199254,
["end_time"] = 22106.172,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 280960,
},
},
},
["combat_counter"] = 152,
["start_time"] = 22051.837,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 95,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008931,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008931,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 80422,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199160,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 74541,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5881,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008931,
["start_time"] = 1772199160,
["delay"] = 0,
["last_dps"] = 2513.1875,
},
},
},
{
["tipo"] = 3,
["combatId"] = 95,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.00803,
["total_without_pet"] = 0.00803,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.00803,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.00803,
["spec"] = 105,
["healing_taken"] = 0.00803,
["end_time"] = 1772199160,
["start_time"] = 1772199160,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00803,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 95,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 95,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 95,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 22051.837,
["tempo_start"] = 1772199160,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
80422,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
80422,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:32:40",
["timeEnd"] = 1772199160,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов17",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 22012.648,
["playing_solo"] = true,
["CombatEndedAt"] = 22012.648,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:32:08",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 95,
["timeStart"] = 1772199160,
["end_time"] = 22012.648,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 80422,
},
},
},
["combat_counter"] = 151,
["start_time"] = 21980.127,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 94,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.006299,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.006299,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 61443,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199111,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 54962,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2760,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3637,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[409311] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 84,
["c_max"] = 0,
["id"] = 409311,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.006299,
["start_time"] = 1772199111,
["delay"] = 0,
["last_dps"] = 3413.5,
},
},
},
{
["tipo"] = 3,
["combatId"] = 94,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.00599,
["total_without_pet"] = 0.00599,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.00599,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.00599,
["spec"] = 105,
["healing_taken"] = 0.00599,
["end_time"] = 1772199111,
["start_time"] = 1772199111,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00599,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 94,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 94,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 94,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 21980.127,
["tempo_start"] = 1772199111,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
61443,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
61443,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:31:51",
["timeEnd"] = 1772199111,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов16",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 21963.647,
["playing_solo"] = true,
["CombatEndedAt"] = 21963.647,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:31:33",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 94,
["timeStart"] = 1772199111,
["end_time"] = 21963.647,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 61443,
},
},
},
["combat_counter"] = 150,
["start_time"] = 21945.636,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 93,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.006363,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.006363,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 32746,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199111,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 10465,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3919,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 18362,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.006363,
["start_time"] = 1772199111,
["delay"] = 0,
["last_dps"] = 2728.833333333334,
},
},
},
{
["tipo"] = 3,
["combatId"] = 93,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 93,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 93,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 93,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772199111,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
32746,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
32746,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:31:51",
["timeEnd"] = 1772199111,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов15",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:30:47",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 93,
["timeStart"] = 1772199111,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 32746,
},
},
},
["combat_counter"] = 149,
["start_time"] = 21899.314,
["TimeData"] = {
},
["end_time"] = 21963.647,
},
{
{
["tipo"] = 2,
["combatId"] = 90,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.007076,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.007076,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 49787,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199052,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 9298,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 22953,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 16715,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 821,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.007076,
["start_time"] = 1772199052,
["delay"] = 0,
["last_dps"] = 5531.888888888889,
},
},
},
{
["tipo"] = 3,
["combatId"] = 90,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.006299,
["total_without_pet"] = 0.006299,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.006299,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.006299,
["spec"] = 105,
["healing_taken"] = 0.006299,
["end_time"] = 1772199052,
["start_time"] = 1772199052,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.006299,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 90,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 90,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 90,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772199052,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
49787,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
49787,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:30:52",
["timeEnd"] = 1772199052,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов14",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:30:33",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 90,
["timeStart"] = 1772199052,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 49787,
},
},
},
["combat_counter"] = 146,
["start_time"] = 21885.261,
["TimeData"] = {
},
["end_time"] = 21904.665,
},
{
{
["tipo"] = 2,
["combatId"] = 88,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008896,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008896,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 890447,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772199042,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 30668,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 11919,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 38375,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[155625] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 8420,
["c_max"] = 0,
["id"] = 155625,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[274838] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 207719,
["c_max"] = 0,
["id"] = 274838,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 163309,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 78530,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 157645,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5176] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6345,
["c_max"] = 0,
["id"] = 5176,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 130863,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 23186,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[106785] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 33468,
["c_max"] = 0,
["id"] = 106785,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008896,
["start_time"] = 1772199042,
["delay"] = 0,
["last_dps"] = 9678.771739130434,
},
},
},
{
["tipo"] = 3,
["combatId"] = 88,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.0018,
["total_without_pet"] = 0.0018,
["total"] = 82376,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.0018,
["last_hps"] = 895.3913043478261,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.0018,
["spec"] = 105,
["healing_taken"] = 0.0018,
["end_time"] = 1772199042,
["start_time"] = 1772199042,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8936] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 29557,
["c_max"] = 0,
["id"] = 8936,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[774] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 42123,
["c_max"] = 0,
["id"] = 774,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 10696,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.0018,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 88,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 88,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 88,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772199042,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
890447,
82376,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
890447,
82376,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:30:42",
["timeEnd"] = 1772199042,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов13",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:28:45",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 88,
["timeStart"] = 1772199042,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 82376,
},
},
["damage"] = {
{
["Бимладен"] = 890447,
},
},
},
["combat_counter"] = 144,
["start_time"] = 21777.208,
["TimeData"] = {
},
["end_time"] = 21894.565,
},
{
{
["tipo"] = 2,
["combatId"] = 82,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.001668,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.001668,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 37615,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772198952,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 37615,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.001668,
["start_time"] = 1772198952,
["delay"] = 0,
["last_dps"] = 2893.461538461539,
},
},
},
{
["tipo"] = 3,
["combatId"] = 82,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 82,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 82,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 82,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772198952,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
37615,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
37615,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:29:12",
["timeEnd"] = 1772198952,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов12",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:25:30",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 82,
["timeStart"] = 1772198952,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 37615,
},
},
},
["combat_counter"] = 138,
["start_time"] = 21582.218,
["TimeData"] = {
},
["end_time"] = 21804.79,
},
{
{
["tipo"] = 2,
["combatId"] = 80,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.00413,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.00413,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 11117,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772198743,
["friendlyfire"] = {
},
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 8220,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2897,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "DRUID",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.00413,
["start_time"] = 1772198743,
["delay"] = 0,
["last_dps"] = 2223.4,
},
},
},
{
["tipo"] = 3,
["combatId"] = 80,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 80,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 80,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 80,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 21777.208,
["tempo_start"] = 1772198743,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
11117,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
11117,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:25:43",
["timeEnd"] = 1772198743,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов11",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:25:15",
["end_time"] = 21595.594,
["mapId"] = 2552,
["combat_id"] = 80,
["timeStart"] = 1772198743,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 11117,
},
},
},
["combat_counter"] = 136,
["start_time"] = 21567.102,
["TimeData"] = {
},
["training_dummy"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 78,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.002835,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.002835,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 502,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 9215.76923076923,
["end_time"] = 1772197058,
["on_hold"] = false,
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 502,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["tipo"] = 1,
["aID"] = "1615-0B536A51",
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 119805,
["start_time"] = 1772197058,
["delay"] = 0,
["last_dps"] = 38.61538461538461,
},
},
},
{
["tipo"] = 3,
["combatId"] = 78,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.002768,
["total_without_pet"] = 0.002768,
["total"] = 49705,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.002768,
["last_hps"] = 3823.461538461539,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.002768,
["spec"] = 105,
["healing_taken"] = 0.002768,
["end_time"] = 1772197058,
["start_time"] = 1772197058,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[474683] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 15102,
["c_max"] = 0,
["id"] = 474683,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[143924] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 15,
["c_max"] = 0,
["id"] = 143924,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[22842] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 34588,
["c_max"] = 0,
["id"] = 22842,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002768,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 78,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 78,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 78,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 21567.102,
["tempo_start"] = 1772197058,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
502,
49705,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
502,
49705,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:57:39",
["timeEnd"] = 1772197059,
["combatSessionId"] = "Кристаллорот7",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 6.346999999997934,
["playing_solo"] = true,
["CombatEndedAt"] = 20909.123,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:57:25",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 78,
["timeStart"] = 1772197059,
["end_time"] = 19910.948,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 49705,
},
},
["damage"] = {
{
["Бимладен"] = 502,
},
},
},
["combat_counter"] = 134,
["start_time"] = 19897.766,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 77,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005465,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.005465,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 14725,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772196987,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7164,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 253,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7308,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005465,
["start_time"] = 1772196987,
["delay"] = 0,
["last_dps"] = 2103.571428571428,
},
},
},
{
["tipo"] = 3,
["combatId"] = 77,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 77,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 77,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 77,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 19897.766,
["tempo_start"] = 1772196987,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
14725,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
14725,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:56:28",
["timeEnd"] = 1772196988,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов6",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 19840.03,
["playing_solo"] = true,
["CombatEndedAt"] = 19840.03,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:56:20",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 77,
["timeStart"] = 1772196988,
["end_time"] = 19840.03,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 14725,
},
},
},
["combat_counter"] = 133,
["start_time"] = 19832.615,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 76,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.006626,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.006626,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 19112,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772196969,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 17421,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1691,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.006626,
["start_time"] = 1772196969,
["delay"] = 0,
["last_dps"] = 2123.555555555556,
},
},
},
{
["tipo"] = 3,
["combatId"] = 76,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 76,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 76,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 76,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 19832.615,
["tempo_start"] = 1772196969,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
19112,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
19112,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:56:09",
["timeEnd"] = 1772196969,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов5",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 19821.678,
["playing_solo"] = true,
["CombatEndedAt"] = 19821.678,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:56:00",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 76,
["timeStart"] = 1772196969,
["end_time"] = 19821.678,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 19112,
},
},
},
["combat_counter"] = 132,
["start_time"] = 19812.509,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 74,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008519,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.008519,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 15208,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 2422.707692307693,
["end_time"] = 1772195895,
["friendlyfire"] = {
},
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5176] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 941,
["c_max"] = 0,
["id"] = 5176,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 983,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 276,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 13008,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["tipo"] = 1,
["classe"] = "DRUID",
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 157476,
["start_time"] = 1772195895,
["delay"] = 0,
["last_dps"] = 233.9692307692308,
},
},
},
{
["tipo"] = 3,
["combatId"] = 74,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.008883,
["total_without_pet"] = 0.008883,
["total"] = 161276,
["spec"] = 105,
["heal_enemy"] = {
},
["totalabsorb_ps"] = 131.9846153846154,
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 8579,
["last_hps"] = 2481.169230769231,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.008883,
["heal_enemy_amt"] = 0,
["healing_taken"] = 0.008883,
["end_time"] = 1772195895,
["last_event"] = 0,
["aID"] = "1615-0B536A51",
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[81269] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 19956,
["c_max"] = 0,
["id"] = 81269,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[22842] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 29662,
["c_max"] = 0,
["id"] = 22842,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 9475,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[142421] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2172,
["c_max"] = 0,
["id"] = 142421,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[774] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 21271,
["c_max"] = 0,
["id"] = 774,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[455461] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2349,
["c_max"] = 0,
["id"] = 455461,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 5733,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 8579,
["c_max"] = 0,
["id"] = 1235136,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[8936] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 38903,
["c_max"] = 0,
["id"] = 8936,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[33763] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 10401,
["c_max"] = 0,
["id"] = 33763,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[18562] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 6852,
["c_max"] = 0,
["id"] = 18562,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[48438] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 5923,
["c_max"] = 0,
["id"] = 48438,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["targets_overheal"] = {
},
["start_time"] = 1772195895,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.008883,
["delay"] = 0,
["targets_absorbs"] = {
},
},
},
},
{
["tipo"] = 7,
["combatId"] = 74,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 74,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 74,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 19812.509,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 130,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
15208,
161276,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:38:16",
["timeEnd"] = 1772195896,
["combatSessionId"] = "Поточный скакун3",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 18748.071,
["CombatEndedAt"] = 18748.071,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 161276,
},
},
["damage"] = {
{
["Бимладен"] = 15208,
},
},
},
["end_time"] = 18748.071,
["mapId"] = 2552,
["combat_id"] = 74,
["timeStart"] = 1772195896,
["playing_solo"] = true,
["spells_cast_timeline"] = {
},
["is_challenge"] = false,
["frags"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["totals_grupo"] = {
15208,
161276,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["data_inicio"] = "16:37:10",
["start_time"] = 18682.536,
["TimeData"] = {
},
["tempo_start"] = 1772195895,
},
{
{
["tipo"] = 2,
["combatId"] = 73,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005825,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.005825,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 15531,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772195638,
["friendlyfire"] = {
},
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 15531,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "DRUID",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005825,
["start_time"] = 1772195638,
["delay"] = 0,
["last_dps"] = 1194.692307692308,
},
},
},
{
["tipo"] = 3,
["combatId"] = 73,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.0081,
["total_without_pet"] = 0.0081,
["total"] = 43872,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.0081,
["last_hps"] = 3374.769230769231,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.0081,
["spec"] = 105,
["healing_taken"] = 0.0081,
["end_time"] = 1772195638,
["start_time"] = 1772195638,
["targets_overheal"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 5753,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[18562] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 15749,
["c_max"] = 0,
["id"] = 18562,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[774] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 22370,
["c_max"] = 0,
["id"] = 774,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.0081,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 73,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 73,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 73,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 18682.536,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 129,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
15531,
43872,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:33:58",
["timeEnd"] = 1772195638,
["combatSessionId"] = "Тренировочный манекен для рассекающих ударов1",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 18490.875,
["CombatEndedAt"] = 18490.875,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 43872,
},
},
["damage"] = {
{
["Бимладен"] = 15531,
},
},
},
["end_time"] = 18490.875,
["mapId"] = 2552,
["combat_id"] = 73,
["timeStart"] = 1772195638,
["playing_solo"] = true,
["spells_cast_timeline"] = {
},
["is_challenge"] = false,
["frags"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["totals_grupo"] = {
15531,
43872,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["data_inicio"] = "16:23:19",
["start_time"] = 17851.242,
["TimeData"] = {
},
["tempo_start"] = 1772195638,
},
{
{
["tipo"] = 2,
["combatId"] = 71,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.006322,
["pets"] = {
},
["role"] = "HEALER",
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.006322,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 674246,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["mrating"] = 3925,
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["classe"] = "DRUID",
["damage_taken_ps"] = 1485.02752293578,
["end_time"] = 1772131714,
["damage_from"] = {
},
["friendlyfire"] = {
},
["boss_fight_component"] = true,
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 58697,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 12390,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 14054,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[274838] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 266821,
["c_max"] = 0,
["id"] = 274838,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 116418,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 51497,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 88557,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 42616,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 23196,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["last_dps"] = 6185.743119266055,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 161868,
["start_time"] = 1772131714,
["delay"] = 0,
["nome"] = "Бимладен",
},
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.003321,
["pets"] = {
},
["role"] = "DAMAGER",
["aID"] = "",
["total_without_pet"] = 0.003321,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 662497,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Vehicle-0-3103-2648-40306-209059-0000208D4C",
["mrating"] = 0,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 1016.926605504587,
["end_time"] = 1772131714,
["boss_fight_component"] = true,
["classe"] = "MAGE",
["nome"] = "Мереди Крепкая Охота",
["spells"] = {
["_ActorTable"] = {
[413884] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 120382,
["c_max"] = 0,
["id"] = 413884,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[413872] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 124684,
["c_max"] = 0,
["id"] = 413872,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420219] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 49296,
["c_max"] = 0,
["id"] = 420219,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[413886] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 148380,
["c_max"] = 0,
["id"] = 413886,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 59431,
["c_max"] = 0,
["id"] = 420221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420183] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 144546,
["c_max"] = 0,
["id"] = 420183,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420212] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 15778,
["c_max"] = 0,
["id"] = 420212,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["tipo"] = 1,
["last_dps"] = 6077.954128440367,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 110845,
["start_time"] = 1772131714,
["delay"] = 0,
["friendlyfire"] = {
},
},
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.00405,
["pets"] = {
},
["role"] = "DAMAGER",
["aID"] = "",
["total_without_pet"] = 0.00405,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 618815,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Vehicle-0-3103-2648-40306-214390-0000208D4C",
["mrating"] = 0,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 1472.357798165138,
["end_time"] = 1772131714,
["boss_fight_component"] = true,
["classe"] = "SHAMAN",
["nome"] = "Шуджа Люторез",
["spells"] = {
["_ActorTable"] = {
[429663] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 66545,
["c_max"] = 0,
["id"] = 429663,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429697] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2337,
["c_max"] = 0,
["id"] = 429697,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429674] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 45772,
["c_max"] = 0,
["id"] = 429674,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429627] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 98086,
["c_max"] = 0,
["id"] = 429627,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429654] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 19699,
["c_max"] = 0,
["id"] = 429654,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429659] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 69264,
["c_max"] = 0,
["id"] = 429659,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429619] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 86442,
["c_max"] = 0,
["id"] = 429619,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[429652] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 230670,
["c_max"] = 0,
["id"] = 429652,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["tipo"] = 1,
["last_dps"] = 5677.201834862385,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 160487,
["start_time"] = 1772131714,
["delay"] = 0,
["friendlyfire"] = {
},
},
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.001197,
["pets"] = {
},
["role"] = "DAMAGER",
["aID"] = "",
["total_without_pet"] = 0.001197,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 548753,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Vehicle-0-3103-2648-40306-209065-0000208D4C",
["mrating"] = 0,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 1125.54128440367,
["end_time"] = 1772131714,
["boss_fight_component"] = true,
["classe"] = "HUNTER",
["nome"] = "Остин Хаксворт",
["spells"] = {
["_ActorTable"] = {
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 19882,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[433998] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 11718,
["c_max"] = 0,
["id"] = 433998,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[427406] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 45974,
["c_max"] = 0,
["id"] = 427406,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420469] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 39911,
["c_max"] = 0,
["id"] = 420469,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[414259] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 60237,
["c_max"] = 0,
["id"] = 414259,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[464618] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 165588,
["c_max"] = 0,
["id"] = 464618,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420483] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 80264,
["c_max"] = 0,
["id"] = 420483,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["tipo"] = 1,
["last_dps"] = 5034.431192660551,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 122684,
["start_time"] = 1772131714,
["delay"] = 0,
["friendlyfire"] = {
},
},
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.00492,
["pets"] = {
},
["role"] = "TANK",
["aID"] = "",
["total_without_pet"] = 0.00492,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 514964,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Vehicle-0-3103-2648-40306-209057-0000208D4C",
["mrating"] = 0,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["damage_taken_ps"] = 5379.449541284404,
["end_time"] = 1772131714,
["boss_fight_component"] = true,
["classe"] = "PALADIN",
["nome"] = "Капитан Гэррик",
["spells"] = {
["_ActorTable"] = {
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 129119,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[413992] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 72924,
["c_max"] = 0,
["id"] = 413992,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420091] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 71750,
["c_max"] = 0,
["id"] = 420091,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420330] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 48494,
["c_max"] = 0,
["id"] = 420330,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420426] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 16620,
["c_max"] = 0,
["id"] = 420426,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420379] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 105295,
["c_max"] = 0,
["id"] = 420379,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[420094] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 70762,
["c_max"] = 0,
["id"] = 420094,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["tipo"] = 1,
["last_dps"] = 4724.440366972477,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 586360,
["start_time"] = 1772131714,
["delay"] = 0,
["friendlyfire"] = {
},
},
},
},
{
["tipo"] = 3,
["combatId"] = 71,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.00206,
["total_without_pet"] = 0.00206,
["total"] = 615591,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["totalabsorb_ps"] = 1100.688073394495,
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 119975,
["last_hps"] = 5647.623853211009,
["specIcon"] = 136041,
["targets"] = {
},
["last_event"] = 0,
["totalover_without_pet"] = 0.00206,
["healing_taken"] = 0.00206,
["start_time"] = 1772131714,
["end_time"] = 1772131714,
["heal_enemy_amt"] = 0,
["classe"] = "DRUID",
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[81269] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 67134,
["c_max"] = 0,
["id"] = 81269,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[142421] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 6759,
["c_max"] = 0,
["id"] = 142421,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 74468,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[48438] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 53822,
["c_max"] = 0,
["id"] = 48438,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 23538,
["c_max"] = 0,
["id"] = 1235136,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[774] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 160666,
["c_max"] = 0,
["id"] = 774,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[143924] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2352,
["c_max"] = 0,
["id"] = 143924,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 30186,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[145109] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 8559,
["c_max"] = 0,
["id"] = 145109,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[8936] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 39534,
["c_max"] = 0,
["id"] = 8936,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[33763] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 32245,
["c_max"] = 0,
["id"] = 33763,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[18562] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 18066,
["c_max"] = 0,
["id"] = 18562,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[1217091] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 98262,
["c_max"] = 0,
["id"] = 1217091,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["targets_overheal"] = {
},
["boss_fight_component"] = true,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00206,
["delay"] = 0,
["spec"] = 105,
},
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 0.003248,
["total_without_pet"] = 0.003248,
["total"] = 89536,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["totalabsorb_ps"] = 210.1100917431193,
["on_hold"] = false,
["serial"] = "Vehicle-0-3103-2648-40306-214390-0000208D4C",
["totalabsorb"] = 22902,
["last_hps"] = 821.4311926605504,
["targets"] = {
},
["totalover_without_pet"] = 0.003248,
["last_event"] = 0,
["healing_taken"] = 0.003248,
["end_time"] = 1772131714,
["start_time"] = 1772131714,
["targets_overheal"] = {
},
["boss_fight_component"] = true,
["spells"] = {
["_ActorTable"] = {
[426218] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 66634,
["c_max"] = 0,
["id"] = 426218,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[431605] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 22902,
["c_max"] = 0,
["id"] = 431605,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "SHAMAN",
["heal_enemy_amt"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.003248,
["delay"] = 0,
["nome"] = "Шуджа Люторез",
},
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 0.00663,
["total_without_pet"] = 0.00663,
["total"] = 83787,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["totalabsorb_ps"] = 768.6880733944954,
["on_hold"] = false,
["serial"] = "Vehicle-0-3103-2648-40306-209057-0000208D4C",
["totalabsorb"] = 83787,
["last_hps"] = 768.6880733944954,
["targets"] = {
},
["totalover_without_pet"] = 0.00663,
["last_event"] = 0,
["healing_taken"] = 0.00663,
["end_time"] = 1772131714,
["start_time"] = 1772131714,
["targets_overheal"] = {
},
["boss_fight_component"] = true,
["spells"] = {
["_ActorTable"] = {
[453043] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 81283,
["c_max"] = 0,
["id"] = 453043,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[431605] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2504,
["c_max"] = 0,
["id"] = 431605,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "PALADIN",
["heal_enemy_amt"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00663,
["delay"] = 0,
["nome"] = "Капитан Гэррик",
},
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 0.002138,
["total_without_pet"] = 0.002138,
["total"] = 36259,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["totalabsorb_ps"] = 108.2477064220184,
["on_hold"] = false,
["serial"] = "Vehicle-0-3103-2648-40306-209065-0000208D4C",
["totalabsorb"] = 11799,
["last_hps"] = 332.651376146789,
["targets"] = {
},
["totalover_without_pet"] = 0.002138,
["last_event"] = 0,
["healing_taken"] = 0.002138,
["end_time"] = 1772131714,
["start_time"] = 1772131714,
["targets_overheal"] = {
},
["boss_fight_component"] = true,
["spells"] = {
["_ActorTable"] = {
[284306] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 24460,
["c_max"] = 0,
["id"] = 284306,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[431605] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 11799,
["c_max"] = 0,
["id"] = 431605,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "HUNTER",
["heal_enemy_amt"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002138,
["delay"] = 0,
["nome"] = "Остин Хаксворт",
},
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 0.001599,
["total_without_pet"] = 0.001599,
["total"] = 35272,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["totalabsorb_ps"] = 323.5963302752294,
["on_hold"] = false,
["serial"] = "Vehicle-0-3103-2648-40306-209059-0000208D4C",
["totalabsorb"] = 35272,
["last_hps"] = 323.5963302752294,
["targets"] = {
},
["totalover_without_pet"] = 0.001599,
["last_event"] = 0,
["healing_taken"] = 0.001599,
["end_time"] = 1772131714,
["start_time"] = 1772131714,
["targets_overheal"] = {
},
["boss_fight_component"] = true,
["spells"] = {
["_ActorTable"] = {
[295238] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 31206,
["c_max"] = 0,
["id"] = 295238,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[431605] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 4066,
["c_max"] = 0,
["id"] = 431605,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "MAGE",
["heal_enemy_amt"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.001599,
["delay"] = 0,
["nome"] = "Мереди Крепкая Охота",
},
},
},
{
["tipo"] = 7,
["combatId"] = 71,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 71,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["interrupt_cast_overlap"] = 0,
["dispell"] = 4.00661,
["pets"] = {
},
["classe"] = "PALADIN",
["interrupt_spells"] = {
["_ActorTable"] = {
[430109] = {
["total"] = 4,
["id"] = 430109,
["interrompeu_oque"] = {
},
["targets"] = {
},
["counter"] = 1,
},
},
["tipo"] = 9,
},
["dispell_targets"] = {
},
["interrompeu_oque"] = {
},
["interrupt_targets"] = {
},
["serial"] = "Vehicle-0-3103-2648-40306-209057-0000208D4C",
["dispell_oque"] = {
},
["dispell_spells"] = {
["_ActorTable"] = {
},
["tipo"] = 9,
},
["interrupt"] = 4.00643,
["nome"] = "Капитан Гэррик",
["aID"] = "",
["tipo"] = 4,
["boss_fight_component"] = true,
["grupo"] = true,
["last_event"] = 0,
},
{
["flag_original"] = 1298,
["interrupt_cast_overlap"] = 0,
["dispell"] = 1.006831,
["pets"] = {
},
["classe"] = "SHAMAN",
["interrupt_spells"] = {
["_ActorTable"] = {
[430109] = {
["total"] = 1,
["id"] = 430109,
["interrompeu_oque"] = {
},
["targets"] = {
},
["counter"] = 1,
},
},
["tipo"] = 9,
},
["dispell_targets"] = {
},
["interrompeu_oque"] = {
},
["interrupt_targets"] = {
},
["serial"] = "Vehicle-0-3103-2648-40306-214390-0000208D4C",
["dispell_oque"] = {
},
["dispell_spells"] = {
["_ActorTable"] = {
},
["tipo"] = 9,
},
["interrupt"] = 1.008095,
["nome"] = "Шуджа Люторез",
["aID"] = "",
["tipo"] = 4,
["boss_fight_component"] = true,
["grupo"] = true,
["last_event"] = 0,
},
{
["flag_original"] = 1298,
["interrupt_cast_overlap"] = 0,
["dispell"] = 1.003915,
["pets"] = {
},
["classe"] = "MAGE",
["interrupt_spells"] = {
["_ActorTable"] = {
[430109] = {
["total"] = 1,
["id"] = 430109,
["interrompeu_oque"] = {
},
["targets"] = {
},
["counter"] = 1,
},
},
["tipo"] = 9,
},
["dispell_targets"] = {
},
["interrompeu_oque"] = {
},
["interrupt_targets"] = {
},
["serial"] = "Vehicle-0-3103-2648-40306-209059-0000208D4C",
["dispell_oque"] = {
},
["dispell_spells"] = {
["_ActorTable"] = {
},
["tipo"] = 9,
},
["interrupt"] = 1.003136,
["nome"] = "Мереди Крепкая Охота",
["aID"] = "",
["tipo"] = 4,
["boss_fight_component"] = true,
["grupo"] = true,
["last_event"] = 0,
},
},
},
{
["tipo"] = 2,
["combatId"] = 71,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 17851.242,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 126,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZbmx0MjZMmFzMzYZGAAAAAgBAwAsN2w0MDAAmlZ2aWmZxGYgZmFQzAgZGAAA",
},
["totals"] = {
3019275,
860445,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 3,
["interrupt"] = 3,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "party",
["zoneName"] = "Гнездовье",
["data_fim"] = "22:48:35",
["timeEnd"] = 1772131715,
["combatSessionId"] = "(!) Кириосс32",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Кириосс",
["trinketProcs"] = {
},
["playing_solo"] = true,
["TotalElapsedCombatTime"] = 5.847000000008848,
["raid_roster"] = {
},
["CombatEndedAt"] = 81461.63100000001,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Мереди Крепкая Охота"] = 35272,
["Капитан Гэррик"] = 83787,
["Остин Хаксворт"] = 36259,
["Шуджа Люторез"] = 89536,
["Бимладен"] = 615591,
},
},
["damage"] = {
{
["Мереди Крепкая Охота"] = 662497,
["Капитан Гэррик"] = 514964,
["Остин Хаксворт"] = 548753,
["Бимладен"] = 674246,
["Шуджа Люторез"] = 618815,
},
},
},
["end_time"] = 79935.356,
["mapId"] = 2648,
["combat_id"] = 71,
["timeStart"] = 1772131715,
["resincked"] = true,
["spells_cast_timeline"] = {
},
["is_challenge"] = false,
["frags"] = {
},
["is_boss"] = {
["diff_string"] = "Соратник",
["index"] = 1,
["zone"] = "Гнездовье",
["encounter"] = "Кириосс",
["mapid"] = 2648,
["name"] = "Кириосс",
["ej_instance_id"] = 0,
["id"] = 2816,
["unixtime"] = 1772131715,
["diff"] = 205,
},
["cleu_events"] = {
["n"] = 1,
},
["totals_grupo"] = {
3019275,
860445,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 3,
["interrupt"] = 3,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["data_inicio"] = "22:46:45",
["start_time"] = 79825.392,
["TimeData"] = {
},
["tempo_start"] = 1772131714,
},
{
{
["tipo"] = 2,
["combatId"] = 63,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.00537,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.00537,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 70970,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772120600,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 12779,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 20603,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2986,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1964,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5980,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 26658,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.00537,
["start_time"] = 1772120600,
["delay"] = 0,
["last_dps"] = 7097,
},
},
},
{
["tipo"] = 3,
["combatId"] = 63,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.002273,
["total_without_pet"] = 0.002273,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.002273,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.002273,
["spec"] = 105,
["healing_taken"] = 0.002273,
["end_time"] = 1772120600,
["start_time"] = 1772120600,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002273,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
},
},
{
["tipo"] = 7,
["combatId"] = 63,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 63,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 63,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 78809.289,
["tempo_start"] = 1772120600,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZzMmmZMjxsYmZGLzAAAAAAAAwAsN2w0MDAAmlZ2aWmZxGjZgZmFQzAgZGAAA",
},
["totals"] = {
70970,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
70970,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "19:43:21",
["timeEnd"] = 1772120601,
["combatSessionId"] = "Тренировочный манекен18",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "19:43:00",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 63,
["timeStart"] = 1772120601,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 70970,
},
},
},
["combat_counter"] = 118,
["start_time"] = 68800.446,
["TimeData"] = {
},
["end_time"] = 68821.217,
},
{
{
["tipo"] = 2,
["combatId"] = 61,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.001544,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.001544,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 112503,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772120590,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 17962,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 26565,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6074,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3946,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 12930,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 15272,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 29754,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.001544,
["start_time"] = 1772120590,
["delay"] = 0,
["last_dps"] = 4891.434782608696,
},
},
},
{
["tipo"] = 3,
["combatId"] = 61,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 61,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 61,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 61,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772120590,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZzMmmZMjxsYmZGLzAAAAAAAAwAsN2w0MDAAmlZ2aWmZxGjZgZmFQzAgZGAAA",
},
["totals"] = {
112503,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
112503,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "19:43:11",
["timeEnd"] = 1772120591,
["combatSessionId"] = "Тренировочный манекен17",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "19:23:00",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 61,
["timeStart"] = 1772120591,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 112503,
},
},
},
["combat_counter"] = 116,
["start_time"] = 67598.789,
["TimeData"] = {
},
["end_time"] = 68810.92,
},
{
{
["tipo"] = 2,
["combatId"] = 58,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.001173,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.001173,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 10721,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772119395,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 10721,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.001173,
["start_time"] = 1772119395,
["delay"] = 0,
["last_dps"] = 1786.833333333333,
},
},
},
{
["tipo"] = 3,
["combatId"] = 58,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 58,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 58,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 58,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 68800.335,
["tempo_start"] = 1772119395,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZzMmmZMjxsYmZGLzAAAAAAAAwAsN2w0MDAAmlZ2aWmZxGjZgZmFQzAgZGAAA",
},
["totals"] = {
10721,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
10721,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "19:23:15",
["timeEnd"] = 1772119395,
["combatSessionId"] = "Тренировочный манекен16",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "19:22:16",
["end_time"] = 67614.295,
["mapId"] = 2552,
["combat_id"] = 58,
["timeStart"] = 1772119395,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 10721,
},
},
},
["combat_counter"] = 113,
["start_time"] = 67554.639,
["TimeData"] = {
},
["training_dummy"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 56,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005893,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.005893,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 8268,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772119342,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 8268,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005893,
["start_time"] = 1772119342,
["delay"] = 0,
["last_dps"] = 1653.6,
},
},
},
{
["tipo"] = 3,
["combatId"] = 56,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 56,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 56,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 56,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772119342,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPmZmZZMjZm5BsMmHghFsYbGAAAAAAAAAAsMoZzMmmZMjxsYmZGLzAAAAAAAAwAsN2w0MDAAmlZ2aWmZxGjZgZmFQzAgZGAAA",
},
["totals"] = {
8268,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
8268,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "19:22:22",
["timeEnd"] = 1772119342,
["combatSessionId"] = "Тренировочный манекен15",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "19:22:00",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 56,
["timeStart"] = 1772119342,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 8268,
},
},
},
["combat_counter"] = 111,
["start_time"] = 67539.061,
["TimeData"] = {
},
["end_time"] = 67560.907,
},
{
{
["tipo"] = 2,
["combatId"] = 52,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005849,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.005849,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 52702,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772117397,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 10978,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[106785] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3846,
["c_max"] = 0,
["id"] = 106785,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 11072,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1724,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7033,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7423,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 10626,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005849,
["start_time"] = 1772117397,
["delay"] = 0,
["last_dps"] = 4054,
},
},
},
{
["tipo"] = 3,
["combatId"] = 52,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["heal_enemy_amt"] = 0,
["totalover"] = 0.001945,
["total_without_pet"] = 0.001945,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.001945,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.001945,
["spec"] = 105,
["healing_taken"] = 0.001945,
["end_time"] = 1772117397,
["start_time"] = 1772117397,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "DRUID",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.001945,
["delay"] = 0,
["aID"] = "1615-0B536A51",
},
},
},
{
["tipo"] = 7,
["combatId"] = 52,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 52,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 52,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 67539.061,
["tempo_start"] = 1772117397,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
52702,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
52702,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:49:58",
["timeEnd"] = 1772117398,
["combatSessionId"] = "Тренировочный манекен13",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:48:43",
["end_time"] = 65617.349,
["mapId"] = 2552,
["combat_id"] = 52,
["timeStart"] = 1772117398,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 52702,
},
},
},
["combat_counter"] = 107,
["start_time"] = 65542.575,
["TimeData"] = {
},
["training_dummy"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 50,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008495,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008495,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 78052,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772117336,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 11328,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 11484,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2789,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2492,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6468,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 16614,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 26877,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008495,
["start_time"] = 1772117336,
["delay"] = 0,
["last_dps"] = 6504.333333333333,
},
},
},
{
["tipo"] = 3,
["combatId"] = 50,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 50,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 50,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 50,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772117336,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
78052,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
78052,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:48:57",
["timeEnd"] = 1772117337,
["combatSessionId"] = "Тренировочный манекен12",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:43:39",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 50,
["timeStart"] = 1772117337,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 78052,
},
},
},
["combat_counter"] = 105,
["start_time"] = 65238.478,
["TimeData"] = {
},
["end_time"] = 65555.751,
},
{
{
["tipo"] = 2,
["combatId"] = 48,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.00586,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.00586,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 40511,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["friendlyfire"] = {
},
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5089,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7408,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2793,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1698,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 13546,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2333,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7644,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "DRUID",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.00586,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 3682.818181818182,
},
},
},
{
["tipo"] = 3,
["combatId"] = 48,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 48,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 48,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 48,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 65238.587,
["tempo_start"] = 1772116908,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
40511,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
40511,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:41:49",
["timeEnd"] = 1772116909,
["combatSessionId"] = "Тренировочный манекен11",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 65128.158,
["playing_solo"] = true,
["CombatEndedAt"] = 65128.158,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:41:38",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 48,
["timeStart"] = 1772116909,
["end_time"] = 65128.158,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 40511,
},
},
},
["combat_counter"] = 103,
["start_time"] = 65116.937,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 45,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.003497,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.003497,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 13549,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772112363,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 13549,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.003497,
["start_time"] = 1772112363,
["delay"] = 0,
["last_dps"] = 2258.166666666667,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.001884,
["pets"] = {
},
["classe"] = "EVOKER",
["total_without_pet"] = 0.001884,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 35319284,
["spec"] = 1468,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 58468660,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "Spiro",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 49278962,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.001613,
["pets"] = {
},
["classe"] = "DEATHKNIGHT",
["total_without_pet"] = 0.001613,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 50601173,
["spec"] = 251,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 16784901,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "Drek'Thar",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 28695493,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.006323,
["pets"] = {
},
["classe"] = "WARRIOR",
["total_without_pet"] = 0.006323,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 26551684,
["spec"] = 73,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 35193688,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "Footman Malakai",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 54388505,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.002524,
["pets"] = {
},
["classe"] = "HUNTER",
["total_without_pet"] = 0.002524,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 49788134,
["spec"] = 253,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 32714010,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "Fritz Fizzlesprocket",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 39844995,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.007538,
["pets"] = {
},
["classe"] = "MAGE",
["total_without_pet"] = 0.007538,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 21661290,
["spec"] = 62,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 59349481,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "Nozdormu",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 28861032,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.006906,
["pets"] = {
},
["classe"] = "WARLOCK",
["total_without_pet"] = 0.006906,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 59294278,
["spec"] = 267,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 59378163,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "M'uru",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 43665887,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
{
["flag_original"] = "0x514",
["totalabsorbed"] = 0.006152,
["pets"] = {
},
["classe"] = "WARRIOR",
["total_without_pet"] = 0.006152,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 57836942,
["spec"] = 72,
["testBar"] = true,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "0x0000-0000-0000",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 56672261,
["raid_targets"] = {
},
["end_time"] = 1772116908,
["aID"] = "",
["nome"] = "General Rajaxx",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 37694986,
["start_time"] = 1772116908,
["delay"] = 0,
["last_dps"] = 0,
},
},
},
{
["tipo"] = 3,
["combatId"] = 45,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["classe"] = "DRUID",
["totalover"] = 0.00471,
["total_without_pet"] = 0.00471,
["total"] = 12858,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.00471,
["last_hps"] = 2143,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.00471,
["spec"] = 105,
["healing_taken"] = 0.00471,
["end_time"] = 1772112363,
["start_time"] = 1772112363,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[48438] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 6608,
["c_max"] = 0,
["id"] = 48438,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 6250,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00471,
["delay"] = 0,
["heal_enemy_amt"] = 0,
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 40170290,
["total_without_pet"] = 0.006888,
["total"] = 11368752,
["spec"] = 1468,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 39925623,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.006888,
["healing_taken"] = 35803771,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Drakaris",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "EVOKER",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.006888,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 57914292,
["total_without_pet"] = 0.004361,
["total"] = 43244545,
["spec"] = 73,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 13394590,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.004361,
["healing_taken"] = 17021467,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Stormwind Guard",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "WARRIOR",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.004361,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 55395166,
["total_without_pet"] = 0.004707,
["total"] = 33716550,
["spec"] = 102,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 37854686,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.004707,
["healing_taken"] = 49032183,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Malfurion Stormrage",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "DRUID",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.004707,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 22121333,
["total_without_pet"] = 0.008304,
["total"] = 42039483,
["spec"] = 256,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 28675765,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.008304,
["healing_taken"] = 48932946,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Velen",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "PRIEST",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.008304,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 44334398,
["total_without_pet"] = 0.002125,
["total"] = 35771445,
["spec"] = 257,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 38780463,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.002125,
["healing_taken"] = 37687088,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Tyrande Whisperwind",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "PRIEST",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002125,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 12375259,
["total_without_pet"] = 0.004675,
["total"] = 24445131,
["spec"] = 63,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 10814140,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.004675,
["healing_taken"] = 38532229,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Roland",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "MAGE",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.004675,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 15233119,
["total_without_pet"] = 0.004009,
["total"] = 18276091,
["spec"] = 66,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 58936753,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.004009,
["healing_taken"] = 12696374,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Bolvar Fordragon",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "PALADIN",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.004009,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 13876108,
["total_without_pet"] = 0.00312,
["total"] = 55726774,
["spec"] = 1467,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 50116302,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.00312,
["healing_taken"] = 37596239,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Spiro",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "EVOKER",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00312,
["delay"] = 0,
["targets_absorbs"] = {
},
},
{
["flag_original"] = 276,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "",
["totalover"] = 30527785,
["total_without_pet"] = 0.005843,
["total"] = 42931909,
["spec"] = 264,
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "0x0000-0000-0000",
["totalabsorb"] = 49664365,
["last_hps"] = 0,
["targets"] = {
},
["heal_enemy_amt"] = 0,
["totalover_without_pet"] = 0.005843,
["healing_taken"] = 57372457,
["start_time"] = 1772116908,
["end_time"] = 1772116908,
["testBar"] = true,
["targets_overheal"] = {
},
["nome"] = "Your Math Teacher",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "SHAMAN",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.005843,
["delay"] = 0,
["targets_absorbs"] = {
},
},
},
},
{
["tipo"] = 7,
["combatId"] = 45,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 45,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 45,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 65116.937,
["tempo_start"] = 1772112363,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
423973327,
346959667,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
423973327,
346959667,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:26:04",
["timeEnd"] = 1772112364,
["combatSessionId"] = "Тренировочный манекен9",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Illidan Stormrage",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:09:23",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 45,
["timeStart"] = 1772112364,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 12858,
},
},
["damage"] = {
{
["Бимладен"] = 13549,
},
},
},
["combat_counter"] = 100,
["start_time"] = 64106.384,
["TimeData"] = {
},
["end_time"] = 64466.384,
},
{
{
["tipo"] = 2,
["combatId"] = 43,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.007163,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.007163,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 6397,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772110950,
["friendlyfire"] = {
},
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6397,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "DRUID",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.007163,
["start_time"] = 1772110950,
["delay"] = 0,
["last_dps"] = 1066.166666666667,
},
},
},
{
["tipo"] = 3,
["combatId"] = 43,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["heal_enemy_amt"] = 0,
["totalover"] = 0.001354,
["total_without_pet"] = 0.001354,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.001354,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.001354,
["spec"] = 105,
["healing_taken"] = 0.001354,
["end_time"] = 1772110950,
["start_time"] = 1772110950,
["targets_overheal"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "DRUID",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.001354,
["delay"] = 0,
["aID"] = "1615-0B536A51",
},
},
},
{
["tipo"] = 7,
["combatId"] = 43,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 43,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 43,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 59582.375,
["tempo_start"] = 1772110950,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
6397,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
6397,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:02:30",
["timeEnd"] = 1772110950,
["combatSessionId"] = "Тренировочный манекен8",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 59169.206,
["playing_solo"] = true,
["CombatEndedAt"] = 59169.206,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:02:24",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 43,
["timeStart"] = 1772110950,
["end_time"] = 59169.206,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 6397,
},
},
},
["combat_counter"] = 98,
["start_time"] = 59162.889,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 42,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.00685,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.00685,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 6657,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772110870,
["friendlyfire"] = {
},
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6463,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 194,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "DRUID",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.00685,
["start_time"] = 1772110870,
["delay"] = 0,
["last_dps"] = 951,
},
},
},
{
["tipo"] = 3,
["combatId"] = 42,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["heal_enemy_amt"] = 0,
["totalover"] = 0.002511,
["total_without_pet"] = 0.002511,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.002511,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.002511,
["spec"] = 105,
["healing_taken"] = 0.002511,
["end_time"] = 1772110870,
["start_time"] = 1772110870,
["targets_overheal"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "DRUID",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002511,
["delay"] = 0,
["aID"] = "1615-0B536A51",
},
},
},
{
["tipo"] = 7,
["combatId"] = 42,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 42,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 42,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 59162.889,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
6657,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
6657,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:01:10",
["timeEnd"] = 1772110870,
["combatSessionId"] = "Тренировочный манекен7",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 59089.32700000001,
["playing_solo"] = true,
["CombatEndedAt"] = 59089.32700000001,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "17:01:03",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 42,
["timeStart"] = 1772110870,
["end_time"] = 59089.32700000001,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 6657,
},
},
},
["combat_counter"] = 97,
["start_time"] = 59082.043,
["TimeData"] = {
},
["tempo_start"] = 1772110870,
},
{
{
["tipo"] = 2,
["combatId"] = 41,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.002095,
["pets"] = {
},
["aID"] = "1615-0B536A51",
["total_without_pet"] = 0.002095,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 56479,
["spec"] = 105,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["specIcon"] = 136041,
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772110805,
["friendlyfire"] = {
},
["damage_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3743,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 10181,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2789,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 32095,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 7671,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "DRUID",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.002095,
["start_time"] = 1772110805,
["delay"] = 0,
["last_dps"] = 2972.578947368421,
},
},
},
{
["tipo"] = 3,
["combatId"] = 41,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["healing_from"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["heal_enemy_amt"] = 0,
["totalover"] = 0.004546,
["total_without_pet"] = 0.004546,
["total"] = 3788,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.004546,
["last_hps"] = 199.3684210526316,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.004546,
["spec"] = 105,
["healing_taken"] = 0.004546,
["end_time"] = 1772110805,
["start_time"] = 1772110805,
["targets_overheal"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 3788,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["classe"] = "DRUID",
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.004546,
["delay"] = 0,
["aID"] = "1615-0B536A51",
},
},
},
{
["tipo"] = 7,
["combatId"] = 41,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 41,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 41,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 59082.043,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 96,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
56479,
3788,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "17:00:05",
["timeEnd"] = 1772110805,
["combatSessionId"] = "Тренировочный манекен6",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 59023.843,
["CombatEndedAt"] = 59023.843,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 3788,
},
},
["damage"] = {
{
["Бимладен"] = 56479,
},
},
},
["end_time"] = 59023.843,
["mapId"] = 2552,
["combat_id"] = 41,
["timeStart"] = 1772110805,
["playing_solo"] = true,
["spells_cast_timeline"] = {
},
["is_challenge"] = false,
["frags"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["totals_grupo"] = {
56479,
3788,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["data_inicio"] = "16:59:45",
["start_time"] = 59004.374,
["TimeData"] = {
},
["tempo_start"] = 1772110805,
},
{
{
["tipo"] = 2,
["combatId"] = 40,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008125,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008125,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 91467,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772109352,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 11114,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1822] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 18101,
["c_max"] = 0,
["id"] = 1822,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5521,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5291,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 37983,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 13457,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008125,
["start_time"] = 1772109352,
["delay"] = 0,
["last_dps"] = 4355.571428571428,
},
},
},
{
["tipo"] = 3,
["combatId"] = 40,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.003576,
["total_without_pet"] = 0.003576,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.003576,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.003576,
["spec"] = 105,
["healing_taken"] = 0.003576,
["end_time"] = 1772109352,
["start_time"] = 1772109352,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.003576,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 40,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 40,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 40,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 59004.471,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
91467,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
91467,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:35:53",
["timeEnd"] = 1772109353,
["combatSessionId"] = "Тренировочный манекен5",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 57572.535,
["playing_solo"] = true,
["CombatEndedAt"] = 57572.535,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:35:32",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 40,
["timeStart"] = 1772109353,
["end_time"] = 57572.535,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 91467,
},
},
},
["combat_counter"] = 95,
["start_time"] = 57551.26,
["TimeData"] = {
},
["tempo_start"] = 1772109352,
},
{
{
["tipo"] = 2,
["combatId"] = 39,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.001844,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.001844,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 40864,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772109292,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 35342,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5522,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.001844,
["start_time"] = 1772109292,
["delay"] = 0,
["last_dps"] = 659.0967741935484,
},
},
},
{
["tipo"] = 3,
["combatId"] = 39,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.00516,
["total_without_pet"] = 0.00516,
["total"] = 70877,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.00516,
["last_hps"] = 1143.177419354839,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.00516,
["spec"] = 105,
["healing_taken"] = 0.00516,
["end_time"] = 1772109292,
["start_time"] = 1772109292,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[1264659] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 6097,
["c_max"] = 0,
["id"] = 1264659,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[48438] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 26391,
["c_max"] = 0,
["id"] = 48438,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 25395,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[142421] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2844,
["c_max"] = 0,
["id"] = 142421,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[81269] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 4780,
["c_max"] = 0,
["id"] = 81269,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[434141] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 5370,
["c_max"] = 0,
["id"] = 434141,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00516,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 39,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 39,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 39,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["CombatStartedAt"] = 57551.26,
["tempo_start"] = 1772109292,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["combat_counter"] = 94,
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
40864,
70877,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:34:53",
["timeEnd"] = 1772109293,
["combatSessionId"] = "Тренировочный манекен4",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 57512.258,
["CombatEndedAt"] = 57512.258,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 70877,
},
},
["damage"] = {
{
["Бимладен"] = 40864,
},
},
},
["end_time"] = 57512.258,
["mapId"] = 2552,
["combat_id"] = 39,
["timeStart"] = 1772109293,
["playing_solo"] = true,
["spells_cast_timeline"] = {
},
["is_challenge"] = false,
["frags"] = {
},
["raid_roster"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["totals_grupo"] = {
40864,
70877,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["data_inicio"] = "16:33:50",
["start_time"] = 57449.601,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 38,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.003675,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.003675,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 478,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772108552,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 478,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.003675,
["start_time"] = 1772108552,
["delay"] = 0,
["last_dps"] = 28.11764705882353,
},
},
},
{
["tipo"] = 3,
["combatId"] = 38,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.002712,
["total_without_pet"] = 0.002712,
["total"] = 28562,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.002712,
["last_hps"] = 1680.117647058823,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.002712,
["spec"] = 105,
["healing_taken"] = 0.002712,
["end_time"] = 1772108552,
["start_time"] = 1772108552,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 12121,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[48438] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 14247,
["c_max"] = 0,
["id"] = 48438,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2194,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.002712,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 38,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 38,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 38,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 57449.601,
["tempo_start"] = 1772108552,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
478,
28562,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
478,
28562,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:22:32",
["timeEnd"] = 1772108552,
["combatSessionId"] = "Тренировочный манекен3",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 56771.522,
["playing_solo"] = true,
["CombatEndedAt"] = 56771.522,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:22:21",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 38,
["timeStart"] = 1772108552,
["end_time"] = 56771.522,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 28562,
},
},
["damage"] = {
{
["Бимладен"] = 478,
},
},
},
["combat_counter"] = 93,
["start_time"] = 56759.838,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 37,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.005495,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.005495,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 229132,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772108552,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[1079] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 32682,
["c_max"] = 0,
["id"] = 1079,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 23339,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2761,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[274838] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 154540,
["c_max"] = 0,
["id"] = 274838,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1506,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[439531] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 10341,
["c_max"] = 0,
["id"] = 439531,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3963,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.005495,
["start_time"] = 1772108552,
["delay"] = 0,
["last_dps"] = 7637.733333333334,
},
},
},
{
["tipo"] = 3,
["combatId"] = 37,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.005212,
["total_without_pet"] = 0.005212,
["total"] = 24472,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.005212,
["last_hps"] = 815.7333333333333,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.005212,
["spec"] = 105,
["healing_taken"] = 0.005212,
["end_time"] = 1772108552,
["start_time"] = 1772108552,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[8936] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 12936,
["c_max"] = 0,
["id"] = 8936,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 9157,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 2379,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.005212,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 37,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 37,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 37,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772108552,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
229132,
24472,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
229132,
24472,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:22:32",
["timeEnd"] = 1772108552,
["combatSessionId"] = "Тренировочный манекен2",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:19:21",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 37,
["timeStart"] = 1772108552,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 24472,
},
},
["damage"] = {
{
["Бимладен"] = 229132,
},
},
},
["combat_counter"] = 92,
["start_time"] = 56579.727,
["TimeData"] = {
},
["end_time"] = 56771.522,
},
{
{
["tipo"] = 2,
["combatId"] = 33,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.004909,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.004909,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 6150,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772108301,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[197626] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6150,
["c_max"] = 0,
["id"] = 197626,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.004909,
["start_time"] = 1772108301,
["delay"] = 0,
["last_dps"] = 1025,
},
},
},
{
["tipo"] = 3,
["combatId"] = 33,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 33,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 33,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 33,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 56579.727,
["tempo_start"] = 1772108301,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
6150,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
6150,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "16:18:21",
["timeEnd"] = 1772108301,
["combatSessionId"] = "Тренировочный манекен1",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 6.055000000000291,
["playing_solo"] = true,
["CombatEndedAt"] = 56528.759,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "16:18:15",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 33,
["timeStart"] = 1772108301,
["end_time"] = 56520.41600000001,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 6150,
},
},
},
["combat_counter"] = 88,
["start_time"] = 56514.457,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 32,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.002918,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.002918,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 40689,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772028833,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5176] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 28492,
["c_max"] = 0,
["id"] = 5176,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[197626] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 12197,
["c_max"] = 0,
["id"] = 197626,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.002918,
["start_time"] = 1772028833,
["delay"] = 0,
["last_dps"] = 2543.0625,
},
},
},
{
["tipo"] = 3,
["combatId"] = 32,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.003373,
["total_without_pet"] = 0.003373,
["total"] = 58362,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.003373,
["last_hps"] = 3647.625,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.003373,
["spec"] = 105,
["healing_taken"] = 0.003373,
["end_time"] = 1772028833,
["start_time"] = 1772028833,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[422090] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 11063,
["c_max"] = 0,
["id"] = 422090,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[48438] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 43476,
["c_max"] = 0,
["id"] = 48438,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[439530] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 3823,
["c_max"] = 0,
["id"] = 439530,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.003373,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 32,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 32,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 32,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 56513.616,
["overall_added"] = true,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
40689,
58362,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
40689,
58362,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:13:53",
["timeEnd"] = 1772028833,
["combatSessionId"] = "Тренировочный манекен покорителя подземелий24",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 71687.783,
["playing_solo"] = true,
["CombatEndedAt"] = 71687.783,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:13:38",
["end_time"] = 71687.783,
["mapId"] = 2552,
["combat_id"] = 32,
["timeStart"] = 1772028833,
["tempo_start"] = 1772028833,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 58362,
},
},
["damage"] = {
{
["Бимладен"] = 40689,
},
},
},
["combat_counter"] = 87,
["start_time"] = 71672.231,
["TimeData"] = {
},
["training_dummy"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 31,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.004153,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.004153,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 9229,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772028679,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[197626] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 6468,
["c_max"] = 0,
["id"] = 197626,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[1235136] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 2761,
["c_max"] = 0,
["id"] = 1235136,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.004153,
["start_time"] = 1772028679,
["delay"] = 0,
["last_dps"] = 1538.166666666667,
},
},
},
{
["tipo"] = 3,
["combatId"] = 31,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 31,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 31,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 31,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 71671.314,
["tempo_start"] = 1772028679,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
9229,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
9229,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:11:20",
["timeEnd"] = 1772028680,
["combatSessionId"] = "Тренировочный манекен покорителя подземелий23",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 71534.243,
["playing_solo"] = true,
["CombatEndedAt"] = 71534.243,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:11:14",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 31,
["timeStart"] = 1772028680,
["end_time"] = 71534.243,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 9229,
},
},
},
["combat_counter"] = 86,
["start_time"] = 71528.597,
["TimeData"] = {
},
["overall_added"] = true,
},
{
{
["tipo"] = 2,
["combatId"] = 30,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.006583,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.006583,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 32395,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772028679,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[5176] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 22704,
["c_max"] = 0,
["id"] = 5176,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 9691,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.006583,
["start_time"] = 1772028679,
["delay"] = 0,
["last_dps"] = 2024.6875,
},
},
},
{
["tipo"] = 3,
["combatId"] = 30,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 30,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 30,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 30,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772028679,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
32395,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
32395,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:11:20",
["timeEnd"] = 1772028680,
["combatSessionId"] = "Тренировочный манекен покорителя подземелий22",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:10:47",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 30,
["timeStart"] = 1772028680,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Бимладен"] = 32395,
},
},
},
["combat_counter"] = 85,
["start_time"] = 71501.045,
["TimeData"] = {
},
["end_time"] = 71534.243,
},
{
{
["tipo"] = 2,
["combatId"] = 28,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008091,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008091,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 7619,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772028663,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[77758] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3986,
["c_max"] = 0,
["id"] = 77758,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 3633,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008091,
["start_time"] = 1772028663,
["delay"] = 0,
["last_dps"] = 362.8095238095238,
},
},
},
{
["tipo"] = 3,
["combatId"] = 28,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.00628,
["total_without_pet"] = 0.00628,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.00628,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.00628,
["spec"] = 105,
["healing_taken"] = 0.00628,
["end_time"] = 1772028663,
["start_time"] = 1772028663,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.00628,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 28,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 28,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 28,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1772028663,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
7619,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
7619,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:11:03",
["timeEnd"] = 1772028663,
["combatSessionId"] = "Тренировочный манекен покорителя подземелий21",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:07:24",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 28,
["timeStart"] = 1772028663,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
},
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 7619,
},
},
},
["combat_counter"] = 83,
["start_time"] = 71298.738,
["TimeData"] = {
},
["end_time"] = 71517.777,
},
{
{
["tipo"] = 2,
["combatId"] = 26,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008166,
["pets"] = {
},
["classe"] = "DRUID",
["total_without_pet"] = 0.008166,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 22281,
["spec"] = 105,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1615-0B536A51",
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772028330,
["on_hold"] = false,
["specIcon"] = 136041,
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
[22568] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 4162,
["c_max"] = 0,
["id"] = 22568,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 1993,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[5221] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 16126,
["c_max"] = 0,
["id"] = 5221,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["aID"] = "1615-0B536A51",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.008166,
["start_time"] = 1772028330,
["delay"] = 0,
["last_dps"] = 2025.545454545455,
},
},
},
{
["tipo"] = 3,
["combatId"] = 26,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["targets_overheal"] = {
},
["pets"] = {
},
["iniciar_hps"] = false,
["aID"] = "1615-0B536A51",
["totalover"] = 0.004833,
["total_without_pet"] = 0.004833,
["total"] = 0,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["serial"] = "Player-1615-0B536A51",
["totalabsorb"] = 0.004833,
["last_hps"] = 0,
["specIcon"] = 136041,
["targets"] = {
},
["totalover_without_pet"] = 0.004833,
["spec"] = 105,
["healing_taken"] = 0.004833,
["end_time"] = 1772028330,
["start_time"] = 1772028330,
["healing_from"] = {
},
["nome"] = "Бимладен",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 3,
},
["grupo"] = true,
["heal_enemy_amt"] = 0,
["last_event"] = 0,
["custom"] = 0,
["tipo"] = 2,
["totaldenied"] = 0.004833,
["delay"] = 0,
["classe"] = "DRUID",
},
},
},
{
["tipo"] = 7,
["combatId"] = 26,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 26,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["combatId"] = 26,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["CombatStartedAt"] = 71298.738,
["tempo_start"] = 1772028330,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
["Бимладен"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNMMmFmFbzAAAAAAAAAAglBNbmx0MjZMmFzMzYZGYAAAAAAAwAAQAAAzyMbNLzsYDmBmZWANDAAAA",
},
["totals"] = {
22281,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
22281,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "18:05:30",
["timeEnd"] = 1772028330,
["combatSessionId"] = "Тренировочный манекен покорителя подземелий20",
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Неизвестно",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 71184.222,
["playing_solo"] = true,
["CombatEndedAt"] = 71184.222,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "18:05:18",
["training_dummy"] = true,
["mapId"] = 2552,
["combat_id"] = 26,
["timeStart"] = 1772028330,
["end_time"] = 71184.222,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["player_last_events"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
["Бимладен"] = 0,
},
},
["damage"] = {
{
["Бимладен"] = 22281,
},
},
},
["combat_counter"] = 81,
["start_time"] = 71172.762,
["TimeData"] = {
},
["overall_added"] = true,
},
},
},
["ocd_tracker"] = {
["enabled"] = false,
["current_cooldowns"] = {
},
["lines_per_column"] = 12,
["group_frames"] = true,
["width"] = 120,
["frames"] = {
["defensive-raid"] = {
},
["main"] = {
},
["ofensive"] = {
},
["defensive-target"] = {
},
["utility"] = {
},
["defensive-personal"] = {
},
},
["show_options"] = false,
["ignored_cooldowns"] = {
},
["cooldowns"] = {
},
["height"] = 18,
["own_frame"] = {
["defensive-raid"] = false,
["ofensive"] = false,
["defensive-target"] = false,
["utility"] = false,
["defensive-personal"] = false,
},
["framme_locked"] = false,
["show_conditions"] = {
["only_inside_instance"] = true,
["only_in_group"] = true,
},
["show_title"] = true,
["filters"] = {
["itemutil"] = false,
["itempower"] = false,
["defensive-target"] = false,
["itemheal"] = false,
["defensive-personal"] = false,
["defensive-raid"] = false,
["ofensive"] = true,
["crowdcontrol"] = false,
["utility"] = false,
},
},
["combat_counter"] = 166,
["damage_meter_sessions"] = {
{
["endUnixTime"] = 1772213875,
["added"] = false,
["endDate"] = "21:37:55",
["startUnixTime"] = 1772213856,
["sessionName"] = "Сумеречный проклятый клинок",
["startDate"] = "21:37:36",
["startTime"] = 36708.625,
["sessionId"] = 1,
["detailsId"] = "Сумеречный проклятый клинок1",
},
},
["force_font_outline"] = "",
["tabela_instancias"] = {
},
["arena_data_compressed"] = {
},
["arena_data_index_selected"] = 1,
["local_instances_config"] = {
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 2,
["pos"] = {
["normal"] = {
["y"] = -294.0885620117188,
["x"] = 905.923095703125,
["w"] = 285.384033203125,
["h"] = 53.76956176757813,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
[2] = 3,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -387.1405334472656,
["x"] = 905.9241943359375,
["w"] = 285.384033203125,
["h"] = 121.8720474243164,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
[4] = 2,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -529.0125694274902,
["x"] = 905.9241943359375,
["w"] = 285.384033203125,
["h"] = 121.8720474243164,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = false,
["is_open"] = true,
["snap"] = {
[4] = 3,
},
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -353.4861602783203,
["x"] = 533.33349609375,
["w"] = 309.9999084472656,
["h"] = 158.0001068115234,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
},
["coach"] = {
["enabled"] = false,
["welcome_panel_pos"] = {
},
["last_coach_name"] = false,
},
["nick_tag_cache"] = {
["Sociopatiya-Silvermoon"] = {
"La'cringe",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
2,
},
["Гейшайна-Гордунни"] = {
"Xal'atath Feet",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
23,
},
["Бимладен"] = {
"3% Buffer",
false,
false,
false,
false,
false,
2,
},
["last_version"] = 16,
["Вуйдана-ВечнаяПесня"] = {
"Billy Bat",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
20,
},
["nextreset"] = 1773048894,
["Каррхарадон"] = {
"BloodGod",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
11,
},
["Стрресс"] = {
"+5%Stamina",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
15,
},
["Авраамий-Гордунни"] = {
"Авраам",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
4,
},
["Воннта"] = {
"Воннта",
"",
{
0,
1,
0,
1,
},
"",
{
0,
1,
0,
1,
},
{
1,
1,
1,
},
5,
},
},
["last_instance_id"] = 2662,
["data_harvest_for_charsts"] = {
["players"] = {
{
["name"] = "Damage of Each Individual Player",
["playerOnly"] = true,
["playerKey"] = "total",
["combatObjectContainer"] = 1,
},
},
["totals"] = {
{
["combatObjectSubTableKey"] = 1,
["name"] = "Damage of All Player Combined",
["combatObjectSubTableName"] = "totals",
},
},
},
["announce_interrupts"] = {
["enabled"] = false,
["whisper"] = "",
["channel"] = "SAY",
["custom"] = "",
["next"] = "",
},
["last_instance_time"] = 1772213803,
["active_profile"] = "All classes",
["last_realversion"] = 170,
["last_day"] = "27",
["data_harvested_for_charts"] = {
},
["damage_meter_session_info"] = {
},
["benchmark_db"] = {
["frame"] = {
},
},
["combat_log"] = {
["inverse_deathlog_overalldata"] = false,
["track_hunter_frenzy"] = false,
["merge_gemstones_1007"] = false,
["merge_critical_heals"] = false,
["inverse_deathlog_raid"] = false,
["calc_evoker_damage"] = true,
["evoker_show_realtimedps"] = false,
["inverse_deathlog_mplus"] = false,
},
["player_stats"] = {
},
["plugin_database"] = {
["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
["enabled"] = true,
["author"] = "Terciob",
["max_compares"] = 4,
["compare_type"] = 1,
},
["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
["use_square_mode"] = false,
["is_first_run"] = false,
["arrow_color"] = {
1,
1,
1,
0.7989778518676758,
},
["scale"] = 1,
["main_frame_size"] = {
285,
125.0000076293945,
},
["minimap"] = {
["minimapPos"] = 160,
["radius"] = 160,
["hide"] = true,
},
["row_height"] = 20,
["arrow_anchor_x"] = 0,
["font_color"] = {
1,
1,
1,
1,
},
["row_texture"] = "Melli",
["square_grow_direction"] = "right",
["point"] = "RIGHT",
["main_frame_strata"] = "LOW",
["square_amount"] = 5,
["enabled"] = true,
["arrow_size"] = 10,
["per_second"] = {
["enabled"] = false,
["point"] = "CENTER",
["scale"] = 1,
["font_shadow"] = true,
["y"] = 0,
["x"] = 0,
["size"] = 32,
["update_speed"] = 0.05,
["attribute_type"] = 1,
},
["row_spacement"] = 20,
["main_frame_color"] = {
0,
0,
0,
0,
},
["author"] = "Terciob",
["arrow_texture"] = "Interface\\OPTIONSFRAME\\VoiceChat-Play",
["y"] = -184.7283325195313,
["font_size"] = 11,
["x"] = -1.64404296875,
["font_face"] = "ITCAvantGardeGothicDemi",
["square_size"] = 32,
["use_spark"] = false,
["row_color"] = {
0,
0,
0,
0.4000000059604645,
},
["main_frame_locked"] = true,
["arrow_anchor_y"] = 0,
},
},
["mythic_dungeon_currentsaved"] = {
["players"] = {
},
["dungeon_name"] = "\"Сияющий Рассвет\"",
["started"] = false,
["segment_id"] = 2,
["ej_id"] = 0,
["started_at"] = 1772213859.7,
["run_id"] = 2,
["level"] = 2,
["dungeon_zone_id"] = 2662,
["previous_boss_killed_at"] = 1772213922,
},
["character_data"] = {
["logons"] = 147,
},
["SoloTablesSaved"] = {
["Mode"] = 1,
},
["cached_talents"] = {
["Player-1615-0B536A51"] = "CkGA8cL7tpvige+kkmGM9zUPWPMmZZMjZmxsNmhxsgFbzAAAAAAAAAAglBNbmx0MjZMmFmZGLzADAAAAAAAGAACAAYWmZrZZmFbMmBmZWANDAAAA",
["Player-3674-0B8D262C"] = "CwPASnrjTdwaLTX9NnLQoJJXfAYmhZMGDzyYmZaWMzYmZMAAAAAAAAMzgZAwywMz2MzYGzYgBGW0AAbTshBMDAjZmhBzMAzA",
["Player-1615-0B625BC9"] = "CEcBPJc41CfcseY0baneJ1IHrhxMbzMzMWmhZmlZYmZmZDAAAAAAAgZGMzgxUjZegZAAAAwMzYYmZZMzYYshhZZGLLzywMLDzwMTjYDMAAA",
},
["mythic_plus_log"] = {
"27/02/26 21:38:42|Activity Time: 0",
"27/02/26 21:38:42|GetChallengeCompletionInfo() and World State Timers not Found, Activity Time: 0",
"27/02/26 21:38:42|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"27/02/26 21:38:42|MythicDungeonFinished() | merge_boss_trash = true",
"27/02/26 21:38:42|MergeTrashCleanup | no segments to merge.",
"27/02/26 21:38:42|BossDefeated | key level: | 0 | Неизвестно | \"Сияющий Рассвет\"",
"27/02/26 21:38:42|ZONE_CHANGED_NEW_AREA | player has left the dungeon and Details! finished the dungeon because of that.",
"27/02/26 21:37:30|OnChallengeModeStart()",
"27/02/26 21:37:30|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | reverse_death_log = false | autoclose_time = 90 | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 2 | zone: \"Сияющий Рассвет\" | zoneId: 2662",
"27/02/26 21:37:30|CHALLENGE_MODE_START timer ended, starting the dungeon.",
"27/02/26 21:37:20|Event: CHALLENGE_MODE_START, starting 10 seconds timer | Level: 2",
"27/02/26 19:49:21|OnChallengeModeStart()",
"27/02/26 19:49:21|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | reverse_death_log = false | autoclose_time = 90 | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 20 | zone: \"Сияющий Рассвет\" | zoneId: 2662",
"27/02/26 19:49:21|CHALLENGE_MODE_START timer ended, starting the dungeon.",
"27/02/26 19:49:11|Event: CHALLENGE_MODE_START, starting 10 seconds timer | Level: 20",
},
["on_death_menu"] = false,
["last_version"] = "12.0.1 14655",
["combat_id"] = 102,
["savedStyles"] = {
},
["announce_firsthit"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["cached_roles"] = {
},
["announce_deaths"] = {
["enabled"] = false,
["last_hits"] = 1,
["only_first"] = 5,
["where"] = 1,
},
["tabela_overall"] = {
{
["tipo"] = 2,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["totalabsorbed"] = 0.008979000000000001,
["pets"] = {
},
["role"] = "TANK",
["classe"] = "DRUID",
["total_without_pet"] = 0.008979000000000001,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 87374.00421,
["spec"] = 104,
["serial"] = "Player-1615-0B536A51",
["aID"] = "1615-0B536A51",
["on_hold"] = false,
["total_extra"] = 0,
["fight_component"] = true,
["mrating"] = 3925,
["avoidable_damage"] = {
},
["damage_from"] = {
},
["targets"] = {
},
["grupo"] = true,
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1772213875,
["nome"] = "Бимладен",
["spells"] = {
["tipo"] = 2,
["_ActorTable"] = {
[33917] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 4022,
["c_max"] = 0,
["id"] = 33917,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[213771] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 26106,
["c_max"] = 0,
["id"] = 213771,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[6603] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 5049,
["c_max"] = 0,
["id"] = 6603,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[8921] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 52197,
["c_max"] = 0,
["id"] = 8921,
["r_dmg"] = 0,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
},
["friendlyfire"] = {
},
["last_dps"] = 0,
["custom"] = 0,
["tipo"] = 1,
["damage_taken"] = 459664.00421,
["start_time"] = 1772213872,
["delay"] = 0,
["last_event"] = 0,
},
},
},
{
["tipo"] = 3,
["_ActorTable"] = {
{
["flag_original"] = 1298,
["pets"] = {
},
["iniciar_hps"] = false,
["heal_enemy_amt"] = 0,
["totalover"] = 0.011914,
["total_without_pet"] = 0.011914,
["total"] = 175100.004774,
["targets_absorbs"] = {
},
["heal_enemy"] = {
},
["on_hold"] = false,
["aID"] = "1615-0B536A51",
["totalabsorb"] = 55291.004774,
["last_hps"] = 0,
["spec"] = 104,
["fight_component"] = true,
["targets"] = {
},
["serial"] = "Player-1615-0B536A51",
["totalover_without_pet"] = 0.011914,
["grupo"] = true,
["healing_taken"] = 0.011914,
["healing_from"] = {
},
["classe"] = "DRUID",
["end_time"] = 1772213875,
["targets_overheal"] = {
},
["start_time"] = 1772213872,
["nome"] = "Бимладен",
["spells"] = {
["tipo"] = 3,
["_ActorTable"] = {
[1217091] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 55291,
["c_max"] = 0,
["id"] = 1217091,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[143924] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 1676,
["c_max"] = 0,
["id"] = 143924,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
[22842] = {
["c_amt"] = 0,
["totalabsorb"] = 0,
["targets_overheal"] = {
},
["n_max"] = 0,
["targets"] = {
},
["n_total"] = 0,
["n_min"] = 0,
["counter"] = 1,
["overheal"] = 0,
["total"] = 118133,
["c_max"] = 0,
["id"] = 22842,
["targets_absorbs"] = {
},
["c_min"] = 0,
["c_total"] = 0,
["totaldenied"] = 0,
["n_amt"] = 0,
["absorbed"] = 0,
},
},
},
["custom"] = 0,
["last_event"] = 0,
["totaldenied"] = 0.011914,
["delay"] = 0,
["tipo"] = 2,
},
},
},
{
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["tempo_start"] = 1772213850,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
},
["totals"] = {
87374,
175100,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
87374,
175100,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["amountCasts"] = {
},
["instance_type"] = "party",
["zoneName"] = "\"Сияющий Рассвет\"",
["data_fim"] = "21:37:55",
["cleu_timeline"] = {
},
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = "21:37:36",
["end_time"] = 36726.94,
["mapId"] = 2662,
["boss_hp"] = 1,
["combat_counter"] = 164,
["is_challenge"] = true,
["frags"] = {
},
["player_last_events"] = {
},
["overall_enemy_name"] = "Неизвестно",
["segments_added"] = {
{
["elapsed"] = 18.31500000000233,
["type"] = 11,
["name"] = "Trash #1",
["clock"] = "21:37:36",
},
},
["PhaseData"] = {
{
1,
1,
},
["heal_section"] = {
},
["heal"] = {
},
["damage_section"] = {
},
["damage"] = {
},
},
["start_time"] = 36708.625,
["TimeData"] = {
},
["spells_cast_timeline"] = {
},
},
["announce_prepots"] = {
["enabled"] = false,
["channel"] = "SELF",
["reverse"] = false,
},
["arena_data_headers"] = {
},
["ignore_nicktag"] = false,
["announce_cooldowns"] = {
["enabled"] = false,
["ignored_cooldowns"] = {
},
["custom"] = "",
["channel"] = "RAID",
},
["rank_window"] = {
["last_difficulty"] = 15,
["last_raid"] = "",
},
["announce_damagerecord"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["cached_specs"] = {
["Player-1615-0B536A51"] = 105,
},
}
