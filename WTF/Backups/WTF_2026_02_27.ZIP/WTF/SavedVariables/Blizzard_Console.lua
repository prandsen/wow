
Blizzard_Console_SavedVars = {
["version"] = 3,
["messageHistory"] = {
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 3m 40s",
0,
},
{
"Level: 59d 20h 17m 54s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000008000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c000",
0,
},
{
"Proficiency in item class 2 set to 0x000000c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/26/2026 (Thu) 19:52",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 10h 56m 4s",
0,
},
{
"Level: 19d 8h 27m 27s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 10h 57m 25s",
0,
},
{
"Level: 19d 8h 28m 48s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 10h 57m 38s",
0,
},
{
"Level: 19d 8h 29m 1s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 10h 59m 0s",
0,
},
{
"Level: 19d 8h 30m 23s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 11h 4m 17s",
0,
},
{
"Level: 19d 8h 35m 40s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:13",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 26m 37s",
0,
},
{
"Level: 59d 20h 40m 51s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 28m 24s",
0,
},
{
"Level: 59d 20h 42m 38s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 29m 17s",
0,
},
{
"Level: 59d 20h 43m 31s",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:18",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:18",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:19",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:19",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:20",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:20",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:22",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:22",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 35m 16s",
0,
},
{
"Level: 59d 20h 49m 30s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 36m 21s",
0,
},
{
"Level: 59d 20h 50m 35s",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:23",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:23",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:25",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:25",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:26",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:26",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:26",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:26",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:27",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:27",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:28",
0,
},
{
"Time set to 2/26/2026 (Thu) 20:28",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 42m 21s",
0,
},
{
"Level: 59d 20h 56m 35s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 52m 2s",
0,
},
{
"Level: 59d 21h 6m 16s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 15h 56m 9s",
0,
},
{
"Level: 59d 21h 10m 23s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 3m 47s",
0,
},
{
"Level: 59d 21h 18m 1s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 7m 48s",
0,
},
{
"Level: 59d 21h 22m 2s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 11m 30s",
0,
},
{
"Level: 59d 21h 25m 44s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 13m 8s",
0,
},
{
"Level: 59d 21h 27m 22s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 18m 11s",
0,
},
{
"Level: 59d 21h 32m 25s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000008000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c000",
0,
},
{
"Proficiency in item class 2 set to 0x000000c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/26/2026 (Thu) 21:06",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 11h 16m 0s",
0,
},
{
"Level: 19d 8h 47m 23s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 11h 37m 6s",
0,
},
{
"Level: 19d 9h 8m 29s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000008000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c000",
0,
},
{
"Proficiency in item class 2 set to 0x000000c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 0:45",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 11h 38m 25s",
0,
},
{
"Level: 19d 9h 9m 48s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 11h 45m 42s",
0,
},
{
"Level: 19d 9h 17m 5s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 11h 57m 40s",
0,
},
{
"Level: 19d 9h 29m 3s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 1:09",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 18m 39s",
0,
},
{
"Level: 59d 21h 32m 53s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 19m 1s",
0,
},
{
"Level: 59d 21h 33m 15s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 20m 7s",
0,
},
{
"Level: 59d 21h 34m 21s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000008000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c000",
0,
},
{
"Proficiency in item class 2 set to 0x000000c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c400",
0,
},
{
"Proficiency in item class 2 set to 0x000010c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 2 set to 0x000018c410",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 1:11",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 64d 12h 1m 29s",
0,
},
{
"Level: 19d 9h 32m 52s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 1:14",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 21m 6s",
0,
},
{
"Level: 59d 21h 35m 20s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 28m 12s",
0,
},
{
"Level: 59d 21h 42m 26s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 28m 42s",
0,
},
{
"Level: 59d 21h 42m 56s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 29m 17s",
0,
},
{
"Level: 59d 21h 43m 31s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 29m 41s",
0,
},
{
"Level: 59d 21h 43m 55s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 34m 30s",
0,
},
{
"Level: 59d 21h 48m 44s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 35m 37s",
0,
},
{
"Level: 59d 21h 49m 51s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:41",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 16h 43m 50s",
0,
},
{
"Level: 59d 21h 58m 4s",
0,
},
{
"Player-1615-0B536A51 TRAIT_VALIDATION: Config 26544478. Failed to purchase node 94626 entry 117226 rank 0 with fail reason NODE_OP_FAILURE_REASON_MAX_RANK",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:53",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:53",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:57",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:57",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:59",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 17h 0m 43s",
0,
},
{
"Level: 59d 22h 14m 57s",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:59",
0,
},
{
"Time set to 2/27/2026 (Fri) 12:59",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 17h 15m 56s",
0,
},
{
"Level: 59d 22h 30m 10s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 13:32",
0,
},
{
"Time set to 2/27/2026 (Fri) 13:32",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 13:52",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 17h 53m 37s",
0,
},
{
"Level: 59d 23h 7m 51s",
0,
},
{
"Time set to 2/27/2026 (Fri) 13:53",
0,
},
{
"Time set to 2/27/2026 (Fri) 13:53",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:14",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:14",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:15",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:15",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 18h 17m 46s",
0,
},
{
"Level: 59d 23h 32m 0s",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:19",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:19",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:19",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:19",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:22",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:22",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:24",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:24",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:24",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:24",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 18h 29m 10s",
0,
},
{
"Level: 59d 23h 43m 24s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 18h 48m 12s",
0,
},
{
"Level: 60d 0h 2m 26s",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:47",
0,
},
{
"Time set to 2/27/2026 (Fri) 14:47",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 18h 57m 55s",
0,
},
{
"Level: 60d 0h 12m 9s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 19h 9m 50s",
0,
},
{
"Level: 60d 0h 24m 4s",
0,
},
{
"Time set to 2/27/2026 (Fri) 15:18",
0,
},
{
"Time set to 2/27/2026 (Fri) 15:18",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 19h 21m 35s",
0,
},
{
"Level: 60d 0h 35m 49s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 15:21",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 19h 22m 33s",
0,
},
{
"Level: 60d 0h 36m 47s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 15:30",
0,
},
{
"Time set to 2/27/2026 (Fri) 15:30",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 19h 40m 49s",
0,
},
{
"Level: 60d 0h 55m 3s",
0,
},
{
"Weather changed to 0, intensity 0.131520\n",
0,
},
{
"Weather changed to 1, intensity 0.222734\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 19h 44m 8s",
0,
},
{
"Level: 60d 0h 58m 22s",
0,
},
{
"Weather changed to 0, intensity 0.114312\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:01",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:01",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 20h 8m 49s",
0,
},
{
"Level: 60d 1h 23m 3s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:22",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:22",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:24",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:24",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:34",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 20h 36m 13s",
0,
},
{
"Level: 60d 1h 50m 27s",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:42",
0,
},
{
"Time set to 2/27/2026 (Fri) 16:42",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 17:23",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 21h 24m 33s",
0,
},
{
"Level: 60d 2h 38m 47s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 21h 30m 40s",
0,
},
{
"Level: 60d 2h 44m 54s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 22h 8m 58s",
0,
},
{
"Level: 60d 3h 23m 12s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 2/27/2026 (Fri) 18:26",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 379d 22h 26m 22s",
0,
},
{
"Level: 60d 3h 40m 36s",
0,
},
{
"Time set to 2/27/2026 (Fri) 18:27",
0,
},
{
"Time set to 2/27/2026 (Fri) 18:27",
0,
},
{
"Time set to 2/27/2026 (Fri) 18:27",
0,
},
{
"Time set to 2/27/2026 (Fri) 18:27",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2464.67, -2325.49, 1066.06)",
0,
},
{
"[Airlock] Preload initiated for map 2601",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2552 with translation: (0.340088, 0.820068, 1131.33)\n    Location : (2258.73, -2261.5, 548.708)\n    Location in previous map : (2258.39, -2262.32, -582.625)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2552. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2262.78, -2254.05, -586.603)",
0,
},
{
"[Airlock] Preload initiated for map 2552",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
},
["height"] = 300,
["fontHeight"] = 14,
["isShown"] = false,
["commandHistory"] = {
},
}
