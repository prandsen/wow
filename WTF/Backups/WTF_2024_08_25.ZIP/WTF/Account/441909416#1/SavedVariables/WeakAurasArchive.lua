
WeakAurasArchive = {
["RawData"] = {
},
["ReadOnly"] = {
},
["Repository"] = {
["migration"] = {
["timestamp"] = 1724584383,
["version"] = 1,
["data"] = "lUIlj)IsTyRuZiD0rnd1bWp",
},
["history"] = {
["timestamp"] = 1724584383,
["version"] = 1,
["data"] = "lUIlj)IsTyRuZiD0rnd1bWp",
},
},
}
