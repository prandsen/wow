
WeakAurasSaved = {
["dynamicIconCache"] = {
},
["editor_tab_spaces"] = 4,
["displays"] = {
},
["editor_font_size"] = 12,
["lastArchiveClear"] = 1724523963,
["minimap"] = {
["hide"] = false,
},
["lastUpgrade"] = 1724523969,
["dbVersion"] = 75,
["migrationCutoff"] = 730,
["registered"] = {
},
["historyCutoff"] = 730,
["features"] = {
},
["login_squelch_time"] = 10,
}
