
PremadeGroupsFilterSettings = {
["signupOnEnter"] = false,
["classNamesInTooltip"] = true,
["ratingInfo"] = true,
["specIcon"] = false,
["oneClickSignUp"] = true,
["dialogMovable"] = true,
["leaderCrown"] = false,
["missingRoles"] = false,
["version"] = 3,
["classBar"] = false,
["persistSignUpNote"] = true,
["classCircle"] = false,
["skipSignUpDialog"] = false,
["coloredGroupTexts"] = true,
}
