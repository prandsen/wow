
BugGrabberDB = {
["session"] = 20,
["lastSanitation"] = 3,
["errors"] = {
},
}
