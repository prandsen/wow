
RaiderIO_Config = {
["minimapIcon"] = {
["minimapPos"] = 180,
["showInCompartment"] = true,
["hide"] = false,
["lock"] = false,
},
["profilePoint"] = {
["y"] = 0,
["x"] = -16,
["point"] = "TOPLEFT",
},
}
RaiderIO_LastCharacter = "eu-Бимладен-howling-fjord"
RaiderIO_MissingCharacters = {
["eu-Трольгидеон-howling-fjord"] = true,
["eu-Крракен-howling-fjord"] = true,
["eu-Малхоли-howling-fjord"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
