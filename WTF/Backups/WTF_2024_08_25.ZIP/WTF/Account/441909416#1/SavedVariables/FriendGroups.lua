
FriendGroups_SavedVars = {
["hide_high_level"] = false,
["show_search"] = false,
["show_retail"] = false,
["show_realm"] = false,
["ingame_only"] = false,
["show_faction_icons"] = true,
["add_mobile_text"] = false,
["hide_offline"] = false,
["show_mobile_afk"] = false,
["colour_classes"] = true,
["gray_faction"] = false,
["ingame_retail"] = false,
["show_btag"] = false,
["hide_empty_groups"] = false,
["sort_by_status"] = false,
["collapsed"] = {
},
["hide_afk"] = false,
}
