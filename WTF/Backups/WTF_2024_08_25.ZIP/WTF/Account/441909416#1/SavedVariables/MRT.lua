
VMRT = {
["Note"] = {
["BlackNames"] = {
"Note Loader Default",
},
["FontSize"] = 12,
["AutoLoad"] = {
},
["OptionsFormatting"] = true,
["BlackLastUpdateTime"] = {
},
["Profiles"] = {
["Now"] = "default",
["List"] = {
},
},
["BlackLastUpdateName"] = {
},
["PersonalWidth"] = 300.0000610351563,
["OnlyPromoted"] = true,
["Strata"] = "HIGH",
["Height"] = 200,
["Black"] = {
"",
"",
"",
"",
},
["Width"] = 300.0000610351563,
["PersonalHeight"] = 200,
},
["ProfileKeys"] = {
["Вольтчара-СвежевательДуш"] = "default",
["Бимладен-Ревущийфьорд"] = "default",
},
["Encounter"] = {
["list"] = {
["Бимладен"] = {
},
["Вольтчара"] = {
},
},
["names"] = {
},
},
["MarksSimple"] = {
["buffMax"] = 100,
["autoMarkState"] = {
},
["autoMarkNames"] = {
},
["buffMarksState"] = {
},
["markMax"] = 100,
["buffMarks"] = {
},
["names"] = {
},
},
["Marks"] = {
["list"] = {
},
},
["ExCD2"] = {
["upd4525"] = true,
["gnGUIDs"] = {
["Бимладен"] = 105,
["Вольтчара"] = 264,
},
["NoRaid"] = true,
["CDECol"] = {
},
["upd4380"] = true,
["Save"] = {
},
["Profiles"] = {
["Now"] = "default",
["List"] = {
},
},
["userDB"] = {
},
["colSet"] = {
{
["enabled"] = true,
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["enabled"] = true,
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["enabled"] = true,
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
{
["frameGeneral"] = true,
["iconGray"] = true,
["textGeneral"] = true,
["methodsGeneral"] = true,
["blacklistGeneral"] = true,
["fontShadow"] = false,
["iconGeneral"] = true,
["fontOutline"] = true,
["visibilityGeneral"] = true,
["fontGeneral"] = true,
["textureAnimation"] = true,
["textureGeneral"] = true,
},
},
["Priority"] = {
},
["CDE"] = {
},
["OptFav"] = {
},
},
["Attendance"] = {
["data"] = {
},
["alts"] = {
},
},
["Inspect"] = {
["Soulbinds"] = {
},
},
["InspectViewer"] = {
["ColorizeLowIlvl685"] = false,
["ColorizeNoEnch"] = true,
["ColorizeNoGems"] = true,
["ColorizeLowIlvl"] = true,
["ColorizeNoTopEnchGems"] = false,
["ColorizeNoValorUpgrade"] = false,
},
["RaidCheck"] = {
["FlaskExp"] = 1,
["BuffsCheck"] = true,
["ReadyCheckFrame"] = true,
["ReadyCheckFrameTimerFade"] = 4,
["ReadyCheckFrameOnlyRL"] = true,
["WeaponEnch"] = {
},
},
["BattleRes"] = {
["Strata"] = "HIGH",
},
["InviteTool"] = {
["Words"] = "инв inv byd штм 123",
["InvByChat"] = true,
["RaidDiff"] = 16,
["PromoteRank"] = 2,
["Ranks"] = {
true,
},
["LootThreshold"] = 2,
["MasterLooters"] = "",
["LootMethod"] = "group",
["PromoteNames"] = "",
["OnlyGuild"] = true,
["Rank"] = 1,
},
["WhoPulled"] = {
},
["Reminder2"] = {
["HistoryFrameShown"] = true,
["FontSize"] = 50,
["data"] = {
{
},
{
},
{
},
{
},
{
},
[0] = {
},
},
["SyncPlayers"] = {
},
["generalSound4"] = "Interface\\AddOns\\MRT\\media\\Sounds\\Applause.ogg",
["generalSound1"] = "Interface\\AddOns\\MRT\\media\\Sounds\\CatMeow2.ogg",
["generalSound5"] = "Interface\\AddOns\\MRT\\media\\Sounds\\BikeHorn.ogg",
["zoneNames"] = {
},
["HistoryEnabled"] = true,
["options"] = {
},
["v21"] = true,
["Profile"] = 1,
["generalSound2"] = "Interface\\AddOns\\MRT\\media\\Sounds\\KittenMeow.ogg",
["FontOutline"] = true,
["v38"] = true,
["removed"] = {
},
["generalSound3"] = "Interface\\Addons\\MRT\\media\\Sounds\\swordecho.ogg",
["generalSound6"] = "Interface\\Addons\\MRT\\media\\Sounds\\bam.ogg",
},
["Addon"] = {
["Version"] = 4900,
["EJ_CHECK_VER_PTR"] = "56311",
["PreVersion"] = 4900,
["EJ_DATA"] = {
["MapIDToJournalInstance"] = {
},
["EncountersList_dung"] = {
},
["encounterIDtoEJ"] = {
},
["JournalInstance"] = {
-2,
},
["EncountersList_raid"] = {
},
},
["EJ_CHECK_VER"] = 110002,
["Timer"] = 0.1,
},
["Interrupts"] = {
["Profile"] = 1,
["Disabled"] = {
},
["Data"] = {
{
},
{
},
{
},
[0] = {
},
},
},
["BossWatcher"] = {
["optionsDamageGraph"] = true,
["fightsNum"] = 2,
["optionsPositionsDist"] = true,
["optionsHealingGraph"] = true,
["trackingDamageSpells"] = {
},
},
["LootHistory"] = {
["list"] = {
},
["bossNames"] = {
},
["instanceNames"] = {
},
},
["Profile"] = "default",
["LootLink"] = {
},
["RaidGroups"] = {
["KeepPosInGroup"] = true,
["upd4550"] = true,
["profiles"] = {
},
},
["Profiles"] = {
},
["Logging"] = {
},
["MarksBar"] = {
["pulltimer"] = 10,
["pulltimer_right"] = 10,
["Show"] = {
true,
true,
true,
true,
true,
},
["Strata"] = "HIGH",
},
["VisNote"] = {
["data"] = {
},
["sync_data"] = {
},
},
["Timers"] = {
["specTimes"] = {
[62] = 10,
[1467] = 10,
[63] = 10,
[250] = 10,
[251] = 10,
[64] = 10,
[1468] = 10,
[253] = 10,
[65] = 10,
[255] = 10,
[66] = 10,
[257] = 10,
[258] = 10,
[259] = 10,
[260] = 10,
[261] = 25,
[262] = 16,
[263] = 10,
[264] = 10,
[265] = 22,
[266] = 10,
[267] = 10,
[268] = 10,
[269] = 10,
[270] = 10,
[70] = 10,
[102] = 10,
[71] = 10,
[103] = 10,
[72] = 10,
[104] = 10,
[1473] = 10,
[73] = 10,
[581] = 10,
[105] = 10,
[577] = 10,
[256] = 10,
[254] = 10,
[252] = 10,
},
["Type"] = 2,
["Strata"] = "HIGH",
["timeToKillAnalyze"] = 15,
},
}
