
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 300,
["messageHistory"] = {
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.150000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 129.",
0,
},
{
"Time set to 3/21/2026 (Sat) 22:21",
0,
},
{
"Time set to 3/21/2026 (Sat) 22:21",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/21/2026 (Sat) 22:49",
0,
},
{
"Time set to 3/21/2026 (Sat) 22:49",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:17",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 383d 10h 51m 24s",
0,
},
{
"Level: 2d 8h 14m 22s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:34",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:34",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:37",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:37",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:37",
0,
},
{
"Time set to 3/21/2026 (Sat) 23:37",
0,
},
{
"Time set to 3/22/2026 (Sun) 0:19",
0,
},
{
"Time set to 3/22/2026 (Sun) 0:19",
0,
},
{
"Time set to 3/22/2026 (Sun) 0:21",
0,
},
{
"Time set to 3/22/2026 (Sun) 0:21",
0,
},
{
"Time set to 3/22/2026 (Sun) 0:21",
0,
},
{
"Time set to 3/22/2026 (Sun) 0:21",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 10:22",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 383d 12h 18m 13s",
0,
},
{
"Level: 2d 9h 41m 11s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 10:40",
0,
},
{
"Time set to 3/22/2026 (Sun) 10:40",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 10:46",
0,
},
{
"Time set to 3/22/2026 (Sun) 10:46",
0,
},
{
"Time set to 3/22/2026 (Sun) 12:28",
0,
},
{
"Time set to 3/22/2026 (Sun) 12:28",
0,
},
{
"Time set to 3/22/2026 (Sun) 12:28",
0,
},
{
"Time set to 3/22/2026 (Sun) 12:28",
0,
},
{
"Time set to 3/22/2026 (Sun) 12:29",
0,
},
{
"Time set to 3/22/2026 (Sun) 12:29",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 13:39",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 383d 15h 30m 0s",
0,
},
{
"Level: 2d 12h 52m 58s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:02",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 19h 34m 44s",
0,
},
{
"Level: 0d 14h 40m 2s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 19h 37m 39s",
0,
},
{
"Level: 0d 14h 42m 57s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 19h 38m 13s",
0,
},
{
"Level: 0d 14h 43m 31s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:12",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 19h 43m 17s",
0,
},
{
"Level: 0d 14h 48m 35s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 20h 2m 49s",
0,
},
{
"Level: 0d 15h 8m 7s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 20h 6m 23s",
0,
},
{
"Level: 0d 15h 11m 41s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:37",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:37",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:38",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 20h 9m 40s",
0,
},
{
"Level: 0d 15h 14m 58s",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:48",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:48",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:50",
0,
},
{
"Time set to 3/22/2026 (Sun) 14:50",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 20h 21m 45s",
0,
},
{
"Level: 0d 15h 27m 3s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 20h 29m 9s",
0,
},
{
"Level: 0d 15h 34m 27s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 20h 30m 25s",
0,
},
{
"Level: 0d 15h 35m 43s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:02",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:02",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:02",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:02",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:02",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:02",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 2m 27s",
0,
},
{
"Level: 0d 16h 7m 45s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 19m 9s",
0,
},
{
"Level: 0d 16h 24m 27s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 15:50",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 21m 3s",
0,
},
{
"Level: 0d 16h 26m 21s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 21m 27s",
0,
},
{
"Level: 0d 16h 26m 45s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 23m 39s",
0,
},
{
"Level: 0d 16h 28m 57s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 24m 14s",
0,
},
{
"Level: 0d 16h 29m 32s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 31m 52s",
0,
},
{
"Level: 0d 16h 37m 10s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 16:04",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 383d 15h 53m 5s",
0,
},
{
"Level: 2d 13h 16m 3s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 383d 15h 53m 33s",
0,
},
{
"Level: 2d 13h 16m 31s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 383d 15h 55m 49s",
0,
},
{
"Level: 2d 13h 18m 47s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 16:53",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 34m 40s",
0,
},
{
"Level: 0d 16h 39m 58s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 35m 5s",
0,
},
{
"Level: 0d 16h 40m 23s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 122d 21h 35m 26s",
0,
},
{
"Level: 0d 16h 40m 44s",
0,
},
{
"Time set to 3/22/2026 (Sun) 16:55",
0,
},
{
"Time set to 3/22/2026 (Sun) 16:55",
0,
},
{
"Time set to 3/22/2026 (Sun) 16:55",
0,
},
{
"Time set to 3/22/2026 (Sun) 16:55",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.217230\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2952, Current MapID:0, PreviousTransitionID:-1, Position (16.5405, 257.225, 274.159)",
0,
},
{
"[Airlock] Preload initiated for map 2952",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2952, Current MapID:0, PreviousTransitionID:2952, Position (7.6123, 250.405, 270.503)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2952 from previous map 0 with translation: (-4767.33, 4377.68, 242.491)\n    Location : (-23.8521, 235.298, 264.987)\n    Location in previous map : (4743.48, -4142.39, 22.496)",
0,
},
{
"[Airlock] Swapping to preloaded map 2952 but keeping old map 0 RESIDENT.",
0,
},
{
"[Airlock] Freezing AOI updates for old map 0",
0,
},
{
"[Airlock] Finished transition to new map 2952",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:0, Current MapID:2952, PreviousTransitionID:0, Position (4743.48, -4142.39, 22.496)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:0, Current MapID:2952, PreviousTransitionID:0, Position (4776.22, -4286.1, -23.0688)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 0 from previous map 2952 with translation: (4767.33, -4377.68, -242.491)\n    Location : (4784.44, -4122.82, 31.4396)\n    Location in previous map : (17.1118, 254.869, 273.931)",
0,
},
{
"[Airlock] Swapping to preloaded map 0 and unloading map 2952. (Map Table Size 2310 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 0",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2952, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2961, Current MapID:0, PreviousTransitionID:-1, Position (133.16, -671.333, 88.7217)",
0,
},
{
"[Airlock] Preload initiated for map 2961",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2961 from previous map 0 with translation: (-3159.13, 5244.06, -364.128)\n    Location : (98.8354, -672.006, 81.0685)\n    Location in previous map : (3257.97, -5916.06, 445.197)",
0,
},
{
"[Airlock] Swapping to preloaded map 2961 and unloading map 0. (Map Table Size 9 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2961",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:0, Current MapID:2961, PreviousTransitionID:-1, Position (3255.85, -5915.5, 445.246)",
0,
},
{
"[Airlock] Preload initiated for map 0",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:0, Current MapID:2961, PreviousTransitionID:0, Position (3141.72, -5756.22, 409.821)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 0 from previous map 2961 with translation: (3159.13, -5244.06, 364.128)\n    Location : (3277.43, -5916.09, 444.899)\n    Location in previous map : (118.295, -672.029, 80.7707)",
0,
},
{
"[Airlock] Destination 0 had not finished preload at position (3277.43, -5916.09, 444.899), putting up loading screen\n",
0,
},
{
"[Airlock] Swapping to preloaded map 0 and unloading map 2961. (Map Table Size 2310 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 0",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2961, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 17:56",
0,
},
{
"Time set to 3/22/2026 (Sun) 17:56",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2964, Current MapID:2694, PreviousTransitionID:-1, Position (180.595, 646.08, 196.861)",
0,
},
{
"[Airlock] Preload initiated for map 2964",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2964 from previous map 2694 with translation: (136.769, -167.453, -913.978)\n    Location : (152.901, 632.053, 187.292)\n    Location in previous map : (16.1317, 799.506, 1101.27)",
0,
},
{
"[Airlock] Swapping to preloaded map 2964 but keeping old map 2694 RESIDENT.",
0,
},
{
"[Airlock] Freezing AOI updates for old map 2694",
0,
},
{
"[Airlock] Finished transition to new map 2964",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2694, Current MapID:2964, PreviousTransitionID:2694, Position (16.1317, 799.506, 1101.27)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2694, Current MapID:2964, PreviousTransitionID:2694, Position (-372.374, 788.873, 1075.57)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2979, Current MapID:2771, PreviousTransitionID:-1, Position (2373.43, 1011.12, -123.577)",
0,
},
{
"[Airlock] Preload initiated for map 2979, with already loaded cosmetic parent 2771",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2979, Current MapID:2771, PreviousTransitionID:-1, Position (2418.63, 1001.31, -117.027)",
0,
},
{
"[Airlock] Preload initiated for map 2979, with already loaded cosmetic parent 2771",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2771, Current MapID:2771, PreviousTransitionID:-1, Position (2418.63, 1001.31, -117.027)",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2771, Current MapID:2771, PreviousTransitionID:-1, Position (3070.69, 1020.11, -13.4308)",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000000041",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004041",
0,
},
{
"Proficiency in item class 2 set to 0x0000004441",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x0000006441",
0,
},
{
"Proficiency in item class 2 set to 0x0000006451",
0,
},
{
"Proficiency in item class 2 set to 0x00000064d1",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x00000064d1",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 20:39",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 104d 5h 43m 18s",
0,
},
{
"Level: 0d 5h 40m 36s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 104d 5h 44m 48s",
0,
},
{
"Level: 0d 5h 42m 6s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 21:46",
0,
},
{
"Time set to 3/22/2026 (Sun) 21:46",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:07",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:07",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:07",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:07",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.750000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 132.",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:29",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:29",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:52",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:52",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:52",
0,
},
{
"Time set to 3/22/2026 (Sun) 22:52",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 23:17",
0,
},
{
"Time set to 3/22/2026 (Sun) 23:17",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000000041",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004041",
0,
},
{
"Proficiency in item class 2 set to 0x0000004441",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x0000006441",
0,
},
{
"Proficiency in item class 2 set to 0x0000006451",
0,
},
{
"Proficiency in item class 2 set to 0x00000064d1",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x00000064d1",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/22/2026 (Sun) 23:28",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 104d 8h 32m 53s",
0,
},
{
"Level: 0d 8h 30m 11s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
