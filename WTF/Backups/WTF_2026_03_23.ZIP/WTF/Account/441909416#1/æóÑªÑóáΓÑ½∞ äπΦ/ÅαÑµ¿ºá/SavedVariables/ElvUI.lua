
ElvCharacterDB = {
["ConvertKeybindings"] = true,
["ChatEditHistory"] = {
"/с cdm",
"/cdm",
"/rl",
"/bcm",
},
["ChatHistoryLog"] = {
{
"cdm",
"Прециза-СвежевательДуш",
"",
"",
"Прециза-СвежевательДуш",
"",
0,
0,
"",
1,
9843,
"Player-1604-0AA7EEE7",
0,
false,
false,
false,
false,
[52] = "|cffaad372Прециза|r",
[51] = 1772286975,
[50] = "CHAT_MSG_SAY",
},
},
}
