
NewSettingsSeen = {
["NAMEPLATES_LABEL"] = true,
["COMBAT_WARNINGS_LABEL"] = true,
["chatBubblesRaid"] = true,
}
