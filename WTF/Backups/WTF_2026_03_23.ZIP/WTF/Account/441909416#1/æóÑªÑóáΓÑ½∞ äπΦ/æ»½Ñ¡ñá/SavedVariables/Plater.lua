
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[252] = 30,
[251] = 30,
[250] = 30,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA089D9"] = true,
},
["resources_on_target"] = false,
["minimap"] = {
},
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[252] = 30,
[251] = 30,
[250] = 30,
},
}
