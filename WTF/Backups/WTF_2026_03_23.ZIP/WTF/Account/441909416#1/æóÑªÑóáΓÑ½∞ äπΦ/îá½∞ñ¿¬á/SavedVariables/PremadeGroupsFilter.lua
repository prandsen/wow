
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["difficulty"] = {
},
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c121f4"] = {
["enabled"] = true,
},
["version"] = 8,
["c9f8"] = {
["enabled"] = true,
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c3f6"] = {
["enabled"] = true,
},
["c3f5"] = {
["enabled"] = true,
},
}
