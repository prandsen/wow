
NaowhQOL = {
}
