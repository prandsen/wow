
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[103] = 40,
[104] = 30,
[102] = 45,
[105] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1615-0B536A51"] = true,
},
["spellRangeCheckRangeEnemy"] = {
[103] = 40,
[105] = 40,
[102] = 45,
[104] = 30,
[1444] = 40,
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["minimap"] = {
},
}
