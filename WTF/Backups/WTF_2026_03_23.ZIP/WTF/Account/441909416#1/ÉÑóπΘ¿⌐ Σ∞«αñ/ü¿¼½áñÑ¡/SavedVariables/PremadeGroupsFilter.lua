
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dps"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "4",
["act"] = true,
},
["expression"] = "",
["difficulty"] = {
["act"] = true,
["val"] = 3,
},
["dungeon4"] = false,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
["dungeon3"] = false,
["dungeon2"] = true,
["dungeon1"] = true,
},
},
["c121f4"] = {
["enabled"] = true,
},
["version"] = 8,
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["val"] = 2,
["act"] = true,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c3f6"] = {
["enabled"] = true,
},
["c9f8"] = {
["enabled"] = true,
},
}
