
EncounterDetailsDB = {
["chartData"] = {
},
["encounter_spells"] = {
[193473] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Щупальце Бездны",
},
[445257] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[445513] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный инквизитор Вайтмейн",
},
[443723] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[428887] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Камнекрушитель",
},
[425052] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[446794] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[427356] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Благочестивый жрец",
},
[435793] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[456773] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Валиона",
},
[460354] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[427357] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Благочестивый жрец",
},
[460600] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[427869] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[438355] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[443726] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[464442] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[455491] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречная гончая",
},
[441425] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[317898] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Возрожденный воин",
},
[320200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[445262] = {
["school"] = 127,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[437586] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[460364] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[427616] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[437342] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[454989] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[439637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вторящая тень",
},
[451408] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[440149] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[444497] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[437592] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[321226] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[424805] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[423015] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[437343] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[456762] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[76151] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный обманщик",
},
[440407] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[448847] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Генерал Умбрисс",
},
[438622] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Разъевшийся ползун",
},
[454991] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Опутанная паутиной жертва",
},
[320717] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[257288] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Рассекатель из братства Стальных Волн",
},
[98021] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Тотем духовной связи",
},
[445268] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[461876] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[433766] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[445013] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призванный послушник",
},
[333489] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[444502] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[326090] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иглобрюх-разоритель",
},
[320208] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Создание Трупошва",
},
[462661] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Посланница Бездны",
},
[432227] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[426345] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[460360] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[423538] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[461895] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сфера вознесения",
},
[326092] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Иглобрюх-разоритель",
},
[445016] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Потерянный дозорный",
},
[451410] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[440413] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[439646] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[425556] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[444250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
},
[422261] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[448064] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[456245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[426860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[444507] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[458067] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[423536] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[445275] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[447076] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[461904] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сфера вознесения",
},
[427629] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный снайпер",
},
[434284] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[461401] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Космический симулякр",
},
[443203] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[445021] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призванный послушник",
},
[437093] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[331440] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[438599] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Летун-пронзатель",
},
[451160] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[445504] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[257168] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый клинок из братства Стальных Волн",
},
[429422] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Заклинатель проклятой кузни",
},
[333485] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Тошногнил",
},
[442210] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[196809] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[328146] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Червь-трупоед",
},
[429427] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Заклинатель проклятой кузни",
},
[431985] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый служитель",
},
[440421] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[427378] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[446819] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[445281] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[196810] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[425554] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[427635] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Боевая рысь",
},
[437078] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[321755] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[321247] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[441958] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[440168] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[439401] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[327127] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изготовитель кадавров",
},
[453212] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[452445] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Среброжил",
},
[443494] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Осколок кристалла",
},
[429428] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Тотем земляного взрыва",
},
[453173] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[427894] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер кузни Дамиан",
},
[445541] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Брокк",
},
[464980] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[453214] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[328664] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оживленный маг",
},
[461910] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сфера вознесения",
},
[460351] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[433781] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[322527] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[196813] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[432969] = {
["school"] = 106,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[341709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призывательница Туманов",
},
[192082] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем ветряного порыва",
},
[441452] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[446012] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[434803] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[328667] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оживленный маг",
},
[273681] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[439408] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[322274] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Похитительница с \"Золрамуса\"",
},
[428894] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Отважный страж проклятой кузни",
},
[450661] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[441703] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[321253] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
},
[272662] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[423051] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[458340] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[448105] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Валиона",
},
[440177] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[108446] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Матуну",
},
[437620] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[450102] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[440178] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[196816] = {
["school"] = 2,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[323057] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[451176] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[440179] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[437371] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[389541] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Статуя белого тигра",
},
[326574] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[321005] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[270624] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сжимающий ужас",
},
[442428] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[442994] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[436606] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[428161] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Брокк",
},
[181089] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чудище камня Бездны",
},
[321258] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
},
[326629] = {
["school"] = 40,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[450100] = {
["school"] = 33,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эрудакс",
},
[440193] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[448640] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Отважный страж проклятой кузни",
},
[438656] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[433731] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[448887] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[462434] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Смертельный кошмар",
},
[464736] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[321772] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[423305] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[438145] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438139] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантом Пустоты",
},
[30213] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Скверны",
},
[321006] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[463459] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[462692] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[439419] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[448882] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Генерал Умбрисс",
},
[322548] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[462693] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[438845] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[463210] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманный страж",
},
[463461] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[452469] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Яркий Камень",
},
[439865] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[462373] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ловчий из люка",
},
[272422] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Наводчик корпорации Эшвейнов",
},
[434574] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кровавое чудовище",
},
[392375] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[437632] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443003] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[441213] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[404908] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Назгрим",
},
[463208] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманный страж",
},
[463464] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[440191] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[426136] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[427404] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[436867] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[440377] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[334322] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[448888] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[445052] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[272421] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Наводчик корпорации Эшвейнов",
},
[442495] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[471578] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[423324] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[327664] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[442250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[449169] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[443274] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[322550] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тред'ова",
},
[448300] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[322563] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[118297] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изначальный элементаль огня",
},
[464748] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[439697] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[458277] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[427331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[446349] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[423062] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[439686] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[455287] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зараженное порождение",
},
[115804] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Devilsaur",
},
[444546] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[439687] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[458357] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[438153] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантом Пустоты",
},
[445570] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[463217] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманный страж",
},
[434829] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[323496] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изготовитель кадавров",
},
[435341] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[451965] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огненный великан",
},
[448046] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[423076] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[52212] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[334321] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хирург Трупошов",
},
[428703] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Камнекрушитель",
},
[334748] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сборщик трупов",
},
[324859] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Туманный острожал",
},
[434576] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[434832] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[320170] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[100780] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дух огня",
},
[439692] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[446086] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Суреки-неестественник",
},
[443273] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[454782] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[463247] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Туманная защитница",
},
[452237] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скованный кровью ужас",
},
[442251] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[334747] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сборщик трупов",
},
[434579] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[464259] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[446344] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[320771] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[423327] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[322576] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Друст-душеруб",
},
[423839] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[320772] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[439696] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[464923] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[457599] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Желчное порождение",
},
[454437] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[454019] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[281388] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[323489] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изготовитель кадавров",
},
[462216] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[438675] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Разъевшийся ползун",
},
[321575] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некромант с \"Золрамуса\"",
},
[452245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[450088] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[438966] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[451224] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чернокнижник Сумеречного Молота",
},
[442257] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кровавый паразит",
},
[273718] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[438677] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[423588] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[447268] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Генерал Умбрисс",
},
[440468] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[450087] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Щупальце Бездны",
},
[321956] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[446351] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[273720] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[438679] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[275014] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вик'Гот",
},
[322569] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Друст-душеруб",
},
[273721] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[320012] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[433821] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Крылатый переносчик",
},
[432031] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Черная кровь",
},
[455816] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434589] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Архидемон",
},
[449167] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Дорлита",
},
[437417] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[55078] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[438682] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[450191] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[442263] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровавый паразит",
},
[456841] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[450461] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[443031] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[440218] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[453773] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[463236] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманная защитница",
},
[448147] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Страж зала",
},
[343558] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хирург Трупошов",
},
[320784] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[447272] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[428711] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[157331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Большой элементаль бури",
},
[448660] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[449939] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эрудакс",
},
[438957] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[434083] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Прожорливый ползун",
},
[434096] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[449940] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[438960] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[441772] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[428202] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[433845] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кровавый надсмотрщик",
},
[452008] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[439200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[320788] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[428735] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[430013] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[424879] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[449687] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[257862] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[323347] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хранитель врат с \"Золрамуса\"",
},
[444456] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[451241] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[462220] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[438947] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[438200] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[426160] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[427439] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[324372] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Костяное чудовище",
},
[434089] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[423228] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[321834] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[438949] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[269266] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Крушащий ужас",
},
[442530] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[257326] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[443042] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[429999] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[456853] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[343556] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[76303] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[123996] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сюэнь",
},
[455831] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Укрепленная сеть",
},
[463248] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманная защитница",
},
[434860] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[434093] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443061] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[451996] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[429109] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Кованая целительница",
},
[444324] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[428212] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[439333] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Изголодавшийся ползун",
},
[280389] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[424888] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[321821] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чумной мешок",
},
[436923] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[439481] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[424889] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[449697] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Стражник королевы Ге'за",
},
[429493] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чудище камня Бездны",
},
[438956] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[257585] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[441384] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[423356] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[447141] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Переделанный бот-погрузчик",
},
[443305] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[443336] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[443068] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[319902] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[449444] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[450483] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[432565] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призванная тень",
},
[445880] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[440238] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[444363] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[463256] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманная защитница",
},
[257459] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[442285] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сгустолиция",
},
[320839] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Похитительница с \"Золрамуса\"",
},
[463257] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Туманная защитница",
},
[451605] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[257641] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Фузилер из братства Стальных Волн",
},
[321828] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[438706] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[447146] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[449448] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[444608] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[442799] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый потоп",
},
[324387] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Костяное чудовище",
},
[449449] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[442660] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[438708] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[424421] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[272471] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[465051] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксал'атат",
},
[471445] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[394976] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плеточник Бездны",
},
[321576] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хрупкий воин",
},
[444609] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[438823] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дьявольский бес",
},
[454311] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[445632] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[443842] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[435403] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[428737] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[440246] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[455847] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[455080] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[334476] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[201633] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем земляной стены",
},
[441379] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[441782] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[439992] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[424903] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "ЗАЗУ",
},
[30153] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Скверны",
},
[427461] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
},
[324394] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Костяное чудовище",
},
[438476] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[448028] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[449985] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[443063] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[447411] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[461989] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[445877] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[224729] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[434113] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Паутинные нити",
},
[449474] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[459210] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[435410] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[442656] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Брызгающее кровотечение",
},
[445623] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[451607] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[438974] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[435138] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[435156] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[441788] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[442573] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438481] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[451606] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[271971] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зловещий охотник",
},
[438976] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[423393] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[439506] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[435415] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[76369] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный обманщик",
},
[443325] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[423121] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[441791] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[270183] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[451510] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[324914] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Туманная хранительница",
},
[448953] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Генерал Умбрисс",
},
[462508] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Посланница Бездны",
},
[424913] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
},
[323730] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[451016] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[436934] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[322614] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тред'ова",
},
[439324] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[276068] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[461487] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[455622] = {
["school"] = 5,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пульсирующий тотем",
},
[424148] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[439749] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[270187] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вик'Гот",
},
[432605] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[438471] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[325174] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем духовной связи",
},
[443092] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[448975] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Отважный страж проклятой кузни",
},
[428242] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[429521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[459782] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Космический симулякр",
},
[328756] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ингра Малох",
},
[438473] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[333634] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[445123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[438218] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[435405] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[457144] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[447170] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[447443] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[440521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[455099] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Преданный служитель",
},
[434723] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[441289] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[280934] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[443847] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[453310] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[435152] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[445909] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровожадный роевик",
},
[449986] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443081] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[82850] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пробужденный дух пламени Тьмы",
},
[428519] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Дорлита",
},
[432596] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мать Хаоса",
},
[438494] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[444696] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[455870] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Желчное порождение",
},
[428520] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[447175] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[450500] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[454848] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[323137] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Дроман Ульфарран",
},
[433877] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[320580] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[449734] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[433622] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Бранн Бронзобород",
},
[445207] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Подчиненный Бездной завыватель",
},
[441295] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[449236] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Едкий быстролап",
},
[428508] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[438495] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[443342] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[275826] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[443854] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[455363] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[448458] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Преданный служитель",
},
[452806] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[439763] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[436950] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[441298] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[59638] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зеркальное изображение",
},
[424419] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[451600] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изгонятель из зала",
},
[439776] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[456900] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[424420] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[443090] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[3110] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Bizbis",
},
[441556] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[447950] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[423665] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[447439] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[456902] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[444694] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[452299] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[447440] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[445915] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призванный послушник",
},
[323146] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[461507] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[104318] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дикий бес",
},
[434407] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[439780] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[451278] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[429028] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пробудившийся Бездны",
},
[432353] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[441368] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[451279] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сурекийская оружейная стойка",
},
[429029] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пробудившийся Бездны",
},
[437469] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[323149] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ингра Малох",
},
[320336] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленный маг",
},
[436200] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[275836] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Захватчик дома Эшвейнов",
},
[438749] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[455373] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[447965] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[431333] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[451026] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[448213] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[188046] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Обитатель Сна",
},
[439518] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[197509] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Кровавый червь",
},
[461513] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[445152] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[434155] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[429545] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Обращенный глашатай",
},
[448215] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[320596] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[443612] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[424431] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[423664] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[447967] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[443364] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[424432] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[426734] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[1604] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[439522] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[439778] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[426735] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[270481] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Демонический тиран",
},
[434408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[451032] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[451288] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Потерянный дозорный",
},
[438245] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[451040] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный головорез",
},
[452056] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сурекийская оружейная стойка",
},
[263840] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Fenryr",
},
[441315] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Взбешенный прыгун",
},
[447207] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[439781] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[452313] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[322648] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[427002] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[447966] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[461825] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[445409] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[259277] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Nether Ray",
},
[434668] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Аратийская бомба",
},
[464638] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[447456] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[317791] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародей из войска мертвых",
},
[439784] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[436971] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[432119] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ки'катал Жница",
},
[446690] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ненасытный червь",
},
[439785] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[434926] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[269456] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вик'Гот",
},
[439536] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439786] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[455387] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[321891] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[440049] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[439787] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[448013] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[322654] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[433656] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Укрепленный трутень",
},
[428535] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[268443] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Жуткая пушка",
},
[322655] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[446694] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Огромный паук",
},
[439789] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[443888] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[432117] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[445936] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скованный кровью ужас",
},
[444687] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[453345] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призванная тень",
},
[444431] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[442604] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[439825] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[445162] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[424958] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[427260] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый наставник буреклювов",
},
[439792] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[440310] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[448488] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[453859] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[31707] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Water Elemental",
},
[320358] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[320614] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[321893] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[439794] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[423682] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[427007] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[321894] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налтор Криомант",
},
[439795] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[326018] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Личинка иглобрюха",
},
[445422] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[462844] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем каменной преграды",
},
[438773] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[456420] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[336759] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[436757] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[447983] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[325224] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Туманный острожал",
},
[436217] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[451334] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[458212] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Огромный паук",
},
[434710] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[453609] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[320631] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[323177] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[460782] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[424966] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[463609] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Фантом Пустоты",
},
[428547] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[320365] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[455404] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[423200] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скарморак",
},
[448505] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[320366] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[440313] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ксал'атат",
},
[224126] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[456170] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[438012] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[432130] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[456174] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[439811] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[445174] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Забытый глашатай",
},
[439299] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Королева Ансурек",
},
[450047] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Прожорливый скарабей",
},
[268963] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[439037] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голодное порождение",
},
[432132] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[336499] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Призывательница Туманов",
},
[441612] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[441084] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[453616] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж ужаса",
},
[463602] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[257882] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[451315] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439814] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[441867] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[443657] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[322681] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[444411] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[464628] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[257883] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[448248] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[445435] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
},
[440576] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[443907] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[436996] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[320630] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[440577] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[224125] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[455416] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[444414] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чумной роевик",
},
[448515] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[443903] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[320376] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[430097] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[434441] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[450042] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Прожорливый скарабей",
},
[451321] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[464876] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай машины",
},
[114942] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем целительного прилива",
},
[324987] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Туманный хищник",
},
[456696] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный громила",
},
[439817] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[280485] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сжимающий ужас",
},
[443906] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[426771] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[444418] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[439559] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[447999] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[451324] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443396] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443654] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[326263] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[428819] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[320637] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[460789] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[438794] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[428820] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[449536] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[324986] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманный хищник",
},
[436749] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[457465] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[419870] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[443655] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[441865] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[336752] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призывательница Туманов",
},
[419871] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[443656] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[434705] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[457467] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[224127] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[118459] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Темная гончая",
},
[431637] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный странник теней",
},
[434702] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434697] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[442635] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Брызгающее кровотечение",
},
[448006] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[64695] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем хватки земли",
},
[443403] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[450045] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[452099] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ожившая тень",
},
[447240] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[459753] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Фенрир",
},
[75238] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пробужденный дух пламени Тьмы",
},
[438801] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[201754] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Nah'qi",
},
[443405] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[269984] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[450055] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Прожорливый скарабей",
},
[443150] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[321669] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Иллюзорный клон",
},
[325223] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманный острожал",
},
[441872] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королевские оковы",
},
[424737] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[460798] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[3600] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем оков земли",
},
[438804] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[142421] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Древень",
},
[441362] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[451848] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[451305] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Потерянный дозорный",
},
[424739] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[446700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ненасытный червь",
},
[320359] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[439829] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[426786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[458207] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровавый паразит",
},
[326021] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Иглобрюх-поглотитель",
},
[438807] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огромный паук",
},
[426787] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'иккадж",
},
[445457] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[430109] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый рокотун",
},
[436762] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438041] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[427001] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[439576] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[437786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[464640] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[429091] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Верховная жрица Эмия",
},
[439577] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[443361] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[451033] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный головорез",
},
[76711] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный обманщик",
},
[426736] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[326281] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[464642] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[320655] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумокост",
},
[437533] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[436203] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[444123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[436255] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[441626] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[459273] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Космический симулякр",
},
[426793] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[459785] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[433443] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[434722] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[323471] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Изготовитель кадавров",
},
[383061] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[426283] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый завоеватель",
},
[439838] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[268230] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Матрос корпорации Эшвейнов",
},
[456718] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мутировавший детеныш",
},
[428269] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгусток Бездны",
},
[451277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[322450] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[456719] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мутировавший детеныш",
},
[457668] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[333629] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Возрожденный арбалетчик",
},
[439764] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[429099] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оживший пехотинец",
},
[440608] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[453140] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[447258] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Святое оружие",
},
[462859] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный снайпер",
},
[323138] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ингра Малох",
},
[453141] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[455443] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскун",
},
[322709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[444702] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[424414] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[422382] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Древень",
},
[439502] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[319897] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[431660] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный странник теней",
},
[447261] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Генерал Умбрисс",
},
[425011] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Вечный огонь",
},
[444704] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[451098] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Суреки-ополченец",
},
[441305] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[451261] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный заклинатель земли",
},
[435148] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[451099] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Суреки-ополченец",
},
[455447] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Уэйн",
},
[441381] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[427315] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Разлом Бездны",
},
[450077] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[462510] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Посланница Бездны",
},
[461842] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[444094] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[437700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[434119] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443598] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[268752] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[450079] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[435136] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[148187] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дух земли",
},
[455084] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Опутанная паутиной жертва",
},
[325418] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Иглобрюх-кислотник",
},
[440504] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[428086] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[451871] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный заклинатель земли",
},
[452127] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'иккадж",
},
[440107] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[429110] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ремонтница проклятой кузни",
},
[434481] = {
["school"] = 12,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[439852] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[324391] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Костяное чудовище",
},
[439341] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[325021] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Туманный хищник",
},
[325413] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Иглобрюх-кислотник",
},
[447270] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[257650] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[435401] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[274002] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[322465] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[450980] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нитемот Таказдж",
},
[427323] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Странник Бездны",
},
[460315] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[451364] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный громила",
},
[447395] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[439600] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Осколок кристалла",
},
[436787] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438696] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[444833] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[427325] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[334488] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[429487] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[327952] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[444829] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[458272] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Космический симулякр",
},
[442526] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[324381] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Костяное чудовище",
},
[448176] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[427583] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[450345] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[447532] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[428709] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Камнекрушитель",
},
[442277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[454438] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[441395] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгустолиция",
},
[427329] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[267997] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сумеречная гончая",
},
[454439] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[192231] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[90361] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Aradan",
},
[443954] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[334749] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сборщик трупов",
},
[466055] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[426308] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый завоеватель",
},
[449070] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[428866] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[324776] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Туманный культиватор",
},
[451459] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[274991] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[52042] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[448560] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[451114] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленная тьма",
},
[450095] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[464673] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[448561] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[425113] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[462372] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[320171] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[448562] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[441222] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
},
[471580] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[320763] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем прилива маны",
},
[444034] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[423572] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[436799] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[268260] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[432520] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[433475] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сикран",
},
[436800] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[426826] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[427402] = {
["school"] = 9,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проклятый страж птенцов",
},
[423246] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[269029] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[432965] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[448566] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный дракон",
},
[446776] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Боевая рысь",
},
[450101] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[435012] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[456751] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Валиона",
},
[75328] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Валиона",
},
[323250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Дроман Ульфарран",
},
[427852] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[448877] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Генерал Умбрисс",
},
[326319] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Друст-жнец",
},
[448057] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[463182] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[425048] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бурестраж Горрен",
},
[433519] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[455219] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[427854] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[442432] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[442987] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[455220] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[453458] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Яростный снайпер",
},
[320696] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сшитый боец авангарда",
},
[135029] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Wasserelementar",
},
[440899] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[428879] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Камнекрушитель",
},
[459350] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[439621] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[440900] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[196811] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Божественный образ",
},
[438343] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[427346] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Благочестивый жрец",
},
[433740] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[455479] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Взять",
},
[427382] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай машины",
},
[114893] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем каменной преграды",
},
[423547] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[450129] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[442437] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[422233] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[333488] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[445537] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[89766] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Страж Скверны",
},
[321754] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[440904] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[435813] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[321725] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Иллюзорный клон",
},
[443718] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[434786] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[322493] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленный маг",
},
[320703] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сшитый боец авангарда",
},
[440650] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[463428] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[454988] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438618] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Разъевшийся ползун",
},
[333492] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[424795] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "ЗАЗУ",
},
[428120] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[434776] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[437839] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[427865] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[461880] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[434779] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
},
["emotes"] = {
{
["boss"] = "Тред'ова",
},
{
["boss"] = "Призывательница Туманов",
},
{
["boss"] = "Ингра Малох",
},
},
}
