
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c1f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dungeon6"] = false,
["dungeon2"] = false,
["dps"] = {
["max"] = "2",
["min"] = "",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
["val"] = 4,
["act"] = false,
},
["dungeon4"] = false,
["dungeon7"] = false,
["dungeon5"] = false,
["dungeon8"] = false,
["dungeon3"] = false,
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dungeon1"] = false,
},
},
["c3f165"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c114f5"] = {
["enabled"] = true,
},
["c3f6"] = {
["enabled"] = true,
},
["version"] = 6,
["c2f101"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c114f6"] = {
["enabled"] = true,
},
["c6f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c3f5"] = {
["enabled"] = false,
["raid"] = {
["difficulty"] = {
["act"] = true,
["val"] = 3,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "15",
["act"] = true,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c9f8"] = {
["enabled"] = true,
},
}
