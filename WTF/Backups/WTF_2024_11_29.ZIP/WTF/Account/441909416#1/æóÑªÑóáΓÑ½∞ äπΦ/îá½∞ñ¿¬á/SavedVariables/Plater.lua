
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[257] = 40,
[258] = 40,
[256] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA7EF3A"] = true,
},
["spellRangeCheckRangeEnemy"] = {
[257] = 40,
[258] = 40,
[256] = 40,
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["minimap"] = {
},
}
