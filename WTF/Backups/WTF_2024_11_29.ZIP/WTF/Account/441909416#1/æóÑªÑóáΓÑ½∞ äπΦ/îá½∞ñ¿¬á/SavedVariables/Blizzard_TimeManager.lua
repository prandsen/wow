
BlizzardStopwatchOptions = {
["position"] = {
["y"] = 795.7142944335938,
["x"] = 570.8572998046875,
},
}
