
HandyNotes_TheWarWithinDB = {
["profileKeys"] = {
["Beamladen - Twisting Nether"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
["Вантачмэн - Ревущий фьорд"] = "Default",
["Дракобес - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
["Алианкано - Свежеватель Душ"] = "Default",
["Прециза - Свежеватель Душ"] = "Default",
["Сорчистино - Свежеватель Душ"] = "Default",
["Топмэн - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Пва - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["icon_display_disturbed_earth"] = false,
["icon_display_profession_treasures"] = false,
["icon_display_skyriding_glyph"] = false,
["icon_display_flat_earthen"] = false,
},
},
}
