
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[81823] = true,
[66419] = true,
[64531] = true,
[75257] = true,
[82133] = true,
[82288] = true,
[64273] = true,
[76586] = true,
[82088] = true,
},
["VERSION"] = 114,
},
["Сорчистино-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Мальдика-СвежевательДуш"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
[70632] = true,
[82288] = true,
[64531] = true,
[81512] = true,
[83538] = true,
[82041] = true,
[81767] = true,
[82451] = true,
[76586] = true,
},
["Filter"] = 63,
},
["Вольтчара-СвежевательДуш"] = {
["VERSION"] = 114,
["Filter"] = 63,
["Quests"] = {
[81824] = true,
[76586] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Sort"] = 5,
["VERSION"] = 114,
["Алианкано-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Сэйвмэн-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["VERSION"] = 114,
["Quests"] = {
[76586] = true,
[59600] = true,
},
["Filter"] = 63,
},
["Дракобес-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
[71164] = true,
},
["VERSION"] = 114,
},
["Топмэн-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["SortPrio"] = {
},
["Ignore"] = {
},
["Вантачмэн-Ревущийфьорд"] = {
["VERSION"] = 113,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[74835] = true,
[52196] = true,
[49345] = true,
[73146] = true,
[54896] = true,
[82295] = true,
[51612] = true,
[66551] = true,
[82456] = true,
[82586] = true,
[71180] = true,
[70068] = true,
[55466] = true,
[58747] = true,
[72029] = true,
[82292] = true,
[75280] = true,
[69927] = true,
[51297] = true,
[71140] = true,
[58743] = true,
[50497] = true,
[52756] = true,
},
["Filter"] = 63,
},
["Пва-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 114,
},
["Прециза-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["AzeriteFormat"] = 20,
["Beamladen-TwistingNether"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["HideLegion"] = true,
}
