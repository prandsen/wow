
LoggerHeadDB = {
["profileKeys"] = {
["Beamladen - Twisting Nether"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
["Пва - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Дракобес - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["log"] = {
["party"] = {
["Каменный Свод"] = {
false,
false,
[8] = true,
[23] = false,
},
["Туманы Тирна Скитта"] = {
false,
false,
[23] = false,
[8] = true,
},
["\"Сияющий Рассвет\""] = {
false,
false,
[8] = true,
[23] = false,
},
["Город Нитей"] = {
false,
false,
[8] = true,
[23] = false,
},
["Смертельная тризна"] = {
false,
false,
[23] = false,
[8] = true,
},
["Грим Батол"] = {
false,
false,
[23] = false,
[8] = true,
},
["Гнездовье"] = {
false,
},
["Осада Боралуса"] = {
false,
[8] = true,
[23] = false,
},
["Ара-Кара, Город Отголосков"] = {
false,
[8] = true,
[23] = false,
},
},
["raid"] = {
["Неруб'арский дворец"] = {
[14] = false,
[16] = false,
[15] = false,
[17] = false,
},
},
},
["version"] = 3,
["minimap"] = {
["hide"] = true,
},
},
},
}
