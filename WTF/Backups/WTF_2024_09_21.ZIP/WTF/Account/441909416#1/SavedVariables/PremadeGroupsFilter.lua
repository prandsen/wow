
PremadeGroupsFilterSettings = {
["signupOnEnter"] = false,
["classNamesInTooltip"] = true,
["ratingInfo"] = true,
["specIcon"] = true,
["oneClickSignUp"] = true,
["dialogMovable"] = true,
["leaderCrown"] = true,
["missingRoles"] = false,
["version"] = 3,
["classBar"] = true,
["persistSignUpNote"] = true,
["classCircle"] = false,
["skipSignUpDialog"] = false,
["coloredGroupTexts"] = true,
}
