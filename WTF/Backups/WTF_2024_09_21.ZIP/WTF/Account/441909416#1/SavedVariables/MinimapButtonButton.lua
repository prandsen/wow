
MinimapButtonButtonOptions = {
["direction"] = "leftdown",
["scale"] = 1,
["blacklist"] = {
},
["buttonScale"] = 1,
["buttonsShown"] = false,
["version"] = 5,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-0.8350902795791626,
-200.3335418701172,
},
["buttonsPerRow"] = 5,
["hidecompartment"] = false,
["whitelist"] = {
["ZygorGuidesViewerMapIcon"] = true,
["CodexBrowserIcon"] = true,
["TrinketMenu_IconFrame"] = true,
},
["autohide"] = 0,
}
