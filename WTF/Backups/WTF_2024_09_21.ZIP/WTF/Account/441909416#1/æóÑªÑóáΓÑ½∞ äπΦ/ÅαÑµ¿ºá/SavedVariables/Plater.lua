
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[255] = 40,
[254] = 40,
[253] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA7EEE7"] = true,
},
["resources_on_target"] = false,
["minimap"] = {
},
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[255] = 40,
[254] = 40,
[253] = 40,
},
}
