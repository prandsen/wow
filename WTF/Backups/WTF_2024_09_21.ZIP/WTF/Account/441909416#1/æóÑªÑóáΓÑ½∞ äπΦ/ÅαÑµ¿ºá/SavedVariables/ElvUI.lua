
ElvCharacterDB = {
["ConvertKeybindings"] = true,
["ChatEditHistory"] = {
},
["ChatHistoryLog"] = {
{
"ищу крафт т5 |cff0070dd|Hitem:222576::::::::80:268::13:1:3524:2:40:2259:38:8:::::|h[Стержень терпеливого алхимика |A:Professions-ChatIcon-Quality-Tier5:17:17::1|a]|h|r",
"Катопи-СвежевательДуш",
"",
"5. Торговля (услуги): Город",
"Катопи-СвежевательДуш",
"",
42,
5,
"Торговля (услуги): Город",
0,
1745,
"Player-1604-0F7A73D6",
0,
false,
false,
false,
true,
[52] = "|cff00ff98Катопи|r",
[51] = 1725790580,
[50] = "CHAT_MSG_CHANNEL",
},
},
}
