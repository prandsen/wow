
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["difficulty"] = {
},
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c3f6"] = {
["enabled"] = true,
},
["version"] = 6,
["c6f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c9f8"] = {
["enabled"] = true,
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["val"] = 1,
["act"] = true,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["defeated"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
}
