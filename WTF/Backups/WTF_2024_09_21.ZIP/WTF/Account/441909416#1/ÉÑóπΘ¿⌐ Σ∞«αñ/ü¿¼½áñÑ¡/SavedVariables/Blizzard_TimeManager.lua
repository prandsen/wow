
BlizzardStopwatchOptions = {
["position"] = {
["y"] = 849.0474243164062,
["x"] = 716.3805541992188,
},
}
