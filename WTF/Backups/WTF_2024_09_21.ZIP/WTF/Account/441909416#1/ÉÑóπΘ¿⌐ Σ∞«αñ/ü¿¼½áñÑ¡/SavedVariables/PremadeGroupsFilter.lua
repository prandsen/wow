
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = false,
["dungeon"] = {
["difficulty"] = {
},
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c3f6"] = {
["enabled"] = true,
},
["version"] = 6,
["c114f5"] = {
["enabled"] = true,
},
["c114f6"] = {
["enabled"] = true,
},
["c6f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["act"] = true,
["val"] = 2,
},
["heals"] = {
["max"] = "4",
["min"] = "",
["act"] = true,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "0",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c9f8"] = {
["enabled"] = true,
},
}
