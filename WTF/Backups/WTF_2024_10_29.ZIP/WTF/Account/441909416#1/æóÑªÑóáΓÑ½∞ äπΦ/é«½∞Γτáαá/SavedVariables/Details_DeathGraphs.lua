
AdvancedDeathLogsDB = {
["__version"] = 1,
["deathsPerSegment"] = {
{
["deaths"] = {
{
["maxhealth"] = 6028680,
["timeofdeath"] = 236.8859999999986,
["name"] = "Finskröv-TwistingNether",
["events"] = {
{
2,
61999,
1,
1729978597.751,
0,
"Thánátøs-Draenor",
},
{
false,
143924,
2274,
1729978585.649,
0.9734969431762531,
"Finskröv-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
4603,
1729978585.921,
0.9742241038846148,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
218641,
1729978586.085,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439817,
2681952,
1729978586.135,
0.5763175937188986,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
1,
127740,
1729978586.155,
0.5763175937188986,
"Зараженное порождение",
nil,
1,
false,
-1,
false,
false,
},
{
true,
1,
127059,
1729978586.273,
0.556137817727998,
"Зараженное порождение",
nil,
1,
false,
-1,
false,
false,
},
{
false,
8004,
1147258,
1729978586.351,
0.717304150013428,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
73921,
46221,
1729978586.371,
0.7246059303960443,
"Lgrtha-Silvermoon",
nil,
0,
false,
false,
nil,
false,
},
{
true,
1,
129090,
1729978586.41,
0.7246059303960443,
"Зараженное порождение",
nil,
1,
false,
-1,
false,
false,
},
{
true,
440193,
170041,
1729978586.41,
0.6977436375412711,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
455287,
1,
1729978586.651,
0,
"Зараженное порождение",
},
{
false,
422382,
8287,
1729978586.633,
0.6828365486111809,
"Древень <Bearnabeu-TarrenMill>",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
455287,
1,
1729978586.664,
0.6828365486111809,
"Зараженное порождение",
false,
false,
false,
false,
false,
false,
},
{
false,
77489,
69237,
1729978586.716,
0.6927799503382828,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
31860,
1729978586.716,
0.6973554920143442,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
61295,
18513,
1729978586.781,
0.7000142177848692,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
6,
455287,
2,
1729978587.006,
0,
"Зараженное порождение",
},
{
false,
143924,
294,
1729978586.867,
0.7000564402975107,
"Finskröv-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
455287,
2,
1729978587.024,
0.7000564402975107,
"Зараженное порождение",
false,
false,
false,
false,
nil,
false,
},
{
6,
454989,
1,
1729978587.306,
0,
"Раша'нан",
},
{
4,
439780,
1,
1729978587.144,
0.7000564402975107,
"Раша'нан",
false,
false,
false,
false,
false,
false,
},
{
6,
455287,
4,
1729978587.359,
0,
"Зараженное порождение",
},
{
false,
382311,
610405,
1729978587.2,
0.7877191369948199,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
455287,
3,
1729978587.2,
0.7877191369948199,
"Зараженное порождение",
false,
false,
false,
false,
nil,
false,
},
{
false,
422382,
7941,
1729978587.359,
0.7888595756781094,
"Древень <Bearnabeu-TarrenMill>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180894,
1729978587.422,
0.7628806668284718,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
4,
455287,
4,
1729978587.444,
0.7628806668284718,
"Зараженное порождение",
false,
false,
false,
false,
nil,
false,
},
{
true,
439780,
96579,
1729978587.656,
0.7490105714256992,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
455287,
1893526,
1729978587.678,
0.4770737500915539,
"Зараженное порождение",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
2128,
1729978588.103,
0.4773793606592456,
"Finskröv-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
422382,
7540,
1729978588.103,
0.4784622101331158,
"Древень <Bearnabeu-TarrenMill>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
75276,
1729978588.141,
0.4892728967372338,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439780,
96580,
1729978588.161,
0.4754026577204726,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
197997,
140763,
1729978588.284,
0.4956181935945289,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180894,
1729978588.429,
0.4696392847448913,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
382024,
34393,
1729978588.596,
0.4745786006540181,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439780,
96580,
1729978588.655,
0.4607083616372569,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
455287,
1893526,
1729978588.674,
0.1887715403031117,
"Зараженное порождение",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
53482,
1729978588.723,
0.1964523036401838,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
422382,
7213,
1729978588.761,
0.1974881913397893,
"Древень <Bearnabeu-TarrenMill>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439780,
96580,
1729978589.158,
0.1836179523230281,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
273,
1729978589.264,
0.1836571589419096,
"Finskröv-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180894,
1729978589.419,
0.157678250092272,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
422382,
6865,
1729978589.468,
0.1586641601238527,
"Древень <Bearnabeu-TarrenMill>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
157982,
76122,
1729978589.531,
0.1695963441623068,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
52042,
112228,
1729978589.531,
0.18571385487232,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
61295,
47144,
1729978589.569,
0.1924843927497914,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439780,
90785,
1729978589.653,
0.1794463967968336,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
455287,
1249504,
1729978589.698,
1.436139885769434e-07,
"Зараженное порождение",
nil,
8,
false,
530410,
false,
false,
},
{
3,
414658,
0,
1729978571.172,
0,
"Finskröv-TwistingNether",
},
},
["class"] = "MAGE",
["timestring"] = "3m 56s",
["time"] = 1729978589.698,
},
{
["maxhealth"] = 6093720,
["timeofdeath"] = 303.6469999999972,
["name"] = "Shenhé-Draenor",
["events"] = {
{
false,
114083,
117713,
1729978650.977,
1,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
48438,
45542,
1729978651.319,
1,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
201633,
25222,
1729978651.446,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
false,
nil,
false,
},
{
true,
440193,
161562,
1729978651.446,
0.9776261462620534,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
368276,
360480,
1729978651.521,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
1,
false,
},
{
false,
48438,
27857,
1729978651.786,
1,
"Ködex-TwistingNether",
nil,
0,
false,
false,
nil,
false,
},
{
false,
114083,
46125,
1729978651.979,
1,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
201633,
25222,
1729978652.46,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
161562,
1729978652.46,
0.9776261462620534,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
77489,
75953,
1729978652.692,
0.9900902896752722,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
81269,
30469,
1729978652.931,
0.995090355316621,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
114083,
27940,
1729978652.996,
0.9996754035301917,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
6,
455373,
1,
1729978653.363,
0,
"Раша'нан",
},
{
false,
143924,
130359,
1729978653.403,
1,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
201633,
25222,
1729978653.447,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
161562,
1729978653.447,
0.9776261462620534,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
469421,
13875,
1729978653.556,
0.9799030805484991,
"Barada-Silvermoon",
nil,
0,
false,
false,
1,
false,
},
{
false,
114083,
18812,
1729978653.988,
0.9829901931824895,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
368276,
419415,
1729978654.35,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
201633,
25222,
1729978654.464,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
false,
nil,
false,
},
{
true,
440193,
169179,
1729978654.464,
0.9763761708775592,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
368276,
300488,
1729978654.549,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
120688,
1729978654.712,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
422382,
16176,
1729978654.837,
1,
"Древень <Ködex-TwistingNether>",
nil,
0,
false,
-1,
nil,
false,
},
{
1,
586,
1,
1729978654.933,
1,
"Shenhé-Draenor",
nil,
8,
false,
-1,
false,
false,
},
{
false,
201633,
25222,
1729978655.487,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
152260,
1729978655.487,
0.979152635828361,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
422382,
15525,
1729978655.567,
0.9817003406786002,
"Древень <Ködex-TwistingNether>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
4701,
1729978655.567,
0.9824717906303538,
"Barada-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
576707,
1729978655.879,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
81269,
28092,
1729978655.974,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
201633,
25222,
1729978656.048,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
439817,
2424226,
1729978656.048,
0.6063153541678974,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
196809,
194798,
1729978656.118,
0.6382823628259914,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
192846,
1729978656.162,
0.6699290417019489,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
196810,
12860,
1729978656.162,
0.6720394110658185,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
201633,
25222,
1729978656.226,
0.6720394110658185,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
false,
nil,
false,
},
{
false,
17,
303144,
1729978656.226,
0.6720394110658185,
"Shenhé-Draenor",
true,
0,
false,
-1,
nil,
false,
},
{
true,
439817,
2328924,
1729978656.226,
0.3437410973920692,
"Раша'нан",
328366,
8,
false,
-1,
false,
false,
},
{
false,
422382,
7433,
1729978656.226,
0.3449608777561161,
"Древень <Ködex-TwistingNether>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
1,
108776,
1729978656.245,
0.3449608777561161,
"Зараженное порождение",
nil,
1,
false,
-1,
false,
false,
},
{
false,
201633,
25222,
1729978656.258,
0.3449608777561161,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
1,
89867,
1729978656.372,
0.331249384612355,
"Зараженное порождение",
nil,
1,
false,
-1,
false,
false,
},
{
false,
201633,
50444,
1729978656.394,
0.3206409221296679,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
false,
-1,
1,
false,
},
{
5,
27827,
1,
1729978656.394,
0.3206409221296679,
"Shenhé-Draenor",
false,
false,
false,
false,
nil,
false,
},
{
true,
439817,
1979240,
1729978656.394,
1.641033719960878e-07,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
3,
586,
0,
1729978654.933,
0,
"Shenhé-Draenor",
},
},
["class"] = "PRIEST",
["timestring"] = "5m 3s",
["time"] = 1729978656.394,
},
},
["bossname"] = "Раша'нан",
["bossicon"] = {
0,
1,
0,
1,
5907275,
32,
20,
0,
1,
0,
0.9,
},
["date"] = 289623.545,
["timeelapsed"] = 331.2469999999739,
},
{
["deaths"] = {
{
["maxhealth"] = 5022160,
["timeofdeath"] = 23.90499999996973,
["name"] = "Haadige-Kazzak",
["events"] = {
{
false,
114083,
37091,
1729978189.667,
1,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
6,
455373,
1,
1729978189.961,
0,
"Раша'нан",
},
{
false,
114942,
186240,
1729978189.825,
1,
"Тотем целительного прилива <Вольтчара>",
nil,
0,
},
{
false,
48438,
52685,
1729978189.862,
1,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
451968,
465369,
1729978189.862,
1,
"Haadige-Kazzak",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
774,
95370,
1729978189.961,
1,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
201633,
25222,
1729978189.996,
1,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
},
{
true,
439778,
540192,
1729978189.996,
0.902343142572147,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
201633,
25222,
1729978190.036,
0.902343142572147,
"Тотем земляной стены <Lgrtha-Silvermoon>",
true,
0,
},
{
true,
440193,
176635,
1729978190.036,
0.8736297849906889,
"Раша'нан",
25222,
8,
false,
-1,
false,
false,
},
{
false,
422382,
9774,
1729978190.138,
0.8754832873782062,
"Древень <Ködex-TwistingNether>",
nil,
0,
false,
false,
},
{
false,
774,
207939,
1729978190.138,
0.9149160102100029,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
48438,
52097,
1729978190.303,
0.9247954775603706,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
453247,
1502454,
1729978190.477,
1,
"Lgrtha-Silvermoon",
nil,
0,
},
{
false,
114942,
158743,
1729978190.568,
1,
"Тотем целительного прилива <Lgrtha-Silvermoon>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
114083,
62447,
1729978190.685,
1,
"Lgrtha-Silvermoon",
nil,
0,
},
{
false,
122470,
540399,
1729978190.769,
1,
"Haadige-Kazzak",
true,
0,
},
{
true,
439778,
540399,
1729978190.769,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
48438,
51496,
1729978190.769,
1,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
122470,
541088,
1729978191.007,
1,
"Haadige-Kazzak",
true,
0,
},
{
true,
439778,
541088,
1729978191.007,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
122470,
176636,
1729978191.065,
1,
"Haadige-Kazzak",
true,
0,
},
{
true,
440193,
176636,
1729978191.065,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
114942,
110111,
1729978191.145,
1,
"Тотем целительного прилива <Вольтчара>",
nil,
0,
false,
false,
},
{
false,
48438,
50895,
1729978191.235,
1,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
774,
95371,
1729978191.235,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
122470,
541022,
1729978191.279,
1,
"Haadige-Kazzak",
true,
0,
},
{
true,
439778,
541022,
1729978191.279,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
774,
207938,
1729978191.543,
1,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
114083,
105280,
1729978191.674,
1,
"Lgrtha-Silvermoon",
nil,
0,
},
{
false,
48438,
50295,
1729978191.697,
1,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
114942,
62365,
1729978192.049,
1,
"Тотем целительного прилива <Lgrtha-Silvermoon>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
122470,
176635,
1729978192.049,
1,
"Haadige-Kazzak",
true,
0,
},
{
true,
440193,
176635,
1729978192.049,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
48438,
49706,
1729978192.173,
1,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
114942,
184568,
1729978192.455,
1,
"Тотем целительного прилива <Вольтчара>",
nil,
0,
},
{
false,
774,
82571,
1729978192.546,
1,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
48438,
49109,
1729978192.626,
1,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
114083,
57633,
1729978192.686,
1,
"Lgrtha-Silvermoon",
nil,
0,
false,
false,
},
{
false,
122470,
558592,
1729978192.805,
1,
"Haadige-Kazzak",
true,
0,
},
{
true,
439778,
558592,
1729978192.805,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
122470,
102258,
1729978192.959,
1,
"Haadige-Kazzak",
true,
0,
false,
-1,
nil,
false,
},
{
true,
439817,
2736271,
1729978192.959,
0.500496277445072,
"Раша'нан",
102258,
8,
false,
-1,
false,
false,
},
{
false,
774,
207939,
1729978192.959,
0.5399290002768686,
"Ködex-TwistingNether",
nil,
0,
},
{
true,
439817,
2757018,
1729978193.074,
0.01709909998748403,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
90167,
1729978193.074,
1.896360126373439e-07,
"Раша'нан",
nil,
8,
false,
86469,
false,
false,
},
{
3,
0,
0,
0,
0,
"Haadige-Kazzak",
},
},
["class"] = "MONK",
["timestring"] = "0m 23s",
["time"] = 1729978193.13,
},
{
["maxhealth"] = 5835440,
["timeofdeath"] = 43.74800000002142,
["name"] = "Bearnabeu-TarrenMill",
["events"] = {
{
2,
61999,
1,
1729978233.979,
0,
"Wìntér-Draenor",
},
{
false,
33763,
35866,
1729978207.905,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
8936,
79666,
1729978208.038,
1,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
33763,
35865,
1729978208.411,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
38883,
1729978208.823,
1,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
155777,
123069,
1729978208.869,
1,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
114083,
34189,
1729978208.906,
1,
"Вольтчара",
nil,
0,
},
{
false,
33763,
35865,
1729978208.927,
1,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
6,
455084,
1,
1729978209.144,
0,
"Опутанная паутиной жертва",
},
{
false,
774,
113953,
1729978208.984,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
8936,
73766,
1729978209.078,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
5764,
1729978209.163,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
6,
455084,
2,
1729978209.415,
0,
"Опутанная паутиной жертва",
},
{
6,
455084,
2,
1729978209.624,
0,
"Опутанная паутиной жертва",
},
{
false,
33763,
35051,
1729978209.446,
1,
"Bearnabeu-TarrenMill",
nil,
0,
false,
false,
},
{
4,
454991,
1,
1729978209.75,
nil,
"Опутанная паутиной жертва",
false,
false,
false,
false,
nil,
false,
},
{
true,
454988,
1467916,
1729978209.75,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
19076,
1729978209.775,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
439776,
1,
1729978209.872,
nil,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
false,
114083,
2386,
1729978209.904,
0,
"Вольтчара",
nil,
0,
},
{
false,
114911,
2334,
1729978209.904,
0,
"Вольтчара",
nil,
0,
},
{
6,
455084,
1,
1729978210.147,
0,
"Опутанная паутиной жертва",
},
{
false,
145109,
376547,
1729978210.071,
0,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
8936,
77858,
1729978210.123,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
33763,
35051,
1729978210.173,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
89108,
1729978210.24,
0,
"Вольтчара",
nil,
0,
},
{
true,
439776,
1198985,
1729978210.373,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
155777,
120874,
1729978210.401,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
774,
120875,
1729978210.55,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1237814,
1729978210.89,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
114083,
4107,
1729978210.89,
0,
"Вольтчара",
nil,
0,
},
{
false,
33763,
28904,
1729978210.939,
0,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
143924,
19752,
1729978211.008,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1237814,
1729978211.404,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
382024,
95869,
1729978211.673,
0,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
33763,
26763,
1729978211.696,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
8936,
65391,
1729978211.696,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
774,
48983,
1729978211.81,
0,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
114083,
3532,
1729978211.872,
0,
"Вольтчара",
nil,
0,
},
{
true,
439776,
1237814,
1729978211.921,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
114911,
9940,
1729978211.921,
0,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
1008,
1729978211.921,
0,
"Bùstian-Ragnaros",
nil,
0,
},
{
false,
143924,
12812,
1729978212.225,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1237814,
1729978212.393,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
33763,
49313,
1729978212.5,
0,
"Bearnabeu-TarrenMill",
nil,
0,
},
{
false,
155777,
82884,
1729978212.794,
0,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
422382,
7675,
1729978212.851,
0,
"Древень <Ködex-TwistingNether>",
nil,
0,
false,
false,
},
{
false,
114083,
826,
1729978212.886,
0,
"Вольтчара",
nil,
0,
},
{
false,
454991,
1,
1729978212.886,
0,
"Опутанная паутиной жертва",
true,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
788190,
1729978212.912,
1.483697135871049e-07,
"Раша'нан",
1,
8,
false,
449623,
false,
false,
},
{
3,
0,
0,
0,
0,
"Bearnabeu-TarrenMill",
},
},
["class"] = "DRUID",
["timestring"] = "0m 43s",
["time"] = 1729978212.973,
},
{
["maxhealth"] = 8980740,
["timeofdeath"] = 52.62400000001071,
["name"] = "Meshtities-Silvermoon",
["events"] = {
{
2,
20484,
1,
1729978224.27,
0,
"Ködex-TwistingNether",
},
{
true,
124255,
389141,
1729978218.739,
0.5177617554327035,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
},
{
false,
33110,
139236,
1729978218.773,
0.5311850219652752,
"Shenhé-Draenor",
nil,
0,
true,
-1,
},
{
true,
444702,
693444,
1729978218.801,
0.4643324577045054,
"Раша'нан",
1399897,
1,
false,
-1,
false,
false,
},
{
true,
444704,
533282,
1729978218.801,
0.4129205640633291,
"Раша'нан",
337905,
8,
false,
-1,
false,
false,
},
{
false,
379,
106683,
1729978218.816,
0.4232055072065846,
"Lgrtha-Silvermoon",
nil,
0,
true,
-1,
},
{
4,
440193,
1,
1729978218.88,
0.4232055072065846,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
true,
440193,
14540,
1729978218.88,
0.4218037555375939,
"Раша'нан",
9213,
8,
false,
-1,
false,
false,
},
{
true,
440191,
72476,
1729978219.238,
0.4148165922664955,
"Раша'нан",
45923,
8,
false,
-1,
false,
false,
},
{
true,
124255,
459331,
1729978219.255,
0.3705340616014907,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
false,
false,
},
{
false,
216521,
364,
1729978219.546,
0.3705691535965053,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
469421,
520,
1729978219.546,
0.3706192850179548,
"Barada-Silvermoon",
nil,
0,
},
{
false,
455179,
459331,
1729978219.745,
0.3706192850179548,
"Meshtities-Silvermoon",
true,
0,
true,
-1,
nil,
false,
},
{
true,
124255,
459331,
1729978219.745,
0.3706192850179548,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
nil,
false,
},
{
false,
8936,
15289,
1729978219.745,
0.3720932452151486,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
455179,
900703,
1729978219.82,
0.3720932452151486,
"Meshtities-Silvermoon",
true,
0,
false,
-1,
nil,
false,
},
{
true,
444702,
45798,
1729978219.82,
0.3676780166775671,
"Раша'нан",
2811460,
1,
false,
-1,
false,
false,
},
{
true,
444704,
727890,
1729978219.82,
0.2975046313720893,
"Раша'нан",
461216,
8,
false,
-1,
false,
false,
},
{
4,
440193,
2,
1729978219.901,
0.2975046313720893,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
false,
216521,
436868,
1729978219.901,
0.3396215810370571,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
},
{
false,
2061,
624098,
1729978219.901,
0.3997887346212224,
"Shenhé-Draenor",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
216521,
605,
1729978219.922,
0.3998470606019473,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
114083,
864,
1729978219.922,
0.3999303558868171,
"Вольтчара",
nil,
0,
true,
-1,
},
{
false,
143924,
115,
1729978219.922,
0.3999414426434839,
"Meshtities-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
41782,
1729978219.944,
0.3959133829300196,
"Раша'нан",
26473,
8,
false,
-1,
false,
false,
},
{
false,
2061,
332211,
1729978219.944,
0.4279407091822254,
"Shenhé-Draenor",
nil,
0,
true,
-1,
nil,
false,
},
{
true,
124255,
533320,
1729978220.248,
0.3765251520910202,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
nil,
false,
},
{
true,
440191,
95363,
1729978220.263,
0.3673315314300875,
"Раша'нан",
60425,
8,
false,
-1,
false,
false,
},
{
false,
120692,
49965,
1729978220.539,
0.3721484861853228,
"Shenhé-Draenor",
nil,
0,
true,
-1,
},
{
true,
124255,
509676,
1729978220.745,
0.3230123662647926,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
nil,
false,
},
{
false,
77489,
111467,
1729978220.804,
0.3337585184853832,
"Shenhé-Draenor",
nil,
0,
true,
-1,
},
{
true,
444702,
996317,
1729978220.815,
0.2377070042079544,
"Раша'нан",
2011323,
1,
false,
-1,
false,
false,
},
{
true,
444704,
766200,
1729978220.815,
0.1638402828337673,
"Раша'нан",
485491,
8,
false,
-1,
false,
false,
},
{
false,
216521,
296583,
1729978220.838,
0.1924328354640473,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
124507,
423690,
1729978220.838,
0.2332793392215901,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
nil,
false,
},
{
true,
440193,
41781,
1729978220.881,
0.2292513759147056,
"Раша'нан",
26473,
8,
false,
-1,
false,
false,
},
{
4,
440193,
3,
1729978220.964,
0.2292513759147056,
"Раша'нан",
false,
false,
false,
false,
},
{
false,
143924,
19148,
1729978221.135,
0.1542071060133026,
"Meshtities-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
124255,
579905,
1729978221.243,
0.09270978264558165,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
nil,
false,
},
{
true,
440191,
96768,
1729978221.243,
0.08244780354961313,
"Раша'нан",
61315,
8,
false,
-1,
false,
false,
},
{
false,
8936,
15572,
1729978221.269,
0.08409917113479028,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
216521,
324308,
1729978221.585,
0.1184911386928193,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
124507,
463297,
1729978221.585,
0.1676225057689697,
"Meshtities-Silvermoon",
nil,
0,
true,
-1,
},
{
true,
124255,
526277,
1729978221.75,
0.1118122836636351,
"Meshtities-Silvermoon",
nil,
1,
true,
-1,
nil,
false,
},
{
true,
444702,
960449,
1729978221.814,
0.009959320279625357,
"Раша'нан",
1938916,
1,
false,
-1,
false,
false,
},
{
true,
444704,
93913,
1729978221.849,
1.060472376815529e-07,
"Раша'нан",
468012,
8,
false,
644704,
false,
false,
},
{
3,
0,
0,
0,
0,
"Meshtities-Silvermoon",
},
},
["class"] = "MONK",
["timestring"] = "0m 52s",
["time"] = 1729978221.849,
},
{
["maxhealth"] = 6347924,
["timeofdeath"] = 59.87900000001537,
["name"] = "Lazyshammy-Ragnaros",
["events"] = {
{
4,
440193,
4,
1729978221.896,
0.7686961072224912,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
false,
469421,
1436,
1729978221.896,
0.7689115508067282,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440191,
181817,
1729978222.244,
0.7416334824535004,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
379,
144938,
1729978222.27,
0.7633785814870349,
"Lazyshammy-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
7634,
1729978222.593,
0.7645239131876379,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
132,
1729978222.76,
0.7645437171939884,
"Lazyshammy-Ragnaros",
nil,
0,
},
{
true,
440193,
143785,
1729978222.885,
0.7429716031553183,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
114083,
75600,
1729978222.91,
0.754313897701505,
"Вольтчара",
nil,
0,
false,
false,
},
{
4,
440193,
5,
1729978222.972,
0.754313897701505,
"Раша'нан",
false,
false,
false,
false,
},
{
4,
439776,
1,
1729978223.08,
0.754313897701505,
"Раша'нан",
false,
false,
false,
false,
},
{
true,
439776,
1283780,
1729978223.584,
0.5617079335149501,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
1064,
789435,
1729978223.861,
0.6801471437671841,
"Вольтчара",
nil,
0,
},
{
true,
440193,
170271,
1729978223.892,
0.6546013258482191,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1216214,
1729978224.077,
0.4721323123667918,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
354998,
1729978224.191,
0.5253927869608022,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
132,
1729978224.399,
0.5254125909671526,
"Lazyshammy-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1216213,
1729978224.597,
0.3429437275160765,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
37089,
1729978224.597,
0.3485082032095093,
"Shenhé-Draenor",
nil,
0,
},
{
false,
31616,
1333064,
1729978224.597,
0.5485082632216497,
"Lazyshammy-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
196810,
12368,
1729978224.853,
0.5503638386045497,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
},
{
true,
440193,
160812,
1729978224.897,
0.5262371577770183,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1148646,
1729978225.085,
0.3539053950614209,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
69978,
1729978225.55,
0.3644042189734983,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
true,
439776,
1148645,
1729978225.579,
0.1920726062882521,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
132,
1729978225.63,
0.1920924102946026,
"Lazyshammy-Ragnaros",
nil,
0,
},
{
true,
440193,
151353,
1729978225.895,
0.1693848665585048,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1081079,
1729978226.08,
0.007190204578386207,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
false,
1064,
830013,
1729978226.392,
0.1317173464191806,
"Вольтчара",
nil,
0,
},
{
false,
2060,
2653259,
1729978226.53,
0.5297867258546404,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
2061,
1912379,
1729978226.53,
0.8167016187374706,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
196809,
187359,
1729978226.553,
0.8448111552967166,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
1,
false,
},
{
true,
439776,
1081078,
1729978226.577,
0.682616643346949,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
475809,
1729978226.587,
0.7540024346925382,
"Shenhé-Draenor",
nil,
0,
},
{
true,
440193,
151352,
1729978226.886,
0.7312950409867917,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1081078,
1729978227.077,
0.5691005290370242,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
132,
1729978227.238,
0.5691203330433747,
"Lazyshammy-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1081078,
1729978227.575,
0.4069258210936073,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
151353,
1729978227.887,
0.3842182773575094,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
469421,
4831,
1729978227.887,
0.384943073983867,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1081079,
1729978228.081,
0.2227484120037484,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1081078,
1729978228.569,
0.06055390005398092,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
475808,
1729978228.578,
0.131939541369219,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
271,
1729978228.835,
0.131980199594378,
"Lazyshammy-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
151353,
1729978228.885,
0.1092726558582801,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
728336,
1729978229.104,
1.500303511400356e-07,
"Раша'нан",
nil,
8,
false,
352742,
false,
false,
},
{
3,
0,
0,
0,
0,
"Lazyshammy-Ragnaros",
},
},
["class"] = "SHAMAN",
["timestring"] = "0m 59s",
["time"] = 1729978229.104,
},
{
["maxhealth"] = 6108560,
["timeofdeath"] = 60.18900000001304,
["name"] = "Falkao-TwistingNether",
["events"] = {
{
false,
120692,
52868,
1729978220.495,
0,
"Shenhé-Draenor",
nil,
0,
},
{
4,
440193,
3,
1729978220.881,
nil,
"Раша'нан",
false,
false,
false,
false,
1,
false,
},
{
true,
440193,
116368,
1729978220.931,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440191,
179679,
1729978221.243,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
114083,
860,
1729978221.896,
0,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
112179,
1729978221.929,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
4,
440193,
4,
1729978221.998,
nil,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
true,
440191,
179679,
1729978222.244,
0,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
7717,
1729978222.518,
0.7109145959295164,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
4913,
1729978222.76,
0.711680578985279,
"Falkao-TwistingNether",
nil,
0,
},
{
false,
1064,
339814,
1729978222.856,
0.7646607878415586,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
114083,
75600,
1729978222.91,
0.7764475411522954,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
440193,
5,
1729978222.91,
0.7764475411522954,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
true,
440193,
168269,
1729978222.932,
0.7502128163792217,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
81269,
23834,
1729978223.338,
0.7539287618608103,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
1064,
417504,
1729978223.861,
0.8190215747476606,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
169169,
1729978223.936,
0.7926465314827923,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
10521,
1729978223.981,
0.7942868546518698,
"Falkao-TwistingNether",
nil,
0,
},
{
false,
77489,
7717,
1729978224.523,
0.7954900077642899,
"Shenhé-Draenor",
nil,
0,
},
{
false,
120692,
355226,
1729978224.597,
0.8508730928378324,
"Shenhé-Draenor",
nil,
0,
},
{
false,
382024,
58742,
1729978224.708,
0.8600315248878232,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
196810,
12368,
1729978224.853,
0.8619598127839501,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
169168,
1729978224.938,
0.835584925428517,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
196810,
12368,
1729978224.938,
0.837513213324644,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
105814,
1729978225.085,
0.8540106143143571,
"Shenhé-Draenor",
nil,
0,
},
{
false,
196810,
24737,
1729978225.441,
0.8578673460160462,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
169169,
1729978225.935,
0.8314923027511779,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
false,
73921,
119687,
1729978226.23,
0.8501526353371853,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
58775,
1729978226.492,
0.859316212398542,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
44863,
1729978226.657,
0.8663107773956265,
"Shenhé-Draenor",
nil,
0,
},
{
4,
439776,
1,
1729978226.886,
0.8663107773956265,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
true,
440193,
169169,
1729978226.922,
0.8399357341307582,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1256734,
1729978227.402,
0.6439990458342558,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1396372,
1729978227.887,
0.4262914758075329,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
187965,
1729978227.926,
0.3969859587962544,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
144831,
1729978228.231,
0.4195664782241292,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
78452,
1729978228.296,
0.4317978852444192,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1312589,
1729978228.38,
0.2271528754377157,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
44862,
1729978228.65,
0.2341472845253649,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
true,
439776,
1312590,
1729978228.885,
0.0295021188092261,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
33110,
121752,
1729978228.907,
0.04848440437918422,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
true,
440193,
176687,
1729978228.921,
0.02093723397952597,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
157937,
1729978229.248,
0.04556110246679909,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
196813,
79628,
1729978229.248,
0.05797585898303394,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
},
{
true,
439776,
371855,
1729978229.395,
1.559094353272071e-07,
"Раша'нан",
nil,
8,
false,
940734,
false,
false,
},
{
3,
0,
0,
0,
0,
"Falkao-TwistingNether",
},
},
["class"] = "WARRIOR",
["timestring"] = "1m 0s",
["time"] = 1729978229.414,
},
{
["maxhealth"] = 6737850,
["timeofdeath"] = 63.28800000000047,
["name"] = "Nerforc-TwistingNether",
["events"] = {
{
false,
108366,
2797,
1729978225.85,
0.8534409501306904,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
},
{
true,
387846,
2797,
1729978225.85,
0.8534409501306904,
"Nerforc-TwistingNether",
nil,
32,
true,
-1,
},
{
false,
774,
35190,
1729978225.966,
0.8584149901367288,
"Bearnabeu-TarrenMill",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
386124,
6024,
1729978225.993,
0.8584149901367288,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
},
{
false,
108366,
28396,
1729978225.993,
0.8584149901367288,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
nil,
false,
},
{
true,
440193,
187677,
1729978225.993,
0.8389185625688719,
"Раша'нан",
49745,
8,
false,
-1,
false,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
true,
387846,
2840,
1729978226.341,
0.8385572767986122,
"Nerforc-TwistingNether",
284,
32,
true,
-1,
},
{
false,
389372,
3569,
1729978226.392,
0.8390617482047377,
"Nerforc-TwistingNether",
nil,
0,
},
{
false,
143924,
10868,
1729978226.428,
0.840597919468893,
"Nerforc-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
30657,
1729978226.445,
0.8449312284903513,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
2261,
1729978226.544,
0.8452508165680339,
"Barada-Silvermoon",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
108366,
2840,
1729978226.875,
0.8452508165680339,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
nil,
false,
},
{
true,
387846,
2840,
1729978226.875,
0.8452508165680339,
"Nerforc-TwistingNether",
nil,
32,
true,
-1,
nil,
false,
},
{
false,
469421,
1878,
1729978226.897,
0.8455162683194218,
"Bùstian-Ragnaros",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
386124,
1924,
1729978226.989,
0.8455162683194218,
"Nerforc-TwistingNether",
true,
0,
false,
false,
nil,
false,
},
{
false,
108366,
24641,
1729978226.989,
0.8455162683194218,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
nil,
false,
},
{
true,
440193,
187677,
1729978226.989,
0.8250206509589338,
"Раша'нан",
42676,
8,
false,
-1,
false,
false,
},
{
true,
387846,
2465,
1729978227.334,
0.8247069995018893,
"Nerforc-TwistingNether",
246,
32,
true,
-1,
nil,
false,
},
{
false,
389372,
2722,
1729978227.402,
0.8250917490584803,
"Nerforc-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
4131,
1729978227.633,
0.8256756581026673,
"Nerforc-TwistingNether",
nil,
0,
true,
-1,
},
{
false,
108366,
2465,
1729978227.822,
0.8256756581026673,
"Nerforc-TwistingNether",
true,
0,
false,
-1,
nil,
false,
},
{
true,
387846,
2465,
1729978227.822,
0.8256756581026673,
"Nerforc-TwistingNether",
nil,
32,
true,
-1,
},
{
false,
469421,
4831,
1729978227.887,
0.8263585108241556,
"Bùstian-Ragnaros",
nil,
0,
true,
-1,
},
{
false,
386124,
-1238,
1729978227.975,
0.8263585108241556,
"Nerforc-TwistingNether",
true,
0,
},
{
false,
108366,
18474,
1729978227.975,
0.8263585108241556,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
nil,
false,
},
{
true,
440193,
187677,
1729978227.975,
0.8046761347284958,
"Раша'нан",
34280,
8,
false,
-1,
false,
false,
},
{
true,
387846,
1848,
1729978228.34,
0.8044409314727399,
"Nerforc-TwistingNether",
184,
32,
true,
-1,
nil,
false,
},
{
false,
389372,
3357,
1729978228.398,
0.804915437079454,
"Nerforc-TwistingNether",
nil,
0,
false,
false,
},
{
false,
77489,
30657,
1729978228.472,
0.8092487461009124,
"Shenhé-Draenor",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
143924,
5036,
1729978228.835,
0.8099605751850388,
"Nerforc-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
108366,
1848,
1729978228.835,
0.8099605751850388,
"Nerforc-TwistingNether",
true,
0,
false,
-1,
nil,
false,
},
{
true,
387846,
1848,
1729978228.835,
0.8099605751850388,
"Nerforc-TwistingNether",
nil,
32,
true,
-1,
nil,
false,
},
{
false,
120692,
189093,
1729978228.94,
0.8366885134306148,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
386124,
9213,
1729978228.981,
0.8366885134306148,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
},
{
false,
108366,
23993,
1729978228.981,
0.8366885134306148,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
nil,
false,
},
{
true,
440193,
187677,
1729978228.981,
0.817037733726168,
"Раша'нан",
48653,
8,
false,
-1,
false,
false,
},
{
true,
444094,
2922271,
1729978229.104,
0.445285983977909,
"Раша'нан",
292227,
8,
false,
-1,
false,
false,
},
{
true,
387846,
2400,
1729978229.342,
0.4449806720593798,
"Nerforc-TwistingNether",
240,
32,
true,
-1,
nil,
false,
},
{
false,
389372,
2921,
1729978229.395,
0.4453935498899463,
"Nerforc-TwistingNether",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
108366,
2400,
1729978229.83,
0.4453935498899463,
"Nerforc-TwistingNether",
true,
0,
false,
-1,
nil,
false,
},
{
true,
387846,
2400,
1729978229.83,
0.4453935498899463,
"Nerforc-TwistingNether",
nil,
32,
true,
-1,
nil,
false,
},
{
false,
446342,
433738,
1729978229.889,
0.5067015966117162,
"Shenhé-Draenor",
nil,
0,
true,
-1,
nil,
false,
},
{
false,
386124,
877,
1729978229.986,
0.5067015966117162,
"Nerforc-TwistingNether",
true,
0,
false,
-1,
nil,
false,
},
{
false,
108366,
20072,
1729978229.986,
0.5067015966117162,
"Nerforc-TwistingNether",
true,
0,
true,
-1,
nil,
false,
},
{
true,
440193,
187677,
1729978229.986,
0.4854914645530036,
"Раша'нан",
37621,
8,
false,
-1,
false,
false,
},
{
3,
0,
0,
0,
0,
"Nerforc-TwistingNether",
},
},
["class"] = "WARLOCK",
["timestring"] = "1m 3s",
["time"] = 1729978232.513,
},
{
["maxhealth"] = 5394560,
["timeofdeath"] = 63.28800000000047,
["name"] = "Ködex-TwistingNether",
["events"] = {
{
4,
440193,
4,
1729978221.998,
0.71714728085476,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
true,
440193,
153783,
1729978222.833,
0.6610035167753007,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
171195,
1729978222.856,
0.6912271286023997,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
1064,
485273,
1729978222.856,
0.7768996236061777,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
440193,
5,
1729978222.856,
0.7768996236061777,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
4,
440193,
1,
1729978222.856,
0.7768996236061777,
"Раша'нан",
false,
false,
false,
false,
},
{
false,
114083,
78625,
1729978222.91,
0.7907804698920251,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
3274,
1729978223.153,
0.7913584780413397,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
52042,
37623,
1729978223.304,
0.7980006285000035,
"Тотем исцеляющего потока <Lgrtha-Silvermoon>",
nil,
0,
},
{
false,
469421,
5517,
1729978223.543,
0.7989746269605316,
"Barada-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
449209,
243650,
1729978223.584,
0.8431089211691513,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
true,
440193,
169854,
1729978223.82,
0.8131220561130452,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
155189,
1729978223.839,
0.8405198895534826,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
449209,
308980,
1729978223.892,
0.8950687466015098,
"Вольтчара",
nil,
0,
},
{
false,
77489,
30544,
1729978224.099,
0.900461135395849,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
3982,
1729978224.399,
0.9011641373660907,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
192261,
1729978224.462,
0.9351068450006003,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
57088,
1729978224.708,
0.9451854428100306,
"Вольтчара",
nil,
0,
},
{
true,
440193,
169853,
1729978224.819,
0.9151987542988694,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
469421,
951,
1729978224.897,
0.9153666485413857,
"Bùstian-Ragnaros",
nil,
0,
},
{
false,
145109,
169929,
1729978224.975,
0.9453667544683525,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
2178,
1729978225.63,
0.9468684457689238,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
60723,
1729978225.693,
0.957588784452746,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
169853,
1729978225.832,
0.9276020959415848,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
44980,
1729978226.1,
0.9355430875592309,
"Shenhé-Draenor",
nil,
0,
false,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
false,
52042,
283566,
1729978226.445,
0.9856052313798047,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
120194,
1729978226.492,
1,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180695,
1729978226.875,
0.9680992111971866,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
180695,
1729978227.822,
0.9373099493669098,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
81269,
20871,
1729978227.887,
0.9409946189100822,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
2204,
1729978228.042,
0.9413837239684479,
"Ködex-TwistingNether",
nil,
0,
false,
false,
nil,
false,
},
{
false,
77489,
44980,
1729978228.092,
0.9493247155860939,
"Shenhé-Draenor",
nil,
0,
false,
false,
},
{
false,
382024,
56413,
1729978228.285,
0.9592841455577761,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180695,
1729978228.829,
0.9273833567549626,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
469421,
1003,
1729978228.885,
0.9275604313346092,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
145109,
169928,
1729978228.975,
0.9575603607166312,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
194527,
1729978229.146,
0.991903119196085,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
52042,
121283,
1729978229.248,
1,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
false,
nil,
false,
},
{
true,
440193,
180695,
1729978229.83,
0.9680992111971866,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
3,
0,
0,
0,
0,
"Ködex-TwistingNether",
},
},
["class"] = "DRUID",
["timestring"] = "1m 3s",
["time"] = 1729978232.513,
},
{
["maxhealth"] = 7085440,
["timeofdeath"] = 64.49699999997392,
["name"] = "Thánátøs-Draenor",
["events"] = {
{
4,
440193,
4,
1729978221.785,
0.9525890759329653,
"Раша'нан",
false,
false,
false,
false,
},
{
4,
440193,
5,
1729978222.91,
0.9352952799298898,
"Раша'нан",
false,
false,
false,
false,
6,
false,
},
{
false,
207203,
21784,
1729978223.936,
0.9649255617146882,
"Thánátøs-Draenor",
true,
0,
false,
false,
},
{
true,
440193,
177824,
1729978223.936,
0.943951654094509,
"Раша'нан",
21784,
8,
false,
-1,
false,
false,
},
{
false,
143924,
32208,
1729978223.981,
0.9482808492792739,
"Thánátøs-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
25646,
1729978224.005,
0.9517280220223342,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
55078,
17372,
1729978224.039,
0.9540630561365213,
"Thánátøs-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
458357,
115907,
1729978224.622,
0.9696425403106569,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
950,
1729978224.897,
0.9697702332883495,
"Bùstian-Ragnaros",
nil,
0,
false,
false,
nil,
false,
},
{
false,
120692,
360680,
1729978224.938,
1,
"Shenhé-Draenor",
nil,
0,
},
{
false,
444741,
177824,
1729978224.938,
1,
"Верховный лорд Дарион Могрейн <Thánátøs-Draenor>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
177824,
1729978224.938,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
196810,
24738,
1729978224.938,
1,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
444741,
177825,
1729978225.935,
1,
"Верховный лорд Дарион Могрейн <Thánátøs-Draenor>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
177825,
1729978225.935,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
444741,
183324,
1729978226.943,
1,
"Верховный лорд Дарион Могрейн <Thánátøs-Draenor>",
true,
0,
false,
false,
},
{
true,
440193,
183324,
1729978226.943,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
52646,
1729978226.955,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
444741,
183324,
1729978227.926,
1,
"Верховный лорд Дарион Могрейн <Thánátøs-Draenor>",
true,
0,
},
{
true,
440193,
183324,
1729978227.926,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
444741,
184328,
1729978228.921,
1,
"Верховный лорд Дарион Могрейн <Thánátøs-Draenor>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
184328,
1729978228.921,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
52645,
1729978228.967,
1,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
444741,
184328,
1729978229.927,
1,
"Верховный лорд Дарион Могрейн <Thánátøs-Draenor>",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
184328,
1729978229.927,
1,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
3,
48792,
0,
1729978210.676,
0,
"Thánátøs-Draenor",
},
},
["class"] = "DEATHKNIGHT",
["timestring"] = "1m 4s",
["time"] = 1729978233.722,
},
{
["maxhealth"] = 5767060,
["timeofdeath"] = 65.46999999997206,
["name"] = "Nexicdruid-Blackmoore",
["events"] = {
{
true,
440193,
176438,
1729978225.966,
0.8612085081084652,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
382024,
58269,
1729978226.513,
0.8708309938236946,
"Вольтчара",
nil,
0,
},
{
false,
77489,
53748,
1729978226.955,
0.8797070383459391,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
174679,
1729978226.964,
0.8508602239323579,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
185828,
1729978227.96,
0.8201722429566998,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
382024,
60145,
1729978228.296,
0.8301046999372461,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
1002,
1729978228.885,
0.8302701720778148,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
53747,
1729978228.967,
0.8391460514582026,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
185828,
1729978228.975,
0.8084580704825445,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
444094,
2950822,
1729978229.042,
0.3211538461538462,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
22842,
532628,
1729978229.059,
0.4091130230868316,
"Nexicdruid-Blackmoore",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
446342,
433738,
1729978229.544,
0.4807413217954223,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
120692,
155911,
1729978229.556,
0.5064887538395482,
"Shenhé-Draenor",
nil,
0,
},
{
false,
196810,
14842,
1729978229.876,
0.5089397892789906,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
},
{
false,
469421,
15077,
1729978229.889,
0.511429633054794,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
185828,
1729978229.958,
0.480741652079136,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
22842,
532627,
1729978230.09,
0.5687006638702645,
"Nexicdruid-Blackmoore",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
188930,
1729978230.09,
0.5999009148858869,
"Вольтчара",
nil,
0,
false,
false,
nil,
false,
},
{
false,
120692,
225431,
1729978230.257,
0.6371290088185751,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
81269,
23897,
1729978230.924,
0.64107540377184,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
185828,
1729978230.97,
0.610387422796182,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
33110,
95699,
1729978230.982,
0.6261913333553523,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
22842,
532627,
1729978231.064,
0.7141503451464808,
"Nexicdruid-Blackmoore",
nil,
0,
},
{
false,
77489,
88626,
1729978231.575,
0.7287862073521155,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
52042,
300300,
1729978231.825,
0.7783783069656836,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
false,
},
{
false,
382024,
75041,
1729978231.891,
0.7907707170459425,
"Вольтчара",
nil,
0,
false,
-1,
1,
false,
},
{
true,
440193,
181202,
1729978231.963,
0.7608466823000958,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
22842,
532627,
1729978232.061,
0.8488056940912244,
"Nexicdruid-Blackmoore",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
439776,
1,
1729978232.175,
0.8488056940912244,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
false,
2060,
1944832,
1729978232.175,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
2061,
1445512,
1729978232.175,
1,
"Shenhé-Draenor",
nil,
0,
false,
false,
},
{
false,
243241,
42200,
1729978232.184,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
2060,
329570,
1729978232.203,
1,
"Shenhé-Draenor",
nil,
0,
false,
false,
},
{
true,
439776,
1360959,
1729978232.685,
0.7752487036364237,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
33110,
73653,
1729978232.694,
0.7874118968193679,
"Shenhé-Draenor",
nil,
0,
},
{
false,
52042,
113670,
1729978232.838,
0.8061835716880801,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
186806,
1729978232.957,
0.7753340819764177,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1360960,
1729978233.178,
0.5505826204709846,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
432335,
1729978233.562,
0.6219792251544076,
"Shenhé-Draenor",
nil,
0,
},
{
true,
439776,
1360960,
1729978233.684,
0.3972277636489745,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
469421,
9057,
1729978233.888,
0.3987234534465106,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
186806,
1729978233.959,
0.3678739637348482,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1360960,
1729978234.186,
0.1431225022294151,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
452806,
1,
1729978234.394,
0,
"Раша'нан",
},
{
false,
120692,
188388,
1729978234.229,
0.1742332463586221,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1055051,
1729978234.687,
1.651418568550385e-07,
"Раша'нан",
nil,
8,
false,
305908,
false,
false,
},
{
3,
22812,
0,
1729978191.065,
0,
"Nexicdruid-Blackmoore",
},
},
["class"] = "DRUID",
["timestring"] = "1m 5s",
["time"] = 1729978234.695,
},
{
["maxhealth"] = 5869040,
["timeofdeath"] = 65.71199999999953,
["name"] = "Dunkkis-Ravencrest",
["events"] = {
{
4,
440193,
2,
1729978219.962,
0.8188691152676432,
"Раша'нан",
false,
false,
false,
false,
},
{
4,
440193,
3,
1729978220.964,
0.8369158638611846,
"Раша'нан",
false,
false,
false,
false,
},
{
4,
440193,
4,
1729978221.849,
0.7783820799418416,
"Раша'нан",
false,
false,
false,
false,
},
{
4,
440193,
5,
1729978222.82,
0.7608935039140087,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
false,
196810,
12369,
1729978224.938,
0.8012683205462736,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
},
{
false,
120692,
75163,
1729978225.441,
0.8134651958302501,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
166693,
1729978225.814,
0.7864155340057899,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
false,
73921,
121252,
1729978226.23,
0.8060913787955498,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
1064,
81475,
1729978226.392,
0.8193125170385949,
"Вольтчара",
nil,
0,
},
{
false,
77489,
25180,
1729978226.798,
0.8233985343562981,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
165209,
1729978226.807,
0.7965896846724047,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
165209,
1729978227.814,
0.7697808349885111,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
25180,
1729978228.786,
0.7738668523062144,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
165209,
1729978228.815,
0.7470580026223209,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
379032,
1729978228.907,
0.808564409133985,
"Shenhé-Draenor",
nil,
0,
},
{
true,
440193,
161600,
1729978229.805,
0.7823412002959848,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
469421,
15077,
1729978229.889,
0.7847877802443172,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
52042,
258504,
1729978230.03,
0.8267358271345302,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
45276,
1729978230.791,
0.8340828692344641,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
151903,
1729978230.819,
0.8094332151990757,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
387609,
1729978230.873,
0.8723314315016033,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
3,
0,
0,
0,
0,
"Dunkkis-Ravencrest",
},
},
["class"] = "MAGE",
["timestring"] = "1m 5s",
["time"] = 1729978234.937,
},
{
["maxhealth"] = 7286760,
["timeofdeath"] = 67.28899999998976,
["name"] = "Wìntér-Draenor",
["events"] = {
{
false,
469421,
1002,
1729978228.885,
0.9639869142656985,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
169660,
1729978228.981,
0.9418122670263545,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
187113,
1729978229.361,
0.9662680301343078,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
55078,
14890,
1729978229.448,
0.9682141606152334,
"Wìntér-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
143924,
6869,
1729978229.663,
0.9691119423663065,
"Wìntér-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
196810,
24737,
1729978229.876,
0.9723450806944902,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
},
{
false,
469421,
15077,
1729978229.889,
0.9743156521693669,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180488,
1729978229.986,
0.9507257798898979,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
32337,
1729978230.18,
0.9549522420364184,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
55078,
14890,
1729978230.192,
0.956898372517344,
"Wìntér-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
373423,
1729978230.271,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180489,
1729978230.982,
0.9764099970200285,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
240337,
1729978231.034,
1,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
175995,
1729978231.976,
0.9769973650778714,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
17135,
1729978232.167,
0.9792369181867135,
"Wìntér-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
243241,
43758,
1729978232.175,
0.9849561107712898,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
57895,
1729978232.184,
0.9925230163584748,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
55078,
14047,
1729978232.441,
0.9943589663158665,
"Wìntér-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
52042,
105303,
1729978232.838,
1,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
},
{
true,
440193,
181438,
1729978232.981,
0.9762859622432388,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
33110,
141392,
1729978233,
0.9947659676803797,
"Shenhé-Draenor",
nil,
0,
},
{
false,
143924,
3771,
1729978233.321,
0.9952588392749782,
"Wìntér-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
9056,
1729978233.888,
0.9964424630248279,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
55078,
14047,
1729978233.941,
0.9982784129822195,
"Wìntér-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
181438,
1729978233.979,
0.9745643752254584,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
56613,
1729978234.186,
0.9819637227685504,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
6,
452806,
1,
1729978234.394,
0,
"Раша'нан",
},
{
false,
120692,
195001,
1729978234.334,
1,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
439776,
1,
1729978234.475,
1,
"Раша'нан",
false,
false,
false,
false,
false,
false,
},
{
true,
440193,
181439,
1729978234.986,
0.9762858315427364,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
1336058,
1729978234.986,
0.8016623796901875,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
444094,
2757494,
1729978235.125,
0.4412565284900955,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
247103,
1729978235.415,
0.4735530147377887,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
206967,
524900,
1729978235.434,
0.4735530147377887,
"Wìntér-Draenor",
true,
0,
},
{
true,
452806,
2827583,
1729978235.434,
0.1725911897405334,
"Раша'нан",
524900,
8,
false,
-1,
false,
false,
},
{
false,
206967,
420858,
1729978235.476,
0.1725911897405334,
"Wìntér-Draenor",
true,
0,
false,
false,
nil,
false,
},
{
true,
439776,
1202452,
1729978235.476,
0.07043646125775707,
"Раша'нан",
420858,
8,
false,
-1,
false,
false,
},
{
6,
456762,
1,
1729978235.907,
0,
"Раша'нан",
},
{
false,
446342,
433738,
1729978235.757,
0.1271262357732503,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
16662,
1729978235.883,
0.1293039675444513,
"Bùstian-Ragnaros",
nil,
0,
},
{
false,
206967,
57152,
1729978235.982,
0.1293039675444513,
"Wìntér-Draenor",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
163294,
1729978235.982,
0.1154311548173591,
"Раша'нан",
57152,
8,
false,
-1,
false,
false,
},
{
false,
206967,
420858,
1729978235.982,
0.1154311548173591,
"Wìntér-Draenor",
true,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1202452,
1729978235.982,
0.01327642633458283,
"Раша'нан",
420858,
8,
false,
-1,
false,
false,
},
{
false,
77489,
98924,
1729978236.175,
0.02620584283525986,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
206967,
420857,
1729978236.478,
0.02620584283525986,
"Wìntér-Draenor",
true,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
621359,
1729978236.496,
1.307005024127313e-07,
"Раша'нан",
420857,
8,
false,
581092,
false,
false,
},
{
3,
48792,
0,
1729978209.51,
0,
"Wìntér-Draenor",
},
},
["class"] = "DEATHKNIGHT",
["timestring"] = "1m 7s",
["time"] = 1729978236.514,
},
{
["maxhealth"] = 6358340,
["timeofdeath"] = 67.475999999966,
["name"] = "Bùstian-Ragnaros",
["events"] = {
{
4,
440193,
5,
1729978222.989,
0.9199207340636824,
"Раша'нан",
false,
false,
false,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
true,
440193,
173544,
1729978226.807,
0.8932318393831277,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
73921,
22568,
1729978227.009,
0.8966121750800597,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
51954,
1729978227.044,
0.9043940769233073,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
458357,
118716,
1729978227.13,
0.9221758888958789,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
173544,
1729978227.814,
0.8961816945415547,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
81269,
40096,
1729978227.903,
0.9021874522562033,
"Ködex-TwistingNether",
nil,
0,
false,
false,
},
{
true,
440193,
180775,
1729978228.793,
0.875110166470449,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
51953,
1729978229.042,
0.8828919185292364,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
81269,
40293,
1729978229.414,
0.8889271837825369,
"Ködex-TwistingNether",
nil,
0,
},
{
false,
120692,
106081,
1729978229.798,
0.9048164691009637,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180775,
1729978229.798,
0.8777391833152094,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
380020,
1729978229.855,
0.934660273865907,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
196810,
24737,
1729978229.876,
0.9383654920569301,
"Божественный образ <Shenhé-Draenor>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
180775,
1729978230.813,
0.9112882062711758,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
187526,
1729978231.807,
0.883199725594869,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
33110,
74952,
1729978231.825,
0.8944263704529183,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
47301,
1729978231.834,
0.9015113252030328,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
191500,
1729978232.806,
0.8728276010820429,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
232879,
1729978233.615,
0.907709256380069,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
4,
439776,
1,
1729978233.753,
0.907709256380069,
"Раша'нан",
false,
false,
false,
false,
},
{
true,
440193,
180010,
1729978233.806,
0.8807465557063385,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
38828,
1729978233.826,
0.886562386725502,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
120692,
187950,
1729978234.135,
0.9147143760129174,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
6,
452806,
1,
1729978234.394,
0,
"Раша'нан",
},
{
true,
439776,
1423631,
1729978234.263,
0.7014765752082753,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
180010,
1729978234.801,
0.6745138745345448,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
4,
439776,
1,
1729978235.173,
0.6745138745345448,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
false,
52042,
101118,
1729978235.415,
0.6896597795771884,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
452806,
2805325,
1729978235.535,
0.2694656888737108,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
85673,
1703469,
1729978235.55,
0.5246188734411182,
"Bùstian-Ragnaros",
nil,
0,
false,
false,
},
{
true,
439776,
1423631,
1729978235.677,
0.3113810726364761,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
456762,
1,
1729978235.907,
0,
"Раша'нан",
},
{
true,
440193,
180010,
1729978235.799,
0.2844183719627456,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
44174,
1729978235.83,
0.2910349507059342,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
439776,
1423631,
1729978236.175,
0.07779714990129204,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
439776,
519393,
1729978236.687,
1.497844601618271e-07,
"Раша'нан",
nil,
8,
false,
904237,
false,
false,
},
{
3,
0,
0,
0,
0,
"Bùstian-Ragnaros",
},
},
["class"] = "PALADIN",
["timestring"] = "1m 7s",
["time"] = 1729978236.701,
},
{
["maxhealth"] = 6400966,
["timeofdeath"] = 68.07600000000093,
["name"] = "Вольтчара",
["events"] = {
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
false,
143924,
71148,
1729978227.633,
0.946041958041958,
"Вольтчара",
nil,
0,
false,
false,
},
{
true,
440193,
157514,
1729978227.751,
0.9226058622228835,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
81269,
20564,
1729978227.903,
0.9256655259633984,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
30758,
1729978227.903,
0.9302419282844815,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
120692,
365897,
1729978228.444,
0.9846827852998066,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
167569,
1729978228.745,
0.959750632346377,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
9237,
1729978228.835,
0.9611249814015771,
"Вольтчара",
nil,
0,
false,
false,
nil,
false,
},
{
false,
457387,
167568,
1729978229.785,
0.9611249814015771,
"Вольтчара",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
167568,
1729978229.785,
0.9611249814015771,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
45857,
1729978229.903,
0.9679479244160095,
"Shenhé-Draenor",
nil,
0,
false,
false,
},
{
false,
449209,
133099,
1729978230.09,
0.9877513762832911,
"Вольтчара",
nil,
0,
},
{
false,
143924,
11049,
1729978230.468,
0.9893953280761791,
"Вольтчара",
nil,
0,
false,
false,
nil,
false,
},
{
false,
457387,
167568,
1729978230.75,
0.9893953280761791,
"Вольтчара",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
167568,
1729978230.75,
0.9893953280761791,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
457387,
68124,
1729978231.75,
0.9893953280761791,
"Вольтчара",
true,
0,
},
{
true,
440193,
173826,
1729978231.75,
0.9736682041362893,
"Раша'нан",
68124,
8,
false,
-1,
false,
false,
},
{
false,
77489,
45857,
1729978231.92,
0.9804911471507216,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
143924,
3931,
1729978232.167,
0.9810760303526261,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
179203,
1729978232.747,
0.9544128849873531,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
178262,
1729978233.745,
0.927889748549323,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
45857,
1729978233.895,
0.9347126915637554,
"Shenhé-Draenor",
nil,
0,
},
{
false,
52042,
103407,
1729978234.626,
0.9500983484600506,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
},
{
true,
440193,
167567,
1729978234.737,
0.9251664930813867,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
452806,
2778089,
1729978235.322,
0.5118219015027525,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
456762,
1,
1729978235.907,
0,
"Раша'нан",
},
{
true,
440193,
167567,
1729978235.757,
0.4868900461240887,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
167566,
1729978236.749,
0.4619583395328076,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
6,
462434,
5,
1729978237.262,
0,
"Смертельный кошмар",
},
{
true,
1,
3104821,
1729978237.269,
0.4619583395328076,
"Смертельный кошмар",
nil,
1,
false,
5866828,
false,
false,
},
{
true,
1,
3104821,
1729978237.269,
0.4619583395328076,
"Смертельный кошмар",
nil,
1,
false,
2729813,
false,
false,
},
{
true,
1,
3104821,
1729978237.269,
0.4619583395328076,
"Смертельный кошмар",
nil,
1,
false,
6220914,
false,
false,
},
{
true,
1,
3104821,
1729978237.269,
0.4619583395328076,
"Смертельный кошмар",
nil,
1,
false,
6316504,
false,
false,
},
{
true,
1,
3104821,
1729978237.269,
0.4619583395328076,
"Смертельный кошмар",
nil,
1,
false,
6263590,
false,
false,
},
{
3,
108271,
0,
1729978191.567,
0,
"Вольтчара",
},
},
["class"] = "SHAMAN",
["timestring"] = "1m 8s",
["time"] = 1729978237.301,
},
{
["maxhealth"] = 5807760,
["timeofdeath"] = 70.78899999998976,
["name"] = "Monkeypîe-Draenor",
["events"] = {
{
4,
439776,
1,
1729978225.721,
0.8006993935855851,
"Раша'нан",
false,
false,
false,
false,
nil,
false,
},
{
6,
456853,
1,
1729978226.406,
0,
"Раша'нан",
},
{
false,
8936,
13003,
1729978230.468,
0.6775972673634911,
"Ködex-TwistingNether",
nil,
0,
},
{
true,
440193,
196521,
1729978231.01,
0.6453708835808951,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
1714,
1729978231.69,
0.6456519528905535,
"Monkeypîe-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
426605,
60982,
1729978231.703,
0.6556520512812103,
"Monkeypîe-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
203860,
1729978232.003,
0.6222221857812382,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
8936,
10828,
1729978232.081,
0.6239978091680414,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
203859,
1729978233,
0.5905681076524973,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
8936,
10828,
1729978233.692,
0.5923437310393005,
"Ködex-TwistingNether",
nil,
0,
},
{
true,
440193,
203615,
1729978233.998,
0.5589540417241978,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
143924,
3786,
1729978234.135,
0.5595748867687524,
"Monkeypîe-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
426605,
60982,
1729978234.687,
0.5695749851594093,
"Monkeypîe-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
false,
8936,
8113,
1729978234.905,
0.5709053908240873,
"Ködex-TwistingNether",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
203615,
1729978234.994,
0.5375157015089848,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
452806,
3173193,
1729978235.158,
0.01716146234753548,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
31230,
203615,
1729978236.012,
0.01716146234753548,
"Monkeypîe-Draenor",
true,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
203615,
1729978236.012,
0.01716146234753548,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
30542,
1729978236.994,
0.01215304994637709,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
426605,
60981,
1729978237.688,
0.02215298435260588,
"Monkeypîe-Draenor",
nil,
0,
false,
false,
},
{
true,
440193,
30542,
1729978238.001,
0.01714457195144749,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
30542,
1729978239.013,
0.01213615955028911,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
74007,
1729978240.014,
1.639844280387134e-07,
"Раша'нан",
nil,
8,
false,
129608,
false,
false,
},
{
3,
0,
0,
0,
0,
"Monkeypîe-Draenor",
},
},
["class"] = "ROGUE",
["timestring"] = "1m 10s",
["time"] = 1729978240.014,
},
{
["maxhealth"] = 6534704,
["timeofdeath"] = 72.36800000001676,
["name"] = "Lgrtha-Silvermoon",
["events"] = {
{
false,
52042,
110398,
1729978231.825,
0.920240049225919,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
false,
nil,
false,
},
{
false,
382024,
55572,
1729978231.891,
0.9283392402687138,
"Вольтчара",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
469421,
12225,
1729978231.899,
0.9301209398745975,
"Bùstian-Ragnaros",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
382024,
430,
1729978231.92,
0.9301836090631889,
"Вольтчара",
nil,
0,
},
{
true,
440193,
164900,
1729978231.928,
0.9061507039498786,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
243241,
43053,
1729978232.175,
0.9124253471508692,
"Shenhé-Draenor",
nil,
0,
},
{
false,
449209,
286974,
1729978232.734,
0.9542495976783835,
"Lgrtha-Silvermoon",
nil,
0,
false,
false,
nil,
false,
},
{
false,
143924,
13024,
1729978232.915,
0.956147745381208,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
170000,
1729978232.93,
0.9313715545427438,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
33535,
1729978233.549,
0.9362590225413784,
"Shenhé-Draenor",
nil,
0,
false,
false,
},
{
false,
52042,
99889,
1729978233.615,
0.9508170750511629,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
},
{
true,
440193,
170000,
1729978233.929,
0.9260408842126986,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
120692,
188058,
1729978234.135,
0.9534488894874039,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
52042,
224971,
1729978234.626,
0.9862366802469341,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
false,
},
{
true,
440193,
170000,
1729978234.937,
0.96146048940847,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
452806,
2649324,
1729978235.535,
0.5753419187206857,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
379,
96895,
1729978235.535,
0.5894636187871151,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
77489,
40657,
1729978235.55,
0.5953890634395824,
"Shenhé-Draenor",
nil,
0,
},
{
6,
456762,
1,
1729978235.907,
0,
"Раша'нан",
},
{
true,
440193,
170000,
1729978235.937,
0.5706128726011181,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
52042,
104839,
1729978236.429,
0.5858923494911991,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
170000,
1729978236.932,
0.5611161586527349,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
243241,
43772,
1729978236.994,
0.5674955905667423,
"Shenhé-Draenor",
nil,
0,
},
{
6,
462434,
5,
1729978237.262,
0,
"Смертельный кошмар",
},
{
false,
52042,
101872,
1729978237.213,
0.5823426500555424,
"Тотем исцеляющего потока <Вольтчара>",
nil,
0,
false,
false,
},
{
false,
77489,
31364,
1729978237.551,
0.58691371152294,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
170000,
1729978237.93,
0.5621375206844758,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
169999,
1729978238.938,
0.5373614755883106,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
31364,
1729978239.555,
0.5419325370557082,
"Shenhé-Draenor",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
444094,
2655852,
1729978239.832,
0.1548625606397271,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
31616,
1372285,
1729978239.84,
0.3548625314912673,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
false,
379,
218365,
1729978239.853,
0.3866875486232745,
"Lgrtha-Silvermoon",
nil,
0,
false,
-1,
nil,
false,
},
{
true,
440193,
170000,
1729978239.922,
0.3619113577848103,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
true,
440193,
170000,
1729978240.935,
0.3371351669463462,
"Раша'нан",
nil,
8,
false,
-1,
false,
false,
},
{
false,
77489,
31364,
1729978241.547,
0.3417062284137437,
"Shenhé-Draenor",
nil,
0,
false,
false,
nil,
false,
},
{
true,
452806,
2344591,
1729978241.593,
1.457422990497894e-07,
"Раша'нан",
nil,
8,
false,
1629394,
false,
false,
},
{
3,
0,
0,
0,
0,
"Lgrtha-Silvermoon",
},
},
["class"] = "SHAMAN",
["timestring"] = "1m 12s",
["time"] = 1729978241.593,
},
},
["bossname"] = "Раша'нан",
["bossicon"] = {
0,
1,
0,
1,
5907275,
32,
20,
0,
1,
0,
0.9,
},
["date"] = 289181.917,
["timeelapsed"] = 72.64100000000326,
},
},
["spellIdCache"] = {
["Брызги крови"] = 442530,
["Голодный рев"] = 438012,
["Призыв роя"] = 438801,
["Кинжалы Нексуса"] = 439576,
["Бешеное обжорство"] = 445422,
["Космический апокалипсис"] = 448458,
["Фазовые клинки"] = 433519,
["Вспышка тени"] = 447950,
["Кровавый потоп"] = 442799,
["Изгоняющий луч"] = 451600,
["Беззвездная ночь"] = 435405,
["Воплощение ужаса"] = 445174,
["Проникающий удар"] = 438218,
["Град стрел"] = 439559,
["Энтропия катаклизма"] = 438355,
["Шаг через Бездну"] = 450483,
["Ядовитый заряд"] = 438200,
["Выпущенный рой"] = 442994,
["Стрела Бездны"] = 441772,
["Заглатывание"] = 443336,
["Глоток черной крови"] = 442432,
["Извержение шипов"] = 443068,
["Зараженный укус"] = 455287,
["Призрачный удар"] = 445016,
["Ядовитая плеть"] = 435136,
["Безжалостное сокрушение"] = 434697,
["Паутинные нити"] = 439784,
["Ленточка Прелести"] = 72968,
["Подземное извержение"] = 441791,
["Паутинная бомба"] = 439838,
["Берсерк"] = 47008,
["Путь сквозь Бездну"] = 451510,
["Ядовитый дождь"] = 438343,
["Мутация: некротизация"] = 446694,
["Скрежещущий рой"] = 445052,
["Жалящий рой"] = 438677,
["Кислотная реакция"] = 450661,
["Липкий выброс"] = 439792,
["Неумолимый рывок"] = 436203,
["Нити реальности"] = 441782,
["Кольцо яда"] = 437417,
["Безрассудный рывок"] = 440246,
["Смертельный кошмар"] = 462434,
["Насыщение глубин"] = 443888,
["Буря шипов"] = 451277,
["Игра хищника"] = 434803,
["Черный сепсис"] = 438679,
["Разрушительный взмах"] = 456420,
["Пронзающее извержение"] = 440504,
["Закапывание"] = 456174,
["Яростный укус"] = 438807,
["Брызгающее кровотечение"] = 442635,
["Панцирекрушитель"] = 438794,
["Кислотный град"] = 456762,
["Багровый дождь"] = 443203,
["Пиршество"] = 437093,
["Разлом Пустоты"] = 463609,
["Энтропическое опустошение"] = 450129,
["Зараженное порождение"] = 455373,
["Кислотная стрела"] = 448660,
["Разлив кислоты"] = 439789,
["Укрепление панциря"] = 438706,
["Кислотное извержение"] = 452806,
["Паутинные клинки"] = 439299,
["Липкая паутина"] = 446344,
["Вечная ночь"] = 442277,
["Тяжелое сокрушение"] = 435341,
["Жнец"] = 436749,
["Шелковая гробница"] = 439814,
["Разжижение"] = 440899,
["Выявление слабости"] = 435401,
["Внушение ужаса"] = 444497,
["Ликвидация"] = 436923,
["Хищничество"] = 447076,
["Черный бастион"] = 451288,
["Смена фаз"] = 441425,
["Рассекание паутины"] = 439795,
["Космический осадок"] = 459782,
["Королевский приговор"] = 438976,
["Юркий прыжок"] = 450045,
["Поглощающий мрак"] = 443842,
["Дикий натиск"] = 444687,
["Сосредоточение скарабея"] = 438749,
["Выброс яда"] = 446700,
["Раскол мироздания"] = 450980,
["Сосредоточение внимания"] = 442251,
["Фазовый выпад"] = 435403,
["Сумеречная резня"] = 438153,
["Истребление"] = 442428,
["Желудочный сок"] = 435138,
["Нестабильная смесь"] = 443003,
["Вихрь паутины"] = 441626,
["Запутывание"] = 440179,
["Разъедающие брызги"] = 439811,
["Космический симулякр"] = 458272,
["Заражение"] = 442257,
["Реактивный токсин"] = 437592,
["Экспериментальная доза"] = 442526,
["Свертывание крови"] = 452237,
["Исчезновение оружия"] = 461547,
["Паутина ловчего"] = 441452,
["Мутация: ускорение"] = 442263,
["Единение во мраке"] = 449986,
["Мутация: прожорливость"] = 446690,
["Опутывающие сети"] = 455084,
["Потрошение"] = 439037,
["Вырывание"] = 450191,
["Раздирание Бездны"] = 440407,
["Космические осколки"] = 459273,
["Отвратительная отрыжка"] = 444363,
["Парализующий яд"] = 447456,
["Изгнание"] = 448147,
["Биоактивные иглы"] = 455870,
["Потусторонняя хватка"] = 443031,
},
["enemySpellCasts"] = {
["2922-14"] = {
["Пиршество"] = {
{
12,
1726161473,
},
{
52,
1726161473,
},
{
14,
1726161709,
},
{
14,
1726161980,
},
{
54,
1726161980,
},
{
13,
1726162513,
},
{
53,
1726162513,
},
{
108,
1726162513,
},
{
13,
1726163264,
},
{
53,
1726163264,
},
{
108,
1726163264,
},
{
13,
1726163864,
},
{
53,
1726163864,
},
{
108,
1726163864,
},
{
14,
1726164361,
},
{
54,
1726164361,
},
{
109,
1726164361,
},
{
13,
1726164899,
},
{
53,
1726164899,
},
{
108,
1726164899,
},
{
13,
1726698706,
},
{
53,
1726698706,
},
{
108,
1726698706,
},
{
13,
1726699214,
},
{
53,
1726699214,
},
{
108,
1726699214,
},
{
13,
1726699888,
},
{
53,
1726699888,
},
{
108,
1726699888,
},
},
["Космический апокалипсис"] = {
{
276,
1726163264,
},
{
267,
1726163864,
},
},
["Вспышка тени"] = {
{
303,
1726163864,
},
{
270,
1726698706,
},
},
["Кислотная стрела"] = {
{
188,
1726162513,
},
{
193,
1726162513,
},
{
198,
1726162513,
},
{
203,
1726162513,
},
{
208,
1726162513,
},
{
186,
1726163264,
},
{
191,
1726163264,
},
{
196,
1726163264,
},
{
201,
1726163264,
},
{
177,
1726163864,
},
{
182,
1726163864,
},
{
187,
1726163864,
},
{
192,
1726163864,
},
{
197,
1726163864,
},
{
169,
1726164361,
},
{
174,
1726164361,
},
{
179,
1726164361,
},
{
184,
1726164361,
},
{
189,
1726164361,
},
{
168,
1726164899,
},
{
173,
1726164899,
},
{
178,
1726164899,
},
{
183,
1726164899,
},
{
156,
1726698706,
},
{
161,
1726698706,
},
{
166,
1726698706,
},
{
171,
1726698706,
},
{
176,
1726698706,
},
{
151,
1726699214,
},
{
156,
1726699214,
},
{
161,
1726699214,
},
{
166,
1726699214,
},
{
149,
1726699888,
},
{
154,
1726699888,
},
{
159,
1726699888,
},
{
164,
1726699888,
},
},
["Парализующий яд"] = {
{
158,
1726162513,
},
{
162,
1726162513,
},
{
166,
1726162513,
},
{
177,
1726162513,
},
{
159,
1726163264,
},
{
163,
1726163264,
},
{
167,
1726163264,
},
{
178,
1726163264,
},
{
151,
1726163864,
},
{
155,
1726163864,
},
{
159,
1726163864,
},
{
152,
1726164361,
},
{
156,
1726164361,
},
{
160,
1726164361,
},
{
149,
1726164899,
},
{
153,
1726164899,
},
{
157,
1726164899,
},
{
129,
1726698706,
},
{
133,
1726698706,
},
{
137,
1726698706,
},
{
129,
1726699214,
},
{
133,
1726699214,
},
{
137,
1726699214,
},
{
129,
1726699888,
},
{
133,
1726699888,
},
{
137,
1726699888,
},
},
["Паутинные клинки"] = {
{
77,
1726161980,
},
{
78,
1726161980,
},
{
76,
1726162513,
},
{
77,
1726162513,
},
{
78,
1726162513,
},
{
124,
1726162513,
},
{
125,
1726162513,
},
{
126,
1726162513,
},
{
76,
1726163264,
},
{
77,
1726163264,
},
{
124,
1726163264,
},
{
125,
1726163264,
},
{
76,
1726163864,
},
{
77,
1726163864,
},
{
124,
1726163864,
},
{
125,
1726163864,
},
{
77,
1726164361,
},
{
78,
1726164361,
},
{
125,
1726164361,
},
{
126,
1726164361,
},
{
76,
1726164899,
},
{
77,
1726164899,
},
{
124,
1726164899,
},
{
125,
1726164899,
},
{
76,
1726698706,
},
{
77,
1726698706,
},
{
76,
1726699214,
},
{
77,
1726699214,
},
{
76,
1726699888,
},
{
77,
1726699888,
},
},
["Реактивный токсин"] = {
{
18,
1726161473,
},
{
20,
1726161709,
},
{
20,
1726161980,
},
{
76,
1726161980,
},
{
19,
1726162513,
},
{
75,
1726162513,
},
{
131,
1726162513,
},
{
19,
1726163264,
},
{
75,
1726163264,
},
{
131,
1726163264,
},
{
19,
1726163864,
},
{
75,
1726163864,
},
{
131,
1726163864,
},
{
20,
1726164361,
},
{
76,
1726164361,
},
{
132,
1726164361,
},
{
19,
1726164899,
},
{
75,
1726164899,
},
{
19,
1726698706,
},
{
75,
1726698706,
},
{
19,
1726699214,
},
{
75,
1726699214,
},
{
19,
1726699888,
},
{
75,
1726699888,
},
},
["Шелковая гробница"] = {
{
64,
1726161980,
},
{
63,
1726162513,
},
{
117,
1726162513,
},
{
63,
1726163264,
},
{
117,
1726163264,
},
{
63,
1726163864,
},
{
117,
1726163864,
},
{
64,
1726164361,
},
{
118,
1726164361,
},
{
63,
1726164899,
},
{
117,
1726164899,
},
{
63,
1726698706,
},
{
63,
1726699214,
},
{
63,
1726699888,
},
},
["Разжижение"] = {
{
9,
1726161473,
},
{
49,
1726161473,
},
{
10,
1726161709,
},
{
10,
1726161980,
},
{
50,
1726161980,
},
{
105,
1726161980,
},
{
10,
1726162513,
},
{
50,
1726162513,
},
{
105,
1726162513,
},
{
9,
1726163264,
},
{
50,
1726163264,
},
{
105,
1726163264,
},
{
10,
1726163864,
},
{
50,
1726163864,
},
{
105,
1726163864,
},
{
10,
1726164361,
},
{
50,
1726164361,
},
{
105,
1726164361,
},
{
10,
1726164899,
},
{
50,
1726164899,
},
{
105,
1726164899,
},
{
10,
1726698706,
},
{
50,
1726698706,
},
{
105,
1726698706,
},
{
9,
1726699214,
},
{
49,
1726699214,
},
{
104,
1726699214,
},
{
9,
1726699888,
},
{
49,
1726699888,
},
{
104,
1726699888,
},
},
["Изгоняющий луч"] = {
{
218,
1726162513,
},
{
228,
1726162513,
},
{
238,
1726162513,
},
{
215,
1726163264,
},
{
225,
1726163264,
},
{
235,
1726163264,
},
{
257,
1726163264,
},
{
267,
1726163264,
},
{
270,
1726163264,
},
{
278,
1726163264,
},
{
280,
1726163264,
},
{
207,
1726163864,
},
{
208,
1726163864,
},
{
217,
1726163864,
},
{
218,
1726163864,
},
{
245,
1726163864,
},
{
246,
1726163864,
},
{
255,
1726163864,
},
{
256,
1726163864,
},
{
199,
1726164361,
},
{
209,
1726164361,
},
{
227,
1726164361,
},
{
231,
1726164361,
},
{
237,
1726164361,
},
{
197,
1726164899,
},
{
207,
1726164899,
},
{
223,
1726164899,
},
{
224,
1726164899,
},
{
233,
1726164899,
},
{
234,
1726164899,
},
{
188,
1726698706,
},
{
189,
1726698706,
},
{
198,
1726698706,
},
{
199,
1726698706,
},
{
224,
1726698706,
},
{
234,
1726698706,
},
{
180,
1726699214,
},
{
190,
1726699214,
},
{
215,
1726699214,
},
{
216,
1726699214,
},
{
225,
1726699214,
},
{
226,
1726699214,
},
{
177,
1726699888,
},
{
187,
1726699888,
},
{
210,
1726699888,
},
{
220,
1726699888,
},
},
["Хищничество"] = {
{
146,
1726162513,
},
{
148,
1726163264,
},
{
140,
1726163864,
},
{
140,
1726164361,
},
{
138,
1726164899,
},
{
118,
1726698706,
},
{
117,
1726699214,
},
{
117,
1726699888,
},
},
["Кольцо яда"] = {
{
34,
1726161473,
},
{
36,
1726161709,
},
{
36,
1726161980,
},
{
92,
1726161980,
},
{
35,
1726162513,
},
{
91,
1726162513,
},
{
35,
1726163264,
},
{
91,
1726163264,
},
{
35,
1726163864,
},
{
91,
1726163864,
},
{
36,
1726164361,
},
{
92,
1726164361,
},
{
35,
1726164899,
},
{
91,
1726164899,
},
{
35,
1726698706,
},
{
91,
1726698706,
},
{
35,
1726699214,
},
{
91,
1726699214,
},
{
35,
1726699888,
},
{
91,
1726699888,
},
},
["Вырывание"] = {
{
154,
1726162513,
},
{
173,
1726162513,
},
{
218,
1726162513,
},
{
226,
1726162513,
},
{
234,
1726162513,
},
{
242,
1726162513,
},
{
156,
1726163264,
},
{
175,
1726163264,
},
{
215,
1726163264,
},
{
223,
1726163264,
},
{
231,
1726163264,
},
{
239,
1726163264,
},
{
260,
1726163264,
},
{
268,
1726163264,
},
{
276,
1726163264,
},
{
148,
1726163864,
},
{
167,
1726163864,
},
{
208,
1726163864,
},
{
216,
1726163864,
},
{
224,
1726163864,
},
{
247,
1726163864,
},
{
255,
1726163864,
},
{
263,
1726163864,
},
{
148,
1726164361,
},
{
199,
1726164361,
},
{
207,
1726164361,
},
{
215,
1726164361,
},
{
229,
1726164361,
},
{
237,
1726164361,
},
{
146,
1726164899,
},
{
197,
1726164899,
},
{
205,
1726164899,
},
{
225,
1726164899,
},
{
233,
1726164899,
},
{
126,
1726698706,
},
{
145,
1726698706,
},
{
189,
1726698706,
},
{
197,
1726698706,
},
{
205,
1726698706,
},
{
225,
1726698706,
},
{
233,
1726698706,
},
{
241,
1726698706,
},
{
125,
1726699214,
},
{
180,
1726699214,
},
{
188,
1726699214,
},
{
196,
1726699214,
},
{
216,
1726699214,
},
{
224,
1726699214,
},
{
232,
1726699214,
},
{
125,
1726699888,
},
{
177,
1726699888,
},
{
185,
1726699888,
},
{
193,
1726699888,
},
{
213,
1726699888,
},
{
221,
1726699888,
},
},
["Насыщение глубин"] = {
{
330,
1726164899,
},
{
313,
1726699888,
},
},
["Заражение"] = {
{
302,
1726164361,
},
{
303,
1726164899,
},
{
300,
1726699214,
},
{
286,
1726699888,
},
},
["Заглатывание"] = {
{
308,
1726164361,
},
{
308,
1726164899,
},
{
306,
1726699214,
},
{
291,
1726699888,
},
},
["Королевский приговор"] = {
{
321,
1726164361,
},
{
321,
1726164899,
},
{
319,
1726699214,
},
{
304,
1726699888,
},
},
["Изгнание"] = {
{
217,
1726162513,
},
{
227,
1726162513,
},
{
237,
1726162513,
},
{
214,
1726163264,
},
{
224,
1726163264,
},
{
206,
1726163864,
},
{
207,
1726163864,
},
{
198,
1726164361,
},
{
199,
1726164361,
},
{
196,
1726164899,
},
{
188,
1726698706,
},
{
179,
1726699214,
},
{
176,
1726699888,
},
},
["Единение во мраке"] = {
{
291,
1726164361,
},
{
292,
1726164899,
},
{
289,
1726699214,
},
{
275,
1726699888,
},
},
["Бешеное обжорство"] = {
{
345,
1726164899,
},
},
},
["2898-16"] = {
["Истребление"] = {
{
54,
1728495059,
},
{
80,
1728495059,
},
{
53,
1728495358,
},
{
80,
1728495358,
},
{
153,
1728495358,
},
{
180,
1728495358,
},
{
54,
1728495746,
},
{
81,
1728495746,
},
{
154,
1728495746,
},
{
181,
1728495746,
},
{
252,
1728495746,
},
{
53,
1728496261,
},
{
80,
1728496261,
},
{
153,
1728496261,
},
{
181,
1728496261,
},
{
250,
1728496261,
},
{
278,
1728496261,
},
{
349,
1728496261,
},
{
377,
1728496261,
},
{
54,
1728496739,
},
{
81,
1728496739,
},
{
153,
1728496739,
},
{
181,
1728496739,
},
{
250,
1728496739,
},
{
278,
1728496739,
},
{
349,
1728496739,
},
{
377,
1728496739,
},
{
54,
1729187711,
},
{
80,
1729187711,
},
{
53,
1729975956,
},
{
81,
1729975956,
},
{
153,
1729975956,
},
{
181,
1729975956,
},
{
252,
1729975956,
},
{
279,
1729975956,
},
},
["Фазовый выпад"] = {
{
10,
1728495059,
},
{
35,
1728495059,
},
{
61,
1728495059,
},
{
86,
1728495059,
},
{
9,
1728495358,
},
{
35,
1728495358,
},
{
60,
1728495358,
},
{
86,
1728495358,
},
{
107,
1728495358,
},
{
133,
1728495358,
},
{
160,
1728495358,
},
{
187,
1728495358,
},
{
11,
1728495746,
},
{
37,
1728495746,
},
{
62,
1728495746,
},
{
88,
1728495746,
},
{
107,
1728495746,
},
{
134,
1728495746,
},
{
161,
1728495746,
},
{
187,
1728495746,
},
{
205,
1728495746,
},
{
232,
1728495746,
},
{
11,
1728496261,
},
{
36,
1728496261,
},
{
62,
1728496261,
},
{
87,
1728496261,
},
{
107,
1728496261,
},
{
134,
1728496261,
},
{
160,
1728496261,
},
{
187,
1728496261,
},
{
204,
1728496261,
},
{
231,
1728496261,
},
{
257,
1728496261,
},
{
284,
1728496261,
},
{
302,
1728496261,
},
{
329,
1728496261,
},
{
356,
1728496261,
},
{
383,
1728496261,
},
{
401,
1728496261,
},
{
11,
1728496739,
},
{
37,
1728496739,
},
{
62,
1728496739,
},
{
88,
1728496739,
},
{
107,
1728496739,
},
{
134,
1728496739,
},
{
161,
1728496739,
},
{
188,
1728496739,
},
{
204,
1728496739,
},
{
231,
1728496739,
},
{
258,
1728496739,
},
{
285,
1728496739,
},
{
303,
1728496739,
},
{
330,
1728496739,
},
{
356,
1728496739,
},
{
9,
1729187711,
},
{
35,
1729187711,
},
{
61,
1729187711,
},
{
10,
1729975956,
},
{
36,
1729975956,
},
{
62,
1729975956,
},
{
88,
1729975956,
},
{
107,
1729975956,
},
{
134,
1729975956,
},
{
161,
1729975956,
},
{
188,
1729975956,
},
{
205,
1729975956,
},
{
232,
1729975956,
},
{
259,
1729975956,
},
{
286,
1729975956,
},
{
304,
1729975956,
},
},
["Выявление слабости"] = {
{
7,
1728495059,
},
{
8,
1728495059,
},
{
32,
1728495059,
},
{
33,
1728495059,
},
{
58,
1728495059,
},
{
59,
1728495059,
},
{
83,
1728495059,
},
{
85,
1728495059,
},
{
6,
1728495358,
},
{
8,
1728495358,
},
{
32,
1728495358,
},
{
33,
1728495358,
},
{
57,
1728495358,
},
{
59,
1728495358,
},
{
83,
1728495358,
},
{
84,
1728495358,
},
{
104,
1728495358,
},
{
105,
1728495358,
},
{
130,
1728495358,
},
{
132,
1728495358,
},
{
157,
1728495358,
},
{
158,
1728495358,
},
{
184,
1728495358,
},
{
185,
1728495358,
},
{
8,
1728495746,
},
{
9,
1728495746,
},
{
34,
1728495746,
},
{
35,
1728495746,
},
{
59,
1728495746,
},
{
60,
1728495746,
},
{
85,
1728495746,
},
{
86,
1728495746,
},
{
104,
1728495746,
},
{
105,
1728495746,
},
{
131,
1728495746,
},
{
132,
1728495746,
},
{
157,
1728495746,
},
{
159,
1728495746,
},
{
184,
1728495746,
},
{
185,
1728495746,
},
{
202,
1728495746,
},
{
204,
1728495746,
},
{
229,
1728495746,
},
{
230,
1728495746,
},
{
256,
1728495746,
},
{
8,
1728496261,
},
{
9,
1728496261,
},
{
33,
1728496261,
},
{
34,
1728496261,
},
{
59,
1728496261,
},
{
60,
1728496261,
},
{
84,
1728496261,
},
{
86,
1728496261,
},
{
104,
1728496261,
},
{
105,
1728496261,
},
{
130,
1728496261,
},
{
132,
1728496261,
},
{
157,
1728496261,
},
{
159,
1728496261,
},
{
184,
1728496261,
},
{
185,
1728496261,
},
{
201,
1728496261,
},
{
202,
1728496261,
},
{
228,
1728496261,
},
{
229,
1728496261,
},
{
254,
1728496261,
},
{
256,
1728496261,
},
{
281,
1728496261,
},
{
282,
1728496261,
},
{
299,
1728496261,
},
{
301,
1728496261,
},
{
326,
1728496261,
},
{
327,
1728496261,
},
{
353,
1728496261,
},
{
354,
1728496261,
},
{
380,
1728496261,
},
{
381,
1728496261,
},
{
398,
1728496261,
},
{
399,
1728496261,
},
{
8,
1728496739,
},
{
9,
1728496739,
},
{
34,
1728496739,
},
{
35,
1728496739,
},
{
59,
1728496739,
},
{
60,
1728496739,
},
{
85,
1728496739,
},
{
86,
1728496739,
},
{
104,
1728496739,
},
{
105,
1728496739,
},
{
131,
1728496739,
},
{
132,
1728496739,
},
{
158,
1728496739,
},
{
159,
1728496739,
},
{
184,
1728496739,
},
{
186,
1728496739,
},
{
201,
1728496739,
},
{
203,
1728496739,
},
{
228,
1728496739,
},
{
229,
1728496739,
},
{
255,
1728496739,
},
{
256,
1728496739,
},
{
282,
1728496739,
},
{
283,
1728496739,
},
{
300,
1728496739,
},
{
301,
1728496739,
},
{
327,
1728496739,
},
{
328,
1728496739,
},
{
353,
1728496739,
},
{
355,
1728496739,
},
{
380,
1728496739,
},
{
6,
1729187711,
},
{
8,
1729187711,
},
{
32,
1729187711,
},
{
33,
1729187711,
},
{
58,
1729187711,
},
{
59,
1729187711,
},
{
83,
1729187711,
},
{
7,
1729975956,
},
{
9,
1729975956,
},
{
33,
1729975956,
},
{
34,
1729975956,
},
{
59,
1729975956,
},
{
60,
1729975956,
},
{
85,
1729975956,
},
{
86,
1729975956,
},
{
104,
1729975956,
},
{
105,
1729975956,
},
{
131,
1729975956,
},
{
132,
1729975956,
},
{
158,
1729975956,
},
{
159,
1729975956,
},
{
185,
1729975956,
},
{
186,
1729975956,
},
{
202,
1729975956,
},
{
203,
1729975956,
},
{
229,
1729975956,
},
{
230,
1729975956,
},
{
256,
1729975956,
},
{
257,
1729975956,
},
{
283,
1729975956,
},
{
284,
1729975956,
},
{
300,
1729975956,
},
{
302,
1729975956,
},
},
["Фазовые клинки"] = {
{
12,
1728495059,
},
{
18,
1728495059,
},
{
40,
1728495059,
},
{
46,
1728495059,
},
{
68,
1728495059,
},
{
74,
1728495059,
},
{
11,
1728495358,
},
{
17,
1728495358,
},
{
39,
1728495358,
},
{
45,
1728495358,
},
{
67,
1728495358,
},
{
73,
1728495358,
},
{
112,
1728495358,
},
{
118,
1728495358,
},
{
140,
1728495358,
},
{
146,
1728495358,
},
{
168,
1728495358,
},
{
174,
1728495358,
},
{
13,
1728495746,
},
{
19,
1728495746,
},
{
41,
1728495746,
},
{
47,
1728495746,
},
{
69,
1728495746,
},
{
75,
1728495746,
},
{
110,
1728495746,
},
{
116,
1728495746,
},
{
138,
1728495746,
},
{
144,
1728495746,
},
{
166,
1728495746,
},
{
172,
1728495746,
},
{
209,
1728495746,
},
{
215,
1728495746,
},
{
237,
1728495746,
},
{
243,
1728495746,
},
{
12,
1728496261,
},
{
18,
1728496261,
},
{
39,
1728496261,
},
{
46,
1728496261,
},
{
67,
1728496261,
},
{
73,
1728496261,
},
{
110,
1728496261,
},
{
116,
1728496261,
},
{
138,
1728496261,
},
{
144,
1728496261,
},
{
166,
1728496261,
},
{
172,
1728496261,
},
{
207,
1728496261,
},
{
213,
1728496261,
},
{
235,
1728496261,
},
{
241,
1728496261,
},
{
263,
1728496261,
},
{
269,
1728496261,
},
{
306,
1728496261,
},
{
312,
1728496261,
},
{
334,
1728496261,
},
{
340,
1728496261,
},
{
362,
1728496261,
},
{
368,
1728496261,
},
{
13,
1728496739,
},
{
19,
1728496739,
},
{
41,
1728496739,
},
{
47,
1728496739,
},
{
69,
1728496739,
},
{
75,
1728496739,
},
{
113,
1728496739,
},
{
119,
1728496739,
},
{
141,
1728496739,
},
{
147,
1728496739,
},
{
169,
1728496739,
},
{
175,
1728496739,
},
{
210,
1728496739,
},
{
216,
1728496739,
},
{
238,
1728496739,
},
{
244,
1728496739,
},
{
266,
1728496739,
},
{
272,
1728496739,
},
{
306,
1728496739,
},
{
312,
1728496739,
},
{
334,
1728496739,
},
{
340,
1728496739,
},
{
362,
1728496739,
},
{
368,
1728496739,
},
{
12,
1729187711,
},
{
18,
1729187711,
},
{
40,
1729187711,
},
{
46,
1729187711,
},
{
68,
1729187711,
},
{
74,
1729187711,
},
{
12,
1729975956,
},
{
18,
1729975956,
},
{
41,
1729975956,
},
{
47,
1729975956,
},
{
69,
1729975956,
},
{
75,
1729975956,
},
{
109,
1729975956,
},
{
115,
1729975956,
},
{
137,
1729975956,
},
{
144,
1729975956,
},
{
166,
1729975956,
},
{
172,
1729975956,
},
{
207,
1729975956,
},
{
213,
1729975956,
},
{
235,
1729975956,
},
{
241,
1729975956,
},
{
263,
1729975956,
},
{
269,
1729975956,
},
{
306,
1729975956,
},
{
312,
1729975956,
},
},
["Исчезновение оружия"] = {
{
381,
1728496739,
},
},
["Космические осколки"] = {
{
54,
1728495059,
},
{
74,
1728495059,
},
{
80,
1728495059,
},
{
54,
1728495358,
},
{
73,
1728495358,
},
{
80,
1728495358,
},
{
96,
1728495358,
},
{
147,
1728495358,
},
{
153,
1728495358,
},
{
180,
1728495358,
},
{
48,
1728495746,
},
{
54,
1728495746,
},
{
81,
1728495746,
},
{
96,
1728495746,
},
{
154,
1728495746,
},
{
182,
1728495746,
},
{
195,
1728495746,
},
{
243,
1728495746,
},
{
252,
1728495746,
},
{
54,
1728496261,
},
{
80,
1728496261,
},
{
144,
1728496261,
},
{
154,
1728496261,
},
{
173,
1728496261,
},
{
182,
1728496261,
},
{
242,
1728496261,
},
{
251,
1728496261,
},
{
279,
1728496261,
},
{
312,
1728496261,
},
{
341,
1728496261,
},
{
349,
1728496261,
},
{
368,
1728496261,
},
{
377,
1728496261,
},
{
390,
1728496261,
},
{
54,
1728496739,
},
{
81,
1728496739,
},
{
96,
1728496739,
},
{
147,
1728496739,
},
{
153,
1728496739,
},
{
181,
1728496739,
},
{
194,
1728496739,
},
{
245,
1728496739,
},
{
250,
1728496739,
},
{
278,
1728496739,
},
{
292,
1728496739,
},
{
349,
1728496739,
},
{
350,
1728496739,
},
{
368,
1728496739,
},
{
377,
1728496739,
},
{
378,
1728496739,
},
{
54,
1729187711,
},
{
74,
1729187711,
},
{
80,
1729187711,
},
{
53,
1729975956,
},
{
54,
1729975956,
},
{
75,
1729975956,
},
{
81,
1729975956,
},
{
96,
1729975956,
},
{
153,
1729975956,
},
{
181,
1729975956,
},
{
194,
1729975956,
},
{
241,
1729975956,
},
{
252,
1729975956,
},
{
279,
1729975956,
},
{
280,
1729975956,
},
{
292,
1729975956,
},
},
["Космический осадок"] = {
{
54,
1728495059,
},
{
74,
1728495059,
},
{
80,
1728495059,
},
{
54,
1728495358,
},
{
73,
1728495358,
},
{
80,
1728495358,
},
{
96,
1728495358,
},
{
147,
1728495358,
},
{
153,
1728495358,
},
{
180,
1728495358,
},
{
48,
1728495746,
},
{
54,
1728495746,
},
{
81,
1728495746,
},
{
96,
1728495746,
},
{
154,
1728495746,
},
{
182,
1728495746,
},
{
195,
1728495746,
},
{
243,
1728495746,
},
{
252,
1728495746,
},
{
54,
1728496261,
},
{
80,
1728496261,
},
{
144,
1728496261,
},
{
154,
1728496261,
},
{
173,
1728496261,
},
{
182,
1728496261,
},
{
242,
1728496261,
},
{
251,
1728496261,
},
{
279,
1728496261,
},
{
312,
1728496261,
},
{
341,
1728496261,
},
{
349,
1728496261,
},
{
368,
1728496261,
},
{
377,
1728496261,
},
{
390,
1728496261,
},
{
54,
1728496739,
},
{
81,
1728496739,
},
{
96,
1728496739,
},
{
147,
1728496739,
},
{
153,
1728496739,
},
{
181,
1728496739,
},
{
194,
1728496739,
},
{
245,
1728496739,
},
{
250,
1728496739,
},
{
278,
1728496739,
},
{
292,
1728496739,
},
{
349,
1728496739,
},
{
350,
1728496739,
},
{
368,
1728496739,
},
{
377,
1728496739,
},
{
378,
1728496739,
},
{
54,
1729187711,
},
{
74,
1729187711,
},
{
80,
1729187711,
},
{
53,
1729975956,
},
{
54,
1729975956,
},
{
75,
1729975956,
},
{
81,
1729975956,
},
{
96,
1729975956,
},
{
153,
1729975956,
},
{
181,
1729975956,
},
{
194,
1729975956,
},
{
241,
1729975956,
},
{
252,
1729975956,
},
{
279,
1729975956,
},
{
280,
1729975956,
},
{
292,
1729975956,
},
},
["Космический симулякр"] = {
{
18,
1728495059,
},
{
19,
1728495059,
},
{
46,
1728495059,
},
{
47,
1728495059,
},
{
74,
1728495059,
},
{
17,
1728495358,
},
{
18,
1728495358,
},
{
45,
1728495358,
},
{
46,
1728495358,
},
{
73,
1728495358,
},
{
74,
1728495358,
},
{
118,
1728495358,
},
{
119,
1728495358,
},
{
146,
1728495358,
},
{
147,
1728495358,
},
{
174,
1728495358,
},
{
175,
1728495358,
},
{
19,
1728495746,
},
{
20,
1728495746,
},
{
47,
1728495746,
},
{
48,
1728495746,
},
{
75,
1728495746,
},
{
76,
1728495746,
},
{
116,
1728495746,
},
{
117,
1728495746,
},
{
144,
1728495746,
},
{
145,
1728495746,
},
{
146,
1728495746,
},
{
172,
1728495746,
},
{
173,
1728495746,
},
{
215,
1728495746,
},
{
216,
1728495746,
},
{
243,
1728495746,
},
{
244,
1728495746,
},
{
18,
1728496261,
},
{
19,
1728496261,
},
{
46,
1728496261,
},
{
73,
1728496261,
},
{
74,
1728496261,
},
{
116,
1728496261,
},
{
117,
1728496261,
},
{
144,
1728496261,
},
{
145,
1728496261,
},
{
172,
1728496261,
},
{
173,
1728496261,
},
{
213,
1728496261,
},
{
214,
1728496261,
},
{
241,
1728496261,
},
{
242,
1728496261,
},
{
269,
1728496261,
},
{
270,
1728496261,
},
{
312,
1728496261,
},
{
313,
1728496261,
},
{
340,
1728496261,
},
{
341,
1728496261,
},
{
368,
1728496261,
},
{
19,
1728496739,
},
{
20,
1728496739,
},
{
47,
1728496739,
},
{
48,
1728496739,
},
{
75,
1728496739,
},
{
76,
1728496739,
},
{
119,
1728496739,
},
{
120,
1728496739,
},
{
147,
1728496739,
},
{
148,
1728496739,
},
{
175,
1728496739,
},
{
176,
1728496739,
},
{
216,
1728496739,
},
{
217,
1728496739,
},
{
244,
1728496739,
},
{
245,
1728496739,
},
{
272,
1728496739,
},
{
273,
1728496739,
},
{
312,
1728496739,
},
{
313,
1728496739,
},
{
340,
1728496739,
},
{
341,
1728496739,
},
{
368,
1728496739,
},
{
369,
1728496739,
},
{
18,
1729187711,
},
{
19,
1729187711,
},
{
46,
1729187711,
},
{
47,
1729187711,
},
{
74,
1729187711,
},
{
75,
1729187711,
},
{
19,
1729975956,
},
{
20,
1729975956,
},
{
47,
1729975956,
},
{
48,
1729975956,
},
{
75,
1729975956,
},
{
76,
1729975956,
},
{
115,
1729975956,
},
{
116,
1729975956,
},
{
144,
1729975956,
},
{
145,
1729975956,
},
{
172,
1729975956,
},
{
173,
1729975956,
},
{
213,
1729975956,
},
{
214,
1729975956,
},
{
241,
1729975956,
},
{
242,
1729975956,
},
{
269,
1729975956,
},
{
270,
1729975956,
},
{
312,
1729975956,
},
{
313,
1729975956,
},
},
["Разрушительный взмах"] = {
{
96,
1728495358,
},
{
194,
1728495358,
},
{
96,
1728495746,
},
{
194,
1728495746,
},
{
96,
1728496261,
},
{
193,
1728496261,
},
{
291,
1728496261,
},
{
390,
1728496261,
},
{
96,
1728496739,
},
{
193,
1728496739,
},
{
292,
1728496739,
},
{
96,
1729975956,
},
{
194,
1729975956,
},
{
292,
1729975956,
},
},
["Берсерк"] = {
{
393,
1728496261,
},
},
["Град стрел"] = {
{
25,
1728495059,
},
{
65,
1728495059,
},
{
24,
1728495358,
},
{
65,
1728495358,
},
{
112,
1728495358,
},
{
140,
1728495358,
},
{
168,
1728495358,
},
{
25,
1728495746,
},
{
65,
1728495746,
},
{
114,
1728495746,
},
{
142,
1728495746,
},
{
169,
1728495746,
},
{
212,
1728495746,
},
{
240,
1728495746,
},
{
24,
1728496261,
},
{
65,
1728496261,
},
{
113,
1728496261,
},
{
141,
1728496261,
},
{
169,
1728496261,
},
{
211,
1728496261,
},
{
238,
1728496261,
},
{
266,
1728496261,
},
{
309,
1728496261,
},
{
337,
1728496261,
},
{
365,
1728496261,
},
{
25,
1728496739,
},
{
65,
1728496739,
},
{
112,
1728496739,
},
{
140,
1728496739,
},
{
168,
1728496739,
},
{
210,
1728496739,
},
{
238,
1728496739,
},
{
266,
1728496739,
},
{
309,
1728496739,
},
{
337,
1728496739,
},
{
365,
1728496739,
},
{
24,
1729187711,
},
{
65,
1729187711,
},
{
24,
1729975956,
},
{
65,
1729975956,
},
{
113,
1729975956,
},
{
141,
1729975956,
},
{
169,
1729975956,
},
{
211,
1729975956,
},
{
239,
1729975956,
},
{
266,
1729975956,
},
{
309,
1729975956,
},
},
},
["2921-14"] = {
["Пронзающее извержение"] = {
{
26,
1726087120,
},
{
64,
1726087120,
},
{
89,
1726087120,
},
{
26,
1726087566,
},
{
64,
1726087566,
},
{
89,
1726087566,
},
{
215,
1726087566,
},
{
254,
1726087566,
},
{
26,
1726087853,
},
{
64,
1726087853,
},
{
89,
1726087853,
},
{
26,
1726088467,
},
{
64,
1726088467,
},
{
89,
1726088467,
},
{
198,
1726088467,
},
{
237,
1726088467,
},
{
276,
1726088467,
},
{
26,
1726088983,
},
{
64,
1726088983,
},
{
89,
1726088983,
},
{
196,
1726088983,
},
{
235,
1726088983,
},
{
26,
1726158880,
},
{
64,
1726158880,
},
{
89,
1726158880,
},
{
25,
1726159866,
},
{
63,
1726159866,
},
{
88,
1726159866,
},
{
194,
1726159866,
},
{
233,
1726159866,
},
{
272,
1726159866,
},
{
26,
1726698185,
},
{
64,
1726698185,
},
{
89,
1726698185,
},
{
175,
1726698185,
},
{
214,
1726698185,
},
},
["Раскол мироздания"] = {
{
130,
1726087120,
},
{
130,
1726087566,
},
{
130,
1726087853,
},
{
129,
1726088467,
},
{
129,
1726088983,
},
{
130,
1726158880,
},
{
129,
1726159866,
},
{
114,
1726698185,
},
},
["Призыв роя"] = {
{
15,
1726087120,
},
{
69,
1726087120,
},
{
15,
1726087566,
},
{
69,
1726087566,
},
{
208,
1726087566,
},
{
262,
1726087566,
},
{
15,
1726087853,
},
{
69,
1726087853,
},
{
15,
1726088467,
},
{
69,
1726088467,
},
{
191,
1726088467,
},
{
245,
1726088467,
},
{
15,
1726088983,
},
{
69,
1726088983,
},
{
189,
1726088983,
},
{
243,
1726088983,
},
{
15,
1726158880,
},
{
69,
1726158880,
},
{
14,
1726159866,
},
{
68,
1726159866,
},
{
187,
1726159866,
},
{
241,
1726159866,
},
{
15,
1726698185,
},
{
69,
1726698185,
},
{
168,
1726698185,
},
{
222,
1726698185,
},
},
["Энтропическое опустошение"] = {
{
233,
1726087566,
},
{
274,
1726087566,
},
{
216,
1726088467,
},
{
259,
1726088467,
},
{
213,
1726088983,
},
{
256,
1726088983,
},
{
212,
1726159866,
},
{
255,
1726159866,
},
{
378,
1726159866,
},
{
192,
1726698185,
},
{
235,
1726698185,
},
{
340,
1726698185,
},
},
["Подземное извержение"] = {
{
34,
1726087120,
},
{
92,
1726087120,
},
{
34,
1726087566,
},
{
92,
1726087566,
},
{
33,
1726087853,
},
{
91,
1726087853,
},
{
33,
1726088467,
},
{
91,
1726088467,
},
{
34,
1726088983,
},
{
92,
1726088983,
},
{
34,
1726158880,
},
{
92,
1726158880,
},
{
33,
1726159866,
},
{
91,
1726159866,
},
{
33,
1726698185,
},
{
91,
1726698185,
},
},
["Запутывание"] = {
{
43,
1726087120,
},
{
43,
1726087566,
},
{
101,
1726087566,
},
{
42,
1726087853,
},
{
42,
1726088467,
},
{
100,
1726088467,
},
{
42,
1726088983,
},
{
100,
1726159866,
},
{
42,
1726698185,
},
{
100,
1726698185,
},
},
["Паутинная бомба"] = {
{
18,
1726087120,
},
{
77,
1726087120,
},
{
18,
1726087566,
},
{
78,
1726087566,
},
{
17,
1726087853,
},
{
75,
1726087853,
},
{
17,
1726088467,
},
{
77,
1726088467,
},
{
18,
1726088983,
},
{
77,
1726088983,
},
{
18,
1726158880,
},
{
77,
1726158880,
},
{
17,
1726159866,
},
{
77,
1726159866,
},
{
17,
1726698185,
},
{
77,
1726698185,
},
},
["Проникающий удар"] = {
{
12,
1726087120,
},
{
32,
1726087120,
},
{
60,
1726087120,
},
{
80,
1726087120,
},
{
119,
1726087120,
},
{
12,
1726087566,
},
{
32,
1726087566,
},
{
60,
1726087566,
},
{
80,
1726087566,
},
{
119,
1726087566,
},
{
211,
1726087566,
},
{
231,
1726087566,
},
{
257,
1726087566,
},
{
277,
1726087566,
},
{
11,
1726087853,
},
{
31,
1726087853,
},
{
59,
1726087853,
},
{
79,
1726087853,
},
{
119,
1726087853,
},
{
11,
1726088467,
},
{
31,
1726088467,
},
{
59,
1726088467,
},
{
79,
1726088467,
},
{
118,
1726088467,
},
{
194,
1726088467,
},
{
214,
1726088467,
},
{
240,
1726088467,
},
{
260,
1726088467,
},
{
280,
1726088467,
},
{
300,
1726088467,
},
{
11,
1726088983,
},
{
31,
1726088983,
},
{
59,
1726088983,
},
{
79,
1726088983,
},
{
118,
1726088983,
},
{
191,
1726088983,
},
{
211,
1726088983,
},
{
237,
1726088983,
},
{
12,
1726158880,
},
{
32,
1726158880,
},
{
60,
1726158880,
},
{
80,
1726158880,
},
{
119,
1726158880,
},
{
11,
1726159866,
},
{
31,
1726159866,
},
{
59,
1726159866,
},
{
79,
1726159866,
},
{
118,
1726159866,
},
{
190,
1726159866,
},
{
210,
1726159866,
},
{
236,
1726159866,
},
{
256,
1726159866,
},
{
276,
1726159866,
},
{
355,
1726159866,
},
{
378,
1726159866,
},
{
11,
1726698185,
},
{
31,
1726698185,
},
{
59,
1726698185,
},
{
79,
1726698185,
},
{
170,
1726698185,
},
{
190,
1726698185,
},
{
216,
1726698185,
},
{
236,
1726698185,
},
{
316,
1726698185,
},
{
339,
1726698185,
},
},
["Жалящий рой"] = {
{
228,
1726087566,
},
{
211,
1726088467,
},
{
269,
1726088467,
},
{
209,
1726088983,
},
{
207,
1726159866,
},
{
265,
1726159866,
},
{
188,
1726698185,
},
{
246,
1726698185,
},
},
["Закапывание"] = {
{
129,
1726087120,
},
{
129,
1726087566,
},
{
129,
1726087853,
},
{
128,
1726088467,
},
{
129,
1726088983,
},
{
129,
1726158880,
},
{
128,
1726159866,
},
{
289,
1726159866,
},
{
114,
1726698185,
},
{
259,
1726698185,
},
},
["Энтропия катаклизма"] = {
{
253,
1726087566,
},
{
236,
1726088467,
},
{
291,
1726088467,
},
{
234,
1726088983,
},
},
["Шаг через Бездну"] = {
{
127,
1726087120,
},
{
127,
1726087566,
},
{
237,
1726087566,
},
{
265,
1726087566,
},
{
128,
1726087853,
},
{
127,
1726088467,
},
{
220,
1726088467,
},
{
249,
1726088467,
},
{
275,
1726088467,
},
{
127,
1726088983,
},
{
218,
1726088983,
},
{
247,
1726088983,
},
{
127,
1726158880,
},
{
126,
1726159866,
},
{
216,
1726159866,
},
{
245,
1726159866,
},
{
271,
1726159866,
},
{
113,
1726698185,
},
{
196,
1726698185,
},
{
226,
1726698185,
},
{
251,
1726698185,
},
},
["Ядовитый заряд"] = {
{
2,
1726087120,
},
{
3,
1726087120,
},
{
5,
1726087120,
},
{
6,
1726087120,
},
{
10,
1726087120,
},
{
12,
1726087120,
},
{
14,
1726087120,
},
{
15,
1726087120,
},
{
17,
1726087120,
},
{
20,
1726087120,
},
{
21,
1726087120,
},
{
23,
1726087120,
},
{
24,
1726087120,
},
{
26,
1726087120,
},
{
27,
1726087120,
},
{
29,
1726087120,
},
{
30,
1726087120,
},
{
32,
1726087120,
},
{
34,
1726087120,
},
{
35,
1726087120,
},
{
37,
1726087120,
},
{
38,
1726087120,
},
{
40,
1726087120,
},
{
41,
1726087120,
},
{
48,
1726087120,
},
{
50,
1726087120,
},
{
51,
1726087120,
},
{
53,
1726087120,
},
{
54,
1726087120,
},
{
56,
1726087120,
},
{
57,
1726087120,
},
{
59,
1726087120,
},
{
60,
1726087120,
},
{
62,
1726087120,
},
{
64,
1726087120,
},
{
65,
1726087120,
},
{
67,
1726087120,
},
{
68,
1726087120,
},
{
70,
1726087120,
},
{
71,
1726087120,
},
{
73,
1726087120,
},
{
74,
1726087120,
},
{
76,
1726087120,
},
{
79,
1726087120,
},
{
80,
1726087120,
},
{
82,
1726087120,
},
{
86,
1726087120,
},
{
87,
1726087120,
},
{
89,
1726087120,
},
{
90,
1726087120,
},
{
92,
1726087120,
},
{
93,
1726087120,
},
{
95,
1726087120,
},
{
96,
1726087120,
},
{
98,
1726087120,
},
{
99,
1726087120,
},
{
103,
1726087120,
},
{
104,
1726087120,
},
{
106,
1726087120,
},
{
107,
1726087120,
},
{
109,
1726087120,
},
{
111,
1726087120,
},
{
112,
1726087120,
},
{
114,
1726087120,
},
{
115,
1726087120,
},
{
117,
1726087120,
},
{
118,
1726087120,
},
{
3,
1726087566,
},
{
5,
1726087566,
},
{
6,
1726087566,
},
{
10,
1726087566,
},
{
12,
1726087566,
},
{
13,
1726087566,
},
{
15,
1726087566,
},
{
16,
1726087566,
},
{
20,
1726087566,
},
{
21,
1726087566,
},
{
23,
1726087566,
},
{
24,
1726087566,
},
{
26,
1726087566,
},
{
27,
1726087566,
},
{
29,
1726087566,
},
{
30,
1726087566,
},
{
32,
1726087566,
},
{
33,
1726087566,
},
{
35,
1726087566,
},
{
37,
1726087566,
},
{
38,
1726087566,
},
{
40,
1726087566,
},
{
44,
1726087566,
},
{
48,
1726087566,
},
{
50,
1726087566,
},
{
51,
1726087566,
},
{
53,
1726087566,
},
{
54,
1726087566,
},
{
56,
1726087566,
},
{
57,
1726087566,
},
{
59,
1726087566,
},
{
60,
1726087566,
},
{
62,
1726087566,
},
{
64,
1726087566,
},
{
65,
1726087566,
},
{
67,
1726087566,
},
{
68,
1726087566,
},
{
70,
1726087566,
},
{
71,
1726087566,
},
{
73,
1726087566,
},
{
74,
1726087566,
},
{
76,
1726087566,
},
{
79,
1726087566,
},
{
81,
1726087566,
},
{
82,
1726087566,
},
{
86,
1726087566,
},
{
87,
1726087566,
},
{
89,
1726087566,
},
{
90,
1726087566,
},
{
92,
1726087566,
},
{
93,
1726087566,
},
{
95,
1726087566,
},
{
96,
1726087566,
},
{
98,
1726087566,
},
{
99,
1726087566,
},
{
104,
1726087566,
},
{
106,
1726087566,
},
{
107,
1726087566,
},
{
109,
1726087566,
},
{
111,
1726087566,
},
{
112,
1726087566,
},
{
114,
1726087566,
},
{
115,
1726087566,
},
{
117,
1726087566,
},
{
118,
1726087566,
},
{
3,
1726087853,
},
{
4,
1726087853,
},
{
6,
1726087853,
},
{
10,
1726087853,
},
{
11,
1726087853,
},
{
13,
1726087853,
},
{
14,
1726087853,
},
{
16,
1726087853,
},
{
19,
1726087853,
},
{
20,
1726087853,
},
{
22,
1726087853,
},
{
24,
1726087853,
},
{
25,
1726087853,
},
{
27,
1726087853,
},
{
28,
1726087853,
},
{
30,
1726087853,
},
{
31,
1726087853,
},
{
33,
1726087853,
},
{
34,
1726087853,
},
{
36,
1726087853,
},
{
38,
1726087853,
},
{
39,
1726087853,
},
{
44,
1726087853,
},
{
48,
1726087853,
},
{
49,
1726087853,
},
{
51,
1726087853,
},
{
52,
1726087853,
},
{
54,
1726087853,
},
{
55,
1726087853,
},
{
57,
1726087853,
},
{
59,
1726087853,
},
{
60,
1726087853,
},
{
62,
1726087853,
},
{
63,
1726087853,
},
{
65,
1726087853,
},
{
66,
1726087853,
},
{
68,
1726087853,
},
{
69,
1726087853,
},
{
71,
1726087853,
},
{
72,
1726087853,
},
{
74,
1726087853,
},
{
77,
1726087853,
},
{
79,
1726087853,
},
{
80,
1726087853,
},
{
84,
1726087853,
},
{
85,
1726087853,
},
{
87,
1726087853,
},
{
88,
1726087853,
},
{
90,
1726087853,
},
{
91,
1726087853,
},
{
93,
1726087853,
},
{
94,
1726087853,
},
{
96,
1726087853,
},
{
98,
1726087853,
},
{
99,
1726087853,
},
{
104,
1726087853,
},
{
105,
1726087853,
},
{
107,
1726087853,
},
{
108,
1726087853,
},
{
110,
1726087853,
},
{
112,
1726087853,
},
{
113,
1726087853,
},
{
115,
1726087853,
},
{
116,
1726087853,
},
{
119,
1726087853,
},
{
3,
1726088467,
},
{
4,
1726088467,
},
{
6,
1726088467,
},
{
10,
1726088467,
},
{
11,
1726088467,
},
{
13,
1726088467,
},
{
14,
1726088467,
},
{
16,
1726088467,
},
{
19,
1726088467,
},
{
20,
1726088467,
},
{
22,
1726088467,
},
{
24,
1726088467,
},
{
25,
1726088467,
},
{
27,
1726088467,
},
{
28,
1726088467,
},
{
30,
1726088467,
},
{
31,
1726088467,
},
{
33,
1726088467,
},
{
34,
1726088467,
},
{
36,
1726088467,
},
{
37,
1726088467,
},
{
39,
1726088467,
},
{
44,
1726088467,
},
{
48,
1726088467,
},
{
49,
1726088467,
},
{
51,
1726088467,
},
{
52,
1726088467,
},
{
54,
1726088467,
},
{
55,
1726088467,
},
{
57,
1726088467,
},
{
58,
1726088467,
},
{
60,
1726088467,
},
{
61,
1726088467,
},
{
63,
1726088467,
},
{
64,
1726088467,
},
{
66,
1726088467,
},
{
67,
1726088467,
},
{
69,
1726088467,
},
{
70,
1726088467,
},
{
72,
1726088467,
},
{
74,
1726088467,
},
{
75,
1726088467,
},
{
78,
1726088467,
},
{
80,
1726088467,
},
{
84,
1726088467,
},
{
85,
1726088467,
},
{
87,
1726088467,
},
{
88,
1726088467,
},
{
90,
1726088467,
},
{
91,
1726088467,
},
{
93,
1726088467,
},
{
94,
1726088467,
},
{
96,
1726088467,
},
{
97,
1726088467,
},
{
99,
1726088467,
},
{
104,
1726088467,
},
{
105,
1726088467,
},
{
107,
1726088467,
},
{
108,
1726088467,
},
{
110,
1726088467,
},
{
111,
1726088467,
},
{
113,
1726088467,
},
{
114,
1726088467,
},
{
116,
1726088467,
},
{
118,
1726088467,
},
{
3,
1726088983,
},
{
4,
1726088983,
},
{
6,
1726088983,
},
{
10,
1726088983,
},
{
12,
1726088983,
},
{
13,
1726088983,
},
{
15,
1726088983,
},
{
16,
1726088983,
},
{
19,
1726088983,
},
{
21,
1726088983,
},
{
22,
1726088983,
},
{
24,
1726088983,
},
{
25,
1726088983,
},
{
27,
1726088983,
},
{
28,
1726088983,
},
{
30,
1726088983,
},
{
31,
1726088983,
},
{
33,
1726088983,
},
{
34,
1726088983,
},
{
36,
1726088983,
},
{
37,
1726088983,
},
{
39,
1726088983,
},
{
40,
1726088983,
},
{
48,
1726088983,
},
{
49,
1726088983,
},
{
51,
1726088983,
},
{
52,
1726088983,
},
{
54,
1726088983,
},
{
56,
1726088983,
},
{
57,
1726088983,
},
{
59,
1726088983,
},
{
60,
1726088983,
},
{
62,
1726088983,
},
{
63,
1726088983,
},
{
65,
1726088983,
},
{
66,
1726088983,
},
{
68,
1726088983,
},
{
69,
1726088983,
},
{
71,
1726088983,
},
{
72,
1726088983,
},
{
74,
1726088983,
},
{
75,
1726088983,
},
{
78,
1726088983,
},
{
80,
1726088983,
},
{
81,
1726088983,
},
{
85,
1726088983,
},
{
87,
1726088983,
},
{
88,
1726088983,
},
{
90,
1726088983,
},
{
91,
1726088983,
},
{
93,
1726088983,
},
{
95,
1726088983,
},
{
96,
1726088983,
},
{
98,
1726088983,
},
{
99,
1726088983,
},
{
104,
1726088983,
},
{
106,
1726088983,
},
{
107,
1726088983,
},
{
109,
1726088983,
},
{
110,
1726088983,
},
{
112,
1726088983,
},
{
113,
1726088983,
},
{
115,
1726088983,
},
{
116,
1726088983,
},
{
118,
1726088983,
},
{
2,
1726158880,
},
{
3,
1726158880,
},
{
5,
1726158880,
},
{
6,
1726158880,
},
{
10,
1726158880,
},
{
12,
1726158880,
},
{
13,
1726158880,
},
{
15,
1726158880,
},
{
16,
1726158880,
},
{
19,
1726158880,
},
{
21,
1726158880,
},
{
22,
1726158880,
},
{
24,
1726158880,
},
{
26,
1726158880,
},
{
27,
1726158880,
},
{
29,
1726158880,
},
{
30,
1726158880,
},
{
32,
1726158880,
},
{
33,
1726158880,
},
{
35,
1726158880,
},
{
36,
1726158880,
},
{
38,
1726158880,
},
{
40,
1726158880,
},
{
41,
1726158880,
},
{
48,
1726158880,
},
{
50,
1726158880,
},
{
51,
1726158880,
},
{
53,
1726158880,
},
{
54,
1726158880,
},
{
56,
1726158880,
},
{
57,
1726158880,
},
{
59,
1726158880,
},
{
60,
1726158880,
},
{
62,
1726158880,
},
{
63,
1726158880,
},
{
65,
1726158880,
},
{
66,
1726158880,
},
{
68,
1726158880,
},
{
69,
1726158880,
},
{
71,
1726158880,
},
{
72,
1726158880,
},
{
74,
1726158880,
},
{
75,
1726158880,
},
{
78,
1726158880,
},
{
80,
1726158880,
},
{
82,
1726158880,
},
{
86,
1726158880,
},
{
87,
1726158880,
},
{
89,
1726158880,
},
{
90,
1726158880,
},
{
92,
1726158880,
},
{
93,
1726158880,
},
{
95,
1726158880,
},
{
96,
1726158880,
},
{
98,
1726158880,
},
{
99,
1726158880,
},
{
104,
1726158880,
},
{
106,
1726158880,
},
{
107,
1726158880,
},
{
109,
1726158880,
},
{
110,
1726158880,
},
{
112,
1726158880,
},
{
113,
1726158880,
},
{
115,
1726158880,
},
{
116,
1726158880,
},
{
118,
1726158880,
},
{
1,
1726159866,
},
{
2,
1726159866,
},
{
4,
1726159866,
},
{
6,
1726159866,
},
{
10,
1726159866,
},
{
11,
1726159866,
},
{
13,
1726159866,
},
{
14,
1726159866,
},
{
16,
1726159866,
},
{
19,
1726159866,
},
{
20,
1726159866,
},
{
22,
1726159866,
},
{
23,
1726159866,
},
{
25,
1726159866,
},
{
26,
1726159866,
},
{
28,
1726159866,
},
{
29,
1726159866,
},
{
31,
1726159866,
},
{
32,
1726159866,
},
{
34,
1726159866,
},
{
35,
1726159866,
},
{
37,
1726159866,
},
{
38,
1726159866,
},
{
44,
1726159866,
},
{
48,
1726159866,
},
{
49,
1726159866,
},
{
51,
1726159866,
},
{
52,
1726159866,
},
{
54,
1726159866,
},
{
55,
1726159866,
},
{
57,
1726159866,
},
{
58,
1726159866,
},
{
60,
1726159866,
},
{
61,
1726159866,
},
{
63,
1726159866,
},
{
64,
1726159866,
},
{
66,
1726159866,
},
{
68,
1726159866,
},
{
69,
1726159866,
},
{
71,
1726159866,
},
{
72,
1726159866,
},
{
74,
1726159866,
},
{
75,
1726159866,
},
{
78,
1726159866,
},
{
80,
1726159866,
},
{
81,
1726159866,
},
{
85,
1726159866,
},
{
86,
1726159866,
},
{
88,
1726159866,
},
{
90,
1726159866,
},
{
91,
1726159866,
},
{
93,
1726159866,
},
{
94,
1726159866,
},
{
96,
1726159866,
},
{
97,
1726159866,
},
{
99,
1726159866,
},
{
104,
1726159866,
},
{
105,
1726159866,
},
{
107,
1726159866,
},
{
108,
1726159866,
},
{
110,
1726159866,
},
{
111,
1726159866,
},
{
113,
1726159866,
},
{
114,
1726159866,
},
{
116,
1726159866,
},
{
117,
1726159866,
},
{
3,
1726698185,
},
{
4,
1726698185,
},
{
6,
1726698185,
},
{
10,
1726698185,
},
{
11,
1726698185,
},
{
13,
1726698185,
},
{
14,
1726698185,
},
{
16,
1726698185,
},
{
19,
1726698185,
},
{
20,
1726698185,
},
{
22,
1726698185,
},
{
24,
1726698185,
},
{
25,
1726698185,
},
{
27,
1726698185,
},
{
28,
1726698185,
},
{
30,
1726698185,
},
{
31,
1726698185,
},
{
33,
1726698185,
},
{
34,
1726698185,
},
{
36,
1726698185,
},
{
37,
1726698185,
},
{
39,
1726698185,
},
{
44,
1726698185,
},
{
48,
1726698185,
},
{
49,
1726698185,
},
{
51,
1726698185,
},
{
52,
1726698185,
},
{
54,
1726698185,
},
{
55,
1726698185,
},
{
57,
1726698185,
},
{
59,
1726698185,
},
{
60,
1726698185,
},
{
62,
1726698185,
},
{
63,
1726698185,
},
{
65,
1726698185,
},
{
66,
1726698185,
},
{
68,
1726698185,
},
{
69,
1726698185,
},
{
71,
1726698185,
},
{
72,
1726698185,
},
{
74,
1726698185,
},
{
75,
1726698185,
},
{
79,
1726698185,
},
{
80,
1726698185,
},
{
82,
1726698185,
},
{
85,
1726698185,
},
{
87,
1726698185,
},
{
88,
1726698185,
},
{
90,
1726698185,
},
{
91,
1726698185,
},
{
93,
1726698185,
},
{
94,
1726698185,
},
{
96,
1726698185,
},
{
98,
1726698185,
},
{
99,
1726698185,
},
{
104,
1726698185,
},
{
105,
1726698185,
},
{
107,
1726698185,
},
},
["Ядовитый дождь"] = {
{
8,
1726087120,
},
{
46,
1726087120,
},
{
83,
1726087120,
},
{
120,
1726087120,
},
{
8,
1726087566,
},
{
46,
1726087566,
},
{
84,
1726087566,
},
{
120,
1726087566,
},
{
7,
1726087853,
},
{
45,
1726087853,
},
{
82,
1726087853,
},
{
121,
1726087853,
},
{
7,
1726088467,
},
{
45,
1726088467,
},
{
81,
1726088467,
},
{
119,
1726088467,
},
{
7,
1726088983,
},
{
45,
1726088983,
},
{
83,
1726088983,
},
{
119,
1726088983,
},
{
8,
1726158880,
},
{
46,
1726158880,
},
{
83,
1726158880,
},
{
119,
1726158880,
},
{
7,
1726159866,
},
{
45,
1726159866,
},
{
83,
1726159866,
},
{
119,
1726159866,
},
{
7,
1726698185,
},
{
45,
1726698185,
},
{
83,
1726698185,
},
},
["Выпущенный рой"] = {
{
361,
1726159866,
},
{
323,
1726698185,
},
},
["Сосредоточение скарабея"] = {
{
17,
1726087120,
},
{
71,
1726087120,
},
{
18,
1726087566,
},
{
49,
1726087566,
},
{
72,
1726087566,
},
{
104,
1726087566,
},
{
211,
1726087566,
},
{
242,
1726087566,
},
{
265,
1726087566,
},
{
274,
1726087566,
},
{
17,
1726087853,
},
{
71,
1726087853,
},
{
17,
1726088467,
},
{
71,
1726088467,
},
{
194,
1726088467,
},
{
195,
1726088467,
},
{
248,
1726088467,
},
{
255,
1726088467,
},
{
276,
1726088467,
},
{
280,
1726088467,
},
{
282,
1726088467,
},
{
291,
1726088467,
},
{
293,
1726088467,
},
{
17,
1726088983,
},
{
71,
1726088983,
},
{
192,
1726088983,
},
{
245,
1726088983,
},
{
251,
1726088983,
},
{
253,
1726088983,
},
{
18,
1726158880,
},
{
19,
1726158880,
},
{
71,
1726158880,
},
{
76,
1726158880,
},
{
101,
1726158880,
},
{
17,
1726159866,
},
{
71,
1726159866,
},
{
190,
1726159866,
},
{
244,
1726159866,
},
{
256,
1726159866,
},
{
261,
1726159866,
},
{
276,
1726159866,
},
{
17,
1726698185,
},
{
71,
1726698185,
},
{
170,
1726698185,
},
{
224,
1726698185,
},
},
["Нити реальности"] = {
{
222,
1726087566,
},
{
205,
1726088467,
},
{
270,
1726088467,
},
{
202,
1726088983,
},
{
200,
1726159866,
},
{
266,
1726159866,
},
{
358,
1726159866,
},
{
181,
1726698185,
},
{
246,
1726698185,
},
{
320,
1726698185,
},
},
["Панцирекрушитель"] = {
{
15,
1726087120,
},
{
69,
1726087120,
},
{
15,
1726087566,
},
{
69,
1726087566,
},
{
208,
1726087566,
},
{
262,
1726087566,
},
{
15,
1726087853,
},
{
69,
1726087853,
},
{
15,
1726088467,
},
{
69,
1726088467,
},
{
191,
1726088467,
},
{
245,
1726088467,
},
{
15,
1726088983,
},
{
69,
1726088983,
},
{
189,
1726088983,
},
{
243,
1726088983,
},
{
15,
1726158880,
},
{
69,
1726158880,
},
{
14,
1726159866,
},
{
68,
1726159866,
},
{
187,
1726159866,
},
{
241,
1726159866,
},
{
15,
1726698185,
},
{
69,
1726698185,
},
{
168,
1726698185,
},
{
222,
1726698185,
},
},
["Вихрь паутины"] = {
{
227,
1726087566,
},
{
269,
1726087566,
},
{
210,
1726088467,
},
{
253,
1726088467,
},
{
207,
1726088983,
},
{
251,
1726088983,
},
{
206,
1726159866,
},
{
249,
1726159866,
},
{
372,
1726159866,
},
{
186,
1726698185,
},
{
229,
1726698185,
},
{
334,
1726698185,
},
},
["Буря шипов"] = {
{
291,
1726159866,
},
{
260,
1726698185,
},
},
["Стрела Бездны"] = {
{
202,
1726087566,
},
{
204,
1726087566,
},
{
206,
1726087566,
},
{
208,
1726087566,
},
{
210,
1726087566,
},
{
212,
1726087566,
},
{
214,
1726087566,
},
{
216,
1726087566,
},
{
218,
1726087566,
},
{
255,
1726087566,
},
{
257,
1726087566,
},
{
259,
1726087566,
},
{
262,
1726087566,
},
{
264,
1726087566,
},
{
280,
1726087566,
},
{
282,
1726087566,
},
{
184,
1726088467,
},
{
186,
1726088467,
},
{
188,
1726088467,
},
{
190,
1726088467,
},
{
192,
1726088467,
},
{
194,
1726088467,
},
{
196,
1726088467,
},
{
198,
1726088467,
},
{
200,
1726088467,
},
{
238,
1726088467,
},
{
240,
1726088467,
},
{
242,
1726088467,
},
{
244,
1726088467,
},
{
246,
1726088467,
},
{
248,
1726088467,
},
{
264,
1726088467,
},
{
266,
1726088467,
},
{
293,
1726088467,
},
{
295,
1726088467,
},
{
301,
1726088467,
},
{
182,
1726088983,
},
{
184,
1726088983,
},
{
186,
1726088983,
},
{
188,
1726088983,
},
{
190,
1726088983,
},
{
192,
1726088983,
},
{
194,
1726088983,
},
{
196,
1726088983,
},
{
198,
1726088983,
},
{
236,
1726088983,
},
{
238,
1726088983,
},
{
240,
1726088983,
},
{
242,
1726088983,
},
{
244,
1726088983,
},
{
246,
1726088983,
},
{
180,
1726159866,
},
{
182,
1726159866,
},
{
184,
1726159866,
},
{
186,
1726159866,
},
{
188,
1726159866,
},
{
190,
1726159866,
},
{
192,
1726159866,
},
{
194,
1726159866,
},
{
196,
1726159866,
},
{
244,
1726159866,
},
{
260,
1726159866,
},
{
262,
1726159866,
},
{
340,
1726159866,
},
{
342,
1726159866,
},
{
344,
1726159866,
},
{
346,
1726159866,
},
{
348,
1726159866,
},
{
350,
1726159866,
},
{
352,
1726159866,
},
{
354,
1726159866,
},
{
364,
1726159866,
},
{
366,
1726159866,
},
{
368,
1726159866,
},
{
370,
1726159866,
},
{
161,
1726698185,
},
{
163,
1726698185,
},
{
165,
1726698185,
},
{
167,
1726698185,
},
{
169,
1726698185,
},
{
171,
1726698185,
},
{
173,
1726698185,
},
{
175,
1726698185,
},
{
177,
1726698185,
},
{
220,
1726698185,
},
{
222,
1726698185,
},
{
224,
1726698185,
},
{
240,
1726698185,
},
{
242,
1726698185,
},
{
302,
1726698185,
},
{
304,
1726698185,
},
{
306,
1726698185,
},
{
308,
1726698185,
},
{
310,
1726698185,
},
{
312,
1726698185,
},
{
314,
1726698185,
},
{
316,
1726698185,
},
{
326,
1726698185,
},
{
328,
1726698185,
},
{
330,
1726698185,
},
{
332,
1726698185,
},
},
["Безрассудный рывок"] = {
{
42,
1726087120,
},
{
100,
1726087120,
},
{
42,
1726087566,
},
{
100,
1726087566,
},
{
42,
1726087853,
},
{
100,
1726087853,
},
{
41,
1726088467,
},
{
99,
1726088467,
},
{
42,
1726088983,
},
{
100,
1726088983,
},
{
42,
1726158880,
},
{
100,
1726158880,
},
{
41,
1726159866,
},
{
99,
1726159866,
},
{
42,
1726698185,
},
{
100,
1726698185,
},
},
["Юркий прыжок"] = {
{
42,
1726087120,
},
{
100,
1726087120,
},
{
41,
1726087566,
},
{
100,
1726087566,
},
{
40,
1726087853,
},
{
100,
1726087853,
},
{
40,
1726088467,
},
{
100,
1726088467,
},
{
41,
1726088983,
},
{
100,
1726088983,
},
{
42,
1726158880,
},
{
100,
1726158880,
},
{
39,
1726159866,
},
{
100,
1726159866,
},
{
40,
1726698185,
},
{
100,
1726698185,
},
},
["Извержение шипов"] = {
{
375,
1726159866,
},
{
337,
1726698185,
},
},
["Путь сквозь Бездну"] = {
{
256,
1726698185,
},
},
},
["2902-16"] = {
["Тяжелое сокрушение"] = {
{
95,
1727621948,
},
{
96,
1727621948,
},
{
94,
1727622447,
},
{
95,
1727622447,
},
{
269,
1727622447,
},
{
270,
1727622447,
},
{
94,
1727623206,
},
{
95,
1727623206,
},
{
271,
1727623206,
},
{
272,
1727623206,
},
{
447,
1727623206,
},
{
448,
1727623206,
},
{
95,
1727623466,
},
{
96,
1727623466,
},
{
94,
1727624051,
},
{
96,
1727624051,
},
{
95,
1727624668,
},
{
96,
1727624668,
},
{
273,
1727624668,
},
{
274,
1727624668,
},
{
94,
1727625015,
},
{
95,
1727625015,
},
{
94,
1727625604,
},
{
96,
1727625604,
},
{
266,
1727625604,
},
{
267,
1727625604,
},
{
94,
1727628606,
},
{
96,
1727628606,
},
{
94,
1727628873,
},
{
95,
1727628873,
},
{
94,
1727631159,
},
{
95,
1727631159,
},
{
95,
1727631850,
},
{
96,
1727631850,
},
{
263,
1727631850,
},
{
264,
1727631850,
},
{
431,
1727631850,
},
{
432,
1727631850,
},
{
95,
1727892316,
},
{
96,
1727892316,
},
{
95,
1727893601,
},
{
96,
1727893601,
},
{
95,
1727894099,
},
{
96,
1727894099,
},
{
277,
1727894099,
},
{
278,
1727894099,
},
{
95,
1727985140,
},
{
96,
1727985140,
},
{
281,
1727985140,
},
{
282,
1727985140,
},
{
468,
1727985140,
},
{
469,
1727985140,
},
{
95,
1727986257,
},
{
96,
1727986257,
},
{
277,
1727986257,
},
{
278,
1727986257,
},
{
94,
1727987450,
},
{
95,
1727987450,
},
{
262,
1727987450,
},
{
263,
1727987450,
},
{
437,
1727987450,
},
{
439,
1727987450,
},
{
611,
1727987450,
},
{
612,
1727987450,
},
{
94,
1727988274,
},
{
96,
1727988274,
},
{
261,
1727988274,
},
{
262,
1727988274,
},
{
433,
1727988274,
},
{
434,
1727988274,
},
{
95,
1728490934,
},
{
96,
1728490934,
},
{
95,
1728492773,
},
{
96,
1728492773,
},
{
267,
1728492773,
},
{
268,
1728492773,
},
{
445,
1728492773,
},
{
446,
1728492773,
},
{
94,
1729184813,
},
{
96,
1729184813,
},
{
94,
1729185356,
},
{
95,
1729185356,
},
{
259,
1729185356,
},
{
260,
1729185356,
},
{
426,
1729185356,
},
{
427,
1729185356,
},
{
94,
1729970361,
},
{
95,
1729970361,
},
{
94,
1729971251,
},
{
95,
1729971251,
},
{
268,
1729971251,
},
{
269,
1729971251,
},
{
445,
1729971251,
},
{
446,
1729971251,
},
{
95,
1729973842,
},
{
96,
1729973842,
},
{
261,
1729973842,
},
{
262,
1729973842,
},
{
432,
1729973842,
},
{
433,
1729973842,
},
},
["Скрежещущий рой"] = {
{
99,
1727621948,
},
{
99,
1727622447,
},
{
273,
1727622447,
},
{
99,
1727623206,
},
{
276,
1727623206,
},
{
452,
1727623206,
},
{
99,
1727623466,
},
{
100,
1727624051,
},
{
99,
1727624668,
},
{
277,
1727624668,
},
{
99,
1727625015,
},
{
99,
1727625604,
},
{
272,
1727625604,
},
{
99,
1727628606,
},
{
99,
1727628873,
},
{
99,
1727631159,
},
{
99,
1727631850,
},
{
268,
1727631850,
},
{
436,
1727631850,
},
{
99,
1727892316,
},
{
100,
1727893601,
},
{
100,
1727894099,
},
{
282,
1727894099,
},
{
100,
1727985140,
},
{
286,
1727985140,
},
{
473,
1727985140,
},
{
99,
1727986257,
},
{
282,
1727986257,
},
{
98,
1727987450,
},
{
266,
1727987450,
},
{
442,
1727987450,
},
{
615,
1727987450,
},
{
99,
1727988274,
},
{
265,
1727988274,
},
{
437,
1727988274,
},
{
99,
1728490934,
},
{
100,
1728492773,
},
{
272,
1728492773,
},
{
449,
1728492773,
},
{
100,
1729184813,
},
{
99,
1729185356,
},
{
263,
1729185356,
},
{
98,
1729970361,
},
{
99,
1729971251,
},
{
273,
1729971251,
},
{
451,
1729971251,
},
{
99,
1729973842,
},
{
266,
1729973842,
},
{
436,
1729973842,
},
},
["Паутина ловчего"] = {
{
11,
1727621948,
},
{
56,
1727621948,
},
{
11,
1727622447,
},
{
56,
1727622447,
},
{
185,
1727622447,
},
{
230,
1727622447,
},
{
375,
1727622447,
},
{
11,
1727623206,
},
{
56,
1727623206,
},
{
187,
1727623206,
},
{
232,
1727623206,
},
{
364,
1727623206,
},
{
409,
1727623206,
},
{
544,
1727623206,
},
{
589,
1727623206,
},
{
11,
1727623466,
},
{
56,
1727623466,
},
{
11,
1727624051,
},
{
56,
1727624051,
},
{
181,
1727624051,
},
{
11,
1727624668,
},
{
56,
1727624668,
},
{
190,
1727624668,
},
{
235,
1727624668,
},
{
11,
1727625015,
},
{
56,
1727625015,
},
{
11,
1727625604,
},
{
56,
1727625604,
},
{
183,
1727625604,
},
{
228,
1727625604,
},
{
11,
1727628606,
},
{
56,
1727628606,
},
{
10,
1727628873,
},
{
55,
1727628873,
},
{
11,
1727631159,
},
{
56,
1727631159,
},
{
11,
1727631850,
},
{
56,
1727631850,
},
{
179,
1727631850,
},
{
224,
1727631850,
},
{
347,
1727631850,
},
{
392,
1727631850,
},
{
519,
1727631850,
},
{
564,
1727631850,
},
{
11,
1727892316,
},
{
56,
1727892316,
},
{
183,
1727892316,
},
{
228,
1727892316,
},
{
12,
1727892484,
},
{
11,
1727892646,
},
{
56,
1727892646,
},
{
11,
1727893601,
},
{
56,
1727893601,
},
{
11,
1727894099,
},
{
56,
1727894099,
},
{
194,
1727894099,
},
{
239,
1727894099,
},
{
11,
1727985140,
},
{
56,
1727985140,
},
{
197,
1727985140,
},
{
243,
1727985140,
},
{
385,
1727985140,
},
{
430,
1727985140,
},
{
573,
1727985140,
},
{
618,
1727985140,
},
{
11,
1727986257,
},
{
56,
1727986257,
},
{
194,
1727986257,
},
{
239,
1727986257,
},
{
11,
1727987450,
},
{
56,
1727987450,
},
{
178,
1727987450,
},
{
223,
1727987450,
},
{
354,
1727987450,
},
{
399,
1727987450,
},
{
527,
1727987450,
},
{
572,
1727987450,
},
{
11,
1727988274,
},
{
56,
1727988274,
},
{
178,
1727988274,
},
{
223,
1727988274,
},
{
349,
1727988274,
},
{
394,
1727988274,
},
{
517,
1727988274,
},
{
562,
1727988274,
},
{
11,
1728490934,
},
{
56,
1728490934,
},
{
11,
1728492773,
},
{
56,
1728492773,
},
{
184,
1728492773,
},
{
229,
1728492773,
},
{
361,
1728492773,
},
{
406,
1728492773,
},
{
535,
1728492773,
},
{
11,
1729184813,
},
{
56,
1729184813,
},
{
11,
1729185356,
},
{
55,
1729185356,
},
{
176,
1729185356,
},
{
221,
1729185356,
},
{
343,
1729185356,
},
{
388,
1729185356,
},
{
11,
1729970361,
},
{
56,
1729970361,
},
{
190,
1729970361,
},
{
11,
1729971251,
},
{
56,
1729971251,
},
{
185,
1729971251,
},
{
230,
1729971251,
},
{
362,
1729971251,
},
{
407,
1729971251,
},
{
11,
1729973842,
},
{
56,
1729973842,
},
{
177,
1729973842,
},
{
222,
1729973842,
},
{
348,
1729973842,
},
{
393,
1729973842,
},
},
["Ядовитая плеть"] = {
{
7,
1727621948,
},
{
32,
1727621948,
},
{
60,
1727621948,
},
{
6,
1727622447,
},
{
31,
1727622447,
},
{
59,
1727622447,
},
{
181,
1727622447,
},
{
206,
1727622447,
},
{
234,
1727622447,
},
{
371,
1727622447,
},
{
6,
1727623206,
},
{
31,
1727623206,
},
{
59,
1727623206,
},
{
183,
1727623206,
},
{
208,
1727623206,
},
{
236,
1727623206,
},
{
359,
1727623206,
},
{
384,
1727623206,
},
{
412,
1727623206,
},
{
539,
1727623206,
},
{
564,
1727623206,
},
{
592,
1727623206,
},
{
7,
1727623466,
},
{
32,
1727623466,
},
{
60,
1727623466,
},
{
6,
1727624051,
},
{
31,
1727624051,
},
{
59,
1727624051,
},
{
177,
1727624051,
},
{
202,
1727624051,
},
{
7,
1727624668,
},
{
32,
1727624668,
},
{
60,
1727624668,
},
{
185,
1727624668,
},
{
210,
1727624668,
},
{
238,
1727624668,
},
{
6,
1727625015,
},
{
31,
1727625015,
},
{
59,
1727625015,
},
{
6,
1727625604,
},
{
31,
1727625604,
},
{
59,
1727625604,
},
{
178,
1727625604,
},
{
203,
1727625604,
},
{
231,
1727625604,
},
{
7,
1727628606,
},
{
31,
1727628606,
},
{
59,
1727628606,
},
{
6,
1727628873,
},
{
31,
1727628873,
},
{
59,
1727628873,
},
{
6,
1727631159,
},
{
31,
1727631159,
},
{
59,
1727631159,
},
{
7,
1727631850,
},
{
32,
1727631850,
},
{
60,
1727631850,
},
{
175,
1727631850,
},
{
200,
1727631850,
},
{
228,
1727631850,
},
{
343,
1727631850,
},
{
368,
1727631850,
},
{
396,
1727631850,
},
{
514,
1727631850,
},
{
539,
1727631850,
},
{
567,
1727631850,
},
{
7,
1727892316,
},
{
32,
1727892316,
},
{
60,
1727892316,
},
{
179,
1727892316,
},
{
204,
1727892316,
},
{
232,
1727892316,
},
{
7,
1727892484,
},
{
32,
1727892484,
},
{
7,
1727892646,
},
{
32,
1727892646,
},
{
60,
1727892646,
},
{
7,
1727893601,
},
{
32,
1727893601,
},
{
60,
1727893601,
},
{
7,
1727894099,
},
{
32,
1727894099,
},
{
60,
1727894099,
},
{
189,
1727894099,
},
{
214,
1727894099,
},
{
242,
1727894099,
},
{
7,
1727985140,
},
{
32,
1727985140,
},
{
60,
1727985140,
},
{
193,
1727985140,
},
{
218,
1727985140,
},
{
246,
1727985140,
},
{
380,
1727985140,
},
{
405,
1727985140,
},
{
433,
1727985140,
},
{
569,
1727985140,
},
{
594,
1727985140,
},
{
622,
1727985140,
},
{
7,
1727986257,
},
{
32,
1727986257,
},
{
60,
1727986257,
},
{
189,
1727986257,
},
{
214,
1727986257,
},
{
242,
1727986257,
},
{
6,
1727987450,
},
{
31,
1727987450,
},
{
59,
1727987450,
},
{
174,
1727987450,
},
{
199,
1727987450,
},
{
227,
1727987450,
},
{
349,
1727987450,
},
{
374,
1727987450,
},
{
402,
1727987450,
},
{
523,
1727987450,
},
{
548,
1727987450,
},
{
576,
1727987450,
},
{
6,
1727988274,
},
{
31,
1727988274,
},
{
59,
1727988274,
},
{
173,
1727988274,
},
{
198,
1727988274,
},
{
226,
1727988274,
},
{
345,
1727988274,
},
{
370,
1727988274,
},
{
398,
1727988274,
},
{
512,
1727988274,
},
{
537,
1727988274,
},
{
565,
1727988274,
},
{
7,
1728490934,
},
{
32,
1728490934,
},
{
60,
1728490934,
},
{
7,
1728492773,
},
{
32,
1728492773,
},
{
60,
1728492773,
},
{
179,
1728492773,
},
{
204,
1728492773,
},
{
232,
1728492773,
},
{
357,
1728492773,
},
{
382,
1728492773,
},
{
410,
1728492773,
},
{
531,
1728492773,
},
{
6,
1729184813,
},
{
31,
1729184813,
},
{
59,
1729184813,
},
{
6,
1729185356,
},
{
31,
1729185356,
},
{
59,
1729185356,
},
{
171,
1729185356,
},
{
196,
1729185356,
},
{
224,
1729185356,
},
{
338,
1729185356,
},
{
363,
1729185356,
},
{
391,
1729185356,
},
{
6,
1729970361,
},
{
31,
1729970361,
},
{
59,
1729970361,
},
{
186,
1729970361,
},
{
210,
1729970361,
},
{
6,
1729971251,
},
{
31,
1729971251,
},
{
59,
1729971251,
},
{
180,
1729971251,
},
{
205,
1729971251,
},
{
233,
1729971251,
},
{
357,
1729971251,
},
{
382,
1729971251,
},
{
410,
1729971251,
},
{
7,
1729973842,
},
{
32,
1729973842,
},
{
60,
1729973842,
},
{
173,
1729973842,
},
{
198,
1729973842,
},
{
226,
1729973842,
},
{
344,
1729973842,
},
{
369,
1729973842,
},
{
397,
1729973842,
},
},
["Безжалостное сокрушение"] = {
{
4,
1727621948,
},
{
19,
1727621948,
},
{
34,
1727621948,
},
{
53,
1727621948,
},
{
68,
1727621948,
},
{
3,
1727622447,
},
{
18,
1727622447,
},
{
33,
1727622447,
},
{
52,
1727622447,
},
{
67,
1727622447,
},
{
178,
1727622447,
},
{
193,
1727622447,
},
{
208,
1727622447,
},
{
227,
1727622447,
},
{
242,
1727622447,
},
{
368,
1727622447,
},
{
383,
1727622447,
},
{
3,
1727623206,
},
{
18,
1727623206,
},
{
33,
1727623206,
},
{
52,
1727623206,
},
{
67,
1727623206,
},
{
179,
1727623206,
},
{
194,
1727623206,
},
{
209,
1727623206,
},
{
228,
1727623206,
},
{
243,
1727623206,
},
{
356,
1727623206,
},
{
371,
1727623206,
},
{
386,
1727623206,
},
{
405,
1727623206,
},
{
420,
1727623206,
},
{
536,
1727623206,
},
{
551,
1727623206,
},
{
566,
1727623206,
},
{
585,
1727623206,
},
{
600,
1727623206,
},
{
4,
1727623466,
},
{
18,
1727623466,
},
{
34,
1727623466,
},
{
52,
1727623466,
},
{
67,
1727623466,
},
{
3,
1727624051,
},
{
18,
1727624051,
},
{
33,
1727624051,
},
{
52,
1727624051,
},
{
67,
1727624051,
},
{
174,
1727624051,
},
{
189,
1727624051,
},
{
204,
1727624051,
},
{
223,
1727624051,
},
{
3,
1727624668,
},
{
18,
1727624668,
},
{
33,
1727624668,
},
{
52,
1727624668,
},
{
67,
1727624668,
},
{
182,
1727624668,
},
{
197,
1727624668,
},
{
212,
1727624668,
},
{
231,
1727624668,
},
{
246,
1727624668,
},
{
3,
1727625015,
},
{
18,
1727625015,
},
{
33,
1727625015,
},
{
52,
1727625015,
},
{
67,
1727625015,
},
{
3,
1727625604,
},
{
18,
1727625604,
},
{
33,
1727625604,
},
{
52,
1727625604,
},
{
67,
1727625604,
},
{
175,
1727625604,
},
{
190,
1727625604,
},
{
205,
1727625604,
},
{
224,
1727625604,
},
{
239,
1727625604,
},
{
3,
1727628606,
},
{
18,
1727628606,
},
{
33,
1727628606,
},
{
52,
1727628606,
},
{
67,
1727628606,
},
{
3,
1727628873,
},
{
18,
1727628873,
},
{
33,
1727628873,
},
{
52,
1727628873,
},
{
67,
1727628873,
},
{
3,
1727631159,
},
{
18,
1727631159,
},
{
33,
1727631159,
},
{
52,
1727631159,
},
{
67,
1727631159,
},
{
3,
1727631850,
},
{
18,
1727631850,
},
{
33,
1727631850,
},
{
52,
1727631850,
},
{
67,
1727631850,
},
{
172,
1727631850,
},
{
186,
1727631850,
},
{
202,
1727631850,
},
{
220,
1727631850,
},
{
236,
1727631850,
},
{
339,
1727631850,
},
{
354,
1727631850,
},
{
369,
1727631850,
},
{
388,
1727631850,
},
{
403,
1727631850,
},
{
511,
1727631850,
},
{
526,
1727631850,
},
{
541,
1727631850,
},
{
560,
1727631850,
},
{
575,
1727631850,
},
{
4,
1727892316,
},
{
19,
1727892316,
},
{
34,
1727892316,
},
{
53,
1727892316,
},
{
68,
1727892316,
},
{
176,
1727892316,
},
{
191,
1727892316,
},
{
206,
1727892316,
},
{
225,
1727892316,
},
{
4,
1727892484,
},
{
19,
1727892484,
},
{
34,
1727892484,
},
{
4,
1727892646,
},
{
19,
1727892646,
},
{
34,
1727892646,
},
{
53,
1727892646,
},
{
68,
1727892646,
},
{
4,
1727893601,
},
{
19,
1727893601,
},
{
34,
1727893601,
},
{
53,
1727893601,
},
{
68,
1727893601,
},
{
4,
1727894099,
},
{
19,
1727894099,
},
{
34,
1727894099,
},
{
53,
1727894099,
},
{
68,
1727894099,
},
{
186,
1727894099,
},
{
201,
1727894099,
},
{
216,
1727894099,
},
{
235,
1727894099,
},
{
250,
1727894099,
},
{
4,
1727985140,
},
{
19,
1727985140,
},
{
34,
1727985140,
},
{
53,
1727985140,
},
{
68,
1727985140,
},
{
190,
1727985140,
},
{
205,
1727985140,
},
{
220,
1727985140,
},
{
239,
1727985140,
},
{
254,
1727985140,
},
{
377,
1727985140,
},
{
392,
1727985140,
},
{
407,
1727985140,
},
{
426,
1727985140,
},
{
441,
1727985140,
},
{
566,
1727985140,
},
{
581,
1727985140,
},
{
596,
1727985140,
},
{
615,
1727985140,
},
{
3,
1727986257,
},
{
18,
1727986257,
},
{
33,
1727986257,
},
{
52,
1727986257,
},
{
67,
1727986257,
},
{
186,
1727986257,
},
{
201,
1727986257,
},
{
216,
1727986257,
},
{
235,
1727986257,
},
{
250,
1727986257,
},
{
3,
1727987450,
},
{
18,
1727987450,
},
{
33,
1727987450,
},
{
52,
1727987450,
},
{
67,
1727987450,
},
{
170,
1727987450,
},
{
185,
1727987450,
},
{
200,
1727987450,
},
{
219,
1727987450,
},
{
234,
1727987450,
},
{
346,
1727987450,
},
{
361,
1727987450,
},
{
376,
1727987450,
},
{
395,
1727987450,
},
{
410,
1727987450,
},
{
520,
1727987450,
},
{
535,
1727987450,
},
{
550,
1727987450,
},
{
569,
1727987450,
},
{
584,
1727987450,
},
{
3,
1727988274,
},
{
18,
1727988274,
},
{
33,
1727988274,
},
{
52,
1727988274,
},
{
67,
1727988274,
},
{
170,
1727988274,
},
{
185,
1727988274,
},
{
200,
1727988274,
},
{
219,
1727988274,
},
{
234,
1727988274,
},
{
341,
1727988274,
},
{
356,
1727988274,
},
{
371,
1727988274,
},
{
390,
1727988274,
},
{
405,
1727988274,
},
{
509,
1727988274,
},
{
524,
1727988274,
},
{
539,
1727988274,
},
{
558,
1727988274,
},
{
573,
1727988274,
},
{
3,
1728490934,
},
{
18,
1728490934,
},
{
33,
1728490934,
},
{
52,
1728490934,
},
{
67,
1728490934,
},
{
4,
1728492773,
},
{
19,
1728492773,
},
{
34,
1728492773,
},
{
53,
1728492773,
},
{
68,
1728492773,
},
{
176,
1728492773,
},
{
191,
1728492773,
},
{
206,
1728492773,
},
{
225,
1728492773,
},
{
240,
1728492773,
},
{
354,
1728492773,
},
{
369,
1728492773,
},
{
384,
1728492773,
},
{
403,
1728492773,
},
{
418,
1728492773,
},
{
528,
1728492773,
},
{
543,
1728492773,
},
{
3,
1729184813,
},
{
18,
1729184813,
},
{
33,
1729184813,
},
{
52,
1729184813,
},
{
67,
1729184813,
},
{
3,
1729185356,
},
{
18,
1729185356,
},
{
33,
1729185356,
},
{
52,
1729185356,
},
{
67,
1729185356,
},
{
168,
1729185356,
},
{
183,
1729185356,
},
{
198,
1729185356,
},
{
217,
1729185356,
},
{
232,
1729185356,
},
{
335,
1729185356,
},
{
350,
1729185356,
},
{
365,
1729185356,
},
{
384,
1729185356,
},
{
399,
1729185356,
},
{
3,
1729970361,
},
{
18,
1729970361,
},
{
33,
1729970361,
},
{
52,
1729970361,
},
{
67,
1729970361,
},
{
197,
1729970361,
},
{
212,
1729970361,
},
{
3,
1729971251,
},
{
18,
1729971251,
},
{
33,
1729971251,
},
{
52,
1729971251,
},
{
67,
1729971251,
},
{
177,
1729971251,
},
{
192,
1729971251,
},
{
207,
1729971251,
},
{
226,
1729971251,
},
{
241,
1729971251,
},
{
354,
1729971251,
},
{
369,
1729971251,
},
{
384,
1729971251,
},
{
403,
1729971251,
},
{
418,
1729971251,
},
{
3,
1729973842,
},
{
18,
1729973842,
},
{
33,
1729973842,
},
{
52,
1729973842,
},
{
67,
1729973842,
},
{
169,
1729973842,
},
{
184,
1729973842,
},
{
199,
1729973842,
},
{
218,
1729973842,
},
{
233,
1729973842,
},
{
341,
1729973842,
},
{
356,
1729973842,
},
{
371,
1729973842,
},
{
390,
1729973842,
},
{
405,
1729973842,
},
},
["Желудочный сок"] = {
{
17,
1727621948,
},
{
64,
1727621948,
},
{
16,
1727622447,
},
{
63,
1727622447,
},
{
191,
1727622447,
},
{
238,
1727622447,
},
{
381,
1727622447,
},
{
16,
1727623206,
},
{
63,
1727623206,
},
{
193,
1727623206,
},
{
240,
1727623206,
},
{
369,
1727623206,
},
{
416,
1727623206,
},
{
549,
1727623206,
},
{
596,
1727623206,
},
{
17,
1727623466,
},
{
64,
1727623466,
},
{
16,
1727624051,
},
{
63,
1727624051,
},
{
187,
1727624051,
},
{
17,
1727624668,
},
{
64,
1727624668,
},
{
195,
1727624668,
},
{
242,
1727624668,
},
{
16,
1727625015,
},
{
63,
1727625015,
},
{
16,
1727625604,
},
{
63,
1727625604,
},
{
188,
1727625604,
},
{
235,
1727625604,
},
{
16,
1727628606,
},
{
63,
1727628606,
},
{
16,
1727628873,
},
{
63,
1727628873,
},
{
16,
1727631159,
},
{
63,
1727631159,
},
{
17,
1727631850,
},
{
64,
1727631850,
},
{
185,
1727631850,
},
{
232,
1727631850,
},
{
353,
1727631850,
},
{
400,
1727631850,
},
{
524,
1727631850,
},
{
571,
1727631850,
},
{
17,
1727892316,
},
{
64,
1727892316,
},
{
189,
1727892316,
},
{
236,
1727892316,
},
{
17,
1727892484,
},
{
17,
1727892646,
},
{
64,
1727892646,
},
{
17,
1727893601,
},
{
64,
1727893601,
},
{
17,
1727894099,
},
{
64,
1727894099,
},
{
199,
1727894099,
},
{
246,
1727894099,
},
{
17,
1727985140,
},
{
64,
1727985140,
},
{
203,
1727985140,
},
{
250,
1727985140,
},
{
390,
1727985140,
},
{
437,
1727985140,
},
{
579,
1727985140,
},
{
17,
1727986257,
},
{
64,
1727986257,
},
{
199,
1727986257,
},
{
246,
1727986257,
},
{
16,
1727987450,
},
{
63,
1727987450,
},
{
184,
1727987450,
},
{
231,
1727987450,
},
{
359,
1727987450,
},
{
406,
1727987450,
},
{
533,
1727987450,
},
{
580,
1727987450,
},
{
16,
1727988274,
},
{
63,
1727988274,
},
{
183,
1727988274,
},
{
230,
1727988274,
},
{
355,
1727988274,
},
{
402,
1727988274,
},
{
522,
1727988274,
},
{
569,
1727988274,
},
{
17,
1728490934,
},
{
64,
1728490934,
},
{
17,
1728492773,
},
{
64,
1728492773,
},
{
189,
1728492773,
},
{
236,
1728492773,
},
{
367,
1728492773,
},
{
414,
1728492773,
},
{
541,
1728492773,
},
{
16,
1729184813,
},
{
63,
1729184813,
},
{
16,
1729185356,
},
{
63,
1729185356,
},
{
181,
1729185356,
},
{
228,
1729185356,
},
{
348,
1729185356,
},
{
395,
1729185356,
},
{
16,
1729970361,
},
{
63,
1729970361,
},
{
196,
1729970361,
},
{
16,
1729971251,
},
{
63,
1729971251,
},
{
190,
1729971251,
},
{
237,
1729971251,
},
{
367,
1729971251,
},
{
414,
1729971251,
},
{
17,
1729973842,
},
{
64,
1729973842,
},
{
183,
1729973842,
},
{
230,
1729973842,
},
{
354,
1729973842,
},
{
401,
1729973842,
},
},
["Биоактивные иглы"] = {
{
111,
1727621948,
},
{
115,
1727621948,
},
{
121,
1727621948,
},
{
123,
1727621948,
},
{
124,
1727621948,
},
{
126,
1727621948,
},
{
128,
1727621948,
},
{
132,
1727621948,
},
{
134,
1727621948,
},
{
136,
1727621948,
},
{
139,
1727621948,
},
{
143,
1727621948,
},
{
145,
1727621948,
},
{
147,
1727621948,
},
{
150,
1727621948,
},
{
116,
1727622447,
},
{
118,
1727622447,
},
{
122,
1727622447,
},
{
127,
1727622447,
},
{
128,
1727622447,
},
{
129,
1727622447,
},
{
133,
1727622447,
},
{
138,
1727622447,
},
{
139,
1727622447,
},
{
140,
1727622447,
},
{
149,
1727622447,
},
{
150,
1727622447,
},
{
287,
1727622447,
},
{
292,
1727622447,
},
{
297,
1727622447,
},
{
298,
1727622447,
},
{
302,
1727622447,
},
{
303,
1727622447,
},
{
308,
1727622447,
},
{
312,
1727622447,
},
{
314,
1727622447,
},
{
319,
1727622447,
},
{
320,
1727622447,
},
{
323,
1727622447,
},
{
325,
1727622447,
},
{
330,
1727622447,
},
{
331,
1727622447,
},
{
334,
1727622447,
},
{
113,
1727623206,
},
{
114,
1727623206,
},
{
123,
1727623206,
},
{
124,
1727623206,
},
{
125,
1727623206,
},
{
128,
1727623206,
},
{
134,
1727623206,
},
{
136,
1727623206,
},
{
139,
1727623206,
},
{
145,
1727623206,
},
{
146,
1727623206,
},
{
151,
1727623206,
},
{
295,
1727623206,
},
{
296,
1727623206,
},
{
300,
1727623206,
},
{
305,
1727623206,
},
{
306,
1727623206,
},
{
307,
1727623206,
},
{
312,
1727623206,
},
{
316,
1727623206,
},
{
317,
1727623206,
},
{
323,
1727623206,
},
{
327,
1727623206,
},
{
334,
1727623206,
},
{
338,
1727623206,
},
{
464,
1727623206,
},
{
468,
1727623206,
},
{
474,
1727623206,
},
{
476,
1727623206,
},
{
477,
1727623206,
},
{
478,
1727623206,
},
{
482,
1727623206,
},
{
485,
1727623206,
},
{
487,
1727623206,
},
{
488,
1727623206,
},
{
489,
1727623206,
},
{
493,
1727623206,
},
{
498,
1727623206,
},
{
499,
1727623206,
},
{
500,
1727623206,
},
{
504,
1727623206,
},
{
510,
1727623206,
},
{
515,
1727623206,
},
{
115,
1727623466,
},
{
116,
1727623466,
},
{
124,
1727623466,
},
{
126,
1727623466,
},
{
128,
1727623466,
},
{
135,
1727623466,
},
{
137,
1727623466,
},
{
139,
1727623466,
},
{
146,
1727623466,
},
{
148,
1727623466,
},
{
150,
1727623466,
},
{
157,
1727623466,
},
{
160,
1727623466,
},
{
161,
1727623466,
},
{
168,
1727623466,
},
{
113,
1727624051,
},
{
119,
1727624051,
},
{
124,
1727624051,
},
{
128,
1727624051,
},
{
130,
1727624051,
},
{
135,
1727624051,
},
{
139,
1727624051,
},
{
141,
1727624051,
},
{
146,
1727624051,
},
{
150,
1727624051,
},
{
117,
1727624668,
},
{
118,
1727624668,
},
{
123,
1727624668,
},
{
127,
1727624668,
},
{
128,
1727624668,
},
{
134,
1727624668,
},
{
137,
1727624668,
},
{
139,
1727624668,
},
{
145,
1727624668,
},
{
148,
1727624668,
},
{
150,
1727624668,
},
{
159,
1727624668,
},
{
296,
1727624668,
},
{
297,
1727624668,
},
{
298,
1727624668,
},
{
307,
1727624668,
},
{
308,
1727624668,
},
{
309,
1727624668,
},
{
318,
1727624668,
},
{
319,
1727624668,
},
{
320,
1727624668,
},
{
329,
1727624668,
},
{
330,
1727624668,
},
{
340,
1727624668,
},
{
341,
1727624668,
},
{
351,
1727624668,
},
{
115,
1727625015,
},
{
121,
1727625015,
},
{
126,
1727625015,
},
{
129,
1727625015,
},
{
131,
1727625015,
},
{
136,
1727625015,
},
{
137,
1727625015,
},
{
140,
1727625015,
},
{
142,
1727625015,
},
{
148,
1727625015,
},
{
151,
1727625015,
},
{
152,
1727625015,
},
{
159,
1727625015,
},
{
117,
1727625604,
},
{
122,
1727625604,
},
{
127,
1727625604,
},
{
128,
1727625604,
},
{
132,
1727625604,
},
{
138,
1727625604,
},
{
139,
1727625604,
},
{
140,
1727625604,
},
{
143,
1727625604,
},
{
149,
1727625604,
},
{
113,
1727628606,
},
{
118,
1727628606,
},
{
115,
1727628873,
},
{
118,
1727628873,
},
{
113,
1727631159,
},
{
118,
1727631159,
},
{
123,
1727631159,
},
{
124,
1727631159,
},
{
128,
1727631159,
},
{
129,
1727631159,
},
{
134,
1727631159,
},
{
135,
1727631159,
},
{
139,
1727631159,
},
{
140,
1727631159,
},
{
145,
1727631159,
},
{
150,
1727631159,
},
{
151,
1727631159,
},
{
156,
1727631159,
},
{
118,
1727631850,
},
{
123,
1727631850,
},
{
128,
1727631850,
},
{
129,
1727631850,
},
{
134,
1727631850,
},
{
139,
1727631850,
},
{
140,
1727631850,
},
{
145,
1727631850,
},
{
150,
1727631850,
},
{
151,
1727631850,
},
{
160,
1727631850,
},
{
280,
1727631850,
},
{
286,
1727631850,
},
{
292,
1727631850,
},
{
296,
1727631850,
},
{
303,
1727631850,
},
{
307,
1727631850,
},
{
314,
1727631850,
},
{
318,
1727631850,
},
{
329,
1727631850,
},
{
449,
1727631850,
},
{
455,
1727631850,
},
{
460,
1727631850,
},
{
465,
1727631850,
},
{
466,
1727631850,
},
{
471,
1727631850,
},
{
472,
1727631850,
},
{
476,
1727631850,
},
{
477,
1727631850,
},
{
481,
1727631850,
},
{
482,
1727631850,
},
{
487,
1727631850,
},
{
488,
1727631850,
},
{
116,
1727892316,
},
{
119,
1727892316,
},
{
124,
1727892316,
},
{
127,
1727892316,
},
{
128,
1727892316,
},
{
130,
1727892316,
},
{
135,
1727892316,
},
{
139,
1727892316,
},
{
150,
1727892316,
},
{
111,
1727893601,
},
{
119,
1727893601,
},
{
122,
1727893601,
},
{
124,
1727893601,
},
{
125,
1727893601,
},
{
129,
1727893601,
},
{
130,
1727893601,
},
{
133,
1727893601,
},
{
135,
1727893601,
},
{
136,
1727893601,
},
{
116,
1727894099,
},
{
118,
1727894099,
},
{
122,
1727894099,
},
{
126,
1727894099,
},
{
129,
1727894099,
},
{
133,
1727894099,
},
{
136,
1727894099,
},
{
140,
1727894099,
},
{
141,
1727894099,
},
{
144,
1727894099,
},
{
151,
1727894099,
},
{
298,
1727894099,
},
{
301,
1727894099,
},
{
304,
1727894099,
},
{
309,
1727894099,
},
{
311,
1727894099,
},
{
312,
1727894099,
},
{
315,
1727894099,
},
{
320,
1727894099,
},
{
322,
1727894099,
},
{
323,
1727894099,
},
{
327,
1727894099,
},
{
331,
1727894099,
},
{
333,
1727894099,
},
{
334,
1727894099,
},
{
338,
1727894099,
},
{
343,
1727894099,
},
{
344,
1727894099,
},
{
345,
1727894099,
},
{
349,
1727894099,
},
{
355,
1727894099,
},
{
356,
1727894099,
},
{
118,
1727985140,
},
{
119,
1727985140,
},
{
124,
1727985140,
},
{
127,
1727985140,
},
{
128,
1727985140,
},
{
129,
1727985140,
},
{
130,
1727985140,
},
{
135,
1727985140,
},
{
138,
1727985140,
},
{
139,
1727985140,
},
{
140,
1727985140,
},
{
141,
1727985140,
},
{
146,
1727985140,
},
{
149,
1727985140,
},
{
151,
1727985140,
},
{
160,
1727985140,
},
{
162,
1727985140,
},
{
297,
1727985140,
},
{
305,
1727985140,
},
{
308,
1727985140,
},
{
310,
1727985140,
},
{
315,
1727985140,
},
{
316,
1727985140,
},
{
319,
1727985140,
},
{
321,
1727985140,
},
{
326,
1727985140,
},
{
327,
1727985140,
},
{
332,
1727985140,
},
{
337,
1727985140,
},
{
338,
1727985140,
},
{
343,
1727985140,
},
{
348,
1727985140,
},
{
487,
1727985140,
},
{
491,
1727985140,
},
{
497,
1727985140,
},
{
498,
1727985140,
},
{
502,
1727985140,
},
{
508,
1727985140,
},
{
509,
1727985140,
},
{
513,
1727985140,
},
{
519,
1727985140,
},
{
520,
1727985140,
},
{
524,
1727985140,
},
{
525,
1727985140,
},
{
530,
1727985140,
},
{
535,
1727985140,
},
{
536,
1727985140,
},
{
541,
1727985140,
},
{
547,
1727985140,
},
{
118,
1727986257,
},
{
123,
1727986257,
},
{
127,
1727986257,
},
{
128,
1727986257,
},
{
134,
1727986257,
},
{
139,
1727986257,
},
{
145,
1727986257,
},
{
150,
1727986257,
},
{
156,
1727986257,
},
{
161,
1727986257,
},
{
293,
1727986257,
},
{
299,
1727986257,
},
{
302,
1727986257,
},
{
304,
1727986257,
},
{
306,
1727986257,
},
{
309,
1727986257,
},
{
311,
1727986257,
},
{
313,
1727986257,
},
{
315,
1727986257,
},
{
317,
1727986257,
},
{
320,
1727986257,
},
{
322,
1727986257,
},
{
324,
1727986257,
},
{
326,
1727986257,
},
{
327,
1727986257,
},
{
331,
1727986257,
},
{
333,
1727986257,
},
{
337,
1727986257,
},
{
338,
1727986257,
},
{
344,
1727986257,
},
{
348,
1727986257,
},
{
359,
1727986257,
},
{
112,
1727987450,
},
{
118,
1727987450,
},
{
122,
1727987450,
},
{
123,
1727987450,
},
{
128,
1727987450,
},
{
129,
1727987450,
},
{
133,
1727987450,
},
{
135,
1727987450,
},
{
138,
1727987450,
},
{
145,
1727987450,
},
{
149,
1727987450,
},
{
160,
1727987450,
},
{
279,
1727987450,
},
{
285,
1727987450,
},
{
289,
1727987450,
},
{
290,
1727987450,
},
{
295,
1727987450,
},
{
296,
1727987450,
},
{
300,
1727987450,
},
{
305,
1727987450,
},
{
307,
1727987450,
},
{
312,
1727987450,
},
{
316,
1727987450,
},
{
317,
1727987450,
},
{
322,
1727987450,
},
{
327,
1727987450,
},
{
460,
1727987450,
},
{
466,
1727987450,
},
{
470,
1727987450,
},
{
471,
1727987450,
},
{
477,
1727987450,
},
{
481,
1727987450,
},
{
482,
1727987450,
},
{
488,
1727987450,
},
{
492,
1727987450,
},
{
493,
1727987450,
},
{
499,
1727987450,
},
{
504,
1727987450,
},
{
118,
1727988274,
},
{
124,
1727988274,
},
{
128,
1727988274,
},
{
129,
1727988274,
},
{
135,
1727988274,
},
{
139,
1727988274,
},
{
140,
1727988274,
},
{
151,
1727988274,
},
{
285,
1727988274,
},
{
289,
1727988274,
},
{
294,
1727988274,
},
{
295,
1727988274,
},
{
296,
1727988274,
},
{
300,
1727988274,
},
{
305,
1727988274,
},
{
316,
1727988274,
},
{
455,
1727988274,
},
{
456,
1727988274,
},
{
461,
1727988274,
},
{
466,
1727988274,
},
{
467,
1727988274,
},
{
472,
1727988274,
},
{
476,
1727988274,
},
{
478,
1727988274,
},
{
487,
1727988274,
},
{
498,
1727988274,
},
{
117,
1728492773,
},
{
119,
1728492773,
},
{
123,
1728492773,
},
{
128,
1728492773,
},
{
129,
1728492773,
},
{
130,
1728492773,
},
{
134,
1728492773,
},
{
139,
1728492773,
},
{
140,
1728492773,
},
{
141,
1728492773,
},
{
146,
1728492773,
},
{
152,
1728492773,
},
{
157,
1728492773,
},
{
163,
1728492773,
},
{
288,
1728492773,
},
{
290,
1728492773,
},
{
293,
1728492773,
},
{
299,
1728492773,
},
{
301,
1728492773,
},
{
303,
1728492773,
},
{
310,
1728492773,
},
{
312,
1728492773,
},
{
314,
1728492773,
},
{
323,
1728492773,
},
{
325,
1728492773,
},
{
334,
1728492773,
},
{
461,
1728492773,
},
{
467,
1728492773,
},
{
470,
1728492773,
},
{
471,
1728492773,
},
{
473,
1728492773,
},
{
478,
1728492773,
},
{
481,
1728492773,
},
{
482,
1728492773,
},
{
484,
1728492773,
},
{
489,
1728492773,
},
{
492,
1728492773,
},
{
493,
1728492773,
},
{
495,
1728492773,
},
{
500,
1728492773,
},
{
118,
1729184813,
},
{
119,
1729184813,
},
{
121,
1729184813,
},
{
129,
1729184813,
},
{
130,
1729184813,
},
{
132,
1729184813,
},
{
140,
1729184813,
},
{
144,
1729184813,
},
{
151,
1729184813,
},
{
155,
1729184813,
},
{
116,
1729185356,
},
{
118,
1729185356,
},
{
124,
1729185356,
},
{
126,
1729185356,
},
{
128,
1729185356,
},
{
129,
1729185356,
},
{
134,
1729185356,
},
{
136,
1729185356,
},
{
139,
1729185356,
},
{
140,
1729185356,
},
{
277,
1729185356,
},
{
283,
1729185356,
},
{
286,
1729185356,
},
{
288,
1729185356,
},
{
293,
1729185356,
},
{
294,
1729185356,
},
{
297,
1729185356,
},
{
299,
1729185356,
},
{
304,
1729185356,
},
{
305,
1729185356,
},
{
308,
1729185356,
},
{
315,
1729185356,
},
{
110,
1729970361,
},
{
117,
1729970361,
},
{
121,
1729970361,
},
{
122,
1729970361,
},
{
128,
1729970361,
},
{
132,
1729970361,
},
{
133,
1729970361,
},
{
138,
1729970361,
},
{
144,
1729970361,
},
{
149,
1729970361,
},
{
154,
1729970361,
},
{
160,
1729970361,
},
{
115,
1729971251,
},
{
118,
1729971251,
},
{
123,
1729971251,
},
{
125,
1729971251,
},
{
128,
1729971251,
},
{
129,
1729971251,
},
{
134,
1729971251,
},
{
137,
1729971251,
},
{
138,
1729971251,
},
{
139,
1729971251,
},
{
140,
1729971251,
},
{
145,
1729971251,
},
{
149,
1729971251,
},
{
150,
1729971251,
},
{
161,
1729971251,
},
{
290,
1729971251,
},
{
291,
1729971251,
},
{
296,
1729971251,
},
{
301,
1729971251,
},
{
302,
1729971251,
},
{
307,
1729971251,
},
{
312,
1729971251,
},
{
313,
1729971251,
},
{
323,
1729971251,
},
{
325,
1729971251,
},
{
334,
1729971251,
},
{
345,
1729971251,
},
{
469,
1729971251,
},
{
474,
1729971251,
},
{
479,
1729971251,
},
{
480,
1729971251,
},
{
485,
1729971251,
},
{
490,
1729971251,
},
{
491,
1729971251,
},
{
496,
1729971251,
},
{
501,
1729971251,
},
{
502,
1729971251,
},
{
507,
1729971251,
},
{
512,
1729971251,
},
{
513,
1729971251,
},
{
111,
1729973842,
},
{
118,
1729973842,
},
{
122,
1729973842,
},
{
123,
1729973842,
},
{
124,
1729973842,
},
{
128,
1729973842,
},
{
129,
1729973842,
},
{
132,
1729973842,
},
{
134,
1729973842,
},
{
135,
1729973842,
},
{
138,
1729973842,
},
{
141,
1729973842,
},
{
142,
1729973842,
},
{
145,
1729973842,
},
{
150,
1729973842,
},
{
280,
1729973842,
},
{
285,
1729973842,
},
{
290,
1729973842,
},
{
291,
1729973842,
},
{
296,
1729973842,
},
{
301,
1729973842,
},
{
302,
1729973842,
},
{
314,
1729973842,
},
{
450,
1729973842,
},
{
455,
1729973842,
},
{
460,
1729973842,
},
{
461,
1729973842,
},
{
465,
1729973842,
},
{
466,
1729973842,
},
{
471,
1729973842,
},
{
473,
1729973842,
},
{
475,
1729973842,
},
{
478,
1729973842,
},
},
["Поглощающий мрак"] = {
{
141,
1727621948,
},
{
141,
1727622447,
},
{
315,
1727622447,
},
{
142,
1727623206,
},
{
318,
1727623206,
},
{
495,
1727623206,
},
{
141,
1727623466,
},
{
142,
1727624051,
},
{
141,
1727624668,
},
{
320,
1727624668,
},
{
142,
1727625015,
},
{
141,
1727625604,
},
{
142,
1727631159,
},
{
141,
1727631850,
},
{
310,
1727631850,
},
{
478,
1727631850,
},
{
142,
1727892316,
},
{
142,
1727894099,
},
{
324,
1727894099,
},
{
142,
1727985140,
},
{
328,
1727985140,
},
{
515,
1727985140,
},
{
141,
1727986257,
},
{
324,
1727986257,
},
{
141,
1727987450,
},
{
308,
1727987450,
},
{
484,
1727987450,
},
{
142,
1727988274,
},
{
307,
1727988274,
},
{
479,
1727988274,
},
{
142,
1728492773,
},
{
315,
1728492773,
},
{
491,
1728492773,
},
{
142,
1729184813,
},
{
142,
1729185356,
},
{
306,
1729185356,
},
{
141,
1729970361,
},
{
142,
1729971251,
},
{
315,
1729971251,
},
{
493,
1729971251,
},
{
142,
1729973842,
},
{
309,
1729973842,
},
{
479,
1729973842,
},
},
["Потрошение"] = {
{
116,
1727621948,
},
{
121,
1727621948,
},
{
123,
1727621948,
},
{
124,
1727621948,
},
{
125,
1727621948,
},
{
128,
1727621948,
},
{
129,
1727621948,
},
{
130,
1727621948,
},
{
132,
1727621948,
},
{
133,
1727621948,
},
{
134,
1727621948,
},
{
136,
1727621948,
},
{
137,
1727621948,
},
{
138,
1727621948,
},
{
139,
1727621948,
},
{
140,
1727621948,
},
{
141,
1727621948,
},
{
143,
1727621948,
},
{
144,
1727621948,
},
{
145,
1727621948,
},
{
146,
1727621948,
},
{
147,
1727621948,
},
{
148,
1727621948,
},
{
150,
1727621948,
},
{
151,
1727621948,
},
{
152,
1727621948,
},
{
153,
1727621948,
},
{
121,
1727622447,
},
{
123,
1727622447,
},
{
129,
1727622447,
},
{
130,
1727622447,
},
{
132,
1727622447,
},
{
133,
1727622447,
},
{
134,
1727622447,
},
{
136,
1727622447,
},
{
137,
1727622447,
},
{
139,
1727622447,
},
{
141,
1727622447,
},
{
143,
1727622447,
},
{
146,
1727622447,
},
{
147,
1727622447,
},
{
148,
1727622447,
},
{
149,
1727622447,
},
{
156,
1727622447,
},
{
292,
1727622447,
},
{
297,
1727622447,
},
{
299,
1727622447,
},
{
301,
1727622447,
},
{
303,
1727622447,
},
{
304,
1727622447,
},
{
305,
1727622447,
},
{
307,
1727622447,
},
{
308,
1727622447,
},
{
311,
1727622447,
},
{
312,
1727622447,
},
{
313,
1727622447,
},
{
315,
1727622447,
},
{
316,
1727622447,
},
{
318,
1727622447,
},
{
319,
1727622447,
},
{
320,
1727622447,
},
{
322,
1727622447,
},
{
323,
1727622447,
},
{
325,
1727622447,
},
{
327,
1727622447,
},
{
328,
1727622447,
},
{
329,
1727622447,
},
{
331,
1727622447,
},
{
333,
1727622447,
},
{
334,
1727622447,
},
{
337,
1727622447,
},
{
118,
1727623206,
},
{
119,
1727623206,
},
{
123,
1727623206,
},
{
125,
1727623206,
},
{
127,
1727623206,
},
{
128,
1727623206,
},
{
129,
1727623206,
},
{
134,
1727623206,
},
{
135,
1727623206,
},
{
137,
1727623206,
},
{
138,
1727623206,
},
{
139,
1727623206,
},
{
141,
1727623206,
},
{
142,
1727623206,
},
{
143,
1727623206,
},
{
144,
1727623206,
},
{
145,
1727623206,
},
{
150,
1727623206,
},
{
152,
1727623206,
},
{
301,
1727623206,
},
{
306,
1727623206,
},
{
307,
1727623206,
},
{
308,
1727623206,
},
{
309,
1727623206,
},
{
310,
1727623206,
},
{
311,
1727623206,
},
{
314,
1727623206,
},
{
315,
1727623206,
},
{
316,
1727623206,
},
{
318,
1727623206,
},
{
319,
1727623206,
},
{
322,
1727623206,
},
{
323,
1727623206,
},
{
324,
1727623206,
},
{
326,
1727623206,
},
{
329,
1727623206,
},
{
330,
1727623206,
},
{
333,
1727623206,
},
{
334,
1727623206,
},
{
336,
1727623206,
},
{
340,
1727623206,
},
{
469,
1727623206,
},
{
473,
1727623206,
},
{
477,
1727623206,
},
{
481,
1727623206,
},
{
482,
1727623206,
},
{
483,
1727623206,
},
{
485,
1727623206,
},
{
487,
1727623206,
},
{
488,
1727623206,
},
{
490,
1727623206,
},
{
491,
1727623206,
},
{
492,
1727623206,
},
{
494,
1727623206,
},
{
495,
1727623206,
},
{
496,
1727623206,
},
{
497,
1727623206,
},
{
498,
1727623206,
},
{
500,
1727623206,
},
{
502,
1727623206,
},
{
503,
1727623206,
},
{
505,
1727623206,
},
{
510,
1727623206,
},
{
518,
1727623206,
},
{
120,
1727623466,
},
{
121,
1727623466,
},
{
128,
1727623466,
},
{
129,
1727623466,
},
{
130,
1727623466,
},
{
133,
1727623466,
},
{
134,
1727623466,
},
{
135,
1727623466,
},
{
136,
1727623466,
},
{
137,
1727623466,
},
{
138,
1727623466,
},
{
139,
1727623466,
},
{
140,
1727623466,
},
{
141,
1727623466,
},
{
142,
1727623466,
},
{
144,
1727623466,
},
{
145,
1727623466,
},
{
146,
1727623466,
},
{
149,
1727623466,
},
{
151,
1727623466,
},
{
152,
1727623466,
},
{
159,
1727623466,
},
{
164,
1727623466,
},
{
168,
1727623466,
},
{
118,
1727624051,
},
{
124,
1727624051,
},
{
126,
1727624051,
},
{
127,
1727624051,
},
{
129,
1727624051,
},
{
130,
1727624051,
},
{
133,
1727624051,
},
{
136,
1727624051,
},
{
137,
1727624051,
},
{
138,
1727624051,
},
{
139,
1727624051,
},
{
140,
1727624051,
},
{
141,
1727624051,
},
{
142,
1727624051,
},
{
144,
1727624051,
},
{
145,
1727624051,
},
{
147,
1727624051,
},
{
149,
1727624051,
},
{
157,
1727624051,
},
{
122,
1727624668,
},
{
123,
1727624668,
},
{
128,
1727624668,
},
{
129,
1727624668,
},
{
131,
1727624668,
},
{
132,
1727624668,
},
{
133,
1727624668,
},
{
134,
1727624668,
},
{
137,
1727624668,
},
{
138,
1727624668,
},
{
139,
1727624668,
},
{
140,
1727624668,
},
{
142,
1727624668,
},
{
144,
1727624668,
},
{
145,
1727624668,
},
{
146,
1727624668,
},
{
147,
1727624668,
},
{
149,
1727624668,
},
{
151,
1727624668,
},
{
152,
1727624668,
},
{
153,
1727624668,
},
{
154,
1727624668,
},
{
157,
1727624668,
},
{
162,
1727624668,
},
{
302,
1727624668,
},
{
303,
1727624668,
},
{
307,
1727624668,
},
{
308,
1727624668,
},
{
310,
1727624668,
},
{
312,
1727624668,
},
{
313,
1727624668,
},
{
314,
1727624668,
},
{
315,
1727624668,
},
{
316,
1727624668,
},
{
317,
1727624668,
},
{
318,
1727624668,
},
{
319,
1727624668,
},
{
321,
1727624668,
},
{
322,
1727624668,
},
{
323,
1727624668,
},
{
324,
1727624668,
},
{
325,
1727624668,
},
{
327,
1727624668,
},
{
328,
1727624668,
},
{
329,
1727624668,
},
{
331,
1727624668,
},
{
332,
1727624668,
},
{
333,
1727624668,
},
{
334,
1727624668,
},
{
335,
1727624668,
},
{
340,
1727624668,
},
{
341,
1727624668,
},
{
342,
1727624668,
},
{
350,
1727624668,
},
{
121,
1727625015,
},
{
122,
1727625015,
},
{
125,
1727625015,
},
{
126,
1727625015,
},
{
129,
1727625015,
},
{
130,
1727625015,
},
{
132,
1727625015,
},
{
133,
1727625015,
},
{
134,
1727625015,
},
{
136,
1727625015,
},
{
137,
1727625015,
},
{
138,
1727625015,
},
{
139,
1727625015,
},
{
140,
1727625015,
},
{
141,
1727625015,
},
{
143,
1727625015,
},
{
144,
1727625015,
},
{
145,
1727625015,
},
{
147,
1727625015,
},
{
148,
1727625015,
},
{
150,
1727625015,
},
{
151,
1727625015,
},
{
153,
1727625015,
},
{
155,
1727625015,
},
{
156,
1727625015,
},
{
122,
1727625604,
},
{
124,
1727625604,
},
{
128,
1727625604,
},
{
129,
1727625604,
},
{
130,
1727625604,
},
{
131,
1727625604,
},
{
132,
1727625604,
},
{
133,
1727625604,
},
{
135,
1727625604,
},
{
137,
1727625604,
},
{
138,
1727625604,
},
{
139,
1727625604,
},
{
141,
1727625604,
},
{
142,
1727625604,
},
{
145,
1727625604,
},
{
148,
1727625604,
},
{
150,
1727625604,
},
{
156,
1727625604,
},
{
118,
1727631159,
},
{
123,
1727631159,
},
{
126,
1727631159,
},
{
128,
1727631159,
},
{
129,
1727631159,
},
{
130,
1727631159,
},
{
132,
1727631159,
},
{
133,
1727631159,
},
{
134,
1727631159,
},
{
137,
1727631159,
},
{
139,
1727631159,
},
{
140,
1727631159,
},
{
142,
1727631159,
},
{
144,
1727631159,
},
{
146,
1727631159,
},
{
148,
1727631159,
},
{
149,
1727631159,
},
{
150,
1727631159,
},
{
151,
1727631159,
},
{
152,
1727631159,
},
{
153,
1727631159,
},
{
154,
1727631159,
},
{
155,
1727631159,
},
{
123,
1727631850,
},
{
124,
1727631850,
},
{
129,
1727631850,
},
{
131,
1727631850,
},
{
132,
1727631850,
},
{
133,
1727631850,
},
{
137,
1727631850,
},
{
138,
1727631850,
},
{
139,
1727631850,
},
{
141,
1727631850,
},
{
142,
1727631850,
},
{
144,
1727631850,
},
{
145,
1727631850,
},
{
146,
1727631850,
},
{
148,
1727631850,
},
{
149,
1727631850,
},
{
150,
1727631850,
},
{
152,
1727631850,
},
{
153,
1727631850,
},
{
157,
1727631850,
},
{
158,
1727631850,
},
{
286,
1727631850,
},
{
291,
1727631850,
},
{
293,
1727631850,
},
{
294,
1727631850,
},
{
298,
1727631850,
},
{
299,
1727631850,
},
{
300,
1727631850,
},
{
302,
1727631850,
},
{
303,
1727631850,
},
{
305,
1727631850,
},
{
306,
1727631850,
},
{
309,
1727631850,
},
{
310,
1727631850,
},
{
311,
1727631850,
},
{
312,
1727631850,
},
{
313,
1727631850,
},
{
314,
1727631850,
},
{
315,
1727631850,
},
{
316,
1727631850,
},
{
317,
1727631850,
},
{
318,
1727631850,
},
{
320,
1727631850,
},
{
325,
1727631850,
},
{
454,
1727631850,
},
{
459,
1727631850,
},
{
461,
1727631850,
},
{
463,
1727631850,
},
{
466,
1727631850,
},
{
468,
1727631850,
},
{
471,
1727631850,
},
{
473,
1727631850,
},
{
474,
1727631850,
},
{
475,
1727631850,
},
{
476,
1727631850,
},
{
478,
1727631850,
},
{
479,
1727631850,
},
{
480,
1727631850,
},
{
481,
1727631850,
},
{
482,
1727631850,
},
{
483,
1727631850,
},
{
486,
1727631850,
},
{
487,
1727631850,
},
{
488,
1727631850,
},
{
489,
1727631850,
},
{
490,
1727631850,
},
{
493,
1727631850,
},
{
121,
1727892316,
},
{
123,
1727892316,
},
{
124,
1727892316,
},
{
129,
1727892316,
},
{
130,
1727892316,
},
{
132,
1727892316,
},
{
133,
1727892316,
},
{
134,
1727892316,
},
{
136,
1727892316,
},
{
137,
1727892316,
},
{
138,
1727892316,
},
{
140,
1727892316,
},
{
142,
1727892316,
},
{
143,
1727892316,
},
{
148,
1727892316,
},
{
149,
1727892316,
},
{
122,
1727893601,
},
{
124,
1727893601,
},
{
125,
1727893601,
},
{
129,
1727893601,
},
{
130,
1727893601,
},
{
131,
1727893601,
},
{
133,
1727893601,
},
{
135,
1727893601,
},
{
136,
1727893601,
},
{
121,
1727894099,
},
{
125,
1727894099,
},
{
127,
1727894099,
},
{
129,
1727894099,
},
{
132,
1727894099,
},
{
134,
1727894099,
},
{
135,
1727894099,
},
{
136,
1727894099,
},
{
140,
1727894099,
},
{
142,
1727894099,
},
{
143,
1727894099,
},
{
147,
1727894099,
},
{
148,
1727894099,
},
{
150,
1727894099,
},
{
303,
1727894099,
},
{
307,
1727894099,
},
{
310,
1727894099,
},
{
311,
1727894099,
},
{
315,
1727894099,
},
{
316,
1727894099,
},
{
317,
1727894099,
},
{
319,
1727894099,
},
{
322,
1727894099,
},
{
324,
1727894099,
},
{
326,
1727894099,
},
{
329,
1727894099,
},
{
330,
1727894099,
},
{
332,
1727894099,
},
{
333,
1727894099,
},
{
334,
1727894099,
},
{
336,
1727894099,
},
{
337,
1727894099,
},
{
339,
1727894099,
},
{
341,
1727894099,
},
{
344,
1727894099,
},
{
346,
1727894099,
},
{
347,
1727894099,
},
{
348,
1727894099,
},
{
354,
1727894099,
},
{
355,
1727894099,
},
{
123,
1727985140,
},
{
125,
1727985140,
},
{
127,
1727985140,
},
{
129,
1727985140,
},
{
130,
1727985140,
},
{
131,
1727985140,
},
{
132,
1727985140,
},
{
133,
1727985140,
},
{
134,
1727985140,
},
{
138,
1727985140,
},
{
140,
1727985140,
},
{
141,
1727985140,
},
{
142,
1727985140,
},
{
143,
1727985140,
},
{
145,
1727985140,
},
{
147,
1727985140,
},
{
148,
1727985140,
},
{
150,
1727985140,
},
{
151,
1727985140,
},
{
153,
1727985140,
},
{
155,
1727985140,
},
{
157,
1727985140,
},
{
163,
1727985140,
},
{
165,
1727985140,
},
{
172,
1727985140,
},
{
307,
1727985140,
},
{
309,
1727985140,
},
{
311,
1727985140,
},
{
312,
1727985140,
},
{
315,
1727985140,
},
{
316,
1727985140,
},
{
318,
1727985140,
},
{
319,
1727985140,
},
{
320,
1727985140,
},
{
321,
1727985140,
},
{
322,
1727985140,
},
{
323,
1727985140,
},
{
324,
1727985140,
},
{
325,
1727985140,
},
{
326,
1727985140,
},
{
327,
1727985140,
},
{
328,
1727985140,
},
{
329,
1727985140,
},
{
331,
1727985140,
},
{
332,
1727985140,
},
{
334,
1727985140,
},
{
335,
1727985140,
},
{
336,
1727985140,
},
{
338,
1727985140,
},
{
340,
1727985140,
},
{
341,
1727985140,
},
{
342,
1727985140,
},
{
343,
1727985140,
},
{
345,
1727985140,
},
{
347,
1727985140,
},
{
348,
1727985140,
},
{
350,
1727985140,
},
{
492,
1727985140,
},
{
496,
1727985140,
},
{
497,
1727985140,
},
{
500,
1727985140,
},
{
502,
1727985140,
},
{
503,
1727985140,
},
{
504,
1727985140,
},
{
505,
1727985140,
},
{
506,
1727985140,
},
{
508,
1727985140,
},
{
510,
1727985140,
},
{
511,
1727985140,
},
{
512,
1727985140,
},
{
513,
1727985140,
},
{
514,
1727985140,
},
{
515,
1727985140,
},
{
516,
1727985140,
},
{
518,
1727985140,
},
{
519,
1727985140,
},
{
520,
1727985140,
},
{
522,
1727985140,
},
{
524,
1727985140,
},
{
525,
1727985140,
},
{
526,
1727985140,
},
{
527,
1727985140,
},
{
528,
1727985140,
},
{
529,
1727985140,
},
{
530,
1727985140,
},
{
531,
1727985140,
},
{
533,
1727985140,
},
{
534,
1727985140,
},
{
535,
1727985140,
},
{
538,
1727985140,
},
{
540,
1727985140,
},
{
546,
1727985140,
},
{
553,
1727985140,
},
{
123,
1727986257,
},
{
128,
1727986257,
},
{
129,
1727986257,
},
{
130,
1727986257,
},
{
131,
1727986257,
},
{
133,
1727986257,
},
{
134,
1727986257,
},
{
135,
1727986257,
},
{
136,
1727986257,
},
{
138,
1727986257,
},
{
139,
1727986257,
},
{
140,
1727986257,
},
{
141,
1727986257,
},
{
144,
1727986257,
},
{
145,
1727986257,
},
{
147,
1727986257,
},
{
149,
1727986257,
},
{
151,
1727986257,
},
{
154,
1727986257,
},
{
156,
1727986257,
},
{
158,
1727986257,
},
{
298,
1727986257,
},
{
305,
1727986257,
},
{
307,
1727986257,
},
{
311,
1727986257,
},
{
312,
1727986257,
},
{
314,
1727986257,
},
{
315,
1727986257,
},
{
316,
1727986257,
},
{
317,
1727986257,
},
{
318,
1727986257,
},
{
319,
1727986257,
},
{
321,
1727986257,
},
{
322,
1727986257,
},
{
323,
1727986257,
},
{
324,
1727986257,
},
{
326,
1727986257,
},
{
327,
1727986257,
},
{
328,
1727986257,
},
{
329,
1727986257,
},
{
332,
1727986257,
},
{
333,
1727986257,
},
{
334,
1727986257,
},
{
335,
1727986257,
},
{
336,
1727986257,
},
{
339,
1727986257,
},
{
341,
1727986257,
},
{
346,
1727986257,
},
{
351,
1727986257,
},
{
358,
1727986257,
},
{
119,
1727987450,
},
{
123,
1727987450,
},
{
126,
1727987450,
},
{
127,
1727987450,
},
{
129,
1727987450,
},
{
130,
1727987450,
},
{
131,
1727987450,
},
{
132,
1727987450,
},
{
133,
1727987450,
},
{
136,
1727987450,
},
{
137,
1727987450,
},
{
138,
1727987450,
},
{
140,
1727987450,
},
{
144,
1727987450,
},
{
145,
1727987450,
},
{
147,
1727987450,
},
{
155,
1727987450,
},
{
163,
1727987450,
},
{
285,
1727987450,
},
{
290,
1727987450,
},
{
291,
1727987450,
},
{
292,
1727987450,
},
{
295,
1727987450,
},
{
296,
1727987450,
},
{
297,
1727987450,
},
{
298,
1727987450,
},
{
299,
1727987450,
},
{
300,
1727987450,
},
{
301,
1727987450,
},
{
302,
1727987450,
},
{
303,
1727987450,
},
{
304,
1727987450,
},
{
305,
1727987450,
},
{
306,
1727987450,
},
{
308,
1727987450,
},
{
309,
1727987450,
},
{
311,
1727987450,
},
{
312,
1727987450,
},
{
313,
1727987450,
},
{
315,
1727987450,
},
{
318,
1727987450,
},
{
319,
1727987450,
},
{
320,
1727987450,
},
{
322,
1727987450,
},
{
323,
1727987450,
},
{
326,
1727987450,
},
{
330,
1727987450,
},
{
463,
1727987450,
},
{
465,
1727987450,
},
{
466,
1727987450,
},
{
470,
1727987450,
},
{
471,
1727987450,
},
{
472,
1727987450,
},
{
474,
1727987450,
},
{
475,
1727987450,
},
{
477,
1727987450,
},
{
479,
1727987450,
},
{
480,
1727987450,
},
{
481,
1727987450,
},
{
484,
1727987450,
},
{
487,
1727987450,
},
{
488,
1727987450,
},
{
489,
1727987450,
},
{
491,
1727987450,
},
{
494,
1727987450,
},
{
496,
1727987450,
},
{
498,
1727987450,
},
{
502,
1727987450,
},
{
506,
1727987450,
},
{
123,
1727988274,
},
{
124,
1727988274,
},
{
128,
1727988274,
},
{
129,
1727988274,
},
{
131,
1727988274,
},
{
132,
1727988274,
},
{
133,
1727988274,
},
{
134,
1727988274,
},
{
138,
1727988274,
},
{
139,
1727988274,
},
{
141,
1727988274,
},
{
146,
1727988274,
},
{
149,
1727988274,
},
{
150,
1727988274,
},
{
153,
1727988274,
},
{
157,
1727988274,
},
{
290,
1727988274,
},
{
292,
1727988274,
},
{
294,
1727988274,
},
{
298,
1727988274,
},
{
299,
1727988274,
},
{
300,
1727988274,
},
{
303,
1727988274,
},
{
305,
1727988274,
},
{
306,
1727988274,
},
{
307,
1727988274,
},
{
308,
1727988274,
},
{
315,
1727988274,
},
{
461,
1727988274,
},
{
462,
1727988274,
},
{
467,
1727988274,
},
{
468,
1727988274,
},
{
469,
1727988274,
},
{
470,
1727988274,
},
{
473,
1727988274,
},
{
474,
1727988274,
},
{
475,
1727988274,
},
{
476,
1727988274,
},
{
477,
1727988274,
},
{
479,
1727988274,
},
{
481,
1727988274,
},
{
483,
1727988274,
},
{
485,
1727988274,
},
{
486,
1727988274,
},
{
490,
1727988274,
},
{
493,
1727988274,
},
{
497,
1727988274,
},
{
504,
1727988274,
},
{
121,
1728492773,
},
{
123,
1728492773,
},
{
125,
1728492773,
},
{
128,
1728492773,
},
{
130,
1728492773,
},
{
132,
1728492773,
},
{
136,
1728492773,
},
{
138,
1728492773,
},
{
139,
1728492773,
},
{
140,
1728492773,
},
{
143,
1728492773,
},
{
145,
1728492773,
},
{
147,
1728492773,
},
{
151,
1728492773,
},
{
152,
1728492773,
},
{
154,
1728492773,
},
{
158,
1728492773,
},
{
166,
1728492773,
},
{
296,
1728492773,
},
{
298,
1728492773,
},
{
300,
1728492773,
},
{
301,
1728492773,
},
{
303,
1728492773,
},
{
305,
1728492773,
},
{
306,
1728492773,
},
{
307,
1728492773,
},
{
308,
1728492773,
},
{
309,
1728492773,
},
{
310,
1728492773,
},
{
311,
1728492773,
},
{
312,
1728492773,
},
{
313,
1728492773,
},
{
315,
1728492773,
},
{
316,
1728492773,
},
{
318,
1728492773,
},
{
319,
1728492773,
},
{
320,
1728492773,
},
{
322,
1728492773,
},
{
324,
1728492773,
},
{
325,
1728492773,
},
{
326,
1728492773,
},
{
327,
1728492773,
},
{
329,
1728492773,
},
{
330,
1728492773,
},
{
335,
1728492773,
},
{
337,
1728492773,
},
{
466,
1728492773,
},
{
474,
1728492773,
},
{
475,
1728492773,
},
{
478,
1728492773,
},
{
481,
1728492773,
},
{
482,
1728492773,
},
{
484,
1728492773,
},
{
487,
1728492773,
},
{
488,
1728492773,
},
{
489,
1728492773,
},
{
491,
1728492773,
},
{
492,
1728492773,
},
{
494,
1728492773,
},
{
496,
1728492773,
},
{
498,
1728492773,
},
{
499,
1728492773,
},
{
503,
1728492773,
},
{
507,
1728492773,
},
{
121,
1729184813,
},
{
124,
1729184813,
},
{
125,
1729184813,
},
{
128,
1729184813,
},
{
129,
1729184813,
},
{
130,
1729184813,
},
{
132,
1729184813,
},
{
133,
1729184813,
},
{
134,
1729184813,
},
{
136,
1729184813,
},
{
137,
1729184813,
},
{
138,
1729184813,
},
{
139,
1729184813,
},
{
140,
1729184813,
},
{
141,
1729184813,
},
{
142,
1729184813,
},
{
143,
1729184813,
},
{
146,
1729184813,
},
{
147,
1729184813,
},
{
148,
1729184813,
},
{
150,
1729184813,
},
{
151,
1729184813,
},
{
153,
1729184813,
},
{
154,
1729184813,
},
{
157,
1729184813,
},
{
121,
1729185356,
},
{
122,
1729185356,
},
{
125,
1729185356,
},
{
128,
1729185356,
},
{
129,
1729185356,
},
{
133,
1729185356,
},
{
135,
1729185356,
},
{
136,
1729185356,
},
{
138,
1729185356,
},
{
139,
1729185356,
},
{
142,
1729185356,
},
{
146,
1729185356,
},
{
282,
1729185356,
},
{
289,
1729185356,
},
{
290,
1729185356,
},
{
291,
1729185356,
},
{
293,
1729185356,
},
{
294,
1729185356,
},
{
296,
1729185356,
},
{
298,
1729185356,
},
{
299,
1729185356,
},
{
300,
1729185356,
},
{
301,
1729185356,
},
{
302,
1729185356,
},
{
303,
1729185356,
},
{
304,
1729185356,
},
{
307,
1729185356,
},
{
310,
1729185356,
},
{
311,
1729185356,
},
{
115,
1729970361,
},
{
124,
1729970361,
},
{
125,
1729970361,
},
{
126,
1729970361,
},
{
127,
1729970361,
},
{
131,
1729970361,
},
{
133,
1729970361,
},
{
135,
1729970361,
},
{
139,
1729970361,
},
{
143,
1729970361,
},
{
147,
1729970361,
},
{
148,
1729970361,
},
{
150,
1729970361,
},
{
154,
1729970361,
},
{
156,
1729970361,
},
{
121,
1729971251,
},
{
123,
1729971251,
},
{
128,
1729971251,
},
{
129,
1729971251,
},
{
132,
1729971251,
},
{
133,
1729971251,
},
{
135,
1729971251,
},
{
137,
1729971251,
},
{
138,
1729971251,
},
{
139,
1729971251,
},
{
141,
1729971251,
},
{
142,
1729971251,
},
{
144,
1729971251,
},
{
146,
1729971251,
},
{
149,
1729971251,
},
{
152,
1729971251,
},
{
153,
1729971251,
},
{
155,
1729971251,
},
{
157,
1729971251,
},
{
297,
1729971251,
},
{
303,
1729971251,
},
{
304,
1729971251,
},
{
305,
1729971251,
},
{
306,
1729971251,
},
{
308,
1729971251,
},
{
310,
1729971251,
},
{
311,
1729971251,
},
{
312,
1729971251,
},
{
314,
1729971251,
},
{
315,
1729971251,
},
{
317,
1729971251,
},
{
321,
1729971251,
},
{
322,
1729971251,
},
{
324,
1729971251,
},
{
327,
1729971251,
},
{
328,
1729971251,
},
{
330,
1729971251,
},
{
331,
1729971251,
},
{
337,
1729971251,
},
{
344,
1729971251,
},
{
475,
1729971251,
},
{
476,
1729971251,
},
{
479,
1729971251,
},
{
481,
1729971251,
},
{
483,
1729971251,
},
{
484,
1729971251,
},
{
486,
1729971251,
},
{
488,
1729971251,
},
{
490,
1729971251,
},
{
491,
1729971251,
},
{
497,
1729971251,
},
{
498,
1729971251,
},
{
500,
1729971251,
},
{
503,
1729971251,
},
{
504,
1729971251,
},
{
505,
1729971251,
},
{
508,
1729971251,
},
{
510,
1729971251,
},
{
511,
1729971251,
},
{
512,
1729971251,
},
{
515,
1729971251,
},
{
117,
1729973842,
},
{
124,
1729973842,
},
{
126,
1729973842,
},
{
128,
1729973842,
},
{
129,
1729973842,
},
{
130,
1729973842,
},
{
132,
1729973842,
},
{
133,
1729973842,
},
{
134,
1729973842,
},
{
136,
1729973842,
},
{
138,
1729973842,
},
{
139,
1729973842,
},
{
140,
1729973842,
},
{
141,
1729973842,
},
{
142,
1729973842,
},
{
143,
1729973842,
},
{
147,
1729973842,
},
{
149,
1729973842,
},
{
286,
1729973842,
},
{
291,
1729973842,
},
{
294,
1729973842,
},
{
295,
1729973842,
},
{
296,
1729973842,
},
{
299,
1729973842,
},
{
300,
1729973842,
},
{
301,
1729973842,
},
{
302,
1729973842,
},
{
304,
1729973842,
},
{
305,
1729973842,
},
{
306,
1729973842,
},
{
307,
1729973842,
},
{
313,
1729973842,
},
{
457,
1729973842,
},
{
464,
1729973842,
},
{
465,
1729973842,
},
{
469,
1729973842,
},
{
470,
1729973842,
},
{
472,
1729973842,
},
{
474,
1729973842,
},
{
475,
1729973842,
},
{
477,
1729973842,
},
{
478,
1729973842,
},
{
482,
1729973842,
},
},
["Голодный рев"] = {
{
153,
1727621948,
},
{
152,
1727622447,
},
{
159,
1727622447,
},
{
166,
1727622447,
},
{
327,
1727622447,
},
{
334,
1727622447,
},
{
341,
1727622447,
},
{
348,
1727622447,
},
{
356,
1727622447,
},
{
153,
1727623206,
},
{
160,
1727623206,
},
{
167,
1727623206,
},
{
330,
1727623206,
},
{
337,
1727623206,
},
{
344,
1727623206,
},
{
506,
1727623206,
},
{
513,
1727623206,
},
{
520,
1727623206,
},
{
527,
1727623206,
},
{
153,
1727623466,
},
{
160,
1727623466,
},
{
168,
1727623466,
},
{
154,
1727624051,
},
{
161,
1727624051,
},
{
152,
1727624668,
},
{
159,
1727624668,
},
{
166,
1727624668,
},
{
173,
1727624668,
},
{
331,
1727624668,
},
{
338,
1727624668,
},
{
345,
1727624668,
},
{
153,
1727625015,
},
{
153,
1727625604,
},
{
160,
1727625604,
},
{
167,
1727625604,
},
{
153,
1727631159,
},
{
160,
1727631159,
},
{
153,
1727631850,
},
{
160,
1727631850,
},
{
322,
1727631850,
},
{
329,
1727631850,
},
{
490,
1727631850,
},
{
497,
1727631850,
},
{
153,
1727892316,
},
{
160,
1727892316,
},
{
167,
1727892316,
},
{
154,
1727894099,
},
{
161,
1727894099,
},
{
168,
1727894099,
},
{
175,
1727894099,
},
{
336,
1727894099,
},
{
343,
1727894099,
},
{
350,
1727894099,
},
{
357,
1727894099,
},
{
365,
1727894099,
},
{
372,
1727894099,
},
{
154,
1727985140,
},
{
161,
1727985140,
},
{
168,
1727985140,
},
{
175,
1727985140,
},
{
340,
1727985140,
},
{
347,
1727985140,
},
{
354,
1727985140,
},
{
361,
1727985140,
},
{
369,
1727985140,
},
{
526,
1727985140,
},
{
533,
1727985140,
},
{
540,
1727985140,
},
{
547,
1727985140,
},
{
555,
1727985140,
},
{
153,
1727986257,
},
{
160,
1727986257,
},
{
167,
1727986257,
},
{
173,
1727986257,
},
{
335,
1727986257,
},
{
342,
1727986257,
},
{
349,
1727986257,
},
{
356,
1727986257,
},
{
153,
1727987450,
},
{
160,
1727987450,
},
{
320,
1727987450,
},
{
327,
1727987450,
},
{
334,
1727987450,
},
{
496,
1727987450,
},
{
503,
1727987450,
},
{
510,
1727987450,
},
{
154,
1727988274,
},
{
161,
1727988274,
},
{
319,
1727988274,
},
{
326,
1727988274,
},
{
491,
1727988274,
},
{
498,
1727988274,
},
{
154,
1728492773,
},
{
161,
1728492773,
},
{
326,
1728492773,
},
{
333,
1728492773,
},
{
340,
1728492773,
},
{
503,
1728492773,
},
{
510,
1728492773,
},
{
517,
1728492773,
},
{
154,
1729184813,
},
{
161,
1729184813,
},
{
153,
1729185356,
},
{
318,
1729185356,
},
{
325,
1729185356,
},
{
153,
1729970361,
},
{
160,
1729970361,
},
{
167,
1729970361,
},
{
174,
1729970361,
},
{
154,
1729971251,
},
{
161,
1729971251,
},
{
168,
1729971251,
},
{
327,
1729971251,
},
{
334,
1729971251,
},
{
341,
1729971251,
},
{
505,
1729971251,
},
{
511,
1729971251,
},
{
154,
1729973842,
},
{
161,
1729973842,
},
{
321,
1729973842,
},
{
328,
1729973842,
},
{
491,
1729973842,
},
{
498,
1729973842,
},
},
["Смена фаз"] = {
{
90,
1727621948,
},
{
89,
1727622447,
},
{
169,
1727622447,
},
{
264,
1727622447,
},
{
359,
1727622447,
},
{
89,
1727623206,
},
{
171,
1727623206,
},
{
266,
1727623206,
},
{
348,
1727623206,
},
{
442,
1727623206,
},
{
527,
1727623206,
},
{
90,
1727623466,
},
{
89,
1727624051,
},
{
165,
1727624051,
},
{
90,
1727624668,
},
{
174,
1727624668,
},
{
268,
1727624668,
},
{
89,
1727625015,
},
{
89,
1727625604,
},
{
167,
1727625604,
},
{
261,
1727625604,
},
{
89,
1727628606,
},
{
89,
1727628873,
},
{
89,
1727631159,
},
{
90,
1727631850,
},
{
163,
1727631850,
},
{
258,
1727631850,
},
{
331,
1727631850,
},
{
426,
1727631850,
},
{
502,
1727631850,
},
{
90,
1727892316,
},
{
167,
1727892316,
},
{
90,
1727893601,
},
{
90,
1727894099,
},
{
178,
1727894099,
},
{
272,
1727894099,
},
{
373,
1727894099,
},
{
90,
1727985140,
},
{
181,
1727985140,
},
{
276,
1727985140,
},
{
369,
1727985140,
},
{
463,
1727985140,
},
{
558,
1727985140,
},
{
90,
1727986257,
},
{
178,
1727986257,
},
{
272,
1727986257,
},
{
89,
1727987450,
},
{
162,
1727987450,
},
{
257,
1727987450,
},
{
337,
1727987450,
},
{
432,
1727987450,
},
{
512,
1727987450,
},
{
606,
1727987450,
},
{
89,
1727988274,
},
{
162,
1727988274,
},
{
256,
1727988274,
},
{
333,
1727988274,
},
{
428,
1727988274,
},
{
501,
1727988274,
},
{
90,
1728490934,
},
{
90,
1728492773,
},
{
168,
1728492773,
},
{
262,
1728492773,
},
{
345,
1728492773,
},
{
440,
1728492773,
},
{
519,
1728492773,
},
{
89,
1729184813,
},
{
89,
1729185356,
},
{
160,
1729185356,
},
{
254,
1729185356,
},
{
327,
1729185356,
},
{
421,
1729185356,
},
{
89,
1729970361,
},
{
174,
1729970361,
},
{
89,
1729971251,
},
{
169,
1729971251,
},
{
263,
1729971251,
},
{
346,
1729971251,
},
{
440,
1729971251,
},
{
90,
1729973842,
},
{
161,
1729973842,
},
{
256,
1729973842,
},
{
333,
1729973842,
},
{
427,
1729973842,
},
{
500,
1729973842,
},
},
["Игра хищника"] = {
{
34,
1727621948,
},
{
70,
1727621948,
},
{
33,
1727622447,
},
{
69,
1727622447,
},
{
208,
1727622447,
},
{
244,
1727622447,
},
{
33,
1727623206,
},
{
69,
1727623206,
},
{
210,
1727623206,
},
{
246,
1727623206,
},
{
386,
1727623206,
},
{
422,
1727623206,
},
{
566,
1727623206,
},
{
603,
1727623206,
},
{
34,
1727623466,
},
{
70,
1727623466,
},
{
34,
1727624051,
},
{
70,
1727624051,
},
{
204,
1727624051,
},
{
70,
1727624668,
},
{
212,
1727624668,
},
{
248,
1727624668,
},
{
33,
1727625015,
},
{
69,
1727625015,
},
{
34,
1727625604,
},
{
70,
1727625604,
},
{
205,
1727625604,
},
{
241,
1727625604,
},
{
34,
1727628606,
},
{
70,
1727628606,
},
{
33,
1727628873,
},
{
69,
1727628873,
},
{
33,
1727631159,
},
{
69,
1727631159,
},
{
34,
1727631850,
},
{
70,
1727631850,
},
{
202,
1727631850,
},
{
238,
1727631850,
},
{
370,
1727631850,
},
{
406,
1727631850,
},
{
541,
1727631850,
},
{
34,
1727892316,
},
{
70,
1727892316,
},
{
206,
1727892316,
},
{
242,
1727892316,
},
{
34,
1727892484,
},
{
34,
1727892646,
},
{
70,
1727892646,
},
{
34,
1727893601,
},
{
70,
1727893601,
},
{
34,
1727894099,
},
{
70,
1727894099,
},
{
217,
1727894099,
},
{
253,
1727894099,
},
{
34,
1727985140,
},
{
70,
1727985140,
},
{
220,
1727985140,
},
{
256,
1727985140,
},
{
407,
1727985140,
},
{
443,
1727985140,
},
{
596,
1727985140,
},
{
34,
1727986257,
},
{
70,
1727986257,
},
{
216,
1727986257,
},
{
252,
1727986257,
},
{
33,
1727987450,
},
{
69,
1727987450,
},
{
201,
1727987450,
},
{
237,
1727987450,
},
{
377,
1727987450,
},
{
413,
1727987450,
},
{
550,
1727987450,
},
{
586,
1727987450,
},
{
34,
1727988274,
},
{
70,
1727988274,
},
{
200,
1727988274,
},
{
236,
1727988274,
},
{
372,
1727988274,
},
{
408,
1727988274,
},
{
539,
1727988274,
},
{
575,
1727988274,
},
{
34,
1728490934,
},
{
70,
1728490934,
},
{
34,
1728492773,
},
{
70,
1728492773,
},
{
206,
1728492773,
},
{
242,
1728492773,
},
{
384,
1728492773,
},
{
420,
1728492773,
},
{
34,
1729184813,
},
{
70,
1729184813,
},
{
33,
1729185356,
},
{
69,
1729185356,
},
{
198,
1729185356,
},
{
234,
1729185356,
},
{
365,
1729185356,
},
{
401,
1729185356,
},
{
33,
1729970361,
},
{
69,
1729970361,
},
{
213,
1729970361,
},
{
33,
1729971251,
},
{
69,
1729971251,
},
{
207,
1729971251,
},
{
243,
1729971251,
},
{
384,
1729971251,
},
{
420,
1729971251,
},
{
34,
1729973842,
},
{
70,
1729973842,
},
{
200,
1729973842,
},
{
236,
1729973842,
},
{
371,
1729973842,
},
{
407,
1729973842,
},
},
["Неумолимый рывок"] = {
{
106,
1727621948,
},
{
110,
1727621948,
},
{
117,
1727621948,
},
{
125,
1727621948,
},
{
132,
1727621948,
},
{
106,
1727622447,
},
{
110,
1727622447,
},
{
117,
1727622447,
},
{
124,
1727622447,
},
{
131,
1727622447,
},
{
280,
1727622447,
},
{
284,
1727622447,
},
{
291,
1727622447,
},
{
298,
1727622447,
},
{
306,
1727622447,
},
{
106,
1727623206,
},
{
111,
1727623206,
},
{
118,
1727623206,
},
{
125,
1727623206,
},
{
132,
1727623206,
},
{
283,
1727623206,
},
{
287,
1727623206,
},
{
294,
1727623206,
},
{
302,
1727623206,
},
{
309,
1727623206,
},
{
459,
1727623206,
},
{
464,
1727623206,
},
{
471,
1727623206,
},
{
478,
1727623206,
},
{
485,
1727623206,
},
{
106,
1727623466,
},
{
111,
1727623466,
},
{
118,
1727623466,
},
{
125,
1727623466,
},
{
132,
1727623466,
},
{
107,
1727624051,
},
{
111,
1727624051,
},
{
118,
1727624051,
},
{
125,
1727624051,
},
{
132,
1727624051,
},
{
106,
1727624668,
},
{
110,
1727624668,
},
{
117,
1727624668,
},
{
124,
1727624668,
},
{
131,
1727624668,
},
{
284,
1727624668,
},
{
289,
1727624668,
},
{
296,
1727624668,
},
{
303,
1727624668,
},
{
310,
1727624668,
},
{
106,
1727625015,
},
{
111,
1727625015,
},
{
118,
1727625015,
},
{
125,
1727625015,
},
{
132,
1727625015,
},
{
106,
1727625604,
},
{
110,
1727625604,
},
{
117,
1727625604,
},
{
124,
1727625604,
},
{
131,
1727625604,
},
{
279,
1727625604,
},
{
107,
1727628606,
},
{
111,
1727628606,
},
{
118,
1727628606,
},
{
106,
1727628873,
},
{
110,
1727628873,
},
{
117,
1727628873,
},
{
106,
1727631159,
},
{
111,
1727631159,
},
{
118,
1727631159,
},
{
125,
1727631159,
},
{
132,
1727631159,
},
{
106,
1727631850,
},
{
110,
1727631850,
},
{
117,
1727631850,
},
{
124,
1727631850,
},
{
131,
1727631850,
},
{
275,
1727631850,
},
{
279,
1727631850,
},
{
286,
1727631850,
},
{
293,
1727631850,
},
{
300,
1727631850,
},
{
443,
1727631850,
},
{
447,
1727631850,
},
{
454,
1727631850,
},
{
461,
1727631850,
},
{
468,
1727631850,
},
{
106,
1727892316,
},
{
110,
1727892316,
},
{
118,
1727892316,
},
{
125,
1727892316,
},
{
132,
1727892316,
},
{
107,
1727893601,
},
{
112,
1727893601,
},
{
119,
1727893601,
},
{
126,
1727893601,
},
{
133,
1727893601,
},
{
107,
1727894099,
},
{
111,
1727894099,
},
{
118,
1727894099,
},
{
125,
1727894099,
},
{
133,
1727894099,
},
{
289,
1727894099,
},
{
293,
1727894099,
},
{
300,
1727894099,
},
{
307,
1727894099,
},
{
314,
1727894099,
},
{
107,
1727985140,
},
{
111,
1727985140,
},
{
118,
1727985140,
},
{
125,
1727985140,
},
{
132,
1727985140,
},
{
293,
1727985140,
},
{
298,
1727985140,
},
{
305,
1727985140,
},
{
312,
1727985140,
},
{
319,
1727985140,
},
{
479,
1727985140,
},
{
484,
1727985140,
},
{
491,
1727985140,
},
{
498,
1727985140,
},
{
505,
1727985140,
},
{
106,
1727986257,
},
{
110,
1727986257,
},
{
117,
1727986257,
},
{
124,
1727986257,
},
{
131,
1727986257,
},
{
289,
1727986257,
},
{
293,
1727986257,
},
{
300,
1727986257,
},
{
307,
1727986257,
},
{
314,
1727986257,
},
{
105,
1727987450,
},
{
110,
1727987450,
},
{
117,
1727987450,
},
{
124,
1727987450,
},
{
131,
1727987450,
},
{
273,
1727987450,
},
{
277,
1727987450,
},
{
284,
1727987450,
},
{
291,
1727987450,
},
{
298,
1727987450,
},
{
449,
1727987450,
},
{
453,
1727987450,
},
{
460,
1727987450,
},
{
467,
1727987450,
},
{
474,
1727987450,
},
{
622,
1727987450,
},
{
626,
1727987450,
},
{
106,
1727988274,
},
{
110,
1727988274,
},
{
118,
1727988274,
},
{
125,
1727988274,
},
{
132,
1727988274,
},
{
272,
1727988274,
},
{
277,
1727988274,
},
{
284,
1727988274,
},
{
291,
1727988274,
},
{
298,
1727988274,
},
{
444,
1727988274,
},
{
449,
1727988274,
},
{
456,
1727988274,
},
{
463,
1727988274,
},
{
470,
1727988274,
},
{
106,
1728490934,
},
{
110,
1728490934,
},
{
107,
1728492773,
},
{
112,
1728492773,
},
{
119,
1728492773,
},
{
126,
1728492773,
},
{
133,
1728492773,
},
{
280,
1728492773,
},
{
284,
1728492773,
},
{
291,
1728492773,
},
{
298,
1728492773,
},
{
305,
1728492773,
},
{
456,
1728492773,
},
{
460,
1728492773,
},
{
467,
1728492773,
},
{
474,
1728492773,
},
{
481,
1728492773,
},
{
107,
1729184813,
},
{
111,
1729184813,
},
{
118,
1729184813,
},
{
125,
1729184813,
},
{
132,
1729184813,
},
{
106,
1729185356,
},
{
111,
1729185356,
},
{
118,
1729185356,
},
{
125,
1729185356,
},
{
132,
1729185356,
},
{
271,
1729185356,
},
{
275,
1729185356,
},
{
282,
1729185356,
},
{
289,
1729185356,
},
{
296,
1729185356,
},
{
105,
1729970361,
},
{
110,
1729970361,
},
{
117,
1729970361,
},
{
124,
1729970361,
},
{
131,
1729970361,
},
{
106,
1729971251,
},
{
111,
1729971251,
},
{
118,
1729971251,
},
{
125,
1729971251,
},
{
132,
1729971251,
},
{
280,
1729971251,
},
{
284,
1729971251,
},
{
291,
1729971251,
},
{
298,
1729971251,
},
{
305,
1729971251,
},
{
458,
1729971251,
},
{
462,
1729971251,
},
{
469,
1729971251,
},
{
476,
1729971251,
},
{
483,
1729971251,
},
{
106,
1729973842,
},
{
110,
1729973842,
},
{
117,
1729973842,
},
{
125,
1729973842,
},
{
132,
1729973842,
},
{
273,
1729973842,
},
{
277,
1729973842,
},
{
284,
1729973842,
},
{
291,
1729973842,
},
{
299,
1729973842,
},
{
443,
1729973842,
},
{
448,
1729973842,
},
{
455,
1729973842,
},
{
462,
1729973842,
},
{
469,
1729973842,
},
},
},
["2917-16"] = {
["Свертывание крови"] = {
{
10,
1727989210,
},
{
42,
1727989210,
},
{
69,
1727989210,
},
{
101,
1727989210,
},
{
11,
1727989433,
},
{
43,
1727989433,
},
{
10,
1727989655,
},
{
42,
1727989655,
},
{
69,
1727989655,
},
{
10,
1727989882,
},
{
42,
1727989882,
},
{
69,
1727989882,
},
{
11,
1727990743,
},
{
43,
1727990743,
},
{
70,
1727990743,
},
{
102,
1727990743,
},
{
11,
1727990937,
},
{
42,
1727990937,
},
{
69,
1727990937,
},
{
10,
1727991218,
},
{
42,
1727991218,
},
{
69,
1727991218,
},
{
10,
1727991387,
},
{
42,
1727991387,
},
{
11,
1728493898,
},
{
43,
1728493898,
},
{
70,
1728493898,
},
{
102,
1728493898,
},
{
139,
1728493898,
},
{
171,
1728493898,
},
{
198,
1728493898,
},
{
230,
1728493898,
},
{
267,
1728493898,
},
{
10,
1729186151,
},
{
42,
1729186151,
},
{
69,
1729186151,
},
{
101,
1729186151,
},
{
138,
1729186151,
},
{
170,
1729186151,
},
{
197,
1729186151,
},
{
10,
1729186358,
},
{
42,
1729186358,
},
{
69,
1729186358,
},
{
11,
1729186747,
},
{
43,
1729186747,
},
{
70,
1729186747,
},
{
102,
1729186747,
},
{
139,
1729186747,
},
{
171,
1729186747,
},
{
198,
1729186747,
},
{
230,
1729186747,
},
{
10,
1729187138,
},
{
42,
1729187138,
},
{
69,
1729187138,
},
{
101,
1729187138,
},
{
138,
1729187138,
},
{
170,
1729187138,
},
{
197,
1729187138,
},
{
229,
1729187138,
},
{
266,
1729187138,
},
{
11,
1729974802,
},
{
43,
1729974802,
},
{
70,
1729974802,
},
{
102,
1729974802,
},
{
139,
1729974802,
},
{
171,
1729974802,
},
{
198,
1729974802,
},
{
230,
1729974802,
},
{
11,
1729975188,
},
{
43,
1729975188,
},
{
70,
1729975188,
},
{
102,
1729975188,
},
{
139,
1729975188,
},
{
171,
1729975188,
},
{
198,
1729975188,
},
{
230,
1729975188,
},
},
["Брызгающее кровотечение"] = {
{
36,
1727989210,
},
{
36,
1727989210,
},
{
95,
1727989210,
},
{
95,
1727989210,
},
{
101,
1727989210,
},
{
105,
1727989210,
},
{
109,
1727989210,
},
{
112,
1727989210,
},
{
37,
1727989433,
},
{
37,
1727989433,
},
{
38,
1727989433,
},
{
39,
1727989433,
},
{
46,
1727989433,
},
{
47,
1727989433,
},
{
48,
1727989433,
},
{
49,
1727989433,
},
{
51,
1727989433,
},
{
36,
1727989655,
},
{
36,
1727989655,
},
{
52,
1727989655,
},
{
57,
1727989655,
},
{
95,
1727989655,
},
{
95,
1727989655,
},
{
97,
1727989655,
},
{
36,
1727989882,
},
{
36,
1727989882,
},
{
37,
1727990743,
},
{
37,
1727990743,
},
{
96,
1727990743,
},
{
96,
1727990743,
},
{
36,
1727990937,
},
{
37,
1727990937,
},
{
37,
1727990937,
},
{
53,
1727990937,
},
{
57,
1727990937,
},
{
36,
1727991218,
},
{
36,
1727991218,
},
{
36,
1727991218,
},
{
42,
1727991218,
},
{
43,
1727991218,
},
{
55,
1727991218,
},
{
36,
1727991387,
},
{
36,
1727991387,
},
{
48,
1727991387,
},
{
51,
1727991387,
},
{
52,
1727991387,
},
{
57,
1727991387,
},
{
37,
1728493898,
},
{
37,
1728493898,
},
{
39,
1728493898,
},
{
96,
1728493898,
},
{
96,
1728493898,
},
{
106,
1728493898,
},
{
165,
1728493898,
},
{
165,
1728493898,
},
{
224,
1728493898,
},
{
224,
1728493898,
},
{
237,
1728493898,
},
{
293,
1728493898,
},
{
293,
1728493898,
},
{
36,
1729186151,
},
{
36,
1729186151,
},
{
95,
1729186151,
},
{
95,
1729186151,
},
{
164,
1729186151,
},
{
164,
1729186151,
},
{
36,
1729186358,
},
{
36,
1729186358,
},
{
55,
1729186358,
},
{
37,
1729186747,
},
{
37,
1729186747,
},
{
37,
1729186747,
},
{
96,
1729186747,
},
{
96,
1729186747,
},
{
165,
1729186747,
},
{
165,
1729186747,
},
{
184,
1729186747,
},
{
224,
1729186747,
},
{
224,
1729186747,
},
{
36,
1729187138,
},
{
36,
1729187138,
},
{
95,
1729187138,
},
{
95,
1729187138,
},
{
164,
1729187138,
},
{
164,
1729187138,
},
{
223,
1729187138,
},
{
223,
1729187138,
},
{
37,
1729974802,
},
{
37,
1729974802,
},
{
37,
1729974802,
},
{
96,
1729974802,
},
{
96,
1729974802,
},
{
165,
1729974802,
},
{
165,
1729974802,
},
{
224,
1729974802,
},
{
224,
1729974802,
},
{
37,
1729975188,
},
{
37,
1729975188,
},
{
96,
1729975188,
},
{
96,
1729975188,
},
{
165,
1729975188,
},
{
165,
1729975188,
},
{
224,
1729975188,
},
{
224,
1729975188,
},
},
["Призрачный удар"] = {
{
31,
1727989210,
},
{
45,
1727989210,
},
{
90,
1727989210,
},
{
38,
1727989433,
},
{
55,
1727989433,
},
{
28,
1727989655,
},
{
30,
1727989882,
},
{
47,
1727989882,
},
{
30,
1727990743,
},
{
89,
1727990743,
},
{
29,
1727990937,
},
{
40,
1727991218,
},
{
29,
1727991387,
},
{
46,
1727991387,
},
{
30,
1728493898,
},
{
48,
1728493898,
},
{
88,
1728493898,
},
{
157,
1728493898,
},
{
218,
1728493898,
},
{
233,
1728493898,
},
{
287,
1728493898,
},
{
29,
1729186151,
},
{
88,
1729186151,
},
{
104,
1729186151,
},
{
156,
1729186151,
},
{
174,
1729186151,
},
{
29,
1729186358,
},
{
46,
1729186358,
},
{
30,
1729186747,
},
{
89,
1729186747,
},
{
157,
1729186747,
},
{
217,
1729186747,
},
{
233,
1729186747,
},
{
29,
1729187138,
},
{
88,
1729187138,
},
{
155,
1729187138,
},
{
219,
1729187138,
},
{
232,
1729187138,
},
{
30,
1729974802,
},
{
90,
1729974802,
},
{
158,
1729974802,
},
{
174,
1729974802,
},
{
217,
1729974802,
},
{
30,
1729975188,
},
{
88,
1729975188,
},
{
160,
1729975188,
},
{
218,
1729975188,
},
{
233,
1729975188,
},
},
["Багровый дождь"] = {
{
10,
1727989210,
},
{
11,
1727989433,
},
{
10,
1727989655,
},
{
10,
1727989882,
},
{
11,
1727990743,
},
{
11,
1727990937,
},
{
10,
1727991218,
},
{
10,
1727991387,
},
{
11,
1728493898,
},
{
139,
1728493898,
},
{
267,
1728493898,
},
{
10,
1729186151,
},
{
138,
1729186151,
},
{
10,
1729186358,
},
{
11,
1729186747,
},
{
139,
1729186747,
},
{
10,
1729187138,
},
{
138,
1729187138,
},
{
266,
1729187138,
},
{
11,
1729974802,
},
{
139,
1729974802,
},
{
11,
1729975188,
},
{
139,
1729975188,
},
},
["Внушение ужаса"] = {
{
2,
1727989210,
},
{
61,
1727989210,
},
{
3,
1727989433,
},
{
2,
1727989655,
},
{
61,
1727989655,
},
{
2,
1727989882,
},
{
61,
1727989882,
},
{
3,
1727990743,
},
{
62,
1727990743,
},
{
2,
1727990937,
},
{
61,
1727990937,
},
{
2,
1727991218,
},
{
61,
1727991218,
},
{
2,
1727991387,
},
{
61,
1727991387,
},
{
3,
1728493898,
},
{
62,
1728493898,
},
{
131,
1728493898,
},
{
190,
1728493898,
},
{
259,
1728493898,
},
{
2,
1729186151,
},
{
61,
1729186151,
},
{
130,
1729186151,
},
{
189,
1729186151,
},
{
2,
1729186358,
},
{
61,
1729186358,
},
{
3,
1729186747,
},
{
62,
1729186747,
},
{
131,
1729186747,
},
{
190,
1729186747,
},
{
259,
1729186747,
},
{
2,
1729187138,
},
{
61,
1729187138,
},
{
130,
1729187138,
},
{
189,
1729187138,
},
{
258,
1729187138,
},
{
3,
1729974802,
},
{
62,
1729974802,
},
{
131,
1729974802,
},
{
190,
1729974802,
},
{
3,
1729975188,
},
{
62,
1729975188,
},
{
131,
1729975188,
},
{
190,
1729975188,
},
},
["Черный сепсис"] = {
{
55,
1727989433,
},
{
98,
1727989655,
},
{
105,
1727990743,
},
{
86,
1727991218,
},
{
209,
1729186151,
},
},
["Отвратительная отрыжка"] = {
{
18,
1727989210,
},
{
77,
1727989210,
},
{
19,
1727989433,
},
{
18,
1727989655,
},
{
77,
1727989655,
},
{
18,
1727989882,
},
{
77,
1727989882,
},
{
19,
1727990743,
},
{
78,
1727990743,
},
{
19,
1727990937,
},
{
77,
1727990937,
},
{
18,
1727991218,
},
{
77,
1727991218,
},
{
18,
1727991387,
},
{
19,
1728493898,
},
{
78,
1728493898,
},
{
147,
1728493898,
},
{
206,
1728493898,
},
{
275,
1728493898,
},
{
18,
1729186151,
},
{
77,
1729186151,
},
{
146,
1729186151,
},
{
205,
1729186151,
},
{
18,
1729186358,
},
{
77,
1729186358,
},
{
19,
1729186747,
},
{
78,
1729186747,
},
{
147,
1729186747,
},
{
206,
1729186747,
},
{
18,
1729187138,
},
{
77,
1729187138,
},
{
146,
1729187138,
},
{
205,
1729187138,
},
{
274,
1729187138,
},
{
19,
1729974802,
},
{
78,
1729974802,
},
{
147,
1729974802,
},
{
206,
1729974802,
},
{
19,
1729975188,
},
{
78,
1729975188,
},
{
147,
1729975188,
},
{
206,
1729975188,
},
},
["Воплощение ужаса"] = {
{
25,
1727989210,
},
{
29,
1727989210,
},
{
33,
1727989210,
},
{
37,
1727989210,
},
{
41,
1727989210,
},
{
45,
1727989210,
},
{
49,
1727989210,
},
{
53,
1727989210,
},
{
57,
1727989210,
},
{
61,
1727989210,
},
{
65,
1727989210,
},
{
69,
1727989210,
},
{
73,
1727989210,
},
{
77,
1727989210,
},
{
81,
1727989210,
},
{
83,
1727989210,
},
{
85,
1727989210,
},
{
87,
1727989210,
},
{
91,
1727989210,
},
{
95,
1727989210,
},
{
99,
1727989210,
},
{
103,
1727989210,
},
{
107,
1727989210,
},
{
111,
1727989210,
},
{
25,
1727989433,
},
{
29,
1727989433,
},
{
33,
1727989433,
},
{
37,
1727989433,
},
{
41,
1727989433,
},
{
45,
1727989433,
},
{
49,
1727989433,
},
{
53,
1727989433,
},
{
57,
1727989433,
},
{
25,
1727989655,
},
{
29,
1727989655,
},
{
33,
1727989655,
},
{
37,
1727989655,
},
{
41,
1727989655,
},
{
45,
1727989655,
},
{
49,
1727989655,
},
{
53,
1727989655,
},
{
57,
1727989655,
},
{
61,
1727989655,
},
{
65,
1727989655,
},
{
69,
1727989655,
},
{
73,
1727989655,
},
{
77,
1727989655,
},
{
81,
1727989655,
},
{
84,
1727989655,
},
{
85,
1727989655,
},
{
88,
1727989655,
},
{
89,
1727989655,
},
{
92,
1727989655,
},
{
93,
1727989655,
},
{
96,
1727989655,
},
{
97,
1727989655,
},
{
25,
1727989882,
},
{
29,
1727989882,
},
{
33,
1727989882,
},
{
37,
1727989882,
},
{
41,
1727989882,
},
{
45,
1727989882,
},
{
49,
1727989882,
},
{
53,
1727989882,
},
{
57,
1727989882,
},
{
61,
1727989882,
},
{
65,
1727989882,
},
{
69,
1727989882,
},
{
73,
1727989882,
},
{
77,
1727989882,
},
{
81,
1727989882,
},
{
84,
1727989882,
},
{
85,
1727989882,
},
{
25,
1727990743,
},
{
29,
1727990743,
},
{
33,
1727990743,
},
{
37,
1727990743,
},
{
41,
1727990743,
},
{
45,
1727990743,
},
{
49,
1727990743,
},
{
53,
1727990743,
},
{
57,
1727990743,
},
{
61,
1727990743,
},
{
65,
1727990743,
},
{
69,
1727990743,
},
{
73,
1727990743,
},
{
78,
1727990743,
},
{
81,
1727990743,
},
{
84,
1727990743,
},
{
86,
1727990743,
},
{
88,
1727990743,
},
{
90,
1727990743,
},
{
92,
1727990743,
},
{
94,
1727990743,
},
{
96,
1727990743,
},
{
98,
1727990743,
},
{
100,
1727990743,
},
{
102,
1727990743,
},
{
104,
1727990743,
},
{
106,
1727990743,
},
{
25,
1727990937,
},
{
29,
1727990937,
},
{
33,
1727990937,
},
{
37,
1727990937,
},
{
41,
1727990937,
},
{
45,
1727990937,
},
{
49,
1727990937,
},
{
53,
1727990937,
},
{
57,
1727990937,
},
{
61,
1727990937,
},
{
65,
1727990937,
},
{
69,
1727990937,
},
{
73,
1727990937,
},
{
77,
1727990937,
},
{
81,
1727990937,
},
{
85,
1727990937,
},
{
25,
1727991218,
},
{
29,
1727991218,
},
{
33,
1727991218,
},
{
37,
1727991218,
},
{
41,
1727991218,
},
{
84,
1727991218,
},
{
88,
1727991218,
},
{
25,
1727991387,
},
{
29,
1727991387,
},
{
33,
1727991387,
},
{
37,
1727991387,
},
{
41,
1727991387,
},
{
45,
1727991387,
},
{
49,
1727991387,
},
{
53,
1727991387,
},
{
57,
1727991387,
},
{
61,
1727991387,
},
{
65,
1727991387,
},
{
26,
1728493898,
},
{
30,
1728493898,
},
{
34,
1728493898,
},
{
38,
1728493898,
},
{
42,
1728493898,
},
{
84,
1728493898,
},
{
88,
1728493898,
},
{
92,
1728493898,
},
{
96,
1728493898,
},
{
100,
1728493898,
},
{
153,
1728493898,
},
{
157,
1728493898,
},
{
161,
1728493898,
},
{
165,
1728493898,
},
{
169,
1728493898,
},
{
173,
1728493898,
},
{
177,
1728493898,
},
{
181,
1728493898,
},
{
213,
1728493898,
},
{
217,
1728493898,
},
{
221,
1728493898,
},
{
225,
1728493898,
},
{
229,
1728493898,
},
{
233,
1728493898,
},
{
237,
1728493898,
},
{
241,
1728493898,
},
{
245,
1728493898,
},
{
282,
1728493898,
},
{
286,
1728493898,
},
{
290,
1728493898,
},
{
294,
1728493898,
},
{
25,
1729186151,
},
{
29,
1729186151,
},
{
33,
1729186151,
},
{
37,
1729186151,
},
{
41,
1729186151,
},
{
83,
1729186151,
},
{
87,
1729186151,
},
{
91,
1729186151,
},
{
95,
1729186151,
},
{
99,
1729186151,
},
{
103,
1729186151,
},
{
153,
1729186151,
},
{
157,
1729186151,
},
{
161,
1729186151,
},
{
165,
1729186151,
},
{
169,
1729186151,
},
{
173,
1729186151,
},
{
177,
1729186151,
},
{
181,
1729186151,
},
{
185,
1729186151,
},
{
189,
1729186151,
},
{
193,
1729186151,
},
{
197,
1729186151,
},
{
201,
1729186151,
},
{
205,
1729186151,
},
{
209,
1729186151,
},
{
25,
1729186358,
},
{
29,
1729186358,
},
{
33,
1729186358,
},
{
37,
1729186358,
},
{
41,
1729186358,
},
{
45,
1729186358,
},
{
49,
1729186358,
},
{
53,
1729186358,
},
{
57,
1729186358,
},
{
61,
1729186358,
},
{
65,
1729186358,
},
{
69,
1729186358,
},
{
73,
1729186358,
},
{
77,
1729186358,
},
{
81,
1729186358,
},
{
84,
1729186358,
},
{
85,
1729186358,
},
{
25,
1729186747,
},
{
29,
1729186747,
},
{
33,
1729186747,
},
{
37,
1729186747,
},
{
41,
1729186747,
},
{
45,
1729186747,
},
{
49,
1729186747,
},
{
85,
1729186747,
},
{
89,
1729186747,
},
{
93,
1729186747,
},
{
97,
1729186747,
},
{
153,
1729186747,
},
{
157,
1729186747,
},
{
161,
1729186747,
},
{
165,
1729186747,
},
{
169,
1729186747,
},
{
173,
1729186747,
},
{
177,
1729186747,
},
{
181,
1729186747,
},
{
185,
1729186747,
},
{
189,
1729186747,
},
{
193,
1729186747,
},
{
197,
1729186747,
},
{
201,
1729186747,
},
{
205,
1729186747,
},
{
209,
1729186747,
},
{
212,
1729186747,
},
{
213,
1729186747,
},
{
216,
1729186747,
},
{
220,
1729186747,
},
{
224,
1729186747,
},
{
228,
1729186747,
},
{
232,
1729186747,
},
{
236,
1729186747,
},
{
240,
1729186747,
},
{
244,
1729186747,
},
{
248,
1729186747,
},
{
252,
1729186747,
},
{
256,
1729186747,
},
{
260,
1729186747,
},
{
25,
1729187138,
},
{
29,
1729187138,
},
{
33,
1729187138,
},
{
37,
1729187138,
},
{
83,
1729187138,
},
{
87,
1729187138,
},
{
91,
1729187138,
},
{
95,
1729187138,
},
{
99,
1729187138,
},
{
103,
1729187138,
},
{
153,
1729187138,
},
{
157,
1729187138,
},
{
161,
1729187138,
},
{
165,
1729187138,
},
{
169,
1729187138,
},
{
212,
1729187138,
},
{
216,
1729187138,
},
{
220,
1729187138,
},
{
224,
1729187138,
},
{
228,
1729187138,
},
{
280,
1729187138,
},
{
26,
1729974802,
},
{
30,
1729974802,
},
{
34,
1729974802,
},
{
38,
1729974802,
},
{
85,
1729974802,
},
{
89,
1729974802,
},
{
93,
1729974802,
},
{
97,
1729974802,
},
{
101,
1729974802,
},
{
105,
1729974802,
},
{
153,
1729974802,
},
{
157,
1729974802,
},
{
161,
1729974802,
},
{
165,
1729974802,
},
{
169,
1729974802,
},
{
173,
1729974802,
},
{
177,
1729974802,
},
{
181,
1729974802,
},
{
185,
1729974802,
},
{
189,
1729974802,
},
{
193,
1729974802,
},
{
197,
1729974802,
},
{
201,
1729974802,
},
{
205,
1729974802,
},
{
209,
1729974802,
},
{
213,
1729974802,
},
{
217,
1729974802,
},
{
221,
1729974802,
},
{
225,
1729974802,
},
{
229,
1729974802,
},
{
233,
1729974802,
},
{
25,
1729975188,
},
{
29,
1729975188,
},
{
33,
1729975188,
},
{
37,
1729975188,
},
{
41,
1729975188,
},
{
45,
1729975188,
},
{
85,
1729975188,
},
{
89,
1729975188,
},
{
93,
1729975188,
},
{
97,
1729975188,
},
{
101,
1729975188,
},
{
105,
1729975188,
},
{
153,
1729975188,
},
{
155,
1729975188,
},
{
157,
1729975188,
},
{
159,
1729975188,
},
{
161,
1729975188,
},
{
163,
1729975188,
},
{
165,
1729975188,
},
{
167,
1729975188,
},
{
169,
1729975188,
},
{
171,
1729975188,
},
{
175,
1729975188,
},
{
179,
1729975188,
},
{
183,
1729975188,
},
{
213,
1729975188,
},
{
217,
1729975188,
},
{
221,
1729975188,
},
{
225,
1729975188,
},
{
229,
1729975188,
},
},
["Брызги крови"] = {
{
128,
1728493898,
},
{
256,
1728493898,
},
{
127,
1729186151,
},
{
128,
1729186747,
},
{
256,
1729186747,
},
{
127,
1729187138,
},
{
255,
1729187138,
},
{
128,
1729974802,
},
{
128,
1729975188,
},
},
["Черный бастион"] = {
{
24,
1727989433,
},
{
83,
1727989655,
},
{
24,
1727989882,
},
{
81,
1727989882,
},
{
83,
1727989882,
},
{
83,
1727990937,
},
{
61,
1727991218,
},
{
83,
1727991218,
},
{
185,
1729186151,
},
{
82,
1729186358,
},
{
83,
1729186358,
},
{
245,
1729186747,
},
{
99,
1729187138,
},
{
186,
1729974802,
},
{
228,
1729974802,
},
},
["Потусторонняя хватка"] = {
{
18,
1727989210,
},
{
46,
1727989210,
},
{
77,
1727989210,
},
{
105,
1727989210,
},
{
19,
1727989433,
},
{
47,
1727989433,
},
{
18,
1727989655,
},
{
46,
1727989655,
},
{
77,
1727989655,
},
{
18,
1727989882,
},
{
46,
1727989882,
},
{
77,
1727989882,
},
{
19,
1727990743,
},
{
47,
1727990743,
},
{
78,
1727990743,
},
{
19,
1727990937,
},
{
46,
1727990937,
},
{
78,
1727990937,
},
{
18,
1727991218,
},
{
46,
1727991218,
},
{
77,
1727991218,
},
{
18,
1727991387,
},
{
46,
1727991387,
},
{
19,
1728493898,
},
{
47,
1728493898,
},
{
78,
1728493898,
},
{
106,
1728493898,
},
{
147,
1728493898,
},
{
175,
1728493898,
},
{
206,
1728493898,
},
{
234,
1728493898,
},
{
275,
1728493898,
},
{
18,
1729186151,
},
{
46,
1729186151,
},
{
77,
1729186151,
},
{
105,
1729186151,
},
{
146,
1729186151,
},
{
174,
1729186151,
},
{
205,
1729186151,
},
{
18,
1729186358,
},
{
46,
1729186358,
},
{
77,
1729186358,
},
{
19,
1729186747,
},
{
47,
1729186747,
},
{
78,
1729186747,
},
{
106,
1729186747,
},
{
147,
1729186747,
},
{
175,
1729186747,
},
{
206,
1729186747,
},
{
234,
1729186747,
},
{
18,
1729187138,
},
{
46,
1729187138,
},
{
77,
1729187138,
},
{
105,
1729187138,
},
{
146,
1729187138,
},
{
174,
1729187138,
},
{
205,
1729187138,
},
{
233,
1729187138,
},
{
274,
1729187138,
},
{
19,
1729974802,
},
{
47,
1729974802,
},
{
78,
1729974802,
},
{
106,
1729974802,
},
{
147,
1729974802,
},
{
175,
1729974802,
},
{
206,
1729974802,
},
{
234,
1729974802,
},
{
19,
1729975188,
},
{
47,
1729975188,
},
{
78,
1729975188,
},
{
106,
1729975188,
},
{
147,
1729975188,
},
{
175,
1729975188,
},
{
206,
1729975188,
},
{
234,
1729975188,
},
},
},
["2898-15"] = {
["Истребление"] = {
{
44,
1726348058,
},
{
83,
1726348058,
},
{
141,
1726348058,
},
{
181,
1726348058,
},
{
239,
1726348058,
},
{
279,
1726348058,
},
{
338,
1726348058,
},
{
378,
1726348058,
},
{
44,
1726834080,
},
{
44,
1726834749,
},
{
83,
1726834749,
},
{
140,
1726834749,
},
{
180,
1726834749,
},
{
239,
1726834749,
},
{
279,
1726834749,
},
{
337,
1726834749,
},
{
45,
1727878065,
},
{
85,
1727878065,
},
{
141,
1727878065,
},
{
180,
1727878065,
},
},
["Фазовый выпад"] = {
{
10,
1726348058,
},
{
33,
1726348058,
},
{
56,
1726348058,
},
{
79,
1726348058,
},
{
106,
1726348058,
},
{
129,
1726348058,
},
{
152,
1726348058,
},
{
175,
1726348058,
},
{
204,
1726348058,
},
{
227,
1726348058,
},
{
250,
1726348058,
},
{
273,
1726348058,
},
{
302,
1726348058,
},
{
325,
1726348058,
},
{
348,
1726348058,
},
{
372,
1726348058,
},
{
11,
1726834080,
},
{
34,
1726834080,
},
{
10,
1726834749,
},
{
33,
1726834749,
},
{
56,
1726834749,
},
{
79,
1726834749,
},
{
105,
1726834749,
},
{
128,
1726834749,
},
{
151,
1726834749,
},
{
174,
1726834749,
},
{
203,
1726834749,
},
{
226,
1726834749,
},
{
249,
1726834749,
},
{
272,
1726834749,
},
{
302,
1726834749,
},
{
325,
1726834749,
},
{
348,
1726834749,
},
{
11,
1727878065,
},
{
33,
1727878065,
},
{
56,
1727878065,
},
{
79,
1727878065,
},
{
106,
1727878065,
},
{
129,
1727878065,
},
{
152,
1727878065,
},
{
175,
1727878065,
},
{
203,
1727878065,
},
},
["Выявление слабости"] = {
{
7,
1726348058,
},
{
8,
1726348058,
},
{
30,
1726348058,
},
{
31,
1726348058,
},
{
53,
1726348058,
},
{
54,
1726348058,
},
{
76,
1726348058,
},
{
77,
1726348058,
},
{
103,
1726348058,
},
{
104,
1726348058,
},
{
126,
1726348058,
},
{
127,
1726348058,
},
{
149,
1726348058,
},
{
150,
1726348058,
},
{
172,
1726348058,
},
{
173,
1726348058,
},
{
201,
1726348058,
},
{
202,
1726348058,
},
{
224,
1726348058,
},
{
225,
1726348058,
},
{
247,
1726348058,
},
{
248,
1726348058,
},
{
270,
1726348058,
},
{
271,
1726348058,
},
{
299,
1726348058,
},
{
300,
1726348058,
},
{
322,
1726348058,
},
{
324,
1726348058,
},
{
345,
1726348058,
},
{
347,
1726348058,
},
{
369,
1726348058,
},
{
370,
1726348058,
},
{
398,
1726348058,
},
{
399,
1726348058,
},
{
8,
1726834080,
},
{
9,
1726834080,
},
{
31,
1726834080,
},
{
32,
1726834080,
},
{
7,
1726834749,
},
{
8,
1726834749,
},
{
30,
1726834749,
},
{
31,
1726834749,
},
{
53,
1726834749,
},
{
54,
1726834749,
},
{
76,
1726834749,
},
{
77,
1726834749,
},
{
102,
1726834749,
},
{
103,
1726834749,
},
{
125,
1726834749,
},
{
126,
1726834749,
},
{
148,
1726834749,
},
{
149,
1726834749,
},
{
171,
1726834749,
},
{
172,
1726834749,
},
{
200,
1726834749,
},
{
201,
1726834749,
},
{
223,
1726834749,
},
{
224,
1726834749,
},
{
246,
1726834749,
},
{
248,
1726834749,
},
{
269,
1726834749,
},
{
271,
1726834749,
},
{
299,
1726834749,
},
{
300,
1726834749,
},
{
322,
1726834749,
},
{
323,
1726834749,
},
{
345,
1726834749,
},
{
346,
1726834749,
},
{
8,
1727878065,
},
{
9,
1727878065,
},
{
30,
1727878065,
},
{
31,
1727878065,
},
{
53,
1727878065,
},
{
54,
1727878065,
},
{
76,
1727878065,
},
{
77,
1727878065,
},
{
102,
1727878065,
},
{
104,
1727878065,
},
{
126,
1727878065,
},
{
127,
1727878065,
},
{
149,
1727878065,
},
{
150,
1727878065,
},
{
172,
1727878065,
},
{
173,
1727878065,
},
{
200,
1727878065,
},
{
201,
1727878065,
},
},
["Фазовые клинки"] = {
{
14,
1726348058,
},
{
20,
1726348058,
},
{
60,
1726348058,
},
{
66,
1726348058,
},
{
110,
1726348058,
},
{
116,
1726348058,
},
{
153,
1726348058,
},
{
159,
1726348058,
},
{
208,
1726348058,
},
{
214,
1726348058,
},
{
251,
1726348058,
},
{
257,
1726348058,
},
{
307,
1726348058,
},
{
313,
1726348058,
},
{
349,
1726348058,
},
{
355,
1726348058,
},
{
14,
1726834080,
},
{
20,
1726834080,
},
{
13,
1726834749,
},
{
19,
1726834749,
},
{
58,
1726834749,
},
{
64,
1726834749,
},
{
109,
1726834749,
},
{
115,
1726834749,
},
{
152,
1726834749,
},
{
158,
1726834749,
},
{
208,
1726834749,
},
{
214,
1726834749,
},
{
250,
1726834749,
},
{
256,
1726834749,
},
{
306,
1726834749,
},
{
312,
1726834749,
},
{
349,
1726834749,
},
{
355,
1726834749,
},
{
14,
1727878065,
},
{
20,
1727878065,
},
{
60,
1727878065,
},
{
66,
1727878065,
},
{
110,
1727878065,
},
{
116,
1727878065,
},
{
153,
1727878065,
},
{
159,
1727878065,
},
{
208,
1727878065,
},
},
["Космические осколки"] = {
{
44,
1726348058,
},
{
45,
1726348058,
},
{
83,
1726348058,
},
{
95,
1726348058,
},
{
141,
1726348058,
},
{
181,
1726348058,
},
{
194,
1726348058,
},
{
239,
1726348058,
},
{
240,
1726348058,
},
{
280,
1726348058,
},
{
338,
1726348058,
},
{
378,
1726348058,
},
{
45,
1726834080,
},
{
44,
1726834749,
},
{
45,
1726834749,
},
{
83,
1726834749,
},
{
95,
1726834749,
},
{
140,
1726834749,
},
{
180,
1726834749,
},
{
181,
1726834749,
},
{
193,
1726834749,
},
{
239,
1726834749,
},
{
279,
1726834749,
},
{
337,
1726834749,
},
{
45,
1727878065,
},
{
85,
1727878065,
},
{
95,
1727878065,
},
{
141,
1727878065,
},
{
180,
1727878065,
},
{
181,
1727878065,
},
},
["Космический осадок"] = {
{
44,
1726348058,
},
{
45,
1726348058,
},
{
83,
1726348058,
},
{
95,
1726348058,
},
{
141,
1726348058,
},
{
181,
1726348058,
},
{
194,
1726348058,
},
{
239,
1726348058,
},
{
240,
1726348058,
},
{
280,
1726348058,
},
{
338,
1726348058,
},
{
378,
1726348058,
},
{
45,
1726834080,
},
{
44,
1726834749,
},
{
45,
1726834749,
},
{
83,
1726834749,
},
{
95,
1726834749,
},
{
140,
1726834749,
},
{
180,
1726834749,
},
{
181,
1726834749,
},
{
193,
1726834749,
},
{
239,
1726834749,
},
{
279,
1726834749,
},
{
337,
1726834749,
},
{
45,
1727878065,
},
{
85,
1727878065,
},
{
95,
1727878065,
},
{
141,
1727878065,
},
{
180,
1727878065,
},
{
181,
1727878065,
},
},
["Космический симулякр"] = {
{
20,
1726348058,
},
{
21,
1726348058,
},
{
22,
1726348058,
},
{
66,
1726348058,
},
{
67,
1726348058,
},
{
116,
1726348058,
},
{
117,
1726348058,
},
{
159,
1726348058,
},
{
160,
1726348058,
},
{
214,
1726348058,
},
{
215,
1726348058,
},
{
257,
1726348058,
},
{
258,
1726348058,
},
{
313,
1726348058,
},
{
314,
1726348058,
},
{
355,
1726348058,
},
{
356,
1726348058,
},
{
20,
1726834080,
},
{
19,
1726834749,
},
{
20,
1726834749,
},
{
64,
1726834749,
},
{
65,
1726834749,
},
{
115,
1726834749,
},
{
116,
1726834749,
},
{
158,
1726834749,
},
{
159,
1726834749,
},
{
214,
1726834749,
},
{
215,
1726834749,
},
{
256,
1726834749,
},
{
257,
1726834749,
},
{
312,
1726834749,
},
{
313,
1726834749,
},
{
355,
1726834749,
},
{
356,
1726834749,
},
{
20,
1727878065,
},
{
21,
1727878065,
},
{
66,
1727878065,
},
{
67,
1727878065,
},
{
116,
1727878065,
},
{
117,
1727878065,
},
{
159,
1727878065,
},
{
160,
1727878065,
},
},
["Разрушительный взмах"] = {
{
95,
1726348058,
},
{
194,
1726348058,
},
{
292,
1726348058,
},
{
391,
1726348058,
},
{
95,
1726834749,
},
{
193,
1726834749,
},
{
292,
1726834749,
},
{
95,
1727878065,
},
{
193,
1727878065,
},
},
["Исчезновение оружия"] = {
{
400,
1726348058,
},
{
365,
1726834749,
},
{
210,
1727878065,
},
},
["Град стрел"] = {
{
37,
1726348058,
},
{
90,
1726348058,
},
{
133,
1726348058,
},
{
186,
1726348058,
},
{
231,
1726348058,
},
{
284,
1726348058,
},
{
329,
1726348058,
},
{
383,
1726348058,
},
{
36,
1726834080,
},
{
37,
1726834749,
},
{
89,
1726834749,
},
{
132,
1726834749,
},
{
185,
1726834749,
},
{
230,
1726834749,
},
{
284,
1726834749,
},
{
329,
1726834749,
},
{
37,
1727878065,
},
{
89,
1727878065,
},
{
133,
1727878065,
},
{
187,
1727878065,
},
},
},
["2898-14"] = {
["Истребление"] = {
{
46,
1726084146,
},
{
84,
1726084146,
},
{
142,
1726084146,
},
{
182,
1726084146,
},
},
["Фазовый выпад"] = {
{
11,
1726084146,
},
{
34,
1726084146,
},
{
57,
1726084146,
},
{
80,
1726084146,
},
{
107,
1726084146,
},
{
130,
1726084146,
},
{
153,
1726084146,
},
{
176,
1726084146,
},
},
["Выявление слабости"] = {
{
8,
1726084146,
},
{
9,
1726084146,
},
{
31,
1726084146,
},
{
33,
1726084146,
},
{
54,
1726084146,
},
{
55,
1726084146,
},
{
77,
1726084146,
},
{
78,
1726084146,
},
{
103,
1726084146,
},
{
105,
1726084146,
},
{
127,
1726084146,
},
{
128,
1726084146,
},
{
150,
1726084146,
},
{
151,
1726084146,
},
{
173,
1726084146,
},
{
174,
1726084146,
},
{
201,
1726084146,
},
{
202,
1726084146,
},
},
["Фазовые клинки"] = {
{
15,
1726084146,
},
{
21,
1726084146,
},
{
60,
1726084146,
},
{
66,
1726084146,
},
{
111,
1726084146,
},
{
117,
1726084146,
},
{
153,
1726084146,
},
{
159,
1726084146,
},
},
["Космические осколки"] = {
{
46,
1726084146,
},
{
84,
1726084146,
},
{
142,
1726084146,
},
{
182,
1726084146,
},
{
194,
1726084146,
},
},
["Космический осадок"] = {
{
46,
1726084146,
},
{
84,
1726084146,
},
{
142,
1726084146,
},
{
182,
1726084146,
},
{
194,
1726084146,
},
},
["Космический симулякр"] = {
{
21,
1726084146,
},
{
22,
1726084146,
},
{
66,
1726084146,
},
{
67,
1726084146,
},
{
117,
1726084146,
},
{
118,
1726084146,
},
{
159,
1726084146,
},
{
160,
1726084146,
},
},
["Разрушительный взмах"] = {
{
96,
1726084146,
},
{
194,
1726084146,
},
},
["Исчезновение оружия"] = {
{
203,
1726084146,
},
},
["Град стрел"] = {
{
37,
1726084146,
},
{
90,
1726084146,
},
{
134,
1726084146,
},
{
187,
1726084146,
},
},
},
["2902-14"] = {
["Тяжелое сокрушение"] = {
{
95,
1726694733,
},
{
96,
1726694733,
},
},
["Скрежещущий рой"] = {
{
99,
1726694733,
},
},
["Паутина ловчего"] = {
{
11,
1726694733,
},
{
56,
1726694733,
},
{
175,
1726694733,
},
},
["Ядовитая плеть"] = {
{
7,
1726694733,
},
{
32,
1726694733,
},
{
60,
1726694733,
},
{
171,
1726694733,
},
},
["Безжалостное сокрушение"] = {
{
4,
1726694733,
},
{
19,
1726694733,
},
{
34,
1726694733,
},
{
53,
1726694733,
},
{
68,
1726694733,
},
{
168,
1726694733,
},
{
183,
1726694733,
},
},
["Желудочный сок"] = {
{
17,
1726694733,
},
{
64,
1726694733,
},
{
181,
1726694733,
},
},
["Голодный рев"] = {
{
154,
1726694733,
},
},
["Игра хищника"] = {
{
34,
1726694733,
},
{
70,
1726694733,
},
},
["Потрошение"] = {
{
126,
1726694733,
},
{
127,
1726694733,
},
{
130,
1726694733,
},
{
131,
1726694733,
},
{
133,
1726694733,
},
{
137,
1726694733,
},
{
139,
1726694733,
},
},
["Смена фаз"] = {
{
90,
1726694733,
},
{
160,
1726694733,
},
},
["Поглощающий мрак"] = {
{
142,
1726694733,
},
},
["Неумолимый рывок"] = {
{
106,
1726694733,
},
{
111,
1726694733,
},
{
118,
1726694733,
},
{
125,
1726694733,
},
{
132,
1726694733,
},
},
},
["2919-14"] = {
["Яростный укус"] = {
{
101,
1726697614,
},
{
111,
1726697614,
},
{
153,
1726697614,
},
},
["Заражение"] = {
{
52,
1726697614,
},
{
54,
1726697614,
},
{
57,
1726697614,
},
},
["Сосредоточение внимания"] = {
{
47,
1726697614,
},
{
57,
1726697614,
},
{
65,
1726697614,
},
{
66,
1726697614,
},
{
97,
1726697614,
},
{
127,
1726697614,
},
{
128,
1726697614,
},
{
129,
1726697614,
},
{
129,
1726697614,
},
{
130,
1726697614,
},
{
131,
1726697614,
},
{
132,
1726697614,
},
{
133,
1726697614,
},
{
134,
1726697614,
},
{
135,
1726697614,
},
{
179,
1726697614,
},
{
180,
1726697614,
},
{
180,
1726697614,
},
{
181,
1726697614,
},
{
182,
1726697614,
},
},
["Мутация: прожорливость"] = {
{
128,
1726697614,
},
},
["Нестабильная смесь"] = {
{
3,
1726697614,
},
{
36,
1726697614,
},
{
56,
1726697614,
},
{
76,
1726697614,
},
{
96,
1726697614,
},
{
116,
1726697614,
},
{
136,
1726697614,
},
{
156,
1726697614,
},
{
176,
1726697614,
},
},
["Кровавый потоп"] = {
{
39,
1726697614,
},
{
40,
1726697614,
},
{
52,
1726697614,
},
{
128,
1726697614,
},
{
133,
1726697614,
},
{
136,
1726697614,
},
},
["Кислотная реакция"] = {
{
126,
1726697614,
},
{
127,
1726697614,
},
{
178,
1726697614,
},
{
179,
1726697614,
},
},
["Глоток черной крови"] = {
{
18,
1726697614,
},
{
190,
1726697614,
},
},
["Экспериментальная доза"] = {
{
34,
1726697614,
},
{
84,
1726697614,
},
{
134,
1726697614,
},
},
["Мутация: ускорение"] = {
{
127,
1726697614,
},
{
128,
1726697614,
},
{
179,
1726697614,
},
{
180,
1726697614,
},
},
},
["2920-15"] = {
["Разлом Пустоты"] = {
{
25,
1726428578,
},
{
25,
1726428578,
},
{
55,
1726428578,
},
{
55,
1726428578,
},
{
85,
1726428578,
},
{
85,
1726428578,
},
{
155,
1726428578,
},
{
155,
1726428578,
},
{
185,
1726428578,
},
{
185,
1726428578,
},
{
215,
1726428578,
},
{
215,
1726428578,
},
{
26,
1726429051,
},
{
26,
1726429051,
},
{
56,
1726429051,
},
{
56,
1726429051,
},
{
86,
1726429051,
},
{
86,
1726429051,
},
{
156,
1726429051,
},
{
156,
1726429051,
},
{
186,
1726429051,
},
{
186,
1726429051,
},
{
216,
1726429051,
},
{
216,
1726429051,
},
{
286,
1726429051,
},
{
286,
1726429051,
},
{
316,
1726429051,
},
{
316,
1726429051,
},
{
346,
1726429051,
},
{
346,
1726429051,
},
{
25,
1726429616,
},
{
26,
1726429616,
},
{
55,
1726429616,
},
{
56,
1726429616,
},
{
85,
1726429616,
},
{
86,
1726429616,
},
{
155,
1726429616,
},
{
156,
1726429616,
},
{
185,
1726429616,
},
{
186,
1726429616,
},
{
215,
1726429616,
},
{
216,
1726429616,
},
{
285,
1726429616,
},
{
286,
1726429616,
},
{
315,
1726429616,
},
{
316,
1726429616,
},
{
345,
1726429616,
},
{
346,
1726429616,
},
{
26,
1726430143,
},
{
26,
1726430143,
},
{
56,
1726430143,
},
{
56,
1726430143,
},
{
86,
1726430143,
},
{
86,
1726430143,
},
{
156,
1726430143,
},
{
156,
1726430143,
},
{
186,
1726430143,
},
{
186,
1726430143,
},
{
26,
1726430601,
},
{
26,
1726430601,
},
{
56,
1726430601,
},
{
56,
1726430601,
},
{
86,
1726430601,
},
{
86,
1726430601,
},
{
156,
1726430601,
},
{
156,
1726430601,
},
{
186,
1726430601,
},
{
186,
1726430601,
},
{
216,
1726430601,
},
{
216,
1726430601,
},
{
286,
1726430601,
},
{
286,
1726430601,
},
{
316,
1726430601,
},
{
316,
1726430601,
},
{
25,
1726430864,
},
{
25,
1726430864,
},
{
55,
1726430864,
},
{
55,
1726430864,
},
{
85,
1726430864,
},
{
85,
1726430864,
},
{
155,
1726430864,
},
{
155,
1726430864,
},
{
26,
1726431208,
},
{
26,
1726431208,
},
{
56,
1726431208,
},
{
56,
1726431208,
},
{
86,
1726431208,
},
{
86,
1726431208,
},
{
156,
1726431208,
},
{
156,
1726431208,
},
{
186,
1726431208,
},
{
186,
1726431208,
},
{
216,
1726431208,
},
{
216,
1726431208,
},
{
25,
1726431742,
},
{
26,
1726431742,
},
{
55,
1726431742,
},
{
56,
1726431742,
},
{
85,
1726431742,
},
{
86,
1726431742,
},
{
155,
1726431742,
},
{
156,
1726431742,
},
{
185,
1726431742,
},
{
186,
1726431742,
},
{
25,
1726431974,
},
{
25,
1726431974,
},
{
55,
1726431974,
},
{
55,
1726431974,
},
{
85,
1726431974,
},
{
85,
1726431974,
},
{
26,
1726432194,
},
{
26,
1726432194,
},
{
56,
1726432194,
},
{
56,
1726432194,
},
{
25,
1726432508,
},
{
25,
1726432508,
},
{
26,
1726432508,
},
{
55,
1726432508,
},
{
55,
1726432508,
},
{
56,
1726432508,
},
{
85,
1726432508,
},
{
85,
1726432508,
},
{
86,
1726432508,
},
{
155,
1726432508,
},
{
155,
1726432508,
},
{
156,
1726432508,
},
{
185,
1726432508,
},
{
185,
1726432508,
},
{
186,
1726432508,
},
{
26,
1726433063,
},
{
26,
1726433063,
},
{
56,
1726433063,
},
{
56,
1726433063,
},
{
86,
1726433063,
},
{
86,
1726433063,
},
{
156,
1726433063,
},
{
156,
1726433063,
},
{
186,
1726433063,
},
{
186,
1726433063,
},
{
216,
1726433063,
},
{
216,
1726433063,
},
{
26,
1726433218,
},
{
26,
1726433218,
},
{
56,
1726433218,
},
{
56,
1726433218,
},
{
25,
1726433352,
},
{
26,
1726433352,
},
{
55,
1726433352,
},
{
55,
1726433352,
},
{
56,
1726433352,
},
{
26,
1726433784,
},
{
26,
1726433784,
},
{
56,
1726433784,
},
{
56,
1726433784,
},
{
86,
1726433784,
},
{
86,
1726433784,
},
{
156,
1726433784,
},
{
156,
1726433784,
},
{
186,
1726433784,
},
{
186,
1726433784,
},
{
216,
1726433784,
},
{
216,
1726433784,
},
{
286,
1726433784,
},
{
286,
1726433784,
},
{
316,
1726433784,
},
{
316,
1726433784,
},
{
26,
1726434292,
},
{
26,
1726434292,
},
{
56,
1726434292,
},
{
56,
1726434292,
},
{
86,
1726434292,
},
{
86,
1726434292,
},
{
156,
1726434292,
},
{
156,
1726434292,
},
{
186,
1726434292,
},
{
186,
1726434292,
},
{
216,
1726434292,
},
{
216,
1726434292,
},
{
286,
1726434292,
},
{
286,
1726434292,
},
{
26,
1726434560,
},
{
26,
1726434560,
},
{
56,
1726434560,
},
{
56,
1726434560,
},
{
86,
1726434560,
},
{
86,
1726434560,
},
{
156,
1726434560,
},
{
156,
1726434560,
},
{
186,
1726434560,
},
{
186,
1726434560,
},
{
25,
1726434867,
},
{
25,
1726434867,
},
{
26,
1726434867,
},
{
55,
1726434867,
},
{
55,
1726434867,
},
{
56,
1726434867,
},
{
85,
1726434867,
},
{
85,
1726434867,
},
{
86,
1726434867,
},
{
155,
1726434867,
},
{
155,
1726434867,
},
{
156,
1726434867,
},
{
185,
1726434867,
},
{
185,
1726434867,
},
{
186,
1726434867,
},
{
26,
1726499229,
},
{
26,
1726499229,
},
{
56,
1726499229,
},
{
56,
1726499229,
},
{
86,
1726499229,
},
{
86,
1726499229,
},
{
156,
1726499229,
},
{
156,
1726499229,
},
{
186,
1726499229,
},
{
186,
1726499229,
},
{
216,
1726499229,
},
{
216,
1726499229,
},
{
26,
1726499652,
},
{
26,
1726499652,
},
{
56,
1726499652,
},
{
56,
1726499652,
},
{
86,
1726499652,
},
{
86,
1726499652,
},
{
156,
1726499652,
},
{
156,
1726499652,
},
{
157,
1726499652,
},
{
26,
1726500017,
},
{
26,
1726500017,
},
{
56,
1726500017,
},
{
56,
1726500017,
},
{
86,
1726500017,
},
{
86,
1726500017,
},
{
156,
1726500017,
},
{
156,
1726500017,
},
{
186,
1726500017,
},
{
186,
1726500017,
},
{
26,
1726500523,
},
{
26,
1726500523,
},
{
56,
1726500523,
},
{
56,
1726500523,
},
{
86,
1726500523,
},
{
86,
1726500523,
},
{
156,
1726500523,
},
{
156,
1726500523,
},
{
157,
1726500523,
},
{
186,
1726500523,
},
{
186,
1726500523,
},
{
187,
1726500523,
},
{
216,
1726500523,
},
{
216,
1726500523,
},
{
217,
1726500523,
},
{
286,
1726500523,
},
{
286,
1726500523,
},
{
287,
1726500523,
},
{
316,
1726500523,
},
{
316,
1726500523,
},
{
317,
1726500523,
},
{
346,
1726500523,
},
{
346,
1726500523,
},
{
347,
1726500523,
},
{
26,
1726501502,
},
{
26,
1726501502,
},
{
56,
1726501502,
},
{
56,
1726501502,
},
{
86,
1726501502,
},
{
86,
1726501502,
},
{
156,
1726501502,
},
{
156,
1726501502,
},
{
157,
1726501502,
},
{
186,
1726501502,
},
{
186,
1726501502,
},
{
187,
1726501502,
},
{
216,
1726501502,
},
{
216,
1726501502,
},
{
217,
1726501502,
},
{
286,
1726501502,
},
{
286,
1726501502,
},
{
287,
1726501502,
},
{
316,
1726501502,
},
{
316,
1726501502,
},
{
317,
1726501502,
},
{
346,
1726501502,
},
{
346,
1726501502,
},
{
347,
1726501502,
},
{
25,
1726854173,
},
{
25,
1726854173,
},
{
26,
1726854173,
},
{
55,
1726854173,
},
{
55,
1726854173,
},
{
56,
1726854173,
},
{
85,
1726854173,
},
{
85,
1726854173,
},
{
86,
1726854173,
},
{
155,
1726854173,
},
{
155,
1726854173,
},
{
156,
1726854173,
},
{
25,
1726855442,
},
{
25,
1726855442,
},
{
26,
1726855442,
},
{
55,
1726855442,
},
{
55,
1726855442,
},
{
56,
1726855442,
},
{
85,
1726855442,
},
{
85,
1726855442,
},
{
86,
1726855442,
},
{
155,
1726855442,
},
{
155,
1726855442,
},
{
156,
1726855442,
},
{
185,
1726855442,
},
{
185,
1726855442,
},
{
186,
1726855442,
},
{
215,
1726855442,
},
{
215,
1726855442,
},
{
216,
1726855442,
},
{
285,
1726855442,
},
{
285,
1726855442,
},
{
286,
1726855442,
},
{
315,
1726855442,
},
{
315,
1726855442,
},
{
316,
1726855442,
},
{
345,
1726855442,
},
{
345,
1726855442,
},
{
26,
1727542626,
},
{
26,
1727542626,
},
{
56,
1727542626,
},
{
56,
1727542626,
},
{
86,
1727542626,
},
{
86,
1727542626,
},
{
156,
1727542626,
},
{
156,
1727542626,
},
{
186,
1727542626,
},
{
186,
1727542626,
},
{
216,
1727542626,
},
{
216,
1727542626,
},
{
25,
1727543267,
},
{
25,
1727543267,
},
{
26,
1727543267,
},
{
55,
1727543267,
},
{
55,
1727543267,
},
{
56,
1727543267,
},
{
85,
1727543267,
},
{
85,
1727543267,
},
{
86,
1727543267,
},
{
155,
1727543267,
},
{
155,
1727543267,
},
{
156,
1727543267,
},
{
185,
1727543267,
},
{
185,
1727543267,
},
{
186,
1727543267,
},
{
215,
1727543267,
},
{
215,
1727543267,
},
{
216,
1727543267,
},
{
25,
1727543781,
},
{
26,
1727543781,
},
{
55,
1727543781,
},
{
55,
1727543781,
},
{
56,
1727543781,
},
{
85,
1727543781,
},
{
85,
1727543781,
},
{
86,
1727543781,
},
{
155,
1727543781,
},
{
156,
1727543781,
},
{
185,
1727543781,
},
{
186,
1727543781,
},
{
215,
1727543781,
},
{
216,
1727543781,
},
{
285,
1727543781,
},
{
286,
1727543781,
},
{
315,
1727543781,
},
{
316,
1727543781,
},
{
345,
1727543781,
},
{
345,
1727543781,
},
{
346,
1727543781,
},
{
26,
1727879504,
},
{
26,
1727879504,
},
{
56,
1727879504,
},
{
56,
1727879504,
},
{
86,
1727879504,
},
{
86,
1727879504,
},
{
156,
1727879504,
},
{
156,
1727879504,
},
{
157,
1727879504,
},
{
186,
1727879504,
},
{
186,
1727879504,
},
{
187,
1727879504,
},
{
216,
1727879504,
},
{
216,
1727879504,
},
{
217,
1727879504,
},
{
286,
1727879504,
},
{
286,
1727879504,
},
{
287,
1727879504,
},
{
316,
1727879504,
},
{
316,
1727879504,
},
},
["Раздирание Бездны"] = {
{
10,
1726428578,
},
{
11,
1726428578,
},
{
40,
1726428578,
},
{
41,
1726428578,
},
{
70,
1726428578,
},
{
71,
1726428578,
},
{
140,
1726428578,
},
{
141,
1726428578,
},
{
170,
1726428578,
},
{
171,
1726428578,
},
{
200,
1726428578,
},
{
201,
1726428578,
},
{
11,
1726429051,
},
{
12,
1726429051,
},
{
41,
1726429051,
},
{
42,
1726429051,
},
{
71,
1726429051,
},
{
72,
1726429051,
},
{
141,
1726429051,
},
{
142,
1726429051,
},
{
171,
1726429051,
},
{
172,
1726429051,
},
{
201,
1726429051,
},
{
202,
1726429051,
},
{
271,
1726429051,
},
{
272,
1726429051,
},
{
301,
1726429051,
},
{
302,
1726429051,
},
{
331,
1726429051,
},
{
332,
1726429051,
},
{
11,
1726429616,
},
{
11,
1726429616,
},
{
12,
1726429616,
},
{
41,
1726429616,
},
{
41,
1726429616,
},
{
42,
1726429616,
},
{
71,
1726429616,
},
{
71,
1726429616,
},
{
72,
1726429616,
},
{
141,
1726429616,
},
{
141,
1726429616,
},
{
142,
1726429616,
},
{
171,
1726429616,
},
{
171,
1726429616,
},
{
172,
1726429616,
},
{
201,
1726429616,
},
{
201,
1726429616,
},
{
202,
1726429616,
},
{
271,
1726429616,
},
{
271,
1726429616,
},
{
272,
1726429616,
},
{
301,
1726429616,
},
{
301,
1726429616,
},
{
302,
1726429616,
},
{
331,
1726429616,
},
{
331,
1726429616,
},
{
332,
1726429616,
},
{
11,
1726430143,
},
{
12,
1726430143,
},
{
41,
1726430143,
},
{
42,
1726430143,
},
{
71,
1726430143,
},
{
72,
1726430143,
},
{
141,
1726430143,
},
{
142,
1726430143,
},
{
171,
1726430143,
},
{
172,
1726430143,
},
{
11,
1726430601,
},
{
12,
1726430601,
},
{
41,
1726430601,
},
{
42,
1726430601,
},
{
71,
1726430601,
},
{
72,
1726430601,
},
{
141,
1726430601,
},
{
142,
1726430601,
},
{
171,
1726430601,
},
{
172,
1726430601,
},
{
201,
1726430601,
},
{
202,
1726430601,
},
{
271,
1726430601,
},
{
272,
1726430601,
},
{
301,
1726430601,
},
{
302,
1726430601,
},
{
11,
1726430864,
},
{
11,
1726430864,
},
{
12,
1726430864,
},
{
41,
1726430864,
},
{
41,
1726430864,
},
{
42,
1726430864,
},
{
71,
1726430864,
},
{
71,
1726430864,
},
{
72,
1726430864,
},
{
141,
1726430864,
},
{
141,
1726430864,
},
{
142,
1726430864,
},
{
11,
1726431208,
},
{
12,
1726431208,
},
{
41,
1726431208,
},
{
42,
1726431208,
},
{
71,
1726431208,
},
{
72,
1726431208,
},
{
141,
1726431208,
},
{
142,
1726431208,
},
{
171,
1726431208,
},
{
172,
1726431208,
},
{
201,
1726431208,
},
{
202,
1726431208,
},
{
11,
1726431742,
},
{
11,
1726431742,
},
{
12,
1726431742,
},
{
41,
1726431742,
},
{
41,
1726431742,
},
{
42,
1726431742,
},
{
71,
1726431742,
},
{
71,
1726431742,
},
{
72,
1726431742,
},
{
141,
1726431742,
},
{
141,
1726431742,
},
{
142,
1726431742,
},
{
171,
1726431742,
},
{
171,
1726431742,
},
{
172,
1726431742,
},
{
11,
1726431974,
},
{
11,
1726431974,
},
{
12,
1726431974,
},
{
41,
1726431974,
},
{
41,
1726431974,
},
{
42,
1726431974,
},
{
71,
1726431974,
},
{
71,
1726431974,
},
{
72,
1726431974,
},
{
11,
1726432194,
},
{
12,
1726432194,
},
{
41,
1726432194,
},
{
42,
1726432194,
},
{
71,
1726432194,
},
{
72,
1726432194,
},
{
11,
1726432508,
},
{
11,
1726432508,
},
{
12,
1726432508,
},
{
41,
1726432508,
},
{
41,
1726432508,
},
{
42,
1726432508,
},
{
71,
1726432508,
},
{
71,
1726432508,
},
{
72,
1726432508,
},
{
141,
1726432508,
},
{
141,
1726432508,
},
{
142,
1726432508,
},
{
171,
1726432508,
},
{
171,
1726432508,
},
{
172,
1726432508,
},
{
11,
1726433063,
},
{
12,
1726433063,
},
{
41,
1726433063,
},
{
42,
1726433063,
},
{
71,
1726433063,
},
{
72,
1726433063,
},
{
141,
1726433063,
},
{
142,
1726433063,
},
{
171,
1726433063,
},
{
172,
1726433063,
},
{
201,
1726433063,
},
{
202,
1726433063,
},
{
11,
1726433218,
},
{
12,
1726433218,
},
{
41,
1726433218,
},
{
42,
1726433218,
},
{
11,
1726433352,
},
{
11,
1726433352,
},
{
12,
1726433352,
},
{
41,
1726433352,
},
{
41,
1726433352,
},
{
42,
1726433352,
},
{
11,
1726433784,
},
{
12,
1726433784,
},
{
41,
1726433784,
},
{
42,
1726433784,
},
{
71,
1726433784,
},
{
72,
1726433784,
},
{
141,
1726433784,
},
{
142,
1726433784,
},
{
171,
1726433784,
},
{
172,
1726433784,
},
{
201,
1726433784,
},
{
202,
1726433784,
},
{
271,
1726433784,
},
{
272,
1726433784,
},
{
301,
1726433784,
},
{
302,
1726433784,
},
{
331,
1726433784,
},
{
332,
1726433784,
},
{
11,
1726434292,
},
{
12,
1726434292,
},
{
41,
1726434292,
},
{
42,
1726434292,
},
{
71,
1726434292,
},
{
72,
1726434292,
},
{
141,
1726434292,
},
{
142,
1726434292,
},
{
171,
1726434292,
},
{
172,
1726434292,
},
{
201,
1726434292,
},
{
202,
1726434292,
},
{
271,
1726434292,
},
{
272,
1726434292,
},
{
11,
1726434560,
},
{
12,
1726434560,
},
{
41,
1726434560,
},
{
42,
1726434560,
},
{
71,
1726434560,
},
{
72,
1726434560,
},
{
141,
1726434560,
},
{
142,
1726434560,
},
{
171,
1726434560,
},
{
172,
1726434560,
},
{
11,
1726434867,
},
{
11,
1726434867,
},
{
12,
1726434867,
},
{
41,
1726434867,
},
{
41,
1726434867,
},
{
42,
1726434867,
},
{
71,
1726434867,
},
{
71,
1726434867,
},
{
72,
1726434867,
},
{
141,
1726434867,
},
{
141,
1726434867,
},
{
142,
1726434867,
},
{
171,
1726434867,
},
{
171,
1726434867,
},
{
172,
1726434867,
},
{
201,
1726434867,
},
{
201,
1726434867,
},
{
202,
1726434867,
},
{
11,
1726499229,
},
{
12,
1726499229,
},
{
41,
1726499229,
},
{
42,
1726499229,
},
{
71,
1726499229,
},
{
72,
1726499229,
},
{
141,
1726499229,
},
{
142,
1726499229,
},
{
171,
1726499229,
},
{
172,
1726499229,
},
{
201,
1726499229,
},
{
202,
1726499229,
},
{
12,
1726499652,
},
{
12,
1726499652,
},
{
13,
1726499652,
},
{
42,
1726499652,
},
{
42,
1726499652,
},
{
43,
1726499652,
},
{
72,
1726499652,
},
{
72,
1726499652,
},
{
73,
1726499652,
},
{
142,
1726499652,
},
{
142,
1726499652,
},
{
143,
1726499652,
},
{
11,
1726500017,
},
{
12,
1726500017,
},
{
41,
1726500017,
},
{
42,
1726500017,
},
{
71,
1726500017,
},
{
72,
1726500017,
},
{
141,
1726500017,
},
{
142,
1726500017,
},
{
171,
1726500017,
},
{
172,
1726500017,
},
{
12,
1726500523,
},
{
12,
1726500523,
},
{
13,
1726500523,
},
{
42,
1726500523,
},
{
42,
1726500523,
},
{
43,
1726500523,
},
{
72,
1726500523,
},
{
72,
1726500523,
},
{
73,
1726500523,
},
{
142,
1726500523,
},
{
142,
1726500523,
},
{
143,
1726500523,
},
{
172,
1726500523,
},
{
172,
1726500523,
},
{
173,
1726500523,
},
{
202,
1726500523,
},
{
202,
1726500523,
},
{
203,
1726500523,
},
{
272,
1726500523,
},
{
272,
1726500523,
},
{
273,
1726500523,
},
{
302,
1726500523,
},
{
302,
1726500523,
},
{
303,
1726500523,
},
{
332,
1726500523,
},
{
332,
1726500523,
},
{
333,
1726500523,
},
{
12,
1726501502,
},
{
12,
1726501502,
},
{
13,
1726501502,
},
{
42,
1726501502,
},
{
42,
1726501502,
},
{
43,
1726501502,
},
{
72,
1726501502,
},
{
72,
1726501502,
},
{
73,
1726501502,
},
{
142,
1726501502,
},
{
142,
1726501502,
},
{
143,
1726501502,
},
{
172,
1726501502,
},
{
172,
1726501502,
},
{
173,
1726501502,
},
{
202,
1726501502,
},
{
202,
1726501502,
},
{
203,
1726501502,
},
{
272,
1726501502,
},
{
272,
1726501502,
},
{
273,
1726501502,
},
{
302,
1726501502,
},
{
302,
1726501502,
},
{
303,
1726501502,
},
{
332,
1726501502,
},
{
332,
1726501502,
},
{
333,
1726501502,
},
{
11,
1726854173,
},
{
11,
1726854173,
},
{
12,
1726854173,
},
{
41,
1726854173,
},
{
41,
1726854173,
},
{
42,
1726854173,
},
{
71,
1726854173,
},
{
71,
1726854173,
},
{
72,
1726854173,
},
{
141,
1726854173,
},
{
141,
1726854173,
},
{
142,
1726854173,
},
{
11,
1726855442,
},
{
11,
1726855442,
},
{
12,
1726855442,
},
{
41,
1726855442,
},
{
41,
1726855442,
},
{
42,
1726855442,
},
{
71,
1726855442,
},
{
71,
1726855442,
},
{
72,
1726855442,
},
{
141,
1726855442,
},
{
141,
1726855442,
},
{
142,
1726855442,
},
{
171,
1726855442,
},
{
171,
1726855442,
},
{
172,
1726855442,
},
{
201,
1726855442,
},
{
201,
1726855442,
},
{
202,
1726855442,
},
{
271,
1726855442,
},
{
271,
1726855442,
},
{
272,
1726855442,
},
{
301,
1726855442,
},
{
301,
1726855442,
},
{
302,
1726855442,
},
{
331,
1726855442,
},
{
331,
1726855442,
},
{
332,
1726855442,
},
{
11,
1727542626,
},
{
12,
1727542626,
},
{
41,
1727542626,
},
{
42,
1727542626,
},
{
71,
1727542626,
},
{
72,
1727542626,
},
{
141,
1727542626,
},
{
142,
1727542626,
},
{
171,
1727542626,
},
{
172,
1727542626,
},
{
201,
1727542626,
},
{
202,
1727542626,
},
{
11,
1727543267,
},
{
11,
1727543267,
},
{
12,
1727543267,
},
{
41,
1727543267,
},
{
41,
1727543267,
},
{
42,
1727543267,
},
{
71,
1727543267,
},
{
71,
1727543267,
},
{
72,
1727543267,
},
{
141,
1727543267,
},
{
141,
1727543267,
},
{
142,
1727543267,
},
{
171,
1727543267,
},
{
171,
1727543267,
},
{
172,
1727543267,
},
{
201,
1727543267,
},
{
201,
1727543267,
},
{
202,
1727543267,
},
{
11,
1727543781,
},
{
11,
1727543781,
},
{
12,
1727543781,
},
{
41,
1727543781,
},
{
41,
1727543781,
},
{
42,
1727543781,
},
{
71,
1727543781,
},
{
71,
1727543781,
},
{
72,
1727543781,
},
{
141,
1727543781,
},
{
141,
1727543781,
},
{
142,
1727543781,
},
{
171,
1727543781,
},
{
171,
1727543781,
},
{
172,
1727543781,
},
{
201,
1727543781,
},
{
201,
1727543781,
},
{
202,
1727543781,
},
{
271,
1727543781,
},
{
271,
1727543781,
},
{
272,
1727543781,
},
{
301,
1727543781,
},
{
301,
1727543781,
},
{
302,
1727543781,
},
{
331,
1727543781,
},
{
331,
1727543781,
},
{
332,
1727543781,
},
{
12,
1727879504,
},
{
12,
1727879504,
},
{
13,
1727879504,
},
{
42,
1727879504,
},
{
42,
1727879504,
},
{
43,
1727879504,
},
{
72,
1727879504,
},
{
72,
1727879504,
},
{
73,
1727879504,
},
{
142,
1727879504,
},
{
142,
1727879504,
},
{
143,
1727879504,
},
{
172,
1727879504,
},
{
172,
1727879504,
},
{
173,
1727879504,
},
{
202,
1727879504,
},
{
202,
1727879504,
},
{
203,
1727879504,
},
{
272,
1727879504,
},
{
272,
1727879504,
},
{
273,
1727879504,
},
{
302,
1727879504,
},
{
302,
1727879504,
},
{
303,
1727879504,
},
},
["Сумеречная резня"] = {
{
33,
1726428578,
},
{
34,
1726428578,
},
{
35,
1726428578,
},
{
39,
1726428578,
},
{
40,
1726428578,
},
{
63,
1726428578,
},
{
64,
1726428578,
},
{
65,
1726428578,
},
{
69,
1726428578,
},
{
70,
1726428578,
},
{
163,
1726428578,
},
{
164,
1726428578,
},
{
165,
1726428578,
},
{
169,
1726428578,
},
{
170,
1726428578,
},
{
193,
1726428578,
},
{
194,
1726428578,
},
{
195,
1726428578,
},
{
199,
1726428578,
},
{
200,
1726428578,
},
{
34,
1726429051,
},
{
35,
1726429051,
},
{
40,
1726429051,
},
{
64,
1726429051,
},
{
65,
1726429051,
},
{
70,
1726429051,
},
{
164,
1726429051,
},
{
165,
1726429051,
},
{
170,
1726429051,
},
{
194,
1726429051,
},
{
195,
1726429051,
},
{
200,
1726429051,
},
{
294,
1726429051,
},
{
295,
1726429051,
},
{
300,
1726429051,
},
{
301,
1726429051,
},
{
324,
1726429051,
},
{
325,
1726429051,
},
{
330,
1726429051,
},
{
34,
1726429616,
},
{
35,
1726429616,
},
{
40,
1726429616,
},
{
64,
1726429616,
},
{
65,
1726429616,
},
{
70,
1726429616,
},
{
164,
1726429616,
},
{
165,
1726429616,
},
{
170,
1726429616,
},
{
194,
1726429616,
},
{
195,
1726429616,
},
{
200,
1726429616,
},
{
294,
1726429616,
},
{
295,
1726429616,
},
{
300,
1726429616,
},
{
324,
1726429616,
},
{
325,
1726429616,
},
{
330,
1726429616,
},
{
34,
1726430143,
},
{
35,
1726430143,
},
{
40,
1726430143,
},
{
64,
1726430143,
},
{
65,
1726430143,
},
{
70,
1726430143,
},
{
164,
1726430143,
},
{
165,
1726430143,
},
{
170,
1726430143,
},
{
34,
1726430601,
},
{
35,
1726430601,
},
{
40,
1726430601,
},
{
64,
1726430601,
},
{
65,
1726430601,
},
{
70,
1726430601,
},
{
164,
1726430601,
},
{
165,
1726430601,
},
{
166,
1726430601,
},
{
170,
1726430601,
},
{
171,
1726430601,
},
{
194,
1726430601,
},
{
195,
1726430601,
},
{
196,
1726430601,
},
{
200,
1726430601,
},
{
201,
1726430601,
},
{
294,
1726430601,
},
{
295,
1726430601,
},
{
296,
1726430601,
},
{
300,
1726430601,
},
{
301,
1726430601,
},
{
33,
1726430864,
},
{
34,
1726430864,
},
{
35,
1726430864,
},
{
39,
1726430864,
},
{
40,
1726430864,
},
{
63,
1726430864,
},
{
64,
1726430864,
},
{
65,
1726430864,
},
{
69,
1726430864,
},
{
70,
1726430864,
},
{
163,
1726430864,
},
{
164,
1726430864,
},
{
165,
1726430864,
},
{
34,
1726431208,
},
{
35,
1726431208,
},
{
40,
1726431208,
},
{
64,
1726431208,
},
{
65,
1726431208,
},
{
70,
1726431208,
},
{
164,
1726431208,
},
{
165,
1726431208,
},
{
166,
1726431208,
},
{
170,
1726431208,
},
{
171,
1726431208,
},
{
194,
1726431208,
},
{
195,
1726431208,
},
{
200,
1726431208,
},
{
34,
1726431742,
},
{
35,
1726431742,
},
{
40,
1726431742,
},
{
64,
1726431742,
},
{
65,
1726431742,
},
{
70,
1726431742,
},
{
164,
1726431742,
},
{
165,
1726431742,
},
{
170,
1726431742,
},
{
194,
1726431742,
},
{
195,
1726431742,
},
{
33,
1726431974,
},
{
34,
1726431974,
},
{
35,
1726431974,
},
{
39,
1726431974,
},
{
40,
1726431974,
},
{
63,
1726431974,
},
{
64,
1726431974,
},
{
65,
1726431974,
},
{
69,
1726431974,
},
{
70,
1726431974,
},
{
34,
1726432194,
},
{
35,
1726432194,
},
{
40,
1726432194,
},
{
64,
1726432194,
},
{
65,
1726432194,
},
{
70,
1726432194,
},
{
34,
1726432508,
},
{
35,
1726432508,
},
{
40,
1726432508,
},
{
64,
1726432508,
},
{
65,
1726432508,
},
{
70,
1726432508,
},
{
164,
1726432508,
},
{
165,
1726432508,
},
{
170,
1726432508,
},
{
194,
1726432508,
},
{
195,
1726432508,
},
{
34,
1726433063,
},
{
35,
1726433063,
},
{
40,
1726433063,
},
{
64,
1726433063,
},
{
65,
1726433063,
},
{
70,
1726433063,
},
{
164,
1726433063,
},
{
165,
1726433063,
},
{
170,
1726433063,
},
{
194,
1726433063,
},
{
195,
1726433063,
},
{
200,
1726433063,
},
{
34,
1726433218,
},
{
35,
1726433218,
},
{
40,
1726433218,
},
{
34,
1726433352,
},
{
35,
1726433352,
},
{
40,
1726433352,
},
{
64,
1726433352,
},
{
65,
1726433352,
},
{
34,
1726433784,
},
{
35,
1726433784,
},
{
40,
1726433784,
},
{
64,
1726433784,
},
{
65,
1726433784,
},
{
70,
1726433784,
},
{
164,
1726433784,
},
{
165,
1726433784,
},
{
170,
1726433784,
},
{
194,
1726433784,
},
{
195,
1726433784,
},
{
200,
1726433784,
},
{
294,
1726433784,
},
{
295,
1726433784,
},
{
300,
1726433784,
},
{
324,
1726433784,
},
{
325,
1726433784,
},
{
330,
1726433784,
},
{
34,
1726434292,
},
{
35,
1726434292,
},
{
40,
1726434292,
},
{
64,
1726434292,
},
{
65,
1726434292,
},
{
70,
1726434292,
},
{
164,
1726434292,
},
{
165,
1726434292,
},
{
170,
1726434292,
},
{
194,
1726434292,
},
{
195,
1726434292,
},
{
200,
1726434292,
},
{
294,
1726434292,
},
{
295,
1726434292,
},
{
34,
1726434560,
},
{
35,
1726434560,
},
{
40,
1726434560,
},
{
64,
1726434560,
},
{
65,
1726434560,
},
{
70,
1726434560,
},
{
164,
1726434560,
},
{
165,
1726434560,
},
{
170,
1726434560,
},
{
194,
1726434560,
},
{
195,
1726434560,
},
{
34,
1726434867,
},
{
35,
1726434867,
},
{
40,
1726434867,
},
{
64,
1726434867,
},
{
65,
1726434867,
},
{
70,
1726434867,
},
{
164,
1726434867,
},
{
165,
1726434867,
},
{
170,
1726434867,
},
{
194,
1726434867,
},
{
195,
1726434867,
},
{
200,
1726434867,
},
{
34,
1726499229,
},
{
35,
1726499229,
},
{
40,
1726499229,
},
{
64,
1726499229,
},
{
65,
1726499229,
},
{
70,
1726499229,
},
{
164,
1726499229,
},
{
165,
1726499229,
},
{
166,
1726499229,
},
{
170,
1726499229,
},
{
171,
1726499229,
},
{
194,
1726499229,
},
{
195,
1726499229,
},
{
196,
1726499229,
},
{
200,
1726499229,
},
{
201,
1726499229,
},
{
34,
1726499652,
},
{
36,
1726499652,
},
{
41,
1726499652,
},
{
64,
1726499652,
},
{
65,
1726499652,
},
{
66,
1726499652,
},
{
71,
1726499652,
},
{
165,
1726499652,
},
{
166,
1726499652,
},
{
34,
1726500017,
},
{
35,
1726500017,
},
{
40,
1726500017,
},
{
64,
1726500017,
},
{
65,
1726500017,
},
{
70,
1726500017,
},
{
164,
1726500017,
},
{
165,
1726500017,
},
{
166,
1726500017,
},
{
170,
1726500017,
},
{
171,
1726500017,
},
{
194,
1726500017,
},
{
195,
1726500017,
},
{
196,
1726500017,
},
{
200,
1726500017,
},
{
201,
1726500017,
},
{
35,
1726500523,
},
{
36,
1726500523,
},
{
41,
1726500523,
},
{
65,
1726500523,
},
{
66,
1726500523,
},
{
71,
1726500523,
},
{
165,
1726500523,
},
{
166,
1726500523,
},
{
171,
1726500523,
},
{
195,
1726500523,
},
{
196,
1726500523,
},
{
201,
1726500523,
},
{
295,
1726500523,
},
{
296,
1726500523,
},
{
301,
1726500523,
},
{
325,
1726500523,
},
{
326,
1726500523,
},
{
331,
1726500523,
},
{
35,
1726501502,
},
{
36,
1726501502,
},
{
41,
1726501502,
},
{
65,
1726501502,
},
{
66,
1726501502,
},
{
71,
1726501502,
},
{
165,
1726501502,
},
{
166,
1726501502,
},
{
171,
1726501502,
},
{
195,
1726501502,
},
{
196,
1726501502,
},
{
201,
1726501502,
},
{
294,
1726501502,
},
{
296,
1726501502,
},
{
301,
1726501502,
},
{
325,
1726501502,
},
{
326,
1726501502,
},
{
331,
1726501502,
},
{
34,
1726854173,
},
{
35,
1726854173,
},
{
40,
1726854173,
},
{
64,
1726854173,
},
{
65,
1726854173,
},
{
70,
1726854173,
},
{
34,
1726855442,
},
{
35,
1726855442,
},
{
40,
1726855442,
},
{
64,
1726855442,
},
{
65,
1726855442,
},
{
70,
1726855442,
},
{
164,
1726855442,
},
{
165,
1726855442,
},
{
170,
1726855442,
},
{
194,
1726855442,
},
{
195,
1726855442,
},
{
200,
1726855442,
},
{
294,
1726855442,
},
{
295,
1726855442,
},
{
300,
1726855442,
},
{
324,
1726855442,
},
{
325,
1726855442,
},
{
330,
1726855442,
},
{
34,
1727542626,
},
{
35,
1727542626,
},
{
40,
1727542626,
},
{
64,
1727542626,
},
{
65,
1727542626,
},
{
70,
1727542626,
},
{
164,
1727542626,
},
{
165,
1727542626,
},
{
170,
1727542626,
},
{
194,
1727542626,
},
{
195,
1727542626,
},
{
200,
1727542626,
},
{
34,
1727543267,
},
{
35,
1727543267,
},
{
40,
1727543267,
},
{
64,
1727543267,
},
{
65,
1727543267,
},
{
70,
1727543267,
},
{
164,
1727543267,
},
{
165,
1727543267,
},
{
170,
1727543267,
},
{
194,
1727543267,
},
{
195,
1727543267,
},
{
200,
1727543267,
},
{
34,
1727543781,
},
{
35,
1727543781,
},
{
40,
1727543781,
},
{
64,
1727543781,
},
{
65,
1727543781,
},
{
70,
1727543781,
},
{
164,
1727543781,
},
{
165,
1727543781,
},
{
170,
1727543781,
},
{
194,
1727543781,
},
{
195,
1727543781,
},
{
200,
1727543781,
},
{
294,
1727543781,
},
{
295,
1727543781,
},
{
300,
1727543781,
},
{
324,
1727543781,
},
{
325,
1727543781,
},
{
330,
1727543781,
},
{
34,
1727879504,
},
{
35,
1727879504,
},
{
36,
1727879504,
},
{
40,
1727879504,
},
{
41,
1727879504,
},
{
64,
1727879504,
},
{
65,
1727879504,
},
{
66,
1727879504,
},
{
70,
1727879504,
},
{
71,
1727879504,
},
{
164,
1727879504,
},
{
165,
1727879504,
},
{
166,
1727879504,
},
{
170,
1727879504,
},
{
171,
1727879504,
},
{
194,
1727879504,
},
{
195,
1727879504,
},
{
196,
1727879504,
},
{
200,
1727879504,
},
{
201,
1727879504,
},
{
294,
1727879504,
},
{
295,
1727879504,
},
{
296,
1727879504,
},
{
300,
1727879504,
},
{
301,
1727879504,
},
},
["Беззвездная ночь"] = {
{
100,
1726428578,
},
{
230,
1726428578,
},
{
101,
1726429051,
},
{
231,
1726429051,
},
{
101,
1726429616,
},
{
231,
1726429616,
},
{
101,
1726430143,
},
{
101,
1726430601,
},
{
231,
1726430601,
},
{
100,
1726430864,
},
{
101,
1726431208,
},
{
231,
1726431208,
},
{
101,
1726431742,
},
{
100,
1726431974,
},
{
100,
1726432508,
},
{
101,
1726433063,
},
{
231,
1726433063,
},
{
101,
1726433784,
},
{
231,
1726433784,
},
{
101,
1726434292,
},
{
231,
1726434292,
},
{
101,
1726434560,
},
{
100,
1726434867,
},
{
101,
1726499229,
},
{
231,
1726499229,
},
{
101,
1726499652,
},
{
101,
1726500017,
},
{
101,
1726500523,
},
{
231,
1726500523,
},
{
101,
1726501502,
},
{
231,
1726501502,
},
{
100,
1726854173,
},
{
100,
1726855442,
},
{
230,
1726855442,
},
{
101,
1727542626,
},
{
101,
1727543267,
},
{
230,
1727543267,
},
{
100,
1727543781,
},
{
230,
1727543781,
},
{
101,
1727879504,
},
{
231,
1727879504,
},
},
["Кинжалы Нексуса"] = {
{
46,
1726428578,
},
{
47,
1726428578,
},
{
48,
1726428578,
},
{
49,
1726428578,
},
{
76,
1726428578,
},
{
77,
1726428578,
},
{
78,
1726428578,
},
{
176,
1726428578,
},
{
177,
1726428578,
},
{
178,
1726428578,
},
{
179,
1726428578,
},
{
206,
1726428578,
},
{
207,
1726428578,
},
{
208,
1726428578,
},
{
209,
1726428578,
},
{
47,
1726429051,
},
{
48,
1726429051,
},
{
49,
1726429051,
},
{
77,
1726429051,
},
{
78,
1726429051,
},
{
79,
1726429051,
},
{
177,
1726429051,
},
{
178,
1726429051,
},
{
179,
1726429051,
},
{
180,
1726429051,
},
{
207,
1726429051,
},
{
208,
1726429051,
},
{
209,
1726429051,
},
{
210,
1726429051,
},
{
307,
1726429051,
},
{
308,
1726429051,
},
{
309,
1726429051,
},
{
310,
1726429051,
},
{
311,
1726429051,
},
{
337,
1726429051,
},
{
338,
1726429051,
},
{
339,
1726429051,
},
{
340,
1726429051,
},
{
341,
1726429051,
},
{
47,
1726429616,
},
{
48,
1726429616,
},
{
49,
1726429616,
},
{
77,
1726429616,
},
{
78,
1726429616,
},
{
79,
1726429616,
},
{
177,
1726429616,
},
{
178,
1726429616,
},
{
179,
1726429616,
},
{
180,
1726429616,
},
{
207,
1726429616,
},
{
208,
1726429616,
},
{
209,
1726429616,
},
{
210,
1726429616,
},
{
307,
1726429616,
},
{
308,
1726429616,
},
{
309,
1726429616,
},
{
310,
1726429616,
},
{
337,
1726429616,
},
{
338,
1726429616,
},
{
339,
1726429616,
},
{
340,
1726429616,
},
{
47,
1726430143,
},
{
48,
1726430143,
},
{
49,
1726430143,
},
{
77,
1726430143,
},
{
78,
1726430143,
},
{
79,
1726430143,
},
{
177,
1726430143,
},
{
178,
1726430143,
},
{
179,
1726430143,
},
{
180,
1726430143,
},
{
47,
1726430601,
},
{
48,
1726430601,
},
{
49,
1726430601,
},
{
77,
1726430601,
},
{
78,
1726430601,
},
{
79,
1726430601,
},
{
177,
1726430601,
},
{
178,
1726430601,
},
{
179,
1726430601,
},
{
180,
1726430601,
},
{
207,
1726430601,
},
{
208,
1726430601,
},
{
209,
1726430601,
},
{
210,
1726430601,
},
{
307,
1726430601,
},
{
308,
1726430601,
},
{
309,
1726430601,
},
{
310,
1726430601,
},
{
311,
1726430601,
},
{
46,
1726430864,
},
{
47,
1726430864,
},
{
48,
1726430864,
},
{
49,
1726430864,
},
{
76,
1726430864,
},
{
77,
1726430864,
},
{
78,
1726430864,
},
{
79,
1726430864,
},
{
47,
1726431208,
},
{
48,
1726431208,
},
{
49,
1726431208,
},
{
77,
1726431208,
},
{
78,
1726431208,
},
{
79,
1726431208,
},
{
177,
1726431208,
},
{
178,
1726431208,
},
{
179,
1726431208,
},
{
180,
1726431208,
},
{
207,
1726431208,
},
{
208,
1726431208,
},
{
209,
1726431208,
},
{
210,
1726431208,
},
{
47,
1726431742,
},
{
48,
1726431742,
},
{
49,
1726431742,
},
{
77,
1726431742,
},
{
78,
1726431742,
},
{
79,
1726431742,
},
{
177,
1726431742,
},
{
178,
1726431742,
},
{
179,
1726431742,
},
{
180,
1726431742,
},
{
46,
1726431974,
},
{
47,
1726431974,
},
{
48,
1726431974,
},
{
49,
1726431974,
},
{
76,
1726431974,
},
{
77,
1726431974,
},
{
78,
1726431974,
},
{
79,
1726431974,
},
{
47,
1726432194,
},
{
48,
1726432194,
},
{
49,
1726432194,
},
{
77,
1726432194,
},
{
78,
1726432194,
},
{
79,
1726432194,
},
{
47,
1726432508,
},
{
48,
1726432508,
},
{
49,
1726432508,
},
{
77,
1726432508,
},
{
78,
1726432508,
},
{
79,
1726432508,
},
{
177,
1726432508,
},
{
178,
1726432508,
},
{
179,
1726432508,
},
{
180,
1726432508,
},
{
47,
1726433063,
},
{
48,
1726433063,
},
{
49,
1726433063,
},
{
77,
1726433063,
},
{
78,
1726433063,
},
{
79,
1726433063,
},
{
177,
1726433063,
},
{
178,
1726433063,
},
{
179,
1726433063,
},
{
180,
1726433063,
},
{
207,
1726433063,
},
{
208,
1726433063,
},
{
209,
1726433063,
},
{
210,
1726433063,
},
{
47,
1726433218,
},
{
48,
1726433218,
},
{
49,
1726433218,
},
{
47,
1726433352,
},
{
48,
1726433352,
},
{
49,
1726433352,
},
{
47,
1726433784,
},
{
48,
1726433784,
},
{
49,
1726433784,
},
{
77,
1726433784,
},
{
78,
1726433784,
},
{
79,
1726433784,
},
{
177,
1726433784,
},
{
178,
1726433784,
},
{
179,
1726433784,
},
{
180,
1726433784,
},
{
207,
1726433784,
},
{
208,
1726433784,
},
{
209,
1726433784,
},
{
210,
1726433784,
},
{
307,
1726433784,
},
{
308,
1726433784,
},
{
309,
1726433784,
},
{
310,
1726433784,
},
{
311,
1726433784,
},
{
47,
1726434292,
},
{
48,
1726434292,
},
{
49,
1726434292,
},
{
77,
1726434292,
},
{
78,
1726434292,
},
{
79,
1726434292,
},
{
177,
1726434292,
},
{
178,
1726434292,
},
{
179,
1726434292,
},
{
180,
1726434292,
},
{
207,
1726434292,
},
{
208,
1726434292,
},
{
209,
1726434292,
},
{
210,
1726434292,
},
{
47,
1726434560,
},
{
48,
1726434560,
},
{
49,
1726434560,
},
{
77,
1726434560,
},
{
78,
1726434560,
},
{
79,
1726434560,
},
{
177,
1726434560,
},
{
178,
1726434560,
},
{
179,
1726434560,
},
{
180,
1726434560,
},
{
47,
1726434867,
},
{
48,
1726434867,
},
{
49,
1726434867,
},
{
77,
1726434867,
},
{
78,
1726434867,
},
{
79,
1726434867,
},
{
176,
1726434867,
},
{
177,
1726434867,
},
{
178,
1726434867,
},
{
179,
1726434867,
},
{
207,
1726434867,
},
{
47,
1726499229,
},
{
48,
1726499229,
},
{
49,
1726499229,
},
{
77,
1726499229,
},
{
78,
1726499229,
},
{
79,
1726499229,
},
{
177,
1726499229,
},
{
178,
1726499229,
},
{
179,
1726499229,
},
{
180,
1726499229,
},
{
207,
1726499229,
},
{
208,
1726499229,
},
{
209,
1726499229,
},
{
210,
1726499229,
},
{
47,
1726499652,
},
{
48,
1726499652,
},
{
49,
1726499652,
},
{
50,
1726499652,
},
{
77,
1726499652,
},
{
78,
1726499652,
},
{
79,
1726499652,
},
{
80,
1726499652,
},
{
47,
1726500017,
},
{
48,
1726500017,
},
{
49,
1726500017,
},
{
77,
1726500017,
},
{
78,
1726500017,
},
{
79,
1726500017,
},
{
177,
1726500017,
},
{
178,
1726500017,
},
{
179,
1726500017,
},
{
180,
1726500017,
},
{
207,
1726500017,
},
{
208,
1726500017,
},
{
47,
1726500523,
},
{
48,
1726500523,
},
{
49,
1726500523,
},
{
50,
1726500523,
},
{
77,
1726500523,
},
{
78,
1726500523,
},
{
79,
1726500523,
},
{
80,
1726500523,
},
{
177,
1726500523,
},
{
178,
1726500523,
},
{
179,
1726500523,
},
{
180,
1726500523,
},
{
207,
1726500523,
},
{
208,
1726500523,
},
{
209,
1726500523,
},
{
210,
1726500523,
},
{
307,
1726500523,
},
{
308,
1726500523,
},
{
309,
1726500523,
},
{
310,
1726500523,
},
{
311,
1726500523,
},
{
337,
1726500523,
},
{
338,
1726500523,
},
{
339,
1726500523,
},
{
340,
1726500523,
},
{
341,
1726500523,
},
{
47,
1726501502,
},
{
48,
1726501502,
},
{
49,
1726501502,
},
{
50,
1726501502,
},
{
77,
1726501502,
},
{
78,
1726501502,
},
{
79,
1726501502,
},
{
80,
1726501502,
},
{
177,
1726501502,
},
{
178,
1726501502,
},
{
179,
1726501502,
},
{
180,
1726501502,
},
{
207,
1726501502,
},
{
208,
1726501502,
},
{
209,
1726501502,
},
{
210,
1726501502,
},
{
307,
1726501502,
},
{
308,
1726501502,
},
{
309,
1726501502,
},
{
310,
1726501502,
},
{
311,
1726501502,
},
{
337,
1726501502,
},
{
338,
1726501502,
},
{
339,
1726501502,
},
{
340,
1726501502,
},
{
341,
1726501502,
},
{
47,
1726854173,
},
{
48,
1726854173,
},
{
49,
1726854173,
},
{
77,
1726854173,
},
{
78,
1726854173,
},
{
79,
1726854173,
},
{
47,
1726855442,
},
{
48,
1726855442,
},
{
49,
1726855442,
},
{
77,
1726855442,
},
{
78,
1726855442,
},
{
79,
1726855442,
},
{
177,
1726855442,
},
{
178,
1726855442,
},
{
179,
1726855442,
},
{
180,
1726855442,
},
{
207,
1726855442,
},
{
208,
1726855442,
},
{
209,
1726855442,
},
{
210,
1726855442,
},
{
307,
1726855442,
},
{
308,
1726855442,
},
{
309,
1726855442,
},
{
310,
1726855442,
},
{
337,
1726855442,
},
{
338,
1726855442,
},
{
339,
1726855442,
},
{
340,
1726855442,
},
{
47,
1727542626,
},
{
48,
1727542626,
},
{
49,
1727542626,
},
{
77,
1727542626,
},
{
78,
1727542626,
},
{
79,
1727542626,
},
{
177,
1727542626,
},
{
178,
1727542626,
},
{
179,
1727542626,
},
{
180,
1727542626,
},
{
207,
1727542626,
},
{
208,
1727542626,
},
{
209,
1727542626,
},
{
210,
1727542626,
},
{
47,
1727543267,
},
{
48,
1727543267,
},
{
49,
1727543267,
},
{
77,
1727543267,
},
{
78,
1727543267,
},
{
79,
1727543267,
},
{
177,
1727543267,
},
{
178,
1727543267,
},
{
179,
1727543267,
},
{
180,
1727543267,
},
{
207,
1727543267,
},
{
208,
1727543267,
},
{
209,
1727543267,
},
{
210,
1727543267,
},
{
47,
1727543781,
},
{
48,
1727543781,
},
{
49,
1727543781,
},
{
77,
1727543781,
},
{
78,
1727543781,
},
{
79,
1727543781,
},
{
177,
1727543781,
},
{
178,
1727543781,
},
{
179,
1727543781,
},
{
180,
1727543781,
},
{
207,
1727543781,
},
{
208,
1727543781,
},
{
209,
1727543781,
},
{
210,
1727543781,
},
{
307,
1727543781,
},
{
308,
1727543781,
},
{
309,
1727543781,
},
{
310,
1727543781,
},
{
311,
1727543781,
},
{
337,
1727543781,
},
{
338,
1727543781,
},
{
339,
1727543781,
},
{
340,
1727543781,
},
{
341,
1727543781,
},
{
47,
1727879504,
},
{
48,
1727879504,
},
{
49,
1727879504,
},
{
50,
1727879504,
},
{
77,
1727879504,
},
{
78,
1727879504,
},
{
79,
1727879504,
},
{
80,
1727879504,
},
{
177,
1727879504,
},
{
178,
1727879504,
},
{
179,
1727879504,
},
{
180,
1727879504,
},
{
207,
1727879504,
},
{
208,
1727879504,
},
{
209,
1727879504,
},
{
210,
1727879504,
},
{
307,
1727879504,
},
{
308,
1727879504,
},
{
309,
1727879504,
},
{
310,
1727879504,
},
{
311,
1727879504,
},
},
["Жнец"] = {
{
-1,
1726428578,
},
{
0,
1726429051,
},
{
0,
1726429616,
},
{
0,
1726430143,
},
{
0,
1726430601,
},
{
-1,
1726430864,
},
{
0,
1726431208,
},
{
0,
1726431742,
},
{
-1,
1726431974,
},
{
0,
1726432194,
},
{
-1,
1726432508,
},
{
0,
1726433063,
},
{
0,
1726433218,
},
{
-1,
1726433352,
},
{
0,
1726433784,
},
{
0,
1726434292,
},
{
0,
1726434560,
},
{
-1,
1726434867,
},
{
0,
1726499229,
},
{
0,
1726499652,
},
{
0,
1726500017,
},
{
0,
1726500523,
},
{
0,
1726501502,
},
{
-1,
1726854173,
},
{
-1,
1726855442,
},
{
0,
1727542626,
},
{
-1,
1727543267,
},
{
-1,
1727543781,
},
{
0,
1727879504,
},
},
["Ликвидация"] = {
{
7,
1726428578,
},
{
15,
1726428578,
},
{
15,
1726428578,
},
{
16,
1726428578,
},
{
137,
1726428578,
},
{
145,
1726428578,
},
{
145,
1726428578,
},
{
146,
1726428578,
},
{
8,
1726429051,
},
{
15,
1726429051,
},
{
16,
1726429051,
},
{
17,
1726429051,
},
{
138,
1726429051,
},
{
145,
1726429051,
},
{
146,
1726429051,
},
{
147,
1726429051,
},
{
268,
1726429051,
},
{
275,
1726429051,
},
{
276,
1726429051,
},
{
277,
1726429051,
},
{
8,
1726429616,
},
{
15,
1726429616,
},
{
16,
1726429616,
},
{
138,
1726429616,
},
{
145,
1726429616,
},
{
146,
1726429616,
},
{
147,
1726429616,
},
{
268,
1726429616,
},
{
275,
1726429616,
},
{
276,
1726429616,
},
{
277,
1726429616,
},
{
8,
1726430143,
},
{
16,
1726430143,
},
{
16,
1726430143,
},
{
17,
1726430143,
},
{
138,
1726430143,
},
{
146,
1726430143,
},
{
146,
1726430143,
},
{
147,
1726430143,
},
{
8,
1726430601,
},
{
16,
1726430601,
},
{
16,
1726430601,
},
{
17,
1726430601,
},
{
138,
1726430601,
},
{
146,
1726430601,
},
{
146,
1726430601,
},
{
147,
1726430601,
},
{
268,
1726430601,
},
{
276,
1726430601,
},
{
276,
1726430601,
},
{
277,
1726430601,
},
{
8,
1726430864,
},
{
15,
1726430864,
},
{
16,
1726430864,
},
{
138,
1726430864,
},
{
145,
1726430864,
},
{
146,
1726430864,
},
{
8,
1726431208,
},
{
16,
1726431208,
},
{
16,
1726431208,
},
{
17,
1726431208,
},
{
138,
1726431208,
},
{
146,
1726431208,
},
{
146,
1726431208,
},
{
147,
1726431208,
},
{
8,
1726431742,
},
{
15,
1726431742,
},
{
16,
1726431742,
},
{
138,
1726431742,
},
{
145,
1726431742,
},
{
146,
1726431742,
},
{
147,
1726431742,
},
{
8,
1726431974,
},
{
15,
1726431974,
},
{
16,
1726431974,
},
{
8,
1726432194,
},
{
16,
1726432194,
},
{
16,
1726432194,
},
{
17,
1726432194,
},
{
8,
1726432508,
},
{
15,
1726432508,
},
{
16,
1726432508,
},
{
138,
1726432508,
},
{
145,
1726432508,
},
{
146,
1726432508,
},
{
8,
1726433063,
},
{
16,
1726433063,
},
{
16,
1726433063,
},
{
17,
1726433063,
},
{
138,
1726433063,
},
{
146,
1726433063,
},
{
146,
1726433063,
},
{
147,
1726433063,
},
{
8,
1726433218,
},
{
15,
1726433218,
},
{
16,
1726433218,
},
{
17,
1726433218,
},
{
8,
1726433352,
},
{
15,
1726433352,
},
{
16,
1726433352,
},
{
8,
1726433784,
},
{
15,
1726433784,
},
{
16,
1726433784,
},
{
17,
1726433784,
},
{
138,
1726433784,
},
{
145,
1726433784,
},
{
146,
1726433784,
},
{
147,
1726433784,
},
{
268,
1726433784,
},
{
275,
1726433784,
},
{
276,
1726433784,
},
{
277,
1726433784,
},
{
8,
1726434292,
},
{
15,
1726434292,
},
{
16,
1726434292,
},
{
17,
1726434292,
},
{
138,
1726434292,
},
{
145,
1726434292,
},
{
146,
1726434292,
},
{
147,
1726434292,
},
{
268,
1726434292,
},
{
275,
1726434292,
},
{
276,
1726434292,
},
{
277,
1726434292,
},
{
8,
1726434560,
},
{
15,
1726434560,
},
{
16,
1726434560,
},
{
17,
1726434560,
},
{
138,
1726434560,
},
{
145,
1726434560,
},
{
146,
1726434560,
},
{
147,
1726434560,
},
{
8,
1726434867,
},
{
15,
1726434867,
},
{
16,
1726434867,
},
{
138,
1726434867,
},
{
145,
1726434867,
},
{
146,
1726434867,
},
{
8,
1726499229,
},
{
16,
1726499229,
},
{
16,
1726499229,
},
{
17,
1726499229,
},
{
138,
1726499229,
},
{
146,
1726499229,
},
{
146,
1726499229,
},
{
147,
1726499229,
},
{
9,
1726499652,
},
{
16,
1726499652,
},
{
17,
1726499652,
},
{
139,
1726499652,
},
{
146,
1726499652,
},
{
147,
1726499652,
},
{
8,
1726500017,
},
{
16,
1726500017,
},
{
16,
1726500017,
},
{
17,
1726500017,
},
{
138,
1726500017,
},
{
146,
1726500017,
},
{
146,
1726500017,
},
{
147,
1726500017,
},
{
9,
1726500523,
},
{
16,
1726500523,
},
{
17,
1726500523,
},
{
139,
1726500523,
},
{
146,
1726500523,
},
{
147,
1726500523,
},
{
269,
1726500523,
},
{
276,
1726500523,
},
{
277,
1726500523,
},
{
278,
1726500523,
},
{
9,
1726501502,
},
{
16,
1726501502,
},
{
17,
1726501502,
},
{
139,
1726501502,
},
{
146,
1726501502,
},
{
147,
1726501502,
},
{
269,
1726501502,
},
{
276,
1726501502,
},
{
277,
1726501502,
},
{
278,
1726501502,
},
{
8,
1726854173,
},
{
15,
1726854173,
},
{
16,
1726854173,
},
{
138,
1726854173,
},
{
145,
1726854173,
},
{
146,
1726854173,
},
{
147,
1726854173,
},
{
8,
1726855442,
},
{
15,
1726855442,
},
{
16,
1726855442,
},
{
138,
1726855442,
},
{
145,
1726855442,
},
{
146,
1726855442,
},
{
147,
1726855442,
},
{
268,
1726855442,
},
{
275,
1726855442,
},
{
276,
1726855442,
},
{
277,
1726855442,
},
{
8,
1727542626,
},
{
15,
1727542626,
},
{
16,
1727542626,
},
{
17,
1727542626,
},
{
138,
1727542626,
},
{
145,
1727542626,
},
{
146,
1727542626,
},
{
147,
1727542626,
},
{
8,
1727543267,
},
{
15,
1727543267,
},
{
16,
1727543267,
},
{
138,
1727543267,
},
{
145,
1727543267,
},
{
146,
1727543267,
},
{
147,
1727543267,
},
{
8,
1727543781,
},
{
15,
1727543781,
},
{
16,
1727543781,
},
{
138,
1727543781,
},
{
145,
1727543781,
},
{
146,
1727543781,
},
{
147,
1727543781,
},
{
268,
1727543781,
},
{
275,
1727543781,
},
{
276,
1727543781,
},
{
277,
1727543781,
},
{
9,
1727879504,
},
{
16,
1727879504,
},
{
17,
1727879504,
},
{
139,
1727879504,
},
{
146,
1727879504,
},
{
147,
1727879504,
},
{
269,
1727879504,
},
{
276,
1727879504,
},
{
277,
1727879504,
},
{
278,
1727879504,
},
},
["Вечная ночь"] = {
{
361,
1726429616,
},
{
361,
1726500523,
},
{
361,
1726501502,
},
},
},
["2917-14"] = {
["Брызги крови"] = {
{
128,
1726082945,
},
{
256,
1726082945,
},
{
128,
1726083408,
},
{
128,
1726695414,
},
},
["Черный бастион"] = {
{
224,
1726082945,
},
{
282,
1726082945,
},
{
283,
1726082945,
},
{
300,
1726082945,
},
},
["Призрачный удар"] = {
{
32,
1726082945,
},
{
48,
1726082945,
},
{
85,
1726082945,
},
{
160,
1726082945,
},
{
211,
1726082945,
},
{
234,
1726082945,
},
{
295,
1726082945,
},
{
296,
1726082945,
},
{
32,
1726083408,
},
{
84,
1726083408,
},
{
159,
1726083408,
},
{
209,
1726083408,
},
{
32,
1726695414,
},
{
83,
1726695414,
},
{
158,
1726695414,
},
},
["Отвратительная отрыжка"] = {
{
21,
1726082945,
},
{
72,
1726082945,
},
{
149,
1726082945,
},
{
200,
1726082945,
},
{
277,
1726082945,
},
{
21,
1726083408,
},
{
72,
1726083408,
},
{
149,
1726083408,
},
{
200,
1726083408,
},
{
21,
1726695414,
},
{
72,
1726695414,
},
{
149,
1726695414,
},
},
["Багровый дождь"] = {
{
11,
1726082945,
},
{
139,
1726082945,
},
{
267,
1726082945,
},
{
11,
1726083408,
},
{
139,
1726083408,
},
{
11,
1726695414,
},
{
139,
1726695414,
},
},
["Внушение ужаса"] = {
{
5,
1726082945,
},
{
56,
1726082945,
},
{
133,
1726082945,
},
{
184,
1726082945,
},
{
261,
1726082945,
},
{
312,
1726082945,
},
{
5,
1726083408,
},
{
56,
1726083408,
},
{
133,
1726083408,
},
{
184,
1726083408,
},
{
5,
1726695414,
},
{
56,
1726695414,
},
{
133,
1726695414,
},
{
184,
1726695414,
},
},
["Воплощение ужаса"] = {
{
29,
1726082945,
},
{
33,
1726082945,
},
{
38,
1726082945,
},
{
43,
1726082945,
},
{
79,
1726082945,
},
{
84,
1726082945,
},
{
88,
1726082945,
},
{
93,
1726082945,
},
{
97,
1726082945,
},
{
102,
1726082945,
},
{
107,
1726082945,
},
{
111,
1726082945,
},
{
116,
1726082945,
},
{
120,
1726082945,
},
{
125,
1726082945,
},
{
130,
1726082945,
},
{
134,
1726082945,
},
{
139,
1726082945,
},
{
143,
1726082945,
},
{
148,
1726082945,
},
{
153,
1726082945,
},
{
157,
1726082945,
},
{
161,
1726082945,
},
{
162,
1726082945,
},
{
166,
1726082945,
},
{
171,
1726082945,
},
{
175,
1726082945,
},
{
180,
1726082945,
},
{
184,
1726082945,
},
{
189,
1726082945,
},
{
194,
1726082945,
},
{
198,
1726082945,
},
{
203,
1726082945,
},
{
207,
1726082945,
},
{
208,
1726082945,
},
{
212,
1726082945,
},
{
217,
1726082945,
},
{
221,
1726082945,
},
{
222,
1726082945,
},
{
226,
1726082945,
},
{
230,
1726082945,
},
{
231,
1726082945,
},
{
235,
1726082945,
},
{
240,
1726082945,
},
{
244,
1726082945,
},
{
245,
1726082945,
},
{
249,
1726082945,
},
{
253,
1726082945,
},
{
254,
1726082945,
},
{
258,
1726082945,
},
{
263,
1726082945,
},
{
267,
1726082945,
},
{
268,
1726082945,
},
{
272,
1726082945,
},
{
277,
1726082945,
},
{
281,
1726082945,
},
{
282,
1726082945,
},
{
285,
1726082945,
},
{
286,
1726082945,
},
{
289,
1726082945,
},
{
290,
1726082945,
},
{
291,
1726082945,
},
{
294,
1726082945,
},
{
295,
1726082945,
},
{
298,
1726082945,
},
{
300,
1726082945,
},
{
303,
1726082945,
},
{
304,
1726082945,
},
{
305,
1726082945,
},
{
308,
1726082945,
},
{
309,
1726082945,
},
{
312,
1726082945,
},
{
313,
1726082945,
},
{
28,
1726083408,
},
{
33,
1726083408,
},
{
38,
1726083408,
},
{
79,
1726083408,
},
{
84,
1726083408,
},
{
89,
1726083408,
},
{
156,
1726083408,
},
{
161,
1726083408,
},
{
165,
1726083408,
},
{
170,
1726083408,
},
{
207,
1726083408,
},
{
212,
1726083408,
},
{
216,
1726083408,
},
{
221,
1726083408,
},
{
27,
1726695414,
},
{
31,
1726695414,
},
{
35,
1726695414,
},
{
39,
1726695414,
},
{
78,
1726695414,
},
{
82,
1726695414,
},
{
86,
1726695414,
},
{
90,
1726695414,
},
{
156,
1726695414,
},
{
160,
1726695414,
},
{
164,
1726695414,
},
{
168,
1726695414,
},
{
172,
1726695414,
},
{
176,
1726695414,
},
},
["Потусторонняя хватка"] = {
{
22,
1726082945,
},
{
37,
1726082945,
},
{
52,
1726082945,
},
{
73,
1726082945,
},
{
88,
1726082945,
},
{
103,
1726082945,
},
{
150,
1726082945,
},
{
165,
1726082945,
},
{
180,
1726082945,
},
{
201,
1726082945,
},
{
216,
1726082945,
},
{
231,
1726082945,
},
{
278,
1726082945,
},
{
293,
1726082945,
},
{
308,
1726082945,
},
{
22,
1726083408,
},
{
37,
1726083408,
},
{
52,
1726083408,
},
{
73,
1726083408,
},
{
88,
1726083408,
},
{
103,
1726083408,
},
{
150,
1726083408,
},
{
165,
1726083408,
},
{
180,
1726083408,
},
{
201,
1726083408,
},
{
216,
1726083408,
},
{
22,
1726695414,
},
{
37,
1726695414,
},
{
52,
1726695414,
},
{
73,
1726695414,
},
{
88,
1726695414,
},
{
103,
1726695414,
},
{
150,
1726695414,
},
{
165,
1726695414,
},
{
180,
1726695414,
},
},
},
["2921-15"] = {
["Пронзающее извержение"] = {
{
22,
1726856654,
},
{
62,
1726856654,
},
{
22,
1726857059,
},
{
62,
1726857059,
},
{
88,
1726857059,
},
{
23,
1727103485,
},
{
63,
1727103485,
},
{
89,
1727103485,
},
{
195,
1727103485,
},
{
235,
1727103485,
},
{
262,
1727103485,
},
{
292,
1727103485,
},
{
23,
1727104149,
},
{
63,
1727104149,
},
{
89,
1727104149,
},
{
189,
1727104149,
},
{
229,
1727104149,
},
{
256,
1727104149,
},
{
286,
1727104149,
},
{
22,
1727104418,
},
{
62,
1727104418,
},
{
88,
1727104418,
},
{
23,
1727104743,
},
{
63,
1727104743,
},
{
89,
1727104743,
},
{
23,
1727105692,
},
{
63,
1727105692,
},
{
89,
1727105692,
},
{
192,
1727105692,
},
{
232,
1727105692,
},
{
259,
1727105692,
},
{
289,
1727105692,
},
{
23,
1727881304,
},
{
63,
1727881304,
},
{
89,
1727881304,
},
{
23,
1727881714,
},
{
63,
1727881714,
},
{
23,
1727882226,
},
{
63,
1727882226,
},
{
89,
1727882226,
},
{
23,
1727883194,
},
{
63,
1727883194,
},
{
89,
1727883194,
},
{
197,
1727883194,
},
{
237,
1727883194,
},
{
264,
1727883194,
},
{
294,
1727883194,
},
},
["Панцирекрушитель"] = {
{
14,
1726856654,
},
{
68,
1726856654,
},
{
14,
1726857059,
},
{
68,
1726857059,
},
{
15,
1727103485,
},
{
69,
1727103485,
},
{
201,
1727103485,
},
{
255,
1727103485,
},
{
15,
1727104149,
},
{
69,
1727104149,
},
{
195,
1727104149,
},
{
249,
1727104149,
},
{
14,
1727104418,
},
{
68,
1727104418,
},
{
15,
1727104743,
},
{
69,
1727104743,
},
{
15,
1727105692,
},
{
69,
1727105692,
},
{
198,
1727105692,
},
{
252,
1727105692,
},
{
15,
1727881304,
},
{
69,
1727881304,
},
{
15,
1727881714,
},
{
69,
1727881714,
},
{
15,
1727882226,
},
{
69,
1727882226,
},
{
15,
1727883194,
},
{
69,
1727883194,
},
{
203,
1727883194,
},
{
257,
1727883194,
},
},
["Призыв роя"] = {
{
14,
1726856654,
},
{
68,
1726856654,
},
{
14,
1726857059,
},
{
68,
1726857059,
},
{
15,
1727103485,
},
{
69,
1727103485,
},
{
201,
1727103485,
},
{
255,
1727103485,
},
{
15,
1727104149,
},
{
69,
1727104149,
},
{
195,
1727104149,
},
{
249,
1727104149,
},
{
14,
1727104418,
},
{
68,
1727104418,
},
{
15,
1727104743,
},
{
69,
1727104743,
},
{
15,
1727105692,
},
{
69,
1727105692,
},
{
198,
1727105692,
},
{
252,
1727105692,
},
{
15,
1727881304,
},
{
69,
1727881304,
},
{
15,
1727881714,
},
{
69,
1727881714,
},
{
15,
1727882226,
},
{
69,
1727882226,
},
{
15,
1727883194,
},
{
69,
1727883194,
},
{
203,
1727883194,
},
{
257,
1727883194,
},
},
["Энтропическое опустошение"] = {
{
205,
1727103485,
},
{
261,
1727103485,
},
{
412,
1727103485,
},
{
509,
1727103485,
},
{
199,
1727104149,
},
{
254,
1727104149,
},
{
397,
1727104149,
},
{
203,
1727105692,
},
{
258,
1727105692,
},
{
396,
1727105692,
},
{
209,
1727883194,
},
{
265,
1727883194,
},
{
436,
1727883194,
},
{
533,
1727883194,
},
{
616,
1727883194,
},
},
["Подземное извержение"] = {
{
33,
1726856654,
},
{
33,
1726857059,
},
{
91,
1726857059,
},
{
34,
1727103485,
},
{
92,
1727103485,
},
{
416,
1727103485,
},
{
514,
1727103485,
},
{
34,
1727104149,
},
{
92,
1727104149,
},
{
402,
1727104149,
},
{
33,
1727104418,
},
{
91,
1727104418,
},
{
33,
1727104743,
},
{
91,
1727104743,
},
{
34,
1727105692,
},
{
92,
1727105692,
},
{
400,
1727105692,
},
{
33,
1727881304,
},
{
91,
1727881304,
},
{
34,
1727881714,
},
{
34,
1727882226,
},
{
92,
1727882226,
},
{
34,
1727883194,
},
{
92,
1727883194,
},
{
439,
1727883194,
},
{
537,
1727883194,
},
{
619,
1727883194,
},
},
["Запутывание"] = {
{
42,
1727103485,
},
{
100,
1727103485,
},
{
424,
1727103485,
},
{
42,
1727104149,
},
{
41,
1727104418,
},
{
41,
1727104743,
},
{
42,
1727105692,
},
{
100,
1727105692,
},
{
408,
1727105692,
},
{
41,
1727881304,
},
{
42,
1727882226,
},
{
41,
1727883194,
},
{
99,
1727883194,
},
{
447,
1727883194,
},
{
545,
1727883194,
},
},
["Укрепление панциря"] = {
{
14,
1726856654,
},
{
68,
1726856654,
},
{
14,
1726857059,
},
{
68,
1726857059,
},
{
15,
1727103485,
},
{
69,
1727103485,
},
{
201,
1727103485,
},
{
255,
1727103485,
},
{
15,
1727104149,
},
{
69,
1727104149,
},
{
195,
1727104149,
},
{
249,
1727104149,
},
{
14,
1727104418,
},
{
68,
1727104418,
},
{
15,
1727104743,
},
{
69,
1727104743,
},
{
15,
1727105692,
},
{
69,
1727105692,
},
{
198,
1727105692,
},
{
252,
1727105692,
},
{
15,
1727881304,
},
{
69,
1727881304,
},
{
15,
1727881714,
},
{
69,
1727881714,
},
{
15,
1727882226,
},
{
69,
1727882226,
},
{
15,
1727883194,
},
{
69,
1727883194,
},
{
203,
1727883194,
},
{
257,
1727883194,
},
},
["Раскол мироздания"] = {
{
129,
1727103485,
},
{
129,
1727104149,
},
{
128,
1727104418,
},
{
129,
1727104743,
},
{
129,
1727105692,
},
{
129,
1727881304,
},
{
129,
1727882226,
},
{
129,
1727883194,
},
},
["Проникающий удар"] = {
{
11,
1726856654,
},
{
31,
1726856654,
},
{
58,
1726856654,
},
{
11,
1726857059,
},
{
31,
1726857059,
},
{
58,
1726857059,
},
{
79,
1726857059,
},
{
11,
1727103485,
},
{
31,
1727103485,
},
{
58,
1727103485,
},
{
79,
1727103485,
},
{
117,
1727103485,
},
{
197,
1727103485,
},
{
217,
1727103485,
},
{
237,
1727103485,
},
{
257,
1727103485,
},
{
277,
1727103485,
},
{
297,
1727103485,
},
{
393,
1727103485,
},
{
441,
1727103485,
},
{
461,
1727103485,
},
{
484,
1727103485,
},
{
504,
1727103485,
},
{
12,
1727104149,
},
{
32,
1727104149,
},
{
59,
1727104149,
},
{
80,
1727104149,
},
{
118,
1727104149,
},
{
191,
1727104149,
},
{
211,
1727104149,
},
{
231,
1727104149,
},
{
251,
1727104149,
},
{
271,
1727104149,
},
{
291,
1727104149,
},
{
378,
1727104149,
},
{
426,
1727104149,
},
{
11,
1727104418,
},
{
31,
1727104418,
},
{
58,
1727104418,
},
{
79,
1727104418,
},
{
117,
1727104418,
},
{
11,
1727104743,
},
{
31,
1727104743,
},
{
58,
1727104743,
},
{
79,
1727104743,
},
{
117,
1727104743,
},
{
12,
1727105692,
},
{
32,
1727105692,
},
{
59,
1727105692,
},
{
80,
1727105692,
},
{
118,
1727105692,
},
{
195,
1727105692,
},
{
215,
1727105692,
},
{
235,
1727105692,
},
{
255,
1727105692,
},
{
275,
1727105692,
},
{
295,
1727105692,
},
{
377,
1727105692,
},
{
425,
1727105692,
},
{
445,
1727105692,
},
{
468,
1727105692,
},
{
488,
1727105692,
},
{
11,
1727881304,
},
{
31,
1727881304,
},
{
58,
1727881304,
},
{
79,
1727881304,
},
{
117,
1727881304,
},
{
12,
1727881714,
},
{
32,
1727881714,
},
{
59,
1727881714,
},
{
11,
1727882226,
},
{
31,
1727882226,
},
{
58,
1727882226,
},
{
79,
1727882226,
},
{
117,
1727882226,
},
{
11,
1727883194,
},
{
31,
1727883194,
},
{
58,
1727883194,
},
{
79,
1727883194,
},
{
117,
1727883194,
},
{
200,
1727883194,
},
{
220,
1727883194,
},
{
240,
1727883194,
},
{
260,
1727883194,
},
{
280,
1727883194,
},
{
300,
1727883194,
},
{
416,
1727883194,
},
{
464,
1727883194,
},
{
484,
1727883194,
},
{
507,
1727883194,
},
{
527,
1727883194,
},
{
562,
1727883194,
},
{
596,
1727883194,
},
},
["Жалящий рой"] = {
{
209,
1727103485,
},
{
267,
1727103485,
},
{
454,
1727103485,
},
{
511,
1727103485,
},
{
203,
1727104149,
},
{
261,
1727104149,
},
{
440,
1727104149,
},
{
206,
1727105692,
},
{
264,
1727105692,
},
{
438,
1727105692,
},
{
211,
1727883194,
},
{
269,
1727883194,
},
{
477,
1727883194,
},
{
534,
1727883194,
},
},
["Ядовитый дождь"] = {
{
7,
1726856654,
},
{
45,
1726856654,
},
{
7,
1726857059,
},
{
45,
1726857059,
},
{
81,
1726857059,
},
{
8,
1727103485,
},
{
45,
1727103485,
},
{
83,
1727103485,
},
{
119,
1727103485,
},
{
8,
1727104149,
},
{
46,
1727104149,
},
{
82,
1727104149,
},
{
120,
1727104149,
},
{
7,
1727104418,
},
{
45,
1727104418,
},
{
83,
1727104418,
},
{
119,
1727104418,
},
{
7,
1727104743,
},
{
45,
1727104743,
},
{
83,
1727104743,
},
{
119,
1727104743,
},
{
8,
1727105692,
},
{
46,
1727105692,
},
{
82,
1727105692,
},
{
120,
1727105692,
},
{
7,
1727881304,
},
{
45,
1727881304,
},
{
83,
1727881304,
},
{
119,
1727881304,
},
{
8,
1727881714,
},
{
46,
1727881714,
},
{
8,
1727882226,
},
{
46,
1727882226,
},
{
83,
1727882226,
},
{
119,
1727882226,
},
{
7,
1727883194,
},
{
45,
1727883194,
},
{
83,
1727883194,
},
{
119,
1727883194,
},
},
["Энтропия катаклизма"] = {
{
476,
1727103485,
},
},
["Шаг через Бездну"] = {
{
127,
1727103485,
},
{
217,
1727103485,
},
{
251,
1727103485,
},
{
277,
1727103485,
},
{
306,
1727103485,
},
{
423,
1727103485,
},
{
462,
1727103485,
},
{
491,
1727103485,
},
{
520,
1727103485,
},
{
127,
1727104149,
},
{
211,
1727104149,
},
{
245,
1727104149,
},
{
270,
1727104149,
},
{
299,
1727104149,
},
{
409,
1727104149,
},
{
126,
1727104418,
},
{
127,
1727104743,
},
{
127,
1727105692,
},
{
214,
1727105692,
},
{
249,
1727105692,
},
{
274,
1727105692,
},
{
303,
1727105692,
},
{
407,
1727105692,
},
{
446,
1727105692,
},
{
475,
1727105692,
},
{
127,
1727881304,
},
{
127,
1727882226,
},
{
127,
1727883194,
},
{
221,
1727883194,
},
{
255,
1727883194,
},
{
279,
1727883194,
},
{
308,
1727883194,
},
{
445,
1727883194,
},
{
484,
1727883194,
},
{
515,
1727883194,
},
{
544,
1727883194,
},
{
546,
1727883194,
},
},
["Ядовитый заряд"] = {
{
1,
1726856654,
},
{
2,
1726856654,
},
{
4,
1726856654,
},
{
5,
1726856654,
},
{
9,
1726856654,
},
{
11,
1726856654,
},
{
12,
1726856654,
},
{
14,
1726856654,
},
{
15,
1726856654,
},
{
19,
1726856654,
},
{
20,
1726856654,
},
{
22,
1726856654,
},
{
23,
1726856654,
},
{
25,
1726856654,
},
{
26,
1726856654,
},
{
28,
1726856654,
},
{
29,
1726856654,
},
{
31,
1726856654,
},
{
32,
1726856654,
},
{
34,
1726856654,
},
{
35,
1726856654,
},
{
37,
1726856654,
},
{
38,
1726856654,
},
{
43,
1726856654,
},
{
47,
1726856654,
},
{
49,
1726856654,
},
{
50,
1726856654,
},
{
52,
1726856654,
},
{
53,
1726856654,
},
{
56,
1726856654,
},
{
58,
1726856654,
},
{
59,
1726856654,
},
{
64,
1726856654,
},
{
68,
1726856654,
},
{
2,
1726857059,
},
{
4,
1726857059,
},
{
5,
1726857059,
},
{
9,
1726857059,
},
{
11,
1726857059,
},
{
12,
1726857059,
},
{
14,
1726857059,
},
{
15,
1726857059,
},
{
19,
1726857059,
},
{
20,
1726857059,
},
{
22,
1726857059,
},
{
23,
1726857059,
},
{
25,
1726857059,
},
{
26,
1726857059,
},
{
28,
1726857059,
},
{
29,
1726857059,
},
{
31,
1726857059,
},
{
32,
1726857059,
},
{
34,
1726857059,
},
{
35,
1726857059,
},
{
37,
1726857059,
},
{
38,
1726857059,
},
{
43,
1726857059,
},
{
47,
1726857059,
},
{
49,
1726857059,
},
{
50,
1726857059,
},
{
52,
1726857059,
},
{
53,
1726857059,
},
{
55,
1726857059,
},
{
56,
1726857059,
},
{
58,
1726857059,
},
{
59,
1726857059,
},
{
61,
1726857059,
},
{
63,
1726857059,
},
{
64,
1726857059,
},
{
66,
1726857059,
},
{
67,
1726857059,
},
{
69,
1726857059,
},
{
70,
1726857059,
},
{
72,
1726857059,
},
{
75,
1726857059,
},
{
76,
1726857059,
},
{
78,
1726857059,
},
{
79,
1726857059,
},
{
83,
1726857059,
},
{
85,
1726857059,
},
{
86,
1726857059,
},
{
92,
1726857059,
},
{
3,
1727103485,
},
{
4,
1727103485,
},
{
6,
1727103485,
},
{
10,
1727103485,
},
{
12,
1727103485,
},
{
13,
1727103485,
},
{
15,
1727103485,
},
{
16,
1727103485,
},
{
19,
1727103485,
},
{
21,
1727103485,
},
{
22,
1727103485,
},
{
24,
1727103485,
},
{
25,
1727103485,
},
{
27,
1727103485,
},
{
28,
1727103485,
},
{
30,
1727103485,
},
{
31,
1727103485,
},
{
33,
1727103485,
},
{
35,
1727103485,
},
{
36,
1727103485,
},
{
38,
1727103485,
},
{
39,
1727103485,
},
{
44,
1727103485,
},
{
48,
1727103485,
},
{
49,
1727103485,
},
{
51,
1727103485,
},
{
52,
1727103485,
},
{
54,
1727103485,
},
{
55,
1727103485,
},
{
57,
1727103485,
},
{
58,
1727103485,
},
{
60,
1727103485,
},
{
62,
1727103485,
},
{
63,
1727103485,
},
{
65,
1727103485,
},
{
66,
1727103485,
},
{
68,
1727103485,
},
{
69,
1727103485,
},
{
71,
1727103485,
},
{
72,
1727103485,
},
{
75,
1727103485,
},
{
77,
1727103485,
},
{
78,
1727103485,
},
{
80,
1727103485,
},
{
81,
1727103485,
},
{
85,
1727103485,
},
{
87,
1727103485,
},
{
88,
1727103485,
},
{
90,
1727103485,
},
{
91,
1727103485,
},
{
93,
1727103485,
},
{
94,
1727103485,
},
{
96,
1727103485,
},
{
98,
1727103485,
},
{
102,
1727103485,
},
{
104,
1727103485,
},
{
106,
1727103485,
},
{
107,
1727103485,
},
{
109,
1727103485,
},
{
110,
1727103485,
},
{
112,
1727103485,
},
{
113,
1727103485,
},
{
115,
1727103485,
},
{
116,
1727103485,
},
{
118,
1727103485,
},
{
3,
1727104149,
},
{
5,
1727104149,
},
{
6,
1727104149,
},
{
10,
1727104149,
},
{
12,
1727104149,
},
{
13,
1727104149,
},
{
15,
1727104149,
},
{
16,
1727104149,
},
{
19,
1727104149,
},
{
21,
1727104149,
},
{
22,
1727104149,
},
{
24,
1727104149,
},
{
25,
1727104149,
},
{
27,
1727104149,
},
{
28,
1727104149,
},
{
30,
1727104149,
},
{
32,
1727104149,
},
{
33,
1727104149,
},
{
35,
1727104149,
},
{
36,
1727104149,
},
{
38,
1727104149,
},
{
39,
1727104149,
},
{
44,
1727104149,
},
{
48,
1727104149,
},
{
50,
1727104149,
},
{
51,
1727104149,
},
{
53,
1727104149,
},
{
54,
1727104149,
},
{
56,
1727104149,
},
{
57,
1727104149,
},
{
59,
1727104149,
},
{
60,
1727104149,
},
{
62,
1727104149,
},
{
64,
1727104149,
},
{
65,
1727104149,
},
{
67,
1727104149,
},
{
68,
1727104149,
},
{
70,
1727104149,
},
{
71,
1727104149,
},
{
73,
1727104149,
},
{
76,
1727104149,
},
{
77,
1727104149,
},
{
79,
1727104149,
},
{
80,
1727104149,
},
{
84,
1727104149,
},
{
86,
1727104149,
},
{
87,
1727104149,
},
{
89,
1727104149,
},
{
90,
1727104149,
},
{
92,
1727104149,
},
{
93,
1727104149,
},
{
95,
1727104149,
},
{
96,
1727104149,
},
{
98,
1727104149,
},
{
103,
1727104149,
},
{
104,
1727104149,
},
{
106,
1727104149,
},
{
107,
1727104149,
},
{
109,
1727104149,
},
{
111,
1727104149,
},
{
112,
1727104149,
},
{
114,
1727104149,
},
{
115,
1727104149,
},
{
117,
1727104149,
},
{
118,
1727104149,
},
{
2,
1727104418,
},
{
4,
1727104418,
},
{
5,
1727104418,
},
{
9,
1727104418,
},
{
11,
1727104418,
},
{
13,
1727104418,
},
{
14,
1727104418,
},
{
16,
1727104418,
},
{
19,
1727104418,
},
{
20,
1727104418,
},
{
22,
1727104418,
},
{
23,
1727104418,
},
{
25,
1727104418,
},
{
26,
1727104418,
},
{
28,
1727104418,
},
{
29,
1727104418,
},
{
31,
1727104418,
},
{
32,
1727104418,
},
{
34,
1727104418,
},
{
36,
1727104418,
},
{
37,
1727104418,
},
{
39,
1727104418,
},
{
43,
1727104418,
},
{
47,
1727104418,
},
{
49,
1727104418,
},
{
51,
1727104418,
},
{
52,
1727104418,
},
{
54,
1727104418,
},
{
55,
1727104418,
},
{
57,
1727104418,
},
{
58,
1727104418,
},
{
60,
1727104418,
},
{
61,
1727104418,
},
{
63,
1727104418,
},
{
64,
1727104418,
},
{
66,
1727104418,
},
{
67,
1727104418,
},
{
69,
1727104418,
},
{
70,
1727104418,
},
{
72,
1727104418,
},
{
75,
1727104418,
},
{
76,
1727104418,
},
{
78,
1727104418,
},
{
79,
1727104418,
},
{
81,
1727104418,
},
{
85,
1727104418,
},
{
86,
1727104418,
},
{
88,
1727104418,
},
{
89,
1727104418,
},
{
91,
1727104418,
},
{
93,
1727104418,
},
{
94,
1727104418,
},
{
96,
1727104418,
},
{
97,
1727104418,
},
{
102,
1727104418,
},
{
104,
1727104418,
},
{
105,
1727104418,
},
{
107,
1727104418,
},
{
111,
1727104418,
},
{
113,
1727104418,
},
{
114,
1727104418,
},
{
3,
1727104743,
},
{
4,
1727104743,
},
{
6,
1727104743,
},
{
10,
1727104743,
},
{
11,
1727104743,
},
{
13,
1727104743,
},
{
14,
1727104743,
},
{
16,
1727104743,
},
{
19,
1727104743,
},
{
20,
1727104743,
},
{
22,
1727104743,
},
{
23,
1727104743,
},
{
25,
1727104743,
},
{
26,
1727104743,
},
{
28,
1727104743,
},
{
29,
1727104743,
},
{
31,
1727104743,
},
{
33,
1727104743,
},
{
34,
1727104743,
},
{
36,
1727104743,
},
{
37,
1727104743,
},
{
39,
1727104743,
},
{
44,
1727104743,
},
{
48,
1727104743,
},
{
49,
1727104743,
},
{
51,
1727104743,
},
{
52,
1727104743,
},
{
54,
1727104743,
},
{
55,
1727104743,
},
{
57,
1727104743,
},
{
58,
1727104743,
},
{
60,
1727104743,
},
{
61,
1727104743,
},
{
63,
1727104743,
},
{
64,
1727104743,
},
{
66,
1727104743,
},
{
68,
1727104743,
},
{
69,
1727104743,
},
{
71,
1727104743,
},
{
72,
1727104743,
},
{
75,
1727104743,
},
{
77,
1727104743,
},
{
78,
1727104743,
},
{
80,
1727104743,
},
{
81,
1727104743,
},
{
85,
1727104743,
},
{
87,
1727104743,
},
{
88,
1727104743,
},
{
90,
1727104743,
},
{
91,
1727104743,
},
{
93,
1727104743,
},
{
94,
1727104743,
},
{
96,
1727104743,
},
{
97,
1727104743,
},
{
102,
1727104743,
},
{
104,
1727104743,
},
{
108,
1727104743,
},
{
110,
1727104743,
},
{
111,
1727104743,
},
{
113,
1727104743,
},
{
114,
1727104743,
},
{
116,
1727104743,
},
{
117,
1727104743,
},
{
3,
1727105692,
},
{
5,
1727105692,
},
{
6,
1727105692,
},
{
10,
1727105692,
},
{
12,
1727105692,
},
{
13,
1727105692,
},
{
15,
1727105692,
},
{
16,
1727105692,
},
{
19,
1727105692,
},
{
21,
1727105692,
},
{
22,
1727105692,
},
{
24,
1727105692,
},
{
25,
1727105692,
},
{
27,
1727105692,
},
{
28,
1727105692,
},
{
30,
1727105692,
},
{
31,
1727105692,
},
{
33,
1727105692,
},
{
34,
1727105692,
},
{
36,
1727105692,
},
{
38,
1727105692,
},
{
39,
1727105692,
},
{
44,
1727105692,
},
{
48,
1727105692,
},
{
50,
1727105692,
},
{
51,
1727105692,
},
{
53,
1727105692,
},
{
54,
1727105692,
},
{
56,
1727105692,
},
{
57,
1727105692,
},
{
59,
1727105692,
},
{
60,
1727105692,
},
{
62,
1727105692,
},
{
63,
1727105692,
},
{
65,
1727105692,
},
{
66,
1727105692,
},
{
68,
1727105692,
},
{
70,
1727105692,
},
{
71,
1727105692,
},
{
73,
1727105692,
},
{
76,
1727105692,
},
{
77,
1727105692,
},
{
79,
1727105692,
},
{
80,
1727105692,
},
{
84,
1727105692,
},
{
86,
1727105692,
},
{
87,
1727105692,
},
{
89,
1727105692,
},
{
90,
1727105692,
},
{
92,
1727105692,
},
{
93,
1727105692,
},
{
95,
1727105692,
},
{
96,
1727105692,
},
{
98,
1727105692,
},
{
103,
1727105692,
},
{
104,
1727105692,
},
{
106,
1727105692,
},
{
107,
1727105692,
},
{
109,
1727105692,
},
{
110,
1727105692,
},
{
112,
1727105692,
},
{
113,
1727105692,
},
{
115,
1727105692,
},
{
116,
1727105692,
},
{
118,
1727105692,
},
{
3,
1727881304,
},
{
4,
1727881304,
},
{
6,
1727881304,
},
{
10,
1727881304,
},
{
11,
1727881304,
},
{
13,
1727881304,
},
{
14,
1727881304,
},
{
16,
1727881304,
},
{
19,
1727881304,
},
{
20,
1727881304,
},
{
22,
1727881304,
},
{
23,
1727881304,
},
{
25,
1727881304,
},
{
26,
1727881304,
},
{
28,
1727881304,
},
{
30,
1727881304,
},
{
31,
1727881304,
},
{
33,
1727881304,
},
{
34,
1727881304,
},
{
36,
1727881304,
},
{
37,
1727881304,
},
{
39,
1727881304,
},
{
42,
1727881304,
},
{
44,
1727881304,
},
{
48,
1727881304,
},
{
49,
1727881304,
},
{
51,
1727881304,
},
{
52,
1727881304,
},
{
54,
1727881304,
},
{
55,
1727881304,
},
{
57,
1727881304,
},
{
58,
1727881304,
},
{
60,
1727881304,
},
{
61,
1727881304,
},
{
63,
1727881304,
},
{
65,
1727881304,
},
{
66,
1727881304,
},
{
68,
1727881304,
},
{
69,
1727881304,
},
{
71,
1727881304,
},
{
72,
1727881304,
},
{
75,
1727881304,
},
{
77,
1727881304,
},
{
78,
1727881304,
},
{
80,
1727881304,
},
{
81,
1727881304,
},
{
85,
1727881304,
},
{
87,
1727881304,
},
{
88,
1727881304,
},
{
90,
1727881304,
},
{
91,
1727881304,
},
{
93,
1727881304,
},
{
94,
1727881304,
},
{
96,
1727881304,
},
{
97,
1727881304,
},
{
102,
1727881304,
},
{
104,
1727881304,
},
{
105,
1727881304,
},
{
107,
1727881304,
},
{
108,
1727881304,
},
{
110,
1727881304,
},
{
111,
1727881304,
},
{
113,
1727881304,
},
{
114,
1727881304,
},
{
116,
1727881304,
},
{
118,
1727881304,
},
{
3,
1727881714,
},
{
5,
1727881714,
},
{
6,
1727881714,
},
{
10,
1727881714,
},
{
12,
1727881714,
},
{
13,
1727881714,
},
{
15,
1727881714,
},
{
16,
1727881714,
},
{
19,
1727881714,
},
{
21,
1727881714,
},
{
23,
1727881714,
},
{
24,
1727881714,
},
{
26,
1727881714,
},
{
27,
1727881714,
},
{
29,
1727881714,
},
{
30,
1727881714,
},
{
32,
1727881714,
},
{
33,
1727881714,
},
{
35,
1727881714,
},
{
36,
1727881714,
},
{
38,
1727881714,
},
{
39,
1727881714,
},
{
44,
1727881714,
},
{
48,
1727881714,
},
{
51,
1727881714,
},
{
53,
1727881714,
},
{
54,
1727881714,
},
{
56,
1727881714,
},
{
57,
1727881714,
},
{
59,
1727881714,
},
{
60,
1727881714,
},
{
63,
1727881714,
},
{
65,
1727881714,
},
{
69,
1727881714,
},
{
71,
1727881714,
},
{
72,
1727881714,
},
{
3,
1727882226,
},
{
5,
1727882226,
},
{
6,
1727882226,
},
{
10,
1727882226,
},
{
12,
1727882226,
},
{
13,
1727882226,
},
{
15,
1727882226,
},
{
16,
1727882226,
},
{
19,
1727882226,
},
{
21,
1727882226,
},
{
22,
1727882226,
},
{
24,
1727882226,
},
{
25,
1727882226,
},
{
27,
1727882226,
},
{
28,
1727882226,
},
{
30,
1727882226,
},
{
31,
1727882226,
},
{
33,
1727882226,
},
{
34,
1727882226,
},
{
36,
1727882226,
},
{
38,
1727882226,
},
{
39,
1727882226,
},
{
44,
1727882226,
},
{
48,
1727882226,
},
{
50,
1727882226,
},
{
51,
1727882226,
},
{
53,
1727882226,
},
{
54,
1727882226,
},
{
56,
1727882226,
},
{
57,
1727882226,
},
{
59,
1727882226,
},
{
60,
1727882226,
},
{
62,
1727882226,
},
{
63,
1727882226,
},
{
65,
1727882226,
},
{
66,
1727882226,
},
{
68,
1727882226,
},
{
69,
1727882226,
},
{
71,
1727882226,
},
{
72,
1727882226,
},
{
76,
1727882226,
},
{
77,
1727882226,
},
{
79,
1727882226,
},
{
80,
1727882226,
},
{
82,
1727882226,
},
{
85,
1727882226,
},
{
87,
1727882226,
},
{
89,
1727882226,
},
{
90,
1727882226,
},
{
92,
1727882226,
},
{
93,
1727882226,
},
{
95,
1727882226,
},
{
96,
1727882226,
},
{
98,
1727882226,
},
{
103,
1727882226,
},
{
106,
1727882226,
},
{
107,
1727882226,
},
{
109,
1727882226,
},
{
110,
1727882226,
},
{
112,
1727882226,
},
{
113,
1727882226,
},
{
115,
1727882226,
},
{
116,
1727882226,
},
{
118,
1727882226,
},
{
3,
1727883194,
},
{
4,
1727883194,
},
{
6,
1727883194,
},
{
10,
1727883194,
},
{
11,
1727883194,
},
{
13,
1727883194,
},
{
15,
1727883194,
},
{
16,
1727883194,
},
{
19,
1727883194,
},
{
21,
1727883194,
},
{
22,
1727883194,
},
{
24,
1727883194,
},
{
25,
1727883194,
},
{
27,
1727883194,
},
{
28,
1727883194,
},
{
30,
1727883194,
},
{
31,
1727883194,
},
{
33,
1727883194,
},
{
34,
1727883194,
},
{
36,
1727883194,
},
{
38,
1727883194,
},
{
39,
1727883194,
},
{
44,
1727883194,
},
{
48,
1727883194,
},
{
49,
1727883194,
},
{
51,
1727883194,
},
{
52,
1727883194,
},
{
54,
1727883194,
},
{
55,
1727883194,
},
{
57,
1727883194,
},
{
59,
1727883194,
},
{
60,
1727883194,
},
{
62,
1727883194,
},
{
63,
1727883194,
},
{
65,
1727883194,
},
{
66,
1727883194,
},
{
68,
1727883194,
},
{
69,
1727883194,
},
{
71,
1727883194,
},
{
72,
1727883194,
},
{
75,
1727883194,
},
{
77,
1727883194,
},
{
79,
1727883194,
},
{
80,
1727883194,
},
{
82,
1727883194,
},
{
85,
1727883194,
},
{
87,
1727883194,
},
{
88,
1727883194,
},
{
90,
1727883194,
},
{
91,
1727883194,
},
{
93,
1727883194,
},
{
94,
1727883194,
},
{
96,
1727883194,
},
{
97,
1727883194,
},
{
102,
1727883194,
},
{
104,
1727883194,
},
{
105,
1727883194,
},
{
107,
1727883194,
},
{
108,
1727883194,
},
{
110,
1727883194,
},
{
111,
1727883194,
},
{
113,
1727883194,
},
{
114,
1727883194,
},
{
116,
1727883194,
},
{
118,
1727883194,
},
},
["Закапывание"] = {
{
129,
1727103485,
},
{
312,
1727103485,
},
{
129,
1727104149,
},
{
306,
1727104149,
},
{
128,
1727104418,
},
{
128,
1727104743,
},
{
129,
1727105692,
},
{
308,
1727105692,
},
{
128,
1727881304,
},
{
129,
1727882226,
},
{
129,
1727883194,
},
{
314,
1727883194,
},
},
["Сосредоточение скарабея"] = {
{
16,
1726856654,
},
{
17,
1726857059,
},
{
42,
1726857059,
},
{
71,
1726857059,
},
{
82,
1726857059,
},
{
87,
1726857059,
},
{
88,
1726857059,
},
{
90,
1726857059,
},
{
17,
1727103485,
},
{
18,
1727103485,
},
{
71,
1727103485,
},
{
203,
1727103485,
},
{
204,
1727103485,
},
{
258,
1727103485,
},
{
259,
1727103485,
},
{
262,
1727103485,
},
{
18,
1727104149,
},
{
71,
1727104149,
},
{
197,
1727104149,
},
{
251,
1727104149,
},
{
253,
1727104149,
},
{
254,
1727104149,
},
{
17,
1727104418,
},
{
71,
1727104418,
},
{
17,
1727104743,
},
{
18,
1727104743,
},
{
19,
1727104743,
},
{
71,
1727104743,
},
{
72,
1727104743,
},
{
18,
1727105692,
},
{
19,
1727105692,
},
{
71,
1727105692,
},
{
72,
1727105692,
},
{
201,
1727105692,
},
{
202,
1727105692,
},
{
255,
1727105692,
},
{
17,
1727881304,
},
{
25,
1727881304,
},
{
71,
1727881304,
},
{
17,
1727881714,
},
{
18,
1727881714,
},
{
20,
1727881714,
},
{
72,
1727881714,
},
{
76,
1727881714,
},
{
17,
1727882226,
},
{
33,
1727882226,
},
{
71,
1727882226,
},
{
17,
1727883194,
},
{
71,
1727883194,
},
{
206,
1727883194,
},
{
207,
1727883194,
},
{
217,
1727883194,
},
{
219,
1727883194,
},
{
259,
1727883194,
},
{
261,
1727883194,
},
{
293,
1727883194,
},
},
["Выпущенный рой"] = {
{
397,
1727103485,
},
{
472,
1727103485,
},
{
383,
1727104149,
},
{
381,
1727105692,
},
{
456,
1727105692,
},
{
420,
1727883194,
},
{
495,
1727883194,
},
{
565,
1727883194,
},
{
600,
1727883194,
},
},
["Безрассудный рывок"] = {
{
40,
1726856654,
},
{
40,
1726857059,
},
{
41,
1727103485,
},
{
99,
1727103485,
},
{
423,
1727103485,
},
{
41,
1727104149,
},
{
99,
1727104149,
},
{
409,
1727104149,
},
{
41,
1727104418,
},
{
99,
1727104418,
},
{
41,
1727104743,
},
{
99,
1727104743,
},
{
41,
1727105692,
},
{
99,
1727105692,
},
{
407,
1727105692,
},
{
41,
1727881304,
},
{
99,
1727881304,
},
{
41,
1727881714,
},
{
41,
1727882226,
},
{
99,
1727882226,
},
{
41,
1727883194,
},
{
99,
1727883194,
},
{
446,
1727883194,
},
{
544,
1727883194,
},
},
["Нити реальности"] = {
{
214,
1727103485,
},
{
249,
1727103485,
},
{
275,
1727103485,
},
{
397,
1727103485,
},
{
430,
1727103485,
},
{
452,
1727103485,
},
{
499,
1727103485,
},
{
207,
1727104149,
},
{
243,
1727104149,
},
{
269,
1727104149,
},
{
383,
1727104149,
},
{
416,
1727104149,
},
{
437,
1727104149,
},
{
211,
1727105692,
},
{
247,
1727105692,
},
{
272,
1727105692,
},
{
382,
1727105692,
},
{
415,
1727105692,
},
{
436,
1727105692,
},
{
483,
1727105692,
},
{
215,
1727883194,
},
{
253,
1727883194,
},
{
277,
1727883194,
},
{
421,
1727883194,
},
{
453,
1727883194,
},
{
476,
1727883194,
},
{
521,
1727883194,
},
{
601,
1727883194,
},
},
["Вихрь паутины"] = {
{
200,
1727103485,
},
{
255,
1727103485,
},
{
406,
1727103485,
},
{
504,
1727103485,
},
{
194,
1727104149,
},
{
249,
1727104149,
},
{
392,
1727104149,
},
{
197,
1727105692,
},
{
253,
1727105692,
},
{
391,
1727105692,
},
{
486,
1727105692,
},
{
203,
1727883194,
},
{
259,
1727883194,
},
{
430,
1727883194,
},
{
526,
1727883194,
},
{
610,
1727883194,
},
},
["Буря шипов"] = {
{
314,
1727103485,
},
{
307,
1727104149,
},
{
310,
1727105692,
},
{
316,
1727883194,
},
},
["Стрела Бездны"] = {
{
186,
1727103485,
},
{
188,
1727103485,
},
{
190,
1727103485,
},
{
192,
1727103485,
},
{
194,
1727103485,
},
{
196,
1727103485,
},
{
198,
1727103485,
},
{
208,
1727103485,
},
{
210,
1727103485,
},
{
216,
1727103485,
},
{
237,
1727103485,
},
{
239,
1727103485,
},
{
241,
1727103485,
},
{
243,
1727103485,
},
{
245,
1727103485,
},
{
263,
1727103485,
},
{
265,
1727103485,
},
{
267,
1727103485,
},
{
269,
1727103485,
},
{
271,
1727103485,
},
{
303,
1727103485,
},
{
305,
1727103485,
},
{
383,
1727103485,
},
{
385,
1727103485,
},
{
387,
1727103485,
},
{
389,
1727103485,
},
{
391,
1727103485,
},
{
393,
1727103485,
},
{
400,
1727103485,
},
{
402,
1727103485,
},
{
404,
1727103485,
},
{
414,
1727103485,
},
{
416,
1727103485,
},
{
418,
1727103485,
},
{
420,
1727103485,
},
{
422,
1727103485,
},
{
426,
1727103485,
},
{
433,
1727103485,
},
{
435,
1727103485,
},
{
437,
1727103485,
},
{
439,
1727103485,
},
{
441,
1727103485,
},
{
444,
1727103485,
},
{
446,
1727103485,
},
{
448,
1727103485,
},
{
455,
1727103485,
},
{
457,
1727103485,
},
{
459,
1727103485,
},
{
461,
1727103485,
},
{
478,
1727103485,
},
{
480,
1727103485,
},
{
482,
1727103485,
},
{
484,
1727103485,
},
{
486,
1727103485,
},
{
488,
1727103485,
},
{
490,
1727103485,
},
{
495,
1727103485,
},
{
502,
1727103485,
},
{
511,
1727103485,
},
{
513,
1727103485,
},
{
515,
1727103485,
},
{
517,
1727103485,
},
{
180,
1727104149,
},
{
182,
1727104149,
},
{
184,
1727104149,
},
{
186,
1727104149,
},
{
188,
1727104149,
},
{
190,
1727104149,
},
{
192,
1727104149,
},
{
201,
1727104149,
},
{
203,
1727104149,
},
{
210,
1727104149,
},
{
233,
1727104149,
},
{
235,
1727104149,
},
{
237,
1727104149,
},
{
239,
1727104149,
},
{
256,
1727104149,
},
{
258,
1727104149,
},
{
261,
1727104149,
},
{
263,
1727104149,
},
{
265,
1727104149,
},
{
290,
1727104149,
},
{
292,
1727104149,
},
{
294,
1727104149,
},
{
296,
1727104149,
},
{
298,
1727104149,
},
{
369,
1727104149,
},
{
371,
1727104149,
},
{
373,
1727104149,
},
{
375,
1727104149,
},
{
377,
1727104149,
},
{
379,
1727104149,
},
{
386,
1727104149,
},
{
388,
1727104149,
},
{
390,
1727104149,
},
{
399,
1727104149,
},
{
401,
1727104149,
},
{
404,
1727104149,
},
{
406,
1727104149,
},
{
408,
1727104149,
},
{
419,
1727104149,
},
{
421,
1727104149,
},
{
425,
1727104149,
},
{
427,
1727104149,
},
{
433,
1727104149,
},
{
441,
1727104149,
},
{
183,
1727105692,
},
{
185,
1727105692,
},
{
187,
1727105692,
},
{
189,
1727105692,
},
{
191,
1727105692,
},
{
193,
1727105692,
},
{
195,
1727105692,
},
{
205,
1727105692,
},
{
207,
1727105692,
},
{
213,
1727105692,
},
{
233,
1727105692,
},
{
235,
1727105692,
},
{
237,
1727105692,
},
{
239,
1727105692,
},
{
241,
1727105692,
},
{
243,
1727105692,
},
{
260,
1727105692,
},
{
262,
1727105692,
},
{
264,
1727105692,
},
{
266,
1727105692,
},
{
268,
1727105692,
},
{
296,
1727105692,
},
{
298,
1727105692,
},
{
300,
1727105692,
},
{
302,
1727105692,
},
{
368,
1727105692,
},
{
370,
1727105692,
},
{
372,
1727105692,
},
{
374,
1727105692,
},
{
376,
1727105692,
},
{
378,
1727105692,
},
{
385,
1727105692,
},
{
387,
1727105692,
},
{
389,
1727105692,
},
{
398,
1727105692,
},
{
400,
1727105692,
},
{
402,
1727105692,
},
{
404,
1727105692,
},
{
406,
1727105692,
},
{
411,
1727105692,
},
{
418,
1727105692,
},
{
420,
1727105692,
},
{
422,
1727105692,
},
{
424,
1727105692,
},
{
426,
1727105692,
},
{
428,
1727105692,
},
{
430,
1727105692,
},
{
432,
1727105692,
},
{
439,
1727105692,
},
{
441,
1727105692,
},
{
443,
1727105692,
},
{
445,
1727105692,
},
{
468,
1727105692,
},
{
470,
1727105692,
},
{
472,
1727105692,
},
{
474,
1727105692,
},
{
479,
1727105692,
},
{
188,
1727883194,
},
{
190,
1727883194,
},
{
192,
1727883194,
},
{
194,
1727883194,
},
{
197,
1727883194,
},
{
199,
1727883194,
},
{
201,
1727883194,
},
{
211,
1727883194,
},
{
218,
1727883194,
},
{
220,
1727883194,
},
{
241,
1727883194,
},
{
243,
1727883194,
},
{
245,
1727883194,
},
{
247,
1727883194,
},
{
249,
1727883194,
},
{
267,
1727883194,
},
{
269,
1727883194,
},
{
271,
1727883194,
},
{
273,
1727883194,
},
{
301,
1727883194,
},
{
303,
1727883194,
},
{
305,
1727883194,
},
{
307,
1727883194,
},
{
406,
1727883194,
},
{
408,
1727883194,
},
{
411,
1727883194,
},
{
413,
1727883194,
},
{
415,
1727883194,
},
{
417,
1727883194,
},
{
424,
1727883194,
},
{
426,
1727883194,
},
{
428,
1727883194,
},
{
438,
1727883194,
},
{
440,
1727883194,
},
{
442,
1727883194,
},
{
444,
1727883194,
},
{
449,
1727883194,
},
{
456,
1727883194,
},
{
458,
1727883194,
},
{
460,
1727883194,
},
{
462,
1727883194,
},
{
464,
1727883194,
},
{
466,
1727883194,
},
{
468,
1727883194,
},
{
470,
1727883194,
},
{
472,
1727883194,
},
{
479,
1727883194,
},
{
481,
1727883194,
},
{
483,
1727883194,
},
{
508,
1727883194,
},
{
510,
1727883194,
},
{
512,
1727883194,
},
{
514,
1727883194,
},
{
524,
1727883194,
},
{
535,
1727883194,
},
{
537,
1727883194,
},
{
539,
1727883194,
},
{
541,
1727883194,
},
{
543,
1727883194,
},
{
575,
1727883194,
},
{
577,
1727883194,
},
{
579,
1727883194,
},
{
581,
1727883194,
},
{
583,
1727883194,
},
{
585,
1727883194,
},
{
587,
1727883194,
},
{
589,
1727883194,
},
{
591,
1727883194,
},
{
593,
1727883194,
},
{
595,
1727883194,
},
{
597,
1727883194,
},
{
604,
1727883194,
},
{
606,
1727883194,
},
{
608,
1727883194,
},
{
618,
1727883194,
},
{
620,
1727883194,
},
{
622,
1727883194,
},
{
624,
1727883194,
},
},
["Путь сквозь Бездну"] = {
{
309,
1727103485,
},
{
303,
1727104149,
},
{
306,
1727105692,
},
{
312,
1727883194,
},
},
["Юркий прыжок"] = {
{
39,
1726856654,
},
{
39,
1726857059,
},
{
40,
1727103485,
},
{
99,
1727103485,
},
{
40,
1727104149,
},
{
99,
1727104149,
},
{
40,
1727104418,
},
{
98,
1727104418,
},
{
40,
1727104743,
},
{
98,
1727104743,
},
{
40,
1727105692,
},
{
99,
1727105692,
},
{
40,
1727881304,
},
{
98,
1727881304,
},
{
41,
1727881714,
},
{
40,
1727882226,
},
{
99,
1727882226,
},
{
40,
1727883194,
},
{
98,
1727883194,
},
},
["Извержение шипов"] = {
{
413,
1727103485,
},
{
444,
1727103485,
},
{
508,
1727103485,
},
{
399,
1727104149,
},
{
430,
1727104149,
},
{
397,
1727105692,
},
{
428,
1727105692,
},
{
436,
1727883194,
},
{
467,
1727883194,
},
{
531,
1727883194,
},
{
616,
1727883194,
},
},
["Паутинная бомба"] = {
{
17,
1726856654,
},
{
17,
1726857059,
},
{
73,
1726857059,
},
{
18,
1727103485,
},
{
74,
1727103485,
},
{
18,
1727104149,
},
{
74,
1727104149,
},
{
17,
1727104418,
},
{
73,
1727104418,
},
{
17,
1727104743,
},
{
74,
1727104743,
},
{
18,
1727105692,
},
{
74,
1727105692,
},
{
17,
1727881304,
},
{
74,
1727881304,
},
{
18,
1727881714,
},
{
74,
1727881714,
},
{
18,
1727882226,
},
{
74,
1727882226,
},
{
18,
1727883194,
},
{
74,
1727883194,
},
},
},
["2917-15"] = {
["Брызги крови"] = {
{
128,
1726345500,
},
{
128,
1726346455,
},
{
128,
1727532236,
},
{
128,
1727532653,
},
{
256,
1727532653,
},
{
127,
1727877031,
},
{
255,
1727877031,
},
},
["Брызгающее кровотечение"] = {
{
36,
1726344996,
},
{
36,
1726344996,
},
{
36,
1726344996,
},
{
43,
1726344996,
},
{
53,
1726344996,
},
{
54,
1726344996,
},
{
55,
1726344996,
},
{
56,
1726344996,
},
{
37,
1726345500,
},
{
37,
1726345500,
},
{
86,
1726345500,
},
{
86,
1726345500,
},
{
87,
1726345500,
},
{
95,
1726345500,
},
{
165,
1726345500,
},
{
165,
1726345500,
},
{
180,
1726345500,
},
{
37,
1726345930,
},
{
37,
1726345930,
},
{
39,
1726345930,
},
{
40,
1726345930,
},
{
42,
1726345930,
},
{
86,
1726345930,
},
{
86,
1726345930,
},
{
89,
1726345930,
},
{
91,
1726345930,
},
{
37,
1726346455,
},
{
37,
1726346455,
},
{
57,
1726346455,
},
{
86,
1726346455,
},
{
86,
1726346455,
},
{
86,
1726346455,
},
{
165,
1726346455,
},
{
165,
1726346455,
},
{
165,
1726346455,
},
{
173,
1726346455,
},
{
179,
1726346455,
},
{
37,
1726833220,
},
{
37,
1726833220,
},
{
47,
1726833220,
},
{
48,
1726833220,
},
{
86,
1726833220,
},
{
86,
1726833220,
},
{
86,
1726833220,
},
{
89,
1726833220,
},
{
91,
1726833220,
},
{
94,
1726833220,
},
{
97,
1726833220,
},
{
101,
1726833220,
},
{
104,
1726833220,
},
{
37,
1727532236,
},
{
37,
1727532236,
},
{
86,
1727532236,
},
{
86,
1727532236,
},
{
92,
1727532236,
},
{
93,
1727532236,
},
{
105,
1727532236,
},
{
37,
1727532653,
},
{
37,
1727532653,
},
{
37,
1727532653,
},
{
86,
1727532653,
},
{
86,
1727532653,
},
{
165,
1727532653,
},
{
165,
1727532653,
},
{
214,
1727532653,
},
{
214,
1727532653,
},
{
235,
1727532653,
},
{
36,
1727877031,
},
{
36,
1727877031,
},
{
85,
1727877031,
},
{
85,
1727877031,
},
{
85,
1727877031,
},
{
164,
1727877031,
},
{
164,
1727877031,
},
{
213,
1727877031,
},
{
213,
1727877031,
},
},
["Призрачный удар"] = {
{
36,
1726344996,
},
{
52,
1726344996,
},
{
33,
1726345500,
},
{
84,
1726345500,
},
{
99,
1726345500,
},
{
33,
1726345930,
},
{
32,
1726346455,
},
{
84,
1726346455,
},
{
98,
1726346455,
},
{
32,
1726833220,
},
{
85,
1726833220,
},
{
105,
1726833220,
},
{
31,
1727532236,
},
{
48,
1727532236,
},
{
89,
1727532236,
},
{
104,
1727532236,
},
{
33,
1727532653,
},
{
83,
1727532653,
},
{
161,
1727532653,
},
{
212,
1727532653,
},
{
31,
1727877031,
},
{
82,
1727877031,
},
{
163,
1727877031,
},
{
209,
1727877031,
},
{
226,
1727877031,
},
},
["Багровый дождь"] = {
{
10,
1726344996,
},
{
11,
1726345500,
},
{
139,
1726345500,
},
{
11,
1726345930,
},
{
11,
1726346455,
},
{
139,
1726346455,
},
{
11,
1726833220,
},
{
11,
1727532236,
},
{
139,
1727532236,
},
{
11,
1727532653,
},
{
139,
1727532653,
},
{
10,
1727877031,
},
{
138,
1727877031,
},
{
266,
1727877031,
},
},
["Внушение ужаса"] = {
{
4,
1726344996,
},
{
55,
1726344996,
},
{
5,
1726345500,
},
{
56,
1726345500,
},
{
133,
1726345500,
},
{
5,
1726345930,
},
{
56,
1726345930,
},
{
5,
1726346455,
},
{
56,
1726346455,
},
{
133,
1726346455,
},
{
5,
1726833220,
},
{
56,
1726833220,
},
{
5,
1727532236,
},
{
56,
1727532236,
},
{
133,
1727532236,
},
{
5,
1727532653,
},
{
56,
1727532653,
},
{
133,
1727532653,
},
{
184,
1727532653,
},
{
261,
1727532653,
},
{
4,
1727877031,
},
{
55,
1727877031,
},
{
132,
1727877031,
},
{
183,
1727877031,
},
{
260,
1727877031,
},
},
["Черный сепсис"] = {
{
115,
1726345930,
},
{
116,
1726833220,
},
{
141,
1727532236,
},
},
["Отвратительная отрыжка"] = {
{
20,
1726344996,
},
{
71,
1726344996,
},
{
21,
1726345500,
},
{
72,
1726345500,
},
{
149,
1726345500,
},
{
21,
1726345930,
},
{
72,
1726345930,
},
{
21,
1726346455,
},
{
72,
1726346455,
},
{
149,
1726346455,
},
{
21,
1726833220,
},
{
72,
1726833220,
},
{
21,
1727532236,
},
{
72,
1727532236,
},
{
21,
1727532653,
},
{
72,
1727532653,
},
{
149,
1727532653,
},
{
200,
1727532653,
},
{
20,
1727877031,
},
{
71,
1727877031,
},
{
148,
1727877031,
},
{
199,
1727877031,
},
{
276,
1727877031,
},
},
["Черный бастион"] = {
{
26,
1726344996,
},
{
64,
1726344996,
},
{
77,
1726344996,
},
{
155,
1726345500,
},
{
180,
1726345500,
},
{
78,
1726345930,
},
{
103,
1726345930,
},
{
154,
1726346455,
},
{
77,
1726833220,
},
{
116,
1726833220,
},
{
77,
1727532236,
},
{
115,
1727532236,
},
{
139,
1727532236,
},
{
239,
1727877031,
},
{
263,
1727877031,
},
{
282,
1727877031,
},
},
["Воплощение ужаса"] = {
{
28,
1726344996,
},
{
32,
1726344996,
},
{
37,
1726344996,
},
{
42,
1726344996,
},
{
46,
1726344996,
},
{
51,
1726344996,
},
{
55,
1726344996,
},
{
60,
1726344996,
},
{
65,
1726344996,
},
{
69,
1726344996,
},
{
74,
1726344996,
},
{
78,
1726344996,
},
{
79,
1726344996,
},
{
83,
1726344996,
},
{
28,
1726345500,
},
{
32,
1726345500,
},
{
37,
1726345500,
},
{
42,
1726345500,
},
{
46,
1726345500,
},
{
51,
1726345500,
},
{
55,
1726345500,
},
{
79,
1726345500,
},
{
83,
1726345500,
},
{
88,
1726345500,
},
{
93,
1726345500,
},
{
97,
1726345500,
},
{
102,
1726345500,
},
{
106,
1726345500,
},
{
111,
1726345500,
},
{
116,
1726345500,
},
{
120,
1726345500,
},
{
125,
1726345500,
},
{
129,
1726345500,
},
{
134,
1726345500,
},
{
139,
1726345500,
},
{
143,
1726345500,
},
{
148,
1726345500,
},
{
152,
1726345500,
},
{
157,
1726345500,
},
{
161,
1726345500,
},
{
162,
1726345500,
},
{
166,
1726345500,
},
{
170,
1726345500,
},
{
171,
1726345500,
},
{
175,
1726345500,
},
{
180,
1726345500,
},
{
28,
1726345930,
},
{
32,
1726345930,
},
{
37,
1726345930,
},
{
79,
1726345930,
},
{
83,
1726345930,
},
{
88,
1726345930,
},
{
93,
1726345930,
},
{
97,
1726345930,
},
{
102,
1726345930,
},
{
106,
1726345930,
},
{
111,
1726345930,
},
{
116,
1726345930,
},
{
29,
1726346455,
},
{
34,
1726346455,
},
{
39,
1726346455,
},
{
80,
1726346455,
},
{
85,
1726346455,
},
{
90,
1726346455,
},
{
95,
1726346455,
},
{
100,
1726346455,
},
{
105,
1726346455,
},
{
110,
1726346455,
},
{
115,
1726346455,
},
{
119,
1726346455,
},
{
124,
1726346455,
},
{
129,
1726346455,
},
{
134,
1726346455,
},
{
139,
1726346455,
},
{
144,
1726346455,
},
{
149,
1726346455,
},
{
154,
1726346455,
},
{
156,
1726346455,
},
{
159,
1726346455,
},
{
161,
1726346455,
},
{
164,
1726346455,
},
{
166,
1726346455,
},
{
169,
1726346455,
},
{
171,
1726346455,
},
{
174,
1726346455,
},
{
176,
1726346455,
},
{
28,
1726833220,
},
{
33,
1726833220,
},
{
38,
1726833220,
},
{
42,
1726833220,
},
{
47,
1726833220,
},
{
51,
1726833220,
},
{
56,
1726833220,
},
{
60,
1726833220,
},
{
65,
1726833220,
},
{
69,
1726833220,
},
{
74,
1726833220,
},
{
78,
1726833220,
},
{
83,
1726833220,
},
{
87,
1726833220,
},
{
88,
1726833220,
},
{
92,
1726833220,
},
{
96,
1726833220,
},
{
101,
1726833220,
},
{
106,
1726833220,
},
{
110,
1726833220,
},
{
115,
1726833220,
},
{
119,
1726833220,
},
{
124,
1726833220,
},
{
27,
1727532236,
},
{
31,
1727532236,
},
{
36,
1727532236,
},
{
40,
1727532236,
},
{
44,
1727532236,
},
{
48,
1727532236,
},
{
52,
1727532236,
},
{
57,
1727532236,
},
{
61,
1727532236,
},
{
65,
1727532236,
},
{
69,
1727532236,
},
{
73,
1727532236,
},
{
77,
1727532236,
},
{
78,
1727532236,
},
{
82,
1727532236,
},
{
86,
1727532236,
},
{
87,
1727532236,
},
{
91,
1727532236,
},
{
95,
1727532236,
},
{
99,
1727532236,
},
{
103,
1727532236,
},
{
108,
1727532236,
},
{
112,
1727532236,
},
{
116,
1727532236,
},
{
120,
1727532236,
},
{
124,
1727532236,
},
{
129,
1727532236,
},
{
133,
1727532236,
},
{
137,
1727532236,
},
{
141,
1727532236,
},
{
28,
1727532653,
},
{
32,
1727532653,
},
{
37,
1727532653,
},
{
79,
1727532653,
},
{
84,
1727532653,
},
{
88,
1727532653,
},
{
156,
1727532653,
},
{
160,
1727532653,
},
{
165,
1727532653,
},
{
169,
1727532653,
},
{
173,
1727532653,
},
{
207,
1727532653,
},
{
211,
1727532653,
},
{
216,
1727532653,
},
{
220,
1727532653,
},
{
224,
1727532653,
},
{
229,
1727532653,
},
{
233,
1727532653,
},
{
28,
1727877031,
},
{
32,
1727877031,
},
{
79,
1727877031,
},
{
83,
1727877031,
},
{
155,
1727877031,
},
{
160,
1727877031,
},
{
164,
1727877031,
},
{
169,
1727877031,
},
{
206,
1727877031,
},
{
211,
1727877031,
},
{
215,
1727877031,
},
{
220,
1727877031,
},
{
225,
1727877031,
},
{
229,
1727877031,
},
{
234,
1727877031,
},
{
238,
1727877031,
},
{
243,
1727877031,
},
{
248,
1727877031,
},
{
252,
1727877031,
},
{
257,
1727877031,
},
{
261,
1727877031,
},
{
266,
1727877031,
},
{
271,
1727877031,
},
{
275,
1727877031,
},
{
280,
1727877031,
},
},
["Потусторонняя хватка"] = {
{
21,
1726344996,
},
{
49,
1726344996,
},
{
77,
1726344996,
},
{
22,
1726345500,
},
{
50,
1726345500,
},
{
78,
1726345500,
},
{
106,
1726345500,
},
{
150,
1726345500,
},
{
178,
1726345500,
},
{
22,
1726345930,
},
{
50,
1726345930,
},
{
78,
1726345930,
},
{
106,
1726345930,
},
{
22,
1726346455,
},
{
50,
1726346455,
},
{
78,
1726346455,
},
{
106,
1726346455,
},
{
150,
1726346455,
},
{
178,
1726346455,
},
{
22,
1726833220,
},
{
50,
1726833220,
},
{
78,
1726833220,
},
{
106,
1726833220,
},
{
22,
1727532236,
},
{
50,
1727532236,
},
{
78,
1727532236,
},
{
106,
1727532236,
},
{
22,
1727532653,
},
{
50,
1727532653,
},
{
78,
1727532653,
},
{
106,
1727532653,
},
{
150,
1727532653,
},
{
178,
1727532653,
},
{
206,
1727532653,
},
{
234,
1727532653,
},
{
21,
1727877031,
},
{
49,
1727877031,
},
{
77,
1727877031,
},
{
105,
1727877031,
},
{
149,
1727877031,
},
{
177,
1727877031,
},
{
205,
1727877031,
},
{
233,
1727877031,
},
{
277,
1727877031,
},
},
},
["2919-15"] = {
["Яростный укус"] = {
{
50,
1726504232,
},
{
51,
1726504232,
},
{
59,
1726504232,
},
{
61,
1726504232,
},
{
101,
1726504232,
},
{
102,
1726504232,
},
{
110,
1726504232,
},
{
112,
1726504232,
},
{
120,
1726504232,
},
{
121,
1726504232,
},
{
149,
1726504232,
},
{
152,
1726504232,
},
{
159,
1726504232,
},
{
162,
1726504232,
},
{
169,
1726504232,
},
{
272,
1726504232,
},
{
282,
1726504232,
},
{
292,
1726504232,
},
{
303,
1726504232,
},
{
51,
1726504934,
},
{
60,
1726504934,
},
{
62,
1726504934,
},
{
100,
1726504934,
},
{
101,
1726504934,
},
{
110,
1726504934,
},
{
111,
1726504934,
},
{
119,
1726504934,
},
{
150,
1726504934,
},
{
152,
1726504934,
},
{
159,
1726504934,
},
{
162,
1726504934,
},
{
273,
1726504934,
},
{
282,
1726504934,
},
{
292,
1726504934,
},
{
322,
1726504934,
},
{
332,
1726504934,
},
{
343,
1726504934,
},
{
392,
1726504934,
},
{
401,
1726504934,
},
{
411,
1726504934,
},
{
421,
1726504934,
},
{
442,
1726504934,
},
{
444,
1726504934,
},
{
451,
1726504934,
},
{
454,
1726504934,
},
{
51,
1726505609,
},
{
52,
1726505609,
},
{
60,
1726505609,
},
{
62,
1726505609,
},
{
102,
1726505609,
},
{
112,
1726505609,
},
{
121,
1726505609,
},
{
152,
1726505609,
},
{
154,
1726505609,
},
{
164,
1726505609,
},
{
172,
1726505609,
},
{
173,
1726505609,
},
{
51,
1726506330,
},
{
61,
1726506330,
},
{
101,
1726506330,
},
{
102,
1726506330,
},
{
111,
1726506330,
},
{
112,
1726506330,
},
{
151,
1726506330,
},
{
153,
1726506330,
},
{
161,
1726506330,
},
{
164,
1726506330,
},
{
171,
1726506330,
},
{
174,
1726506330,
},
{
273,
1726506330,
},
{
283,
1726506330,
},
{
292,
1726506330,
},
{
324,
1726506330,
},
{
334,
1726506330,
},
{
344,
1726506330,
},
{
353,
1726506330,
},
{
395,
1726506330,
},
{
404,
1726506330,
},
{
414,
1726506330,
},
{
443,
1726506330,
},
{
445,
1726506330,
},
{
453,
1726506330,
},
{
454,
1726506330,
},
{
463,
1726506330,
},
{
464,
1726506330,
},
{
49,
1726506580,
},
{
51,
1726507123,
},
{
61,
1726507123,
},
{
62,
1726507123,
},
{
100,
1726507123,
},
{
102,
1726507123,
},
{
110,
1726507123,
},
{
112,
1726507123,
},
{
150,
1726507123,
},
{
153,
1726507123,
},
{
160,
1726507123,
},
{
162,
1726507123,
},
{
272,
1726507123,
},
{
282,
1726507123,
},
{
323,
1726507123,
},
{
334,
1726507123,
},
{
345,
1726507123,
},
{
50,
1726507531,
},
{
51,
1726507531,
},
{
60,
1726507531,
},
{
62,
1726507531,
},
{
100,
1726507531,
},
{
103,
1726507531,
},
{
110,
1726507531,
},
{
112,
1726507531,
},
{
120,
1726507531,
},
{
150,
1726507531,
},
{
151,
1726507531,
},
{
160,
1726507531,
},
{
161,
1726507531,
},
{
277,
1726507531,
},
{
51,
1726507998,
},
{
60,
1726507998,
},
{
61,
1726507998,
},
{
102,
1726507998,
},
{
112,
1726507998,
},
{
133,
1726507998,
},
{
51,
1726508742,
},
{
52,
1726508742,
},
{
62,
1726508742,
},
{
63,
1726508742,
},
{
72,
1726508742,
},
{
73,
1726508742,
},
{
83,
1726508742,
},
{
101,
1726508742,
},
{
102,
1726508742,
},
{
111,
1726508742,
},
{
112,
1726508742,
},
{
150,
1726508742,
},
{
160,
1726508742,
},
{
169,
1726508742,
},
{
193,
1726508742,
},
{
202,
1726508742,
},
{
52,
1726509321,
},
{
55,
1726509321,
},
{
61,
1726509321,
},
{
65,
1726509321,
},
{
71,
1726509321,
},
{
75,
1726509321,
},
{
104,
1726509321,
},
{
114,
1726509321,
},
{
123,
1726509321,
},
{
153,
1726509321,
},
{
155,
1726509321,
},
{
162,
1726509321,
},
{
165,
1726509321,
},
{
172,
1726509321,
},
{
175,
1726509321,
},
{
273,
1726509321,
},
{
283,
1726509321,
},
{
293,
1726509321,
},
{
327,
1726509321,
},
{
50,
1726509555,
},
{
52,
1726509555,
},
{
58,
1726509555,
},
{
60,
1726509555,
},
{
50,
1726509990,
},
{
51,
1726509990,
},
{
53,
1726509990,
},
{
59,
1726509990,
},
{
61,
1726509990,
},
{
63,
1726509990,
},
{
71,
1726509990,
},
{
73,
1726509990,
},
{
49,
1726510946,
},
{
52,
1726510946,
},
{
59,
1726510946,
},
{
61,
1726510946,
},
{
101,
1726510946,
},
{
52,
1726511805,
},
{
61,
1726511805,
},
{
71,
1726511805,
},
{
100,
1726511805,
},
{
101,
1726511805,
},
{
110,
1726511805,
},
{
111,
1726511805,
},
{
120,
1726511805,
},
{
151,
1726511805,
},
{
152,
1726511805,
},
{
161,
1726511805,
},
{
162,
1726511805,
},
{
172,
1726511805,
},
{
173,
1726511805,
},
{
53,
1726513590,
},
{
54,
1726513590,
},
{
63,
1726513590,
},
{
64,
1726513590,
},
{
73,
1726513590,
},
{
74,
1726513590,
},
{
104,
1726513590,
},
{
114,
1726513590,
},
{
124,
1726513590,
},
{
136,
1726513590,
},
{
51,
1726514074,
},
{
52,
1726514074,
},
{
53,
1726514074,
},
{
60,
1726514074,
},
{
62,
1726514074,
},
{
63,
1726514074,
},
{
70,
1726514074,
},
{
73,
1726514074,
},
{
74,
1726514074,
},
{
102,
1726514074,
},
{
113,
1726514074,
},
{
123,
1726514074,
},
{
153,
1726514074,
},
{
163,
1726514074,
},
{
172,
1726514074,
},
{
192,
1726514074,
},
{
51,
1726515164,
},
{
52,
1726515164,
},
{
53,
1726515164,
},
{
61,
1726515164,
},
{
62,
1726515164,
},
{
63,
1726515164,
},
{
71,
1726515164,
},
{
72,
1726515164,
},
{
101,
1726515164,
},
{
111,
1726515164,
},
{
121,
1726515164,
},
{
152,
1726515164,
},
{
154,
1726515164,
},
{
162,
1726515164,
},
{
163,
1726515164,
},
{
274,
1726515164,
},
{
284,
1726515164,
},
{
293,
1726515164,
},
{
323,
1726515164,
},
{
332,
1726515164,
},
{
342,
1726515164,
},
{
397,
1726515164,
},
{
407,
1726515164,
},
{
51,
1726515435,
},
{
52,
1726515435,
},
{
62,
1726515435,
},
{
74,
1726515435,
},
{
102,
1726515435,
},
{
103,
1726515435,
},
{
112,
1726515435,
},
{
113,
1726515435,
},
{
123,
1726515435,
},
{
152,
1726515435,
},
{
153,
1726515435,
},
{
162,
1726515435,
},
{
165,
1726515435,
},
{
171,
1726515435,
},
{
175,
1726515435,
},
{
187,
1726515435,
},
{
54,
1726516070,
},
{
63,
1726516070,
},
{
73,
1726516070,
},
{
74,
1726516070,
},
{
101,
1726516070,
},
{
102,
1726516070,
},
{
111,
1726516070,
},
{
112,
1726516070,
},
{
122,
1726516070,
},
{
151,
1726516070,
},
{
154,
1726516070,
},
{
161,
1726516070,
},
{
164,
1726516070,
},
{
170,
1726516070,
},
{
271,
1726516070,
},
{
281,
1726516070,
},
{
322,
1726516070,
},
{
331,
1726516070,
},
{
341,
1726516070,
},
{
393,
1726516070,
},
{
406,
1726516070,
},
{
415,
1726516070,
},
{
443,
1726516070,
},
{
453,
1726516070,
},
{
463,
1726516070,
},
{
472,
1726516070,
},
{
52,
1726516840,
},
{
54,
1726516840,
},
{
62,
1726516840,
},
{
64,
1726516840,
},
{
102,
1726516840,
},
{
105,
1726516840,
},
{
111,
1726516840,
},
{
115,
1726516840,
},
{
121,
1726516840,
},
{
153,
1726516840,
},
{
154,
1726516840,
},
{
162,
1726516840,
},
{
165,
1726516840,
},
{
270,
1726516840,
},
{
280,
1726516840,
},
{
323,
1726516840,
},
{
332,
1726516840,
},
{
342,
1726516840,
},
{
352,
1726516840,
},
{
394,
1726516840,
},
{
405,
1726516840,
},
{
416,
1726516840,
},
{
51,
1726517121,
},
{
54,
1726517121,
},
{
63,
1726517121,
},
{
51,
1726517715,
},
{
54,
1726517715,
},
{
55,
1726517715,
},
{
61,
1726517715,
},
{
64,
1726517715,
},
{
65,
1726517715,
},
{
71,
1726517715,
},
{
75,
1726517715,
},
{
104,
1726517715,
},
{
106,
1726517715,
},
{
113,
1726517715,
},
{
116,
1726517715,
},
{
154,
1726517715,
},
{
163,
1726517715,
},
{
275,
1726517715,
},
{
285,
1726517715,
},
{
324,
1726517715,
},
{
334,
1726517715,
},
{
346,
1726517715,
},
{
355,
1726517715,
},
{
396,
1726517715,
},
{
405,
1726517715,
},
{
415,
1726517715,
},
{
446,
1726517715,
},
{
455,
1726517715,
},
{
465,
1726517715,
},
{
475,
1726517715,
},
{
101,
1726836034,
},
{
111,
1726836034,
},
{
49,
1726836980,
},
{
50,
1726836980,
},
{
59,
1726836980,
},
{
60,
1726836980,
},
{
68,
1726836980,
},
{
70,
1726836980,
},
{
102,
1726836980,
},
{
112,
1726836980,
},
{
152,
1726836980,
},
{
153,
1726836980,
},
{
162,
1726836980,
},
{
164,
1726836980,
},
{
220,
1726836980,
},
{
230,
1726836980,
},
{
231,
1726836980,
},
{
240,
1726836980,
},
{
48,
1726857543,
},
{
58,
1726857543,
},
{
68,
1726857543,
},
{
99,
1726857543,
},
{
109,
1726857543,
},
{
149,
1726857543,
},
{
152,
1726857543,
},
{
159,
1726857543,
},
{
161,
1726857543,
},
{
268,
1726857543,
},
{
278,
1726857543,
},
{
288,
1726857543,
},
{
322,
1726857543,
},
{
49,
1726858252,
},
{
50,
1726858252,
},
{
60,
1726858252,
},
{
100,
1726858252,
},
{
110,
1726858252,
},
{
149,
1726858252,
},
{
150,
1726858252,
},
{
158,
1726858252,
},
{
160,
1726858252,
},
{
169,
1726858252,
},
{
265,
1726858252,
},
{
276,
1726858252,
},
{
286,
1726858252,
},
{
318,
1726858252,
},
{
329,
1726858252,
},
{
338,
1726858252,
},
{
387,
1726858252,
},
{
397,
1726858252,
},
{
406,
1726858252,
},
{
416,
1726858252,
},
{
437,
1726858252,
},
{
446,
1726858252,
},
{
456,
1726858252,
},
{
467,
1726858252,
},
{
50,
1727016093,
},
{
60,
1727016093,
},
{
82,
1727016093,
},
{
92,
1727016093,
},
{
100,
1727016093,
},
{
102,
1727016093,
},
{
110,
1727016093,
},
{
120,
1727016093,
},
{
121,
1727016093,
},
{
49,
1727016526,
},
{
51,
1727016526,
},
{
59,
1727016526,
},
{
60,
1727016526,
},
{
101,
1727016526,
},
{
111,
1727016526,
},
{
120,
1727016526,
},
{
134,
1727016526,
},
{
144,
1727016526,
},
{
151,
1727016526,
},
{
154,
1727016526,
},
{
161,
1727016526,
},
{
164,
1727016526,
},
{
170,
1727016526,
},
{
174,
1727016526,
},
{
51,
1727016989,
},
{
53,
1727016989,
},
{
60,
1727016989,
},
{
62,
1727016989,
},
{
72,
1727016989,
},
{
101,
1727016989,
},
{
103,
1727016989,
},
{
111,
1727016989,
},
{
112,
1727016989,
},
{
154,
1727016989,
},
{
163,
1727016989,
},
{
191,
1727016989,
},
{
201,
1727016989,
},
{
211,
1727016989,
},
{
50,
1727017314,
},
{
53,
1727017314,
},
{
60,
1727017314,
},
{
63,
1727017314,
},
{
70,
1727017314,
},
{
101,
1727017314,
},
{
111,
1727017314,
},
{
52,
1727018146,
},
{
62,
1727018146,
},
{
104,
1727018146,
},
{
114,
1727018146,
},
{
157,
1727018146,
},
{
158,
1727018146,
},
{
162,
1727018146,
},
{
166,
1727018146,
},
{
54,
1727027680,
},
{
63,
1727027680,
},
{
100,
1727027680,
},
{
102,
1727027680,
},
{
111,
1727027680,
},
{
112,
1727027680,
},
{
121,
1727027680,
},
{
224,
1727027680,
},
{
234,
1727027680,
},
{
274,
1727027680,
},
{
284,
1727027680,
},
{
293,
1727027680,
},
{
325,
1727027680,
},
{
336,
1727027680,
},
{
346,
1727027680,
},
{
54,
1727028360,
},
{
64,
1727028360,
},
{
104,
1727028360,
},
{
114,
1727028360,
},
{
140,
1727028360,
},
{
150,
1727028360,
},
{
168,
1727028360,
},
{
53,
1727028771,
},
{
63,
1727028771,
},
{
137,
1727028771,
},
{
147,
1727028771,
},
{
153,
1727028771,
},
{
157,
1727028771,
},
{
163,
1727028771,
},
{
173,
1727028771,
},
{
185,
1727028771,
},
{
53,
1727029280,
},
{
62,
1727029280,
},
{
103,
1727029280,
},
{
113,
1727029280,
},
{
152,
1727029280,
},
{
163,
1727029280,
},
{
223,
1727029280,
},
{
224,
1727029280,
},
{
233,
1727029280,
},
{
234,
1727029280,
},
{
243,
1727029280,
},
{
273,
1727029280,
},
{
274,
1727029280,
},
{
284,
1727029280,
},
{
325,
1727029280,
},
{
335,
1727029280,
},
{
344,
1727029280,
},
{
365,
1727029280,
},
{
375,
1727029280,
},
{
384,
1727029280,
},
{
51,
1727535106,
},
{
52,
1727535106,
},
{
61,
1727535106,
},
{
62,
1727535106,
},
{
102,
1727535106,
},
{
103,
1727535106,
},
{
104,
1727535106,
},
{
111,
1727535106,
},
{
113,
1727535106,
},
{
114,
1727535106,
},
{
153,
1727535106,
},
{
163,
1727535106,
},
{
224,
1727535106,
},
{
233,
1727535106,
},
{
243,
1727535106,
},
{
309,
1727535106,
},
{
319,
1727535106,
},
{
328,
1727535106,
},
{
444,
1727535106,
},
{
455,
1727535106,
},
{
465,
1727535106,
},
{
474,
1727535106,
},
{
498,
1727535106,
},
{
51,
1727535544,
},
{
52,
1727535544,
},
{
61,
1727535544,
},
{
62,
1727535544,
},
{
84,
1727535544,
},
{
93,
1727535544,
},
{
101,
1727535544,
},
{
112,
1727535544,
},
{
50,
1727536065,
},
{
52,
1727536065,
},
{
59,
1727536065,
},
{
100,
1727536065,
},
{
109,
1727536065,
},
{
152,
1727536065,
},
{
162,
1727536065,
},
{
191,
1727536065,
},
{
201,
1727536065,
},
{
322,
1727536065,
},
{
324,
1727536065,
},
{
332,
1727536065,
},
{
334,
1727536065,
},
{
342,
1727536065,
},
{
343,
1727536065,
},
{
351,
1727536065,
},
{
354,
1727536065,
},
{
364,
1727536065,
},
{
51,
1727536600,
},
{
61,
1727536600,
},
{
62,
1727536600,
},
{
101,
1727536600,
},
{
103,
1727536600,
},
{
110,
1727536600,
},
{
116,
1727536600,
},
{
152,
1727536600,
},
{
154,
1727536600,
},
{
49,
1727537288,
},
{
59,
1727537288,
},
{
99,
1727537288,
},
{
100,
1727537288,
},
{
109,
1727537288,
},
{
110,
1727537288,
},
{
150,
1727537288,
},
{
160,
1727537288,
},
{
189,
1727537288,
},
{
199,
1727537288,
},
{
225,
1727537288,
},
{
235,
1727537288,
},
{
273,
1727537288,
},
{
284,
1727537288,
},
{
323,
1727537288,
},
{
333,
1727537288,
},
{
448,
1727537288,
},
{
457,
1727537288,
},
{
467,
1727537288,
},
{
477,
1727537288,
},
{
51,
1727538013,
},
{
52,
1727538013,
},
{
61,
1727538013,
},
{
62,
1727538013,
},
{
102,
1727538013,
},
{
112,
1727538013,
},
{
152,
1727538013,
},
{
155,
1727538013,
},
{
162,
1727538013,
},
{
319,
1727538013,
},
{
322,
1727538013,
},
{
329,
1727538013,
},
{
331,
1727538013,
},
{
51,
1727538532,
},
{
53,
1727538532,
},
{
55,
1727538532,
},
{
61,
1727538532,
},
{
63,
1727538532,
},
{
65,
1727538532,
},
{
72,
1727538532,
},
{
102,
1727538532,
},
{
112,
1727538532,
},
{
133,
1727538532,
},
{
144,
1727538532,
},
{
50,
1727539037,
},
{
52,
1727539037,
},
{
59,
1727539037,
},
{
63,
1727539037,
},
{
69,
1727539037,
},
{
102,
1727539037,
},
{
112,
1727539037,
},
{
152,
1727539037,
},
{
153,
1727539037,
},
{
162,
1727539037,
},
{
163,
1727539037,
},
{
223,
1727539037,
},
{
49,
1727539906,
},
{
51,
1727539906,
},
{
59,
1727539906,
},
{
62,
1727539906,
},
{
100,
1727539906,
},
{
110,
1727539906,
},
{
149,
1727539906,
},
{
49,
1727540620,
},
{
52,
1727540620,
},
{
60,
1727540620,
},
{
62,
1727540620,
},
{
70,
1727540620,
},
{
103,
1727540620,
},
{
115,
1727540620,
},
{
135,
1727540620,
},
{
148,
1727540620,
},
{
150,
1727540620,
},
{
151,
1727540620,
},
{
160,
1727540620,
},
{
161,
1727540620,
},
{
220,
1727540620,
},
{
230,
1727540620,
},
{
271,
1727540620,
},
{
281,
1727540620,
},
{
321,
1727540620,
},
{
331,
1727540620,
},
{
341,
1727540620,
},
{
350,
1727540620,
},
{
51,
1727541370,
},
{
52,
1727541370,
},
{
60,
1727541370,
},
{
61,
1727541370,
},
{
100,
1727541370,
},
{
102,
1727541370,
},
{
111,
1727541370,
},
{
112,
1727541370,
},
{
151,
1727541370,
},
{
152,
1727541370,
},
{
160,
1727541370,
},
{
162,
1727541370,
},
{
221,
1727541370,
},
{
231,
1727541370,
},
{
271,
1727541370,
},
{
281,
1727541370,
},
{
441,
1727541370,
},
{
451,
1727541370,
},
{
523,
1727541370,
},
{
48,
1727541980,
},
{
50,
1727541980,
},
{
51,
1727541980,
},
{
58,
1727541980,
},
{
59,
1727541980,
},
{
61,
1727541980,
},
{
98,
1727541980,
},
{
108,
1727541980,
},
{
149,
1727541980,
},
{
159,
1727541980,
},
{
219,
1727541980,
},
{
228,
1727541980,
},
{
268,
1727541980,
},
{
278,
1727541980,
},
{
319,
1727541980,
},
{
329,
1727541980,
},
{
437,
1727541980,
},
{
447,
1727541980,
},
},
["Выброс яда"] = {
{
283,
1726504232,
},
{
448,
1726504934,
},
{
453,
1726504934,
},
{
458,
1726504934,
},
{
474,
1726506330,
},
{
227,
1726507531,
},
{
251,
1726507531,
},
{
272,
1726507531,
},
{
277,
1726507531,
},
{
133,
1726507998,
},
{
136,
1726507998,
},
{
138,
1726507998,
},
{
141,
1726507998,
},
{
276,
1726509321,
},
{
284,
1726509321,
},
{
327,
1726509321,
},
{
331,
1726509321,
},
{
102,
1726509990,
},
{
107,
1726509990,
},
{
233,
1726511805,
},
{
246,
1726511805,
},
{
249,
1726511805,
},
{
252,
1726511805,
},
{
253,
1726511805,
},
{
254,
1726511805,
},
{
257,
1726511805,
},
{
64,
1726514074,
},
{
154,
1726514074,
},
{
159,
1726514074,
},
{
164,
1726514074,
},
{
168,
1726514074,
},
{
173,
1726514074,
},
{
178,
1726514074,
},
{
183,
1726514074,
},
{
188,
1726514074,
},
{
332,
1726515164,
},
{
284,
1726516070,
},
{
474,
1726516070,
},
{
320,
1726857543,
},
{
321,
1726857543,
},
{
325,
1726857543,
},
{
326,
1726858252,
},
{
448,
1726858252,
},
{
458,
1726858252,
},
{
463,
1726858252,
},
{
468,
1726858252,
},
{
132,
1727016093,
},
{
150,
1727017314,
},
{
152,
1727017314,
},
{
224,
1727018146,
},
{
230,
1727018146,
},
{
236,
1727018146,
},
{
158,
1727027680,
},
{
405,
1727027680,
},
{
444,
1727027680,
},
{
449,
1727027680,
},
{
167,
1727028360,
},
{
153,
1727029280,
},
{
492,
1727535106,
},
{
500,
1727535106,
},
{
101,
1727535544,
},
{
103,
1727535544,
},
{
113,
1727535544,
},
{
119,
1727535544,
},
{
121,
1727535544,
},
{
124,
1727535544,
},
{
126,
1727535544,
},
{
276,
1727537288,
},
{
400,
1727537288,
},
{
406,
1727537288,
},
{
446,
1727537288,
},
{
456,
1727537288,
},
{
458,
1727537288,
},
{
469,
1727537288,
},
{
472,
1727537288,
},
{
474,
1727537288,
},
{
476,
1727537288,
},
{
479,
1727537288,
},
{
364,
1727538013,
},
{
367,
1727538013,
},
{
369,
1727538013,
},
{
372,
1727538013,
},
{
373,
1727538013,
},
{
374,
1727538013,
},
{
376,
1727538013,
},
{
377,
1727538013,
},
{
378,
1727538013,
},
{
379,
1727538013,
},
{
381,
1727538013,
},
{
383,
1727538013,
},
{
158,
1727538532,
},
{
218,
1727538532,
},
{
152,
1727539037,
},
{
155,
1727539037,
},
{
508,
1727541370,
},
{
517,
1727541370,
},
{
527,
1727541370,
},
{
528,
1727541370,
},
{
531,
1727541370,
},
{
388,
1727541980,
},
},
["Сосредоточение внимания"] = {
{
96,
1726504232,
},
{
146,
1726504232,
},
{
216,
1726504232,
},
{
216,
1726504232,
},
{
217,
1726504232,
},
{
219,
1726504232,
},
{
221,
1726504232,
},
{
222,
1726504232,
},
{
223,
1726504232,
},
{
298,
1726504232,
},
{
299,
1726504232,
},
{
300,
1726504232,
},
{
307,
1726504232,
},
{
309,
1726504232,
},
{
309,
1726504232,
},
{
310,
1726504232,
},
{
96,
1726504934,
},
{
147,
1726504934,
},
{
148,
1726504934,
},
{
149,
1726504934,
},
{
151,
1726504934,
},
{
152,
1726504934,
},
{
153,
1726504934,
},
{
154,
1726504934,
},
{
155,
1726504934,
},
{
216,
1726504934,
},
{
218,
1726504934,
},
{
219,
1726504934,
},
{
220,
1726504934,
},
{
221,
1726504934,
},
{
222,
1726504934,
},
{
223,
1726504934,
},
{
267,
1726504934,
},
{
317,
1726504934,
},
{
330,
1726504934,
},
{
342,
1726504934,
},
{
386,
1726504934,
},
{
389,
1726504934,
},
{
393,
1726504934,
},
{
394,
1726504934,
},
{
395,
1726504934,
},
{
396,
1726504934,
},
{
398,
1726504934,
},
{
398,
1726504934,
},
{
399,
1726504934,
},
{
400,
1726504934,
},
{
400,
1726504934,
},
{
401,
1726504934,
},
{
402,
1726504934,
},
{
407,
1726504934,
},
{
408,
1726504934,
},
{
409,
1726504934,
},
{
410,
1726504934,
},
{
415,
1726504934,
},
{
416,
1726504934,
},
{
417,
1726504934,
},
{
418,
1726504934,
},
{
419,
1726504934,
},
{
419,
1726504934,
},
{
421,
1726504934,
},
{
422,
1726504934,
},
{
423,
1726504934,
},
{
424,
1726504934,
},
{
425,
1726504934,
},
{
436,
1726504934,
},
{
437,
1726504934,
},
{
438,
1726504934,
},
{
441,
1726504934,
},
{
442,
1726504934,
},
{
446,
1726504934,
},
{
447,
1726504934,
},
{
448,
1726504934,
},
{
449,
1726504934,
},
{
449,
1726504934,
},
{
450,
1726504934,
},
{
450,
1726504934,
},
{
451,
1726504934,
},
{
452,
1726504934,
},
{
454,
1726504934,
},
{
454,
1726504934,
},
{
455,
1726504934,
},
{
456,
1726504934,
},
{
456,
1726504934,
},
{
457,
1726504934,
},
{
457,
1726504934,
},
{
96,
1726505609,
},
{
146,
1726505609,
},
{
169,
1726505609,
},
{
175,
1726505609,
},
{
177,
1726505609,
},
{
178,
1726505609,
},
{
179,
1726505609,
},
{
97,
1726506330,
},
{
98,
1726506330,
},
{
100,
1726506330,
},
{
101,
1726506330,
},
{
102,
1726506330,
},
{
103,
1726506330,
},
{
148,
1726506330,
},
{
149,
1726506330,
},
{
150,
1726506330,
},
{
151,
1726506330,
},
{
152,
1726506330,
},
{
152,
1726506330,
},
{
153,
1726506330,
},
{
165,
1726506330,
},
{
218,
1726506330,
},
{
219,
1726506330,
},
{
220,
1726506330,
},
{
221,
1726506330,
},
{
223,
1726506330,
},
{
224,
1726506330,
},
{
225,
1726506330,
},
{
225,
1726506330,
},
{
226,
1726506330,
},
{
226,
1726506330,
},
{
228,
1726506330,
},
{
228,
1726506330,
},
{
268,
1726506330,
},
{
269,
1726506330,
},
{
270,
1726506330,
},
{
273,
1726506330,
},
{
274,
1726506330,
},
{
275,
1726506330,
},
{
275,
1726506330,
},
{
318,
1726506330,
},
{
330,
1726506330,
},
{
332,
1726506330,
},
{
343,
1726506330,
},
{
345,
1726506330,
},
{
347,
1726506330,
},
{
348,
1726506330,
},
{
349,
1726506330,
},
{
349,
1726506330,
},
{
351,
1726506330,
},
{
351,
1726506330,
},
{
352,
1726506330,
},
{
353,
1726506330,
},
{
354,
1726506330,
},
{
356,
1726506330,
},
{
356,
1726506330,
},
{
389,
1726506330,
},
{
403,
1726506330,
},
{
410,
1726506330,
},
{
411,
1726506330,
},
{
412,
1726506330,
},
{
433,
1726506330,
},
{
438,
1726506330,
},
{
440,
1726506330,
},
{
441,
1726506330,
},
{
442,
1726506330,
},
{
443,
1726506330,
},
{
444,
1726506330,
},
{
445,
1726506330,
},
{
446,
1726506330,
},
{
447,
1726506330,
},
{
447,
1726506330,
},
{
448,
1726506330,
},
{
448,
1726506330,
},
{
449,
1726506330,
},
{
450,
1726506330,
},
{
450,
1726506330,
},
{
451,
1726506330,
},
{
452,
1726506330,
},
{
452,
1726506330,
},
{
453,
1726506330,
},
{
459,
1726506330,
},
{
460,
1726506330,
},
{
461,
1726506330,
},
{
461,
1726506330,
},
{
462,
1726506330,
},
{
464,
1726506330,
},
{
464,
1726506330,
},
{
465,
1726506330,
},
{
466,
1726506330,
},
{
467,
1726506330,
},
{
468,
1726506330,
},
{
469,
1726506330,
},
{
469,
1726506330,
},
{
470,
1726506330,
},
{
470,
1726506330,
},
{
471,
1726506330,
},
{
471,
1726506330,
},
{
472,
1726506330,
},
{
472,
1726506330,
},
{
473,
1726506330,
},
{
474,
1726506330,
},
{
474,
1726506330,
},
{
475,
1726506330,
},
{
97,
1726507123,
},
{
98,
1726507123,
},
{
99,
1726507123,
},
{
101,
1726507123,
},
{
101,
1726507123,
},
{
146,
1726507123,
},
{
147,
1726507123,
},
{
149,
1726507123,
},
{
150,
1726507123,
},
{
151,
1726507123,
},
{
152,
1726507123,
},
{
153,
1726507123,
},
{
217,
1726507123,
},
{
218,
1726507123,
},
{
219,
1726507123,
},
{
220,
1726507123,
},
{
222,
1726507123,
},
{
223,
1726507123,
},
{
224,
1726507123,
},
{
267,
1726507123,
},
{
268,
1726507123,
},
{
269,
1726507123,
},
{
270,
1726507123,
},
{
273,
1726507123,
},
{
317,
1726507123,
},
{
340,
1726507123,
},
{
356,
1726507123,
},
{
368,
1726507123,
},
{
383,
1726507123,
},
{
386,
1726507123,
},
{
387,
1726507123,
},
{
388,
1726507123,
},
{
388,
1726507123,
},
{
389,
1726507123,
},
{
392,
1726507123,
},
{
393,
1726507123,
},
{
395,
1726507123,
},
{
395,
1726507123,
},
{
407,
1726507123,
},
{
437,
1726507123,
},
{
96,
1726507531,
},
{
97,
1726507531,
},
{
99,
1726507531,
},
{
100,
1726507531,
},
{
101,
1726507531,
},
{
102,
1726507531,
},
{
146,
1726507531,
},
{
161,
1726507531,
},
{
214,
1726507531,
},
{
215,
1726507531,
},
{
216,
1726507531,
},
{
238,
1726507531,
},
{
240,
1726507531,
},
{
245,
1726507531,
},
{
245,
1726507531,
},
{
246,
1726507531,
},
{
247,
1726507531,
},
{
248,
1726507531,
},
{
253,
1726507531,
},
{
254,
1726507531,
},
{
255,
1726507531,
},
{
256,
1726507531,
},
{
257,
1726507531,
},
{
258,
1726507531,
},
{
259,
1726507531,
},
{
260,
1726507531,
},
{
261,
1726507531,
},
{
266,
1726507531,
},
{
268,
1726507531,
},
{
273,
1726507531,
},
{
274,
1726507531,
},
{
275,
1726507531,
},
{
275,
1726507531,
},
{
276,
1726507531,
},
{
277,
1726507531,
},
{
96,
1726507998,
},
{
97,
1726507998,
},
{
98,
1726507998,
},
{
99,
1726507998,
},
{
101,
1726507998,
},
{
102,
1726507998,
},
{
103,
1726507998,
},
{
104,
1726507998,
},
{
110,
1726507998,
},
{
146,
1726508742,
},
{
151,
1726508742,
},
{
152,
1726508742,
},
{
153,
1726508742,
},
{
154,
1726508742,
},
{
156,
1726508742,
},
{
157,
1726508742,
},
{
158,
1726508742,
},
{
159,
1726508742,
},
{
160,
1726508742,
},
{
167,
1726508742,
},
{
173,
1726508742,
},
{
177,
1726508742,
},
{
182,
1726508742,
},
{
183,
1726508742,
},
{
184,
1726508742,
},
{
185,
1726508742,
},
{
187,
1726508742,
},
{
188,
1726508742,
},
{
189,
1726508742,
},
{
189,
1726508742,
},
{
194,
1726508742,
},
{
196,
1726508742,
},
{
197,
1726508742,
},
{
198,
1726508742,
},
{
199,
1726508742,
},
{
199,
1726508742,
},
{
200,
1726508742,
},
{
201,
1726508742,
},
{
202,
1726508742,
},
{
202,
1726508742,
},
{
203,
1726508742,
},
{
98,
1726509321,
},
{
148,
1726509321,
},
{
162,
1726509321,
},
{
167,
1726509321,
},
{
168,
1726509321,
},
{
220,
1726509321,
},
{
270,
1726509321,
},
{
271,
1726509321,
},
{
272,
1726509321,
},
{
273,
1726509321,
},
{
274,
1726509321,
},
{
276,
1726509321,
},
{
277,
1726509321,
},
{
320,
1726509321,
},
{
324,
1726509321,
},
{
325,
1726509321,
},
{
326,
1726509321,
},
{
327,
1726509321,
},
{
327,
1726509321,
},
{
328,
1726509321,
},
{
329,
1726509321,
},
{
330,
1726509321,
},
{
331,
1726509321,
},
{
332,
1726509321,
},
{
332,
1726509321,
},
{
333,
1726509321,
},
{
96,
1726510946,
},
{
96,
1726511805,
},
{
145,
1726511805,
},
{
146,
1726511805,
},
{
146,
1726511805,
},
{
147,
1726511805,
},
{
147,
1726511805,
},
{
148,
1726511805,
},
{
150,
1726511805,
},
{
163,
1726511805,
},
{
176,
1726511805,
},
{
178,
1726511805,
},
{
179,
1726511805,
},
{
217,
1726511805,
},
{
217,
1726511805,
},
{
218,
1726511805,
},
{
219,
1726511805,
},
{
239,
1726511805,
},
{
240,
1726511805,
},
{
241,
1726511805,
},
{
242,
1726511805,
},
{
243,
1726511805,
},
{
243,
1726511805,
},
{
244,
1726511805,
},
{
246,
1726511805,
},
{
246,
1726511805,
},
{
247,
1726511805,
},
{
247,
1726511805,
},
{
248,
1726511805,
},
{
249,
1726511805,
},
{
249,
1726511805,
},
{
251,
1726511805,
},
{
252,
1726511805,
},
{
253,
1726511805,
},
{
254,
1726511805,
},
{
254,
1726511805,
},
{
255,
1726511805,
},
{
256,
1726511805,
},
{
98,
1726513590,
},
{
97,
1726514074,
},
{
147,
1726514074,
},
{
163,
1726514074,
},
{
165,
1726514074,
},
{
169,
1726514074,
},
{
170,
1726514074,
},
{
171,
1726514074,
},
{
172,
1726514074,
},
{
175,
1726514074,
},
{
177,
1726514074,
},
{
177,
1726514074,
},
{
178,
1726514074,
},
{
179,
1726514074,
},
{
179,
1726514074,
},
{
180,
1726514074,
},
{
182,
1726514074,
},
{
183,
1726514074,
},
{
184,
1726514074,
},
{
184,
1726514074,
},
{
186,
1726514074,
},
{
187,
1726514074,
},
{
187,
1726514074,
},
{
188,
1726514074,
},
{
189,
1726514074,
},
{
190,
1726514074,
},
{
191,
1726514074,
},
{
192,
1726514074,
},
{
192,
1726514074,
},
{
97,
1726515164,
},
{
98,
1726515164,
},
{
100,
1726515164,
},
{
101,
1726515164,
},
{
102,
1726515164,
},
{
103,
1726515164,
},
{
147,
1726515164,
},
{
147,
1726515164,
},
{
149,
1726515164,
},
{
150,
1726515164,
},
{
151,
1726515164,
},
{
152,
1726515164,
},
{
153,
1726515164,
},
{
218,
1726515164,
},
{
219,
1726515164,
},
{
220,
1726515164,
},
{
221,
1726515164,
},
{
223,
1726515164,
},
{
224,
1726515164,
},
{
268,
1726515164,
},
{
269,
1726515164,
},
{
270,
1726515164,
},
{
271,
1726515164,
},
{
273,
1726515164,
},
{
274,
1726515164,
},
{
275,
1726515164,
},
{
279,
1726515164,
},
{
280,
1726515164,
},
{
281,
1726515164,
},
{
282,
1726515164,
},
{
288,
1726515164,
},
{
304,
1726515164,
},
{
308,
1726515164,
},
{
310,
1726515164,
},
{
318,
1726515164,
},
{
326,
1726515164,
},
{
329,
1726515164,
},
{
330,
1726515164,
},
{
331,
1726515164,
},
{
335,
1726515164,
},
{
336,
1726515164,
},
{
337,
1726515164,
},
{
338,
1726515164,
},
{
339,
1726515164,
},
{
343,
1726515164,
},
{
344,
1726515164,
},
{
345,
1726515164,
},
{
346,
1726515164,
},
{
347,
1726515164,
},
{
348,
1726515164,
},
{
349,
1726515164,
},
{
350,
1726515164,
},
{
351,
1726515164,
},
{
352,
1726515164,
},
{
353,
1726515164,
},
{
354,
1726515164,
},
{
356,
1726515164,
},
{
358,
1726515164,
},
{
359,
1726515164,
},
{
360,
1726515164,
},
{
360,
1726515164,
},
{
363,
1726515164,
},
{
365,
1726515164,
},
{
369,
1726515164,
},
{
371,
1726515164,
},
{
372,
1726515164,
},
{
373,
1726515164,
},
{
375,
1726515164,
},
{
376,
1726515164,
},
{
377,
1726515164,
},
{
377,
1726515164,
},
{
378,
1726515164,
},
{
379,
1726515164,
},
{
380,
1726515164,
},
{
380,
1726515164,
},
{
381,
1726515164,
},
{
382,
1726515164,
},
{
382,
1726515164,
},
{
383,
1726515164,
},
{
383,
1726515164,
},
{
384,
1726515164,
},
{
384,
1726515164,
},
{
386,
1726515164,
},
{
386,
1726515164,
},
{
387,
1726515164,
},
{
388,
1726515164,
},
{
388,
1726515164,
},
{
389,
1726515164,
},
{
389,
1726515164,
},
{
390,
1726515164,
},
{
391,
1726515164,
},
{
391,
1726515164,
},
{
392,
1726515164,
},
{
393,
1726515164,
},
{
394,
1726515164,
},
{
395,
1726515164,
},
{
395,
1726515164,
},
{
396,
1726515164,
},
{
397,
1726515164,
},
{
397,
1726515164,
},
{
398,
1726515164,
},
{
399,
1726515164,
},
{
399,
1726515164,
},
{
400,
1726515164,
},
{
400,
1726515164,
},
{
401,
1726515164,
},
{
401,
1726515164,
},
{
402,
1726515164,
},
{
403,
1726515164,
},
{
404,
1726515164,
},
{
405,
1726515164,
},
{
405,
1726515164,
},
{
406,
1726515164,
},
{
406,
1726515164,
},
{
407,
1726515164,
},
{
408,
1726515164,
},
{
408,
1726515164,
},
{
409,
1726515164,
},
{
410,
1726515164,
},
{
410,
1726515164,
},
{
411,
1726515164,
},
{
411,
1726515164,
},
{
412,
1726515164,
},
{
97,
1726515435,
},
{
98,
1726515435,
},
{
99,
1726515435,
},
{
100,
1726515435,
},
{
185,
1726515435,
},
{
186,
1726515435,
},
{
187,
1726515435,
},
{
187,
1726515435,
},
{
188,
1726515435,
},
{
97,
1726516070,
},
{
98,
1726516070,
},
{
113,
1726516070,
},
{
139,
1726516070,
},
{
147,
1726516070,
},
{
148,
1726516070,
},
{
148,
1726516070,
},
{
149,
1726516070,
},
{
150,
1726516070,
},
{
216,
1726516070,
},
{
218,
1726516070,
},
{
219,
1726516070,
},
{
220,
1726516070,
},
{
221,
1726516070,
},
{
223,
1726516070,
},
{
224,
1726516070,
},
{
225,
1726516070,
},
{
226,
1726516070,
},
{
268,
1726516070,
},
{
269,
1726516070,
},
{
270,
1726516070,
},
{
271,
1726516070,
},
{
272,
1726516070,
},
{
318,
1726516070,
},
{
319,
1726516070,
},
{
320,
1726516070,
},
{
321,
1726516070,
},
{
323,
1726516070,
},
{
324,
1726516070,
},
{
325,
1726516070,
},
{
388,
1726516070,
},
{
389,
1726516070,
},
{
391,
1726516070,
},
{
392,
1726516070,
},
{
393,
1726516070,
},
{
394,
1726516070,
},
{
396,
1726516070,
},
{
397,
1726516070,
},
{
398,
1726516070,
},
{
437,
1726516070,
},
{
438,
1726516070,
},
{
439,
1726516070,
},
{
441,
1726516070,
},
{
442,
1726516070,
},
{
443,
1726516070,
},
{
443,
1726516070,
},
{
444,
1726516070,
},
{
445,
1726516070,
},
{
447,
1726516070,
},
{
447,
1726516070,
},
{
448,
1726516070,
},
{
449,
1726516070,
},
{
449,
1726516070,
},
{
450,
1726516070,
},
{
451,
1726516070,
},
{
453,
1726516070,
},
{
454,
1726516070,
},
{
455,
1726516070,
},
{
455,
1726516070,
},
{
456,
1726516070,
},
{
456,
1726516070,
},
{
457,
1726516070,
},
{
458,
1726516070,
},
{
459,
1726516070,
},
{
459,
1726516070,
},
{
460,
1726516070,
},
{
461,
1726516070,
},
{
461,
1726516070,
},
{
462,
1726516070,
},
{
462,
1726516070,
},
{
463,
1726516070,
},
{
464,
1726516070,
},
{
465,
1726516070,
},
{
465,
1726516070,
},
{
466,
1726516070,
},
{
467,
1726516070,
},
{
467,
1726516070,
},
{
468,
1726516070,
},
{
469,
1726516070,
},
{
470,
1726516070,
},
{
471,
1726516070,
},
{
471,
1726516070,
},
{
472,
1726516070,
},
{
472,
1726516070,
},
{
473,
1726516070,
},
{
473,
1726516070,
},
{
474,
1726516070,
},
{
475,
1726516070,
},
{
476,
1726516070,
},
{
476,
1726516070,
},
{
98,
1726516840,
},
{
99,
1726516840,
},
{
100,
1726516840,
},
{
101,
1726516840,
},
{
112,
1726516840,
},
{
148,
1726516840,
},
{
148,
1726516840,
},
{
149,
1726516840,
},
{
150,
1726516840,
},
{
165,
1726516840,
},
{
166,
1726516840,
},
{
167,
1726516840,
},
{
168,
1726516840,
},
{
218,
1726516840,
},
{
219,
1726516840,
},
{
220,
1726516840,
},
{
221,
1726516840,
},
{
222,
1726516840,
},
{
266,
1726516840,
},
{
267,
1726516840,
},
{
268,
1726516840,
},
{
268,
1726516840,
},
{
269,
1726516840,
},
{
270,
1726516840,
},
{
271,
1726516840,
},
{
272,
1726516840,
},
{
317,
1726516840,
},
{
317,
1726516840,
},
{
319,
1726516840,
},
{
319,
1726516840,
},
{
335,
1726516840,
},
{
335,
1726516840,
},
{
336,
1726516840,
},
{
337,
1726516840,
},
{
338,
1726516840,
},
{
339,
1726516840,
},
{
340,
1726516840,
},
{
342,
1726516840,
},
{
344,
1726516840,
},
{
357,
1726516840,
},
{
388,
1726516840,
},
{
388,
1726516840,
},
{
389,
1726516840,
},
{
389,
1726516840,
},
{
390,
1726516840,
},
{
392,
1726516840,
},
{
393,
1726516840,
},
{
394,
1726516840,
},
{
394,
1726516840,
},
{
395,
1726516840,
},
{
404,
1726516840,
},
{
407,
1726516840,
},
{
98,
1726517715,
},
{
99,
1726517715,
},
{
100,
1726517715,
},
{
101,
1726517715,
},
{
102,
1726517715,
},
{
147,
1726517715,
},
{
148,
1726517715,
},
{
150,
1726517715,
},
{
151,
1726517715,
},
{
152,
1726517715,
},
{
153,
1726517715,
},
{
153,
1726517715,
},
{
154,
1726517715,
},
{
155,
1726517715,
},
{
167,
1726517715,
},
{
168,
1726517715,
},
{
169,
1726517715,
},
{
170,
1726517715,
},
{
171,
1726517715,
},
{
220,
1726517715,
},
{
221,
1726517715,
},
{
223,
1726517715,
},
{
224,
1726517715,
},
{
225,
1726517715,
},
{
225,
1726517715,
},
{
226,
1726517715,
},
{
269,
1726517715,
},
{
270,
1726517715,
},
{
271,
1726517715,
},
{
273,
1726517715,
},
{
274,
1726517715,
},
{
275,
1726517715,
},
{
276,
1726517715,
},
{
319,
1726517715,
},
{
320,
1726517715,
},
{
320,
1726517715,
},
{
321,
1726517715,
},
{
322,
1726517715,
},
{
331,
1726517715,
},
{
332,
1726517715,
},
{
333,
1726517715,
},
{
333,
1726517715,
},
{
341,
1726517715,
},
{
342,
1726517715,
},
{
343,
1726517715,
},
{
344,
1726517715,
},
{
345,
1726517715,
},
{
347,
1726517715,
},
{
348,
1726517715,
},
{
349,
1726517715,
},
{
350,
1726517715,
},
{
352,
1726517715,
},
{
352,
1726517715,
},
{
389,
1726517715,
},
{
391,
1726517715,
},
{
391,
1726517715,
},
{
392,
1726517715,
},
{
393,
1726517715,
},
{
395,
1726517715,
},
{
405,
1726517715,
},
{
405,
1726517715,
},
{
406,
1726517715,
},
{
408,
1726517715,
},
{
408,
1726517715,
},
{
409,
1726517715,
},
{
410,
1726517715,
},
{
411,
1726517715,
},
{
412,
1726517715,
},
{
413,
1726517715,
},
{
414,
1726517715,
},
{
414,
1726517715,
},
{
428,
1726517715,
},
{
445,
1726517715,
},
{
472,
1726517715,
},
{
473,
1726517715,
},
{
473,
1726517715,
},
{
474,
1726517715,
},
{
487,
1726517715,
},
{
490,
1726517715,
},
{
490,
1726517715,
},
{
491,
1726517715,
},
{
491,
1726517715,
},
{
493,
1726517715,
},
{
493,
1726517715,
},
{
494,
1726517715,
},
{
495,
1726517715,
},
{
496,
1726517715,
},
{
45,
1726836034,
},
{
46,
1726836034,
},
{
64,
1726836034,
},
{
85,
1726836034,
},
{
86,
1726836034,
},
{
87,
1726836034,
},
{
92,
1726836034,
},
{
95,
1726836034,
},
{
96,
1726836034,
},
{
98,
1726836034,
},
{
100,
1726836034,
},
{
100,
1726836034,
},
{
101,
1726836034,
},
{
102,
1726836034,
},
{
102,
1726836034,
},
{
103,
1726836034,
},
{
103,
1726836034,
},
{
104,
1726836034,
},
{
105,
1726836034,
},
{
105,
1726836034,
},
{
106,
1726836034,
},
{
106,
1726836034,
},
{
107,
1726836034,
},
{
108,
1726836034,
},
{
109,
1726836034,
},
{
110,
1726836034,
},
{
110,
1726836034,
},
{
111,
1726836034,
},
{
112,
1726836034,
},
{
112,
1726836034,
},
{
113,
1726836034,
},
{
114,
1726836034,
},
{
114,
1726836034,
},
{
115,
1726836034,
},
{
115,
1726836034,
},
{
116,
1726836034,
},
{
145,
1726836980,
},
{
146,
1726836980,
},
{
146,
1726836980,
},
{
147,
1726836980,
},
{
148,
1726836980,
},
{
149,
1726836980,
},
{
150,
1726836980,
},
{
152,
1726836980,
},
{
153,
1726836980,
},
{
154,
1726836980,
},
{
163,
1726836980,
},
{
167,
1726836980,
},
{
185,
1726836980,
},
{
201,
1726836980,
},
{
214,
1726836980,
},
{
216,
1726836980,
},
{
222,
1726836980,
},
{
229,
1726836980,
},
{
229,
1726836980,
},
{
230,
1726836980,
},
{
230,
1726836980,
},
{
231,
1726836980,
},
{
232,
1726836980,
},
{
232,
1726836980,
},
{
233,
1726836980,
},
{
250,
1726836980,
},
{
252,
1726836980,
},
{
259,
1726836980,
},
{
260,
1726836980,
},
{
261,
1726836980,
},
{
262,
1726836980,
},
{
262,
1726836980,
},
{
264,
1726836980,
},
{
264,
1726836980,
},
{
265,
1726836980,
},
{
266,
1726836980,
},
{
266,
1726836980,
},
{
267,
1726836980,
},
{
268,
1726836980,
},
{
268,
1726836980,
},
{
279,
1726836980,
},
{
280,
1726836980,
},
{
281,
1726836980,
},
{
282,
1726836980,
},
{
283,
1726836980,
},
{
288,
1726836980,
},
{
290,
1726836980,
},
{
296,
1726836980,
},
{
297,
1726836980,
},
{
298,
1726836980,
},
{
298,
1726836980,
},
{
299,
1726836980,
},
{
300,
1726836980,
},
{
301,
1726836980,
},
{
314,
1726836980,
},
{
315,
1726836980,
},
{
317,
1726836980,
},
{
317,
1726836980,
},
{
320,
1726836980,
},
{
320,
1726836980,
},
{
321,
1726836980,
},
{
321,
1726836980,
},
{
322,
1726836980,
},
{
324,
1726836980,
},
{
326,
1726836980,
},
{
328,
1726836980,
},
{
329,
1726836980,
},
{
330,
1726836980,
},
{
330,
1726836980,
},
{
331,
1726836980,
},
{
332,
1726836980,
},
{
335,
1726836980,
},
{
335,
1726836980,
},
{
337,
1726836980,
},
{
339,
1726836980,
},
{
340,
1726836980,
},
{
341,
1726836980,
},
{
342,
1726836980,
},
{
342,
1726836980,
},
{
343,
1726836980,
},
{
344,
1726836980,
},
{
345,
1726836980,
},
{
345,
1726836980,
},
{
346,
1726836980,
},
{
346,
1726836980,
},
{
347,
1726836980,
},
{
348,
1726836980,
},
{
348,
1726836980,
},
{
349,
1726836980,
},
{
350,
1726836980,
},
{
351,
1726836980,
},
{
352,
1726836980,
},
{
352,
1726836980,
},
{
353,
1726836980,
},
{
353,
1726836980,
},
{
354,
1726836980,
},
{
355,
1726836980,
},
{
355,
1726836980,
},
{
356,
1726836980,
},
{
356,
1726836980,
},
{
357,
1726836980,
},
{
357,
1726836980,
},
{
358,
1726836980,
},
{
359,
1726836980,
},
{
359,
1726836980,
},
{
360,
1726836980,
},
{
361,
1726836980,
},
{
362,
1726836980,
},
{
362,
1726836980,
},
{
363,
1726836980,
},
{
363,
1726836980,
},
{
364,
1726836980,
},
{
364,
1726836980,
},
{
365,
1726836980,
},
{
366,
1726836980,
},
{
367,
1726836980,
},
{
367,
1726836980,
},
{
368,
1726836980,
},
{
369,
1726836980,
},
{
370,
1726836980,
},
{
95,
1726857543,
},
{
145,
1726857543,
},
{
162,
1726857543,
},
{
176,
1726857543,
},
{
209,
1726857543,
},
{
222,
1726857543,
},
{
224,
1726857543,
},
{
225,
1726857543,
},
{
227,
1726857543,
},
{
228,
1726857543,
},
{
229,
1726857543,
},
{
230,
1726857543,
},
{
231,
1726857543,
},
{
263,
1726857543,
},
{
264,
1726857543,
},
{
264,
1726857543,
},
{
265,
1726857543,
},
{
267,
1726857543,
},
{
268,
1726857543,
},
{
297,
1726857543,
},
{
298,
1726857543,
},
{
299,
1726857543,
},
{
299,
1726857543,
},
{
300,
1726857543,
},
{
300,
1726857543,
},
{
301,
1726857543,
},
{
302,
1726857543,
},
{
302,
1726857543,
},
{
303,
1726857543,
},
{
304,
1726857543,
},
{
306,
1726857543,
},
{
306,
1726857543,
},
{
308,
1726857543,
},
{
313,
1726857543,
},
{
314,
1726857543,
},
{
314,
1726857543,
},
{
315,
1726857543,
},
{
315,
1726857543,
},
{
316,
1726857543,
},
{
316,
1726857543,
},
{
317,
1726857543,
},
{
318,
1726857543,
},
{
318,
1726857543,
},
{
319,
1726857543,
},
{
319,
1726857543,
},
{
320,
1726857543,
},
{
320,
1726857543,
},
{
321,
1726857543,
},
{
323,
1726857543,
},
{
324,
1726857543,
},
{
94,
1726858252,
},
{
144,
1726858252,
},
{
212,
1726858252,
},
{
262,
1726858252,
},
{
263,
1726858252,
},
{
264,
1726858252,
},
{
312,
1726858252,
},
{
381,
1726858252,
},
{
382,
1726858252,
},
{
383,
1726858252,
},
{
384,
1726858252,
},
{
390,
1726858252,
},
{
396,
1726858252,
},
{
420,
1726858252,
},
{
430,
1726858252,
},
{
431,
1726858252,
},
{
440,
1726858252,
},
{
442,
1726858252,
},
{
444,
1726858252,
},
{
446,
1726858252,
},
{
448,
1726858252,
},
{
448,
1726858252,
},
{
449,
1726858252,
},
{
450,
1726858252,
},
{
450,
1726858252,
},
{
452,
1726858252,
},
{
453,
1726858252,
},
{
455,
1726858252,
},
{
455,
1726858252,
},
{
456,
1726858252,
},
{
457,
1726858252,
},
{
458,
1726858252,
},
{
459,
1726858252,
},
{
460,
1726858252,
},
{
461,
1726858252,
},
{
462,
1726858252,
},
{
462,
1726858252,
},
{
463,
1726858252,
},
{
463,
1726858252,
},
{
464,
1726858252,
},
{
465,
1726858252,
},
{
465,
1726858252,
},
{
466,
1726858252,
},
{
467,
1726858252,
},
{
467,
1726858252,
},
{
468,
1726858252,
},
{
468,
1726858252,
},
{
469,
1726858252,
},
{
144,
1727016093,
},
{
146,
1727016093,
},
{
147,
1727016093,
},
{
148,
1727016093,
},
{
148,
1727016093,
},
{
95,
1727016526,
},
{
143,
1727016526,
},
{
144,
1727016526,
},
{
145,
1727016526,
},
{
146,
1727016526,
},
{
146,
1727016526,
},
{
149,
1727016526,
},
{
153,
1727016526,
},
{
154,
1727016526,
},
{
155,
1727016526,
},
{
156,
1727016526,
},
{
161,
1727016526,
},
{
162,
1727016526,
},
{
164,
1727016526,
},
{
170,
1727016526,
},
{
171,
1727016526,
},
{
171,
1727016526,
},
{
174,
1727016526,
},
{
175,
1727016526,
},
{
176,
1727016526,
},
{
177,
1727016526,
},
{
177,
1727016526,
},
{
178,
1727016526,
},
{
179,
1727016526,
},
{
146,
1727016989,
},
{
147,
1727016989,
},
{
148,
1727016989,
},
{
149,
1727016989,
},
{
150,
1727016989,
},
{
151,
1727016989,
},
{
152,
1727016989,
},
{
153,
1727016989,
},
{
183,
1727016989,
},
{
185,
1727016989,
},
{
185,
1727016989,
},
{
186,
1727016989,
},
{
188,
1727016989,
},
{
189,
1727016989,
},
{
190,
1727016989,
},
{
191,
1727016989,
},
{
192,
1727016989,
},
{
207,
1727016989,
},
{
208,
1727016989,
},
{
209,
1727016989,
},
{
210,
1727016989,
},
{
211,
1727016989,
},
{
214,
1727016989,
},
{
215,
1727016989,
},
{
216,
1727016989,
},
{
216,
1727016989,
},
{
217,
1727016989,
},
{
217,
1727016989,
},
{
218,
1727016989,
},
{
219,
1727016989,
},
{
219,
1727016989,
},
{
97,
1727017314,
},
{
97,
1727017314,
},
{
98,
1727017314,
},
{
99,
1727017314,
},
{
100,
1727017314,
},
{
101,
1727017314,
},
{
102,
1727017314,
},
{
113,
1727017314,
},
{
119,
1727017314,
},
{
136,
1727017314,
},
{
137,
1727017314,
},
{
144,
1727017314,
},
{
145,
1727017314,
},
{
146,
1727017314,
},
{
146,
1727017314,
},
{
148,
1727017314,
},
{
148,
1727017314,
},
{
151,
1727017314,
},
{
153,
1727017314,
},
{
154,
1727017314,
},
{
98,
1727018146,
},
{
99,
1727018146,
},
{
100,
1727018146,
},
{
101,
1727018146,
},
{
102,
1727018146,
},
{
104,
1727018146,
},
{
104,
1727018146,
},
{
186,
1727018146,
},
{
187,
1727018146,
},
{
188,
1727018146,
},
{
188,
1727018146,
},
{
189,
1727018146,
},
{
190,
1727018146,
},
{
199,
1727018146,
},
{
200,
1727018146,
},
{
202,
1727018146,
},
{
202,
1727018146,
},
{
207,
1727018146,
},
{
214,
1727018146,
},
{
215,
1727018146,
},
{
218,
1727018146,
},
{
218,
1727018146,
},
{
219,
1727018146,
},
{
219,
1727018146,
},
{
220,
1727018146,
},
{
227,
1727018146,
},
{
229,
1727018146,
},
{
230,
1727018146,
},
{
230,
1727018146,
},
{
231,
1727018146,
},
{
232,
1727018146,
},
{
232,
1727018146,
},
{
233,
1727018146,
},
{
235,
1727018146,
},
{
236,
1727018146,
},
{
237,
1727018146,
},
{
46,
1727027680,
},
{
46,
1727027680,
},
{
47,
1727027680,
},
{
47,
1727027680,
},
{
49,
1727027680,
},
{
49,
1727027680,
},
{
96,
1727027680,
},
{
96,
1727027680,
},
{
97,
1727027680,
},
{
97,
1727027680,
},
{
100,
1727027680,
},
{
101,
1727027680,
},
{
102,
1727027680,
},
{
113,
1727027680,
},
{
113,
1727027680,
},
{
114,
1727027680,
},
{
115,
1727027680,
},
{
131,
1727027680,
},
{
146,
1727027680,
},
{
147,
1727027680,
},
{
161,
1727027680,
},
{
163,
1727027680,
},
{
181,
1727027680,
},
{
182,
1727027680,
},
{
183,
1727027680,
},
{
184,
1727027680,
},
{
196,
1727027680,
},
{
209,
1727027680,
},
{
268,
1727027680,
},
{
297,
1727027680,
},
{
312,
1727027680,
},
{
318,
1727027680,
},
{
328,
1727027680,
},
{
388,
1727027680,
},
{
388,
1727027680,
},
{
389,
1727027680,
},
{
390,
1727027680,
},
{
392,
1727027680,
},
{
393,
1727027680,
},
{
394,
1727027680,
},
{
395,
1727027680,
},
{
396,
1727027680,
},
{
397,
1727027680,
},
{
418,
1727027680,
},
{
419,
1727027680,
},
{
420,
1727027680,
},
{
426,
1727027680,
},
{
437,
1727027680,
},
{
438,
1727027680,
},
{
439,
1727027680,
},
{
447,
1727027680,
},
{
448,
1727027680,
},
{
449,
1727027680,
},
{
450,
1727027680,
},
{
451,
1727027680,
},
{
48,
1727028360,
},
{
49,
1727028360,
},
{
50,
1727028360,
},
{
52,
1727028360,
},
{
53,
1727028360,
},
{
98,
1727028360,
},
{
99,
1727028360,
},
{
99,
1727028360,
},
{
100,
1727028360,
},
{
102,
1727028360,
},
{
113,
1727028360,
},
{
114,
1727028360,
},
{
127,
1727028360,
},
{
129,
1727028360,
},
{
136,
1727028360,
},
{
138,
1727028360,
},
{
141,
1727028360,
},
{
148,
1727028360,
},
{
149,
1727028360,
},
{
149,
1727028360,
},
{
150,
1727028360,
},
{
150,
1727028360,
},
{
151,
1727028360,
},
{
151,
1727028360,
},
{
152,
1727028360,
},
{
153,
1727028360,
},
{
154,
1727028360,
},
{
155,
1727028360,
},
{
156,
1727028360,
},
{
156,
1727028360,
},
{
157,
1727028360,
},
{
159,
1727028360,
},
{
160,
1727028360,
},
{
161,
1727028360,
},
{
164,
1727028360,
},
{
164,
1727028360,
},
{
166,
1727028360,
},
{
167,
1727028360,
},
{
167,
1727028360,
},
{
168,
1727028360,
},
{
168,
1727028360,
},
{
169,
1727028360,
},
{
169,
1727028360,
},
{
170,
1727028360,
},
{
171,
1727028360,
},
{
47,
1727028771,
},
{
48,
1727028771,
},
{
63,
1727028771,
},
{
64,
1727028771,
},
{
97,
1727028771,
},
{
98,
1727028771,
},
{
102,
1727028771,
},
{
112,
1727028771,
},
{
147,
1727028771,
},
{
148,
1727028771,
},
{
151,
1727028771,
},
{
152,
1727028771,
},
{
153,
1727028771,
},
{
154,
1727028771,
},
{
154,
1727028771,
},
{
155,
1727028771,
},
{
156,
1727028771,
},
{
157,
1727028771,
},
{
158,
1727028771,
},
{
158,
1727028771,
},
{
159,
1727028771,
},
{
160,
1727028771,
},
{
160,
1727028771,
},
{
161,
1727028771,
},
{
162,
1727028771,
},
{
169,
1727028771,
},
{
170,
1727028771,
},
{
171,
1727028771,
},
{
171,
1727028771,
},
{
172,
1727028771,
},
{
173,
1727028771,
},
{
173,
1727028771,
},
{
174,
1727028771,
},
{
174,
1727028771,
},
{
175,
1727028771,
},
{
175,
1727028771,
},
{
176,
1727028771,
},
{
177,
1727028771,
},
{
177,
1727028771,
},
{
178,
1727028771,
},
{
179,
1727028771,
},
{
179,
1727028771,
},
{
180,
1727028771,
},
{
180,
1727028771,
},
{
181,
1727028771,
},
{
182,
1727028771,
},
{
183,
1727028771,
},
{
183,
1727028771,
},
{
184,
1727028771,
},
{
184,
1727028771,
},
{
185,
1727028771,
},
{
185,
1727028771,
},
{
48,
1727029280,
},
{
49,
1727029280,
},
{
50,
1727029280,
},
{
51,
1727029280,
},
{
95,
1727029280,
},
{
96,
1727029280,
},
{
97,
1727029280,
},
{
97,
1727029280,
},
{
99,
1727029280,
},
{
100,
1727029280,
},
{
146,
1727029280,
},
{
147,
1727029280,
},
{
147,
1727029280,
},
{
148,
1727029280,
},
{
150,
1727029280,
},
{
151,
1727029280,
},
{
152,
1727029280,
},
{
318,
1727029280,
},
{
319,
1727029280,
},
{
326,
1727029280,
},
{
328,
1727029280,
},
{
328,
1727029280,
},
{
329,
1727029280,
},
{
330,
1727029280,
},
{
331,
1727029280,
},
{
331,
1727029280,
},
{
334,
1727029280,
},
{
340,
1727029280,
},
{
342,
1727029280,
},
{
344,
1727029280,
},
{
346,
1727029280,
},
{
348,
1727029280,
},
{
348,
1727029280,
},
{
349,
1727029280,
},
{
350,
1727029280,
},
{
350,
1727029280,
},
{
351,
1727029280,
},
{
353,
1727029280,
},
{
361,
1727029280,
},
{
362,
1727029280,
},
{
363,
1727029280,
},
{
363,
1727029280,
},
{
364,
1727029280,
},
{
369,
1727029280,
},
{
371,
1727029280,
},
{
373,
1727029280,
},
{
376,
1727029280,
},
{
380,
1727029280,
},
{
382,
1727029280,
},
{
383,
1727029280,
},
{
384,
1727029280,
},
{
384,
1727029280,
},
{
385,
1727029280,
},
{
386,
1727029280,
},
{
387,
1727029280,
},
{
388,
1727029280,
},
{
389,
1727029280,
},
{
390,
1727029280,
},
{
96,
1727535106,
},
{
110,
1727535106,
},
{
146,
1727535106,
},
{
146,
1727535106,
},
{
148,
1727535106,
},
{
148,
1727535106,
},
{
149,
1727535106,
},
{
150,
1727535106,
},
{
151,
1727535106,
},
{
163,
1727535106,
},
{
164,
1727535106,
},
{
165,
1727535106,
},
{
169,
1727535106,
},
{
171,
1727535106,
},
{
171,
1727535106,
},
{
172,
1727535106,
},
{
173,
1727535106,
},
{
177,
1727535106,
},
{
178,
1727535106,
},
{
180,
1727535106,
},
{
181,
1727535106,
},
{
182,
1727535106,
},
{
184,
1727535106,
},
{
214,
1727535106,
},
{
215,
1727535106,
},
{
216,
1727535106,
},
{
217,
1727535106,
},
{
217,
1727535106,
},
{
218,
1727535106,
},
{
219,
1727535106,
},
{
219,
1727535106,
},
{
220,
1727535106,
},
{
221,
1727535106,
},
{
222,
1727535106,
},
{
237,
1727535106,
},
{
238,
1727535106,
},
{
239,
1727535106,
},
{
240,
1727535106,
},
{
242,
1727535106,
},
{
243,
1727535106,
},
{
268,
1727535106,
},
{
287,
1727535106,
},
{
299,
1727535106,
},
{
388,
1727535106,
},
{
403,
1727535106,
},
{
404,
1727535106,
},
{
419,
1727535106,
},
{
420,
1727535106,
},
{
431,
1727535106,
},
{
433,
1727535106,
},
{
433,
1727535106,
},
{
434,
1727535106,
},
{
438,
1727535106,
},
{
439,
1727535106,
},
{
440,
1727535106,
},
{
441,
1727535106,
},
{
442,
1727535106,
},
{
442,
1727535106,
},
{
444,
1727535106,
},
{
445,
1727535106,
},
{
446,
1727535106,
},
{
447,
1727535106,
},
{
453,
1727535106,
},
{
455,
1727535106,
},
{
457,
1727535106,
},
{
458,
1727535106,
},
{
460,
1727535106,
},
{
460,
1727535106,
},
{
461,
1727535106,
},
{
463,
1727535106,
},
{
465,
1727535106,
},
{
466,
1727535106,
},
{
467,
1727535106,
},
{
468,
1727535106,
},
{
468,
1727535106,
},
{
469,
1727535106,
},
{
470,
1727535106,
},
{
471,
1727535106,
},
{
471,
1727535106,
},
{
474,
1727535106,
},
{
474,
1727535106,
},
{
475,
1727535106,
},
{
476,
1727535106,
},
{
477,
1727535106,
},
{
477,
1727535106,
},
{
479,
1727535106,
},
{
480,
1727535106,
},
{
481,
1727535106,
},
{
483,
1727535106,
},
{
483,
1727535106,
},
{
485,
1727535106,
},
{
485,
1727535106,
},
{
486,
1727535106,
},
{
487,
1727535106,
},
{
487,
1727535106,
},
{
488,
1727535106,
},
{
489,
1727535106,
},
{
489,
1727535106,
},
{
490,
1727535106,
},
{
490,
1727535106,
},
{
491,
1727535106,
},
{
492,
1727535106,
},
{
492,
1727535106,
},
{
493,
1727535106,
},
{
494,
1727535106,
},
{
494,
1727535106,
},
{
495,
1727535106,
},
{
496,
1727535106,
},
{
496,
1727535106,
},
{
497,
1727535106,
},
{
497,
1727535106,
},
{
498,
1727535106,
},
{
498,
1727535106,
},
{
499,
1727535106,
},
{
500,
1727535106,
},
{
96,
1727535544,
},
{
100,
1727535544,
},
{
102,
1727535544,
},
{
103,
1727535544,
},
{
104,
1727535544,
},
{
105,
1727535544,
},
{
111,
1727535544,
},
{
119,
1727535544,
},
{
120,
1727535544,
},
{
121,
1727535544,
},
{
121,
1727535544,
},
{
122,
1727535544,
},
{
122,
1727535544,
},
{
124,
1727535544,
},
{
125,
1727535544,
},
{
126,
1727535544,
},
{
126,
1727535544,
},
{
46,
1727536065,
},
{
96,
1727536065,
},
{
112,
1727536065,
},
{
118,
1727536065,
},
{
129,
1727536065,
},
{
143,
1727536065,
},
{
268,
1727536065,
},
{
281,
1727536065,
},
{
282,
1727536065,
},
{
284,
1727536065,
},
{
296,
1727536065,
},
{
298,
1727536065,
},
{
299,
1727536065,
},
{
300,
1727536065,
},
{
301,
1727536065,
},
{
303,
1727536065,
},
{
303,
1727536065,
},
{
304,
1727536065,
},
{
305,
1727536065,
},
{
305,
1727536065,
},
{
306,
1727536065,
},
{
307,
1727536065,
},
{
309,
1727536065,
},
{
309,
1727536065,
},
{
315,
1727536065,
},
{
319,
1727536065,
},
{
320,
1727536065,
},
{
321,
1727536065,
},
{
322,
1727536065,
},
{
322,
1727536065,
},
{
326,
1727536065,
},
{
327,
1727536065,
},
{
328,
1727536065,
},
{
329,
1727536065,
},
{
330,
1727536065,
},
{
331,
1727536065,
},
{
332,
1727536065,
},
{
333,
1727536065,
},
{
334,
1727536065,
},
{
339,
1727536065,
},
{
340,
1727536065,
},
{
341,
1727536065,
},
{
341,
1727536065,
},
{
343,
1727536065,
},
{
347,
1727536065,
},
{
352,
1727536065,
},
{
353,
1727536065,
},
{
359,
1727536065,
},
{
361,
1727536065,
},
{
362,
1727536065,
},
{
366,
1727536065,
},
{
373,
1727536065,
},
{
374,
1727536065,
},
{
376,
1727536065,
},
{
376,
1727536065,
},
{
377,
1727536065,
},
{
378,
1727536065,
},
{
378,
1727536065,
},
{
379,
1727536065,
},
{
380,
1727536065,
},
{
380,
1727536065,
},
{
381,
1727536065,
},
{
382,
1727536065,
},
{
382,
1727536065,
},
{
383,
1727536065,
},
{
383,
1727536065,
},
{
384,
1727536065,
},
{
384,
1727536065,
},
{
385,
1727536065,
},
{
385,
1727536065,
},
{
386,
1727536065,
},
{
386,
1727536065,
},
{
387,
1727536065,
},
{
94,
1727537288,
},
{
95,
1727537288,
},
{
144,
1727537288,
},
{
144,
1727537288,
},
{
145,
1727537288,
},
{
145,
1727537288,
},
{
146,
1727537288,
},
{
217,
1727537288,
},
{
217,
1727537288,
},
{
218,
1727537288,
},
{
218,
1727537288,
},
{
219,
1727537288,
},
{
221,
1727537288,
},
{
222,
1727537288,
},
{
223,
1727537288,
},
{
224,
1727537288,
},
{
237,
1727537288,
},
{
266,
1727537288,
},
{
267,
1727537288,
},
{
267,
1727537288,
},
{
268,
1727537288,
},
{
268,
1727537288,
},
{
270,
1727537288,
},
{
270,
1727537288,
},
{
317,
1727537288,
},
{
318,
1727537288,
},
{
318,
1727537288,
},
{
319,
1727537288,
},
{
320,
1727537288,
},
{
321,
1727537288,
},
{
321,
1727537288,
},
{
322,
1727537288,
},
{
322,
1727537288,
},
{
323,
1727537288,
},
{
323,
1727537288,
},
{
324,
1727537288,
},
{
337,
1727537288,
},
{
340,
1727537288,
},
{
341,
1727537288,
},
{
346,
1727537288,
},
{
347,
1727537288,
},
{
349,
1727537288,
},
{
350,
1727537288,
},
{
351,
1727537288,
},
{
351,
1727537288,
},
{
352,
1727537288,
},
{
352,
1727537288,
},
{
353,
1727537288,
},
{
354,
1727537288,
},
{
354,
1727537288,
},
{
356,
1727537288,
},
{
361,
1727537288,
},
{
364,
1727537288,
},
{
365,
1727537288,
},
{
366,
1727537288,
},
{
366,
1727537288,
},
{
367,
1727537288,
},
{
368,
1727537288,
},
{
369,
1727537288,
},
{
371,
1727537288,
},
{
375,
1727537288,
},
{
376,
1727537288,
},
{
377,
1727537288,
},
{
382,
1727537288,
},
{
382,
1727537288,
},
{
383,
1727537288,
},
{
383,
1727537288,
},
{
384,
1727537288,
},
{
390,
1727537288,
},
{
391,
1727537288,
},
{
392,
1727537288,
},
{
402,
1727537288,
},
{
403,
1727537288,
},
{
404,
1727537288,
},
{
405,
1727537288,
},
{
406,
1727537288,
},
{
407,
1727537288,
},
{
408,
1727537288,
},
{
413,
1727537288,
},
{
413,
1727537288,
},
{
414,
1727537288,
},
{
414,
1727537288,
},
{
416,
1727537288,
},
{
416,
1727537288,
},
{
417,
1727537288,
},
{
418,
1727537288,
},
{
419,
1727537288,
},
{
419,
1727537288,
},
{
420,
1727537288,
},
{
420,
1727537288,
},
{
422,
1727537288,
},
{
423,
1727537288,
},
{
424,
1727537288,
},
{
426,
1727537288,
},
{
427,
1727537288,
},
{
428,
1727537288,
},
{
432,
1727537288,
},
{
433,
1727537288,
},
{
433,
1727537288,
},
{
435,
1727537288,
},
{
441,
1727537288,
},
{
442,
1727537288,
},
{
443,
1727537288,
},
{
447,
1727537288,
},
{
448,
1727537288,
},
{
450,
1727537288,
},
{
450,
1727537288,
},
{
451,
1727537288,
},
{
451,
1727537288,
},
{
452,
1727537288,
},
{
452,
1727537288,
},
{
453,
1727537288,
},
{
453,
1727537288,
},
{
454,
1727537288,
},
{
455,
1727537288,
},
{
456,
1727537288,
},
{
457,
1727537288,
},
{
457,
1727537288,
},
{
458,
1727537288,
},
{
458,
1727537288,
},
{
459,
1727537288,
},
{
459,
1727537288,
},
{
460,
1727537288,
},
{
460,
1727537288,
},
{
461,
1727537288,
},
{
461,
1727537288,
},
{
462,
1727537288,
},
{
462,
1727537288,
},
{
463,
1727537288,
},
{
463,
1727537288,
},
{
464,
1727537288,
},
{
466,
1727537288,
},
{
467,
1727537288,
},
{
468,
1727537288,
},
{
469,
1727537288,
},
{
470,
1727537288,
},
{
471,
1727537288,
},
{
472,
1727537288,
},
{
472,
1727537288,
},
{
473,
1727537288,
},
{
473,
1727537288,
},
{
474,
1727537288,
},
{
474,
1727537288,
},
{
475,
1727537288,
},
{
475,
1727537288,
},
{
476,
1727537288,
},
{
476,
1727537288,
},
{
477,
1727537288,
},
{
477,
1727537288,
},
{
478,
1727537288,
},
{
478,
1727537288,
},
{
479,
1727537288,
},
{
479,
1727537288,
},
{
480,
1727537288,
},
{
480,
1727537288,
},
{
96,
1727538013,
},
{
110,
1727538013,
},
{
111,
1727538013,
},
{
112,
1727538013,
},
{
112,
1727538013,
},
{
146,
1727538013,
},
{
162,
1727538013,
},
{
163,
1727538013,
},
{
214,
1727538013,
},
{
215,
1727538013,
},
{
216,
1727538013,
},
{
217,
1727538013,
},
{
264,
1727538013,
},
{
271,
1727538013,
},
{
283,
1727538013,
},
{
300,
1727538013,
},
{
314,
1727538013,
},
{
315,
1727538013,
},
{
96,
1727538532,
},
{
97,
1727538532,
},
{
112,
1727538532,
},
{
147,
1727538532,
},
{
148,
1727538532,
},
{
150,
1727538532,
},
{
151,
1727538532,
},
{
152,
1727538532,
},
{
153,
1727538532,
},
{
155,
1727538532,
},
{
156,
1727538532,
},
{
214,
1727538532,
},
{
214,
1727538532,
},
{
215,
1727538532,
},
{
216,
1727538532,
},
{
96,
1727539037,
},
{
146,
1727539037,
},
{
214,
1727539037,
},
{
215,
1727539037,
},
{
216,
1727539037,
},
{
217,
1727539037,
},
{
225,
1727539037,
},
{
226,
1727539037,
},
{
227,
1727539037,
},
{
227,
1727539037,
},
{
228,
1727539037,
},
{
230,
1727539037,
},
{
145,
1727539906,
},
{
146,
1727539906,
},
{
147,
1727539906,
},
{
148,
1727539906,
},
{
149,
1727539906,
},
{
150,
1727539906,
},
{
151,
1727539906,
},
{
152,
1727539906,
},
{
95,
1727540620,
},
{
96,
1727540620,
},
{
97,
1727540620,
},
{
99,
1727540620,
},
{
101,
1727540620,
},
{
102,
1727540620,
},
{
103,
1727540620,
},
{
145,
1727540620,
},
{
146,
1727540620,
},
{
147,
1727540620,
},
{
148,
1727540620,
},
{
151,
1727540620,
},
{
215,
1727540620,
},
{
216,
1727540620,
},
{
216,
1727540620,
},
{
218,
1727540620,
},
{
219,
1727540620,
},
{
220,
1727540620,
},
{
221,
1727540620,
},
{
223,
1727540620,
},
{
223,
1727540620,
},
{
224,
1727540620,
},
{
225,
1727540620,
},
{
232,
1727540620,
},
{
266,
1727540620,
},
{
296,
1727540620,
},
{
297,
1727540620,
},
{
298,
1727540620,
},
{
299,
1727540620,
},
{
313,
1727540620,
},
{
316,
1727540620,
},
{
319,
1727540620,
},
{
321,
1727540620,
},
{
343,
1727540620,
},
{
351,
1727540620,
},
{
353,
1727540620,
},
{
360,
1727540620,
},
{
369,
1727540620,
},
{
371,
1727540620,
},
{
372,
1727540620,
},
{
372,
1727540620,
},
{
373,
1727540620,
},
{
373,
1727540620,
},
{
374,
1727540620,
},
{
375,
1727540620,
},
{
376,
1727540620,
},
{
377,
1727540620,
},
{
381,
1727540620,
},
{
383,
1727540620,
},
{
384,
1727540620,
},
{
384,
1727540620,
},
{
385,
1727540620,
},
{
385,
1727540620,
},
{
386,
1727540620,
},
{
388,
1727540620,
},
{
388,
1727540620,
},
{
389,
1727540620,
},
{
96,
1727541370,
},
{
96,
1727541370,
},
{
98,
1727541370,
},
{
99,
1727541370,
},
{
100,
1727541370,
},
{
101,
1727541370,
},
{
103,
1727541370,
},
{
103,
1727541370,
},
{
146,
1727541370,
},
{
147,
1727541370,
},
{
148,
1727541370,
},
{
149,
1727541370,
},
{
150,
1727541370,
},
{
152,
1727541370,
},
{
153,
1727541370,
},
{
215,
1727541370,
},
{
215,
1727541370,
},
{
216,
1727541370,
},
{
217,
1727541370,
},
{
218,
1727541370,
},
{
219,
1727541370,
},
{
219,
1727541370,
},
{
221,
1727541370,
},
{
222,
1727541370,
},
{
223,
1727541370,
},
{
224,
1727541370,
},
{
238,
1727541370,
},
{
240,
1727541370,
},
{
315,
1727541370,
},
{
319,
1727541370,
},
{
320,
1727541370,
},
{
322,
1727541370,
},
{
322,
1727541370,
},
{
324,
1727541370,
},
{
328,
1727541370,
},
{
329,
1727541370,
},
{
330,
1727541370,
},
{
332,
1727541370,
},
{
340,
1727541370,
},
{
344,
1727541370,
},
{
345,
1727541370,
},
{
346,
1727541370,
},
{
347,
1727541370,
},
{
350,
1727541370,
},
{
385,
1727541370,
},
{
410,
1727541370,
},
{
435,
1727541370,
},
{
485,
1727541370,
},
{
486,
1727541370,
},
{
487,
1727541370,
},
{
488,
1727541370,
},
{
496,
1727541370,
},
{
497,
1727541370,
},
{
498,
1727541370,
},
{
499,
1727541370,
},
{
500,
1727541370,
},
{
506,
1727541370,
},
{
507,
1727541370,
},
{
508,
1727541370,
},
{
509,
1727541370,
},
{
510,
1727541370,
},
{
510,
1727541370,
},
{
511,
1727541370,
},
{
511,
1727541370,
},
{
512,
1727541370,
},
{
515,
1727541370,
},
{
516,
1727541370,
},
{
517,
1727541370,
},
{
518,
1727541370,
},
{
519,
1727541370,
},
{
520,
1727541370,
},
{
521,
1727541370,
},
{
521,
1727541370,
},
{
525,
1727541370,
},
{
526,
1727541370,
},
{
527,
1727541370,
},
{
527,
1727541370,
},
{
528,
1727541370,
},
{
529,
1727541370,
},
{
530,
1727541370,
},
{
531,
1727541370,
},
{
93,
1727541980,
},
{
94,
1727541980,
},
{
95,
1727541980,
},
{
97,
1727541980,
},
{
98,
1727541980,
},
{
99,
1727541980,
},
{
144,
1727541980,
},
{
145,
1727541980,
},
{
145,
1727541980,
},
{
147,
1727541980,
},
{
148,
1727541980,
},
{
212,
1727541980,
},
{
212,
1727541980,
},
{
213,
1727541980,
},
{
213,
1727541980,
},
{
215,
1727541980,
},
{
216,
1727541980,
},
{
217,
1727541980,
},
{
218,
1727541980,
},
{
218,
1727541980,
},
{
219,
1727541980,
},
{
262,
1727541980,
},
{
263,
1727541980,
},
{
277,
1727541980,
},
{
278,
1727541980,
},
{
295,
1727541980,
},
{
312,
1727541980,
},
{
313,
1727541980,
},
{
313,
1727541980,
},
{
314,
1727541980,
},
{
316,
1727541980,
},
{
317,
1727541980,
},
{
318,
1727541980,
},
{
322,
1727541980,
},
{
324,
1727541980,
},
{
332,
1727541980,
},
{
381,
1727541980,
},
{
382,
1727541980,
},
{
431,
1727541980,
},
{
432,
1727541980,
},
{
436,
1727541980,
},
{
437,
1727541980,
},
{
438,
1727541980,
},
{
447,
1727541980,
},
{
463,
1727541980,
},
{
479,
1727541980,
},
{
482,
1727541980,
},
{
488,
1727541980,
},
},
["Мутация: прожорливость"] = {
{
245,
1726507531,
},
{
126,
1726507998,
},
{
246,
1726511805,
},
{
75,
1726836034,
},
{
126,
1727016093,
},
{
126,
1727016526,
},
{
127,
1727017314,
},
{
184,
1727028771,
},
{
127,
1727535106,
},
{
474,
1727537288,
},
{
350,
1727538013,
},
{
351,
1727538013,
},
{
468,
1727541370,
},
{
521,
1727541370,
},
{
522,
1727541370,
},
},
["Заражение"] = {
{
304,
1726504232,
},
{
305,
1726504232,
},
{
309,
1726504232,
},
{
330,
1726504934,
},
{
388,
1726504934,
},
{
390,
1726504934,
},
{
396,
1726504934,
},
{
398,
1726504934,
},
{
404,
1726504934,
},
{
407,
1726504934,
},
{
415,
1726504934,
},
{
425,
1726504934,
},
{
426,
1726504934,
},
{
430,
1726504934,
},
{
439,
1726504934,
},
{
440,
1726504934,
},
{
442,
1726504934,
},
{
444,
1726504934,
},
{
450,
1726504934,
},
{
457,
1726504934,
},
{
157,
1726505609,
},
{
153,
1726506330,
},
{
330,
1726506330,
},
{
333,
1726506330,
},
{
400,
1726506330,
},
{
401,
1726506330,
},
{
402,
1726506330,
},
{
428,
1726506330,
},
{
439,
1726506330,
},
{
440,
1726506330,
},
{
452,
1726506330,
},
{
453,
1726506330,
},
{
456,
1726506330,
},
{
461,
1726506330,
},
{
464,
1726506330,
},
{
466,
1726506330,
},
{
468,
1726506330,
},
{
328,
1726507123,
},
{
356,
1726507123,
},
{
371,
1726507123,
},
{
390,
1726507123,
},
{
395,
1726507123,
},
{
149,
1726507531,
},
{
233,
1726507531,
},
{
235,
1726507531,
},
{
249,
1726507531,
},
{
264,
1726507531,
},
{
98,
1726507998,
},
{
148,
1726508742,
},
{
155,
1726508742,
},
{
165,
1726508742,
},
{
177,
1726508742,
},
{
179,
1726508742,
},
{
192,
1726508742,
},
{
193,
1726508742,
},
{
150,
1726509321,
},
{
325,
1726509321,
},
{
150,
1726511805,
},
{
230,
1726511805,
},
{
240,
1726511805,
},
{
251,
1726511805,
},
{
151,
1726514074,
},
{
153,
1726514074,
},
{
157,
1726514074,
},
{
169,
1726514074,
},
{
170,
1726514074,
},
{
175,
1726514074,
},
{
178,
1726514074,
},
{
185,
1726514074,
},
{
188,
1726514074,
},
{
191,
1726514074,
},
{
276,
1726515164,
},
{
291,
1726515164,
},
{
297,
1726515164,
},
{
314,
1726515164,
},
{
322,
1726515164,
},
{
323,
1726515164,
},
{
325,
1726515164,
},
{
327,
1726515164,
},
{
333,
1726515164,
},
{
339,
1726515164,
},
{
340,
1726515164,
},
{
341,
1726515164,
},
{
342,
1726515164,
},
{
357,
1726515164,
},
{
361,
1726515164,
},
{
365,
1726515164,
},
{
373,
1726515164,
},
{
374,
1726515164,
},
{
375,
1726515164,
},
{
376,
1726515164,
},
{
386,
1726515164,
},
{
387,
1726515164,
},
{
390,
1726515164,
},
{
391,
1726515164,
},
{
392,
1726515164,
},
{
395,
1726515164,
},
{
397,
1726515164,
},
{
400,
1726515164,
},
{
402,
1726515164,
},
{
403,
1726515164,
},
{
406,
1726515164,
},
{
408,
1726515164,
},
{
101,
1726516070,
},
{
127,
1726516070,
},
{
442,
1726516070,
},
{
448,
1726516070,
},
{
452,
1726516070,
},
{
453,
1726516070,
},
{
460,
1726516070,
},
{
463,
1726516070,
},
{
464,
1726516070,
},
{
469,
1726516070,
},
{
470,
1726516070,
},
{
475,
1726516070,
},
{
476,
1726516070,
},
{
100,
1726516840,
},
{
152,
1726516840,
},
{
322,
1726516840,
},
{
323,
1726516840,
},
{
345,
1726516840,
},
{
392,
1726516840,
},
{
395,
1726516840,
},
{
155,
1726517715,
},
{
328,
1726517715,
},
{
334,
1726517715,
},
{
393,
1726517715,
},
{
396,
1726517715,
},
{
400,
1726517715,
},
{
417,
1726517715,
},
{
432,
1726517715,
},
{
463,
1726517715,
},
{
481,
1726517715,
},
{
482,
1726517715,
},
{
483,
1726517715,
},
{
485,
1726517715,
},
{
487,
1726517715,
},
{
52,
1726836034,
},
{
74,
1726836034,
},
{
93,
1726836034,
},
{
94,
1726836034,
},
{
102,
1726836034,
},
{
103,
1726836034,
},
{
111,
1726836034,
},
{
114,
1726836034,
},
{
115,
1726836034,
},
{
151,
1726836980,
},
{
155,
1726836980,
},
{
173,
1726836980,
},
{
189,
1726836980,
},
{
203,
1726836980,
},
{
210,
1726836980,
},
{
217,
1726836980,
},
{
218,
1726836980,
},
{
219,
1726836980,
},
{
226,
1726836980,
},
{
238,
1726836980,
},
{
240,
1726836980,
},
{
247,
1726836980,
},
{
255,
1726836980,
},
{
271,
1726836980,
},
{
272,
1726836980,
},
{
276,
1726836980,
},
{
278,
1726836980,
},
{
288,
1726836980,
},
{
302,
1726836980,
},
{
307,
1726836980,
},
{
312,
1726836980,
},
{
313,
1726836980,
},
{
315,
1726836980,
},
{
320,
1726836980,
},
{
323,
1726836980,
},
{
324,
1726836980,
},
{
331,
1726836980,
},
{
337,
1726836980,
},
{
338,
1726836980,
},
{
346,
1726836980,
},
{
347,
1726836980,
},
{
350,
1726836980,
},
{
351,
1726836980,
},
{
353,
1726836980,
},
{
360,
1726836980,
},
{
362,
1726836980,
},
{
365,
1726836980,
},
{
366,
1726836980,
},
{
367,
1726836980,
},
{
150,
1726857543,
},
{
164,
1726857543,
},
{
197,
1726857543,
},
{
215,
1726857543,
},
{
307,
1726857543,
},
{
309,
1726857543,
},
{
383,
1726858252,
},
{
385,
1726858252,
},
{
408,
1726858252,
},
{
433,
1726858252,
},
{
436,
1726858252,
},
{
443,
1726858252,
},
{
444,
1726858252,
},
{
445,
1726858252,
},
{
447,
1726858252,
},
{
448,
1726858252,
},
{
454,
1726858252,
},
{
455,
1726858252,
},
{
456,
1726858252,
},
{
460,
1726858252,
},
{
467,
1726858252,
},
{
149,
1727016526,
},
{
150,
1727016526,
},
{
151,
1727016526,
},
{
163,
1727016526,
},
{
164,
1727016526,
},
{
167,
1727016526,
},
{
168,
1727016526,
},
{
172,
1727016526,
},
{
174,
1727016526,
},
{
199,
1727016989,
},
{
203,
1727016989,
},
{
101,
1727017314,
},
{
107,
1727017314,
},
{
124,
1727017314,
},
{
125,
1727017314,
},
{
145,
1727017314,
},
{
202,
1727018146,
},
{
207,
1727018146,
},
{
216,
1727018146,
},
{
223,
1727018146,
},
{
224,
1727018146,
},
{
100,
1727027680,
},
{
118,
1727027680,
},
{
169,
1727027680,
},
{
197,
1727027680,
},
{
285,
1727027680,
},
{
300,
1727027680,
},
{
414,
1727027680,
},
{
437,
1727027680,
},
{
440,
1727027680,
},
{
443,
1727027680,
},
{
100,
1727028360,
},
{
102,
1727028360,
},
{
114,
1727028360,
},
{
117,
1727028360,
},
{
124,
1727028360,
},
{
125,
1727028360,
},
{
128,
1727028360,
},
{
138,
1727028360,
},
{
139,
1727028360,
},
{
140,
1727028360,
},
{
152,
1727028360,
},
{
153,
1727028360,
},
{
154,
1727028360,
},
{
156,
1727028360,
},
{
157,
1727028360,
},
{
159,
1727028360,
},
{
161,
1727028360,
},
{
167,
1727028360,
},
{
168,
1727028360,
},
{
51,
1727028771,
},
{
52,
1727028771,
},
{
100,
1727028771,
},
{
162,
1727028771,
},
{
165,
1727028771,
},
{
166,
1727028771,
},
{
178,
1727028771,
},
{
181,
1727028771,
},
{
321,
1727029280,
},
{
323,
1727029280,
},
{
336,
1727029280,
},
{
341,
1727029280,
},
{
351,
1727029280,
},
{
357,
1727029280,
},
{
360,
1727029280,
},
{
370,
1727029280,
},
{
382,
1727029280,
},
{
385,
1727029280,
},
{
98,
1727535106,
},
{
152,
1727535106,
},
{
153,
1727535106,
},
{
157,
1727535106,
},
{
159,
1727535106,
},
{
168,
1727535106,
},
{
172,
1727535106,
},
{
202,
1727535106,
},
{
225,
1727535106,
},
{
275,
1727535106,
},
{
292,
1727535106,
},
{
391,
1727535106,
},
{
393,
1727535106,
},
{
406,
1727535106,
},
{
408,
1727535106,
},
{
420,
1727535106,
},
{
430,
1727535106,
},
{
441,
1727535106,
},
{
443,
1727535106,
},
{
449,
1727535106,
},
{
450,
1727535106,
},
{
453,
1727535106,
},
{
459,
1727535106,
},
{
461,
1727535106,
},
{
464,
1727535106,
},
{
465,
1727535106,
},
{
473,
1727535106,
},
{
475,
1727535106,
},
{
478,
1727535106,
},
{
480,
1727535106,
},
{
481,
1727535106,
},
{
486,
1727535106,
},
{
487,
1727535106,
},
{
488,
1727535106,
},
{
492,
1727535106,
},
{
493,
1727535106,
},
{
494,
1727535106,
},
{
497,
1727535106,
},
{
498,
1727535106,
},
{
98,
1727535544,
},
{
106,
1727535544,
},
{
100,
1727536065,
},
{
106,
1727536065,
},
{
117,
1727536065,
},
{
131,
1727536065,
},
{
152,
1727536065,
},
{
269,
1727536065,
},
{
270,
1727536065,
},
{
271,
1727536065,
},
{
285,
1727536065,
},
{
297,
1727536065,
},
{
314,
1727536065,
},
{
315,
1727536065,
},
{
331,
1727536065,
},
{
335,
1727536065,
},
{
340,
1727536065,
},
{
341,
1727536065,
},
{
347,
1727536065,
},
{
349,
1727536065,
},
{
354,
1727536065,
},
{
374,
1727536065,
},
{
375,
1727536065,
},
{
225,
1727537288,
},
{
328,
1727537288,
},
{
329,
1727537288,
},
{
334,
1727537288,
},
{
338,
1727537288,
},
{
349,
1727537288,
},
{
352,
1727537288,
},
{
353,
1727537288,
},
{
354,
1727537288,
},
{
356,
1727537288,
},
{
363,
1727537288,
},
{
364,
1727537288,
},
{
365,
1727537288,
},
{
370,
1727537288,
},
{
371,
1727537288,
},
{
391,
1727537288,
},
{
392,
1727537288,
},
{
394,
1727537288,
},
{
396,
1727537288,
},
{
398,
1727537288,
},
{
402,
1727537288,
},
{
406,
1727537288,
},
{
415,
1727537288,
},
{
419,
1727537288,
},
{
420,
1727537288,
},
{
421,
1727537288,
},
{
428,
1727537288,
},
{
431,
1727537288,
},
{
439,
1727537288,
},
{
440,
1727537288,
},
{
442,
1727537288,
},
{
443,
1727537288,
},
{
447,
1727537288,
},
{
450,
1727537288,
},
{
453,
1727537288,
},
{
454,
1727537288,
},
{
459,
1727537288,
},
{
460,
1727537288,
},
{
461,
1727537288,
},
{
464,
1727537288,
},
{
466,
1727537288,
},
{
468,
1727537288,
},
{
471,
1727537288,
},
{
475,
1727537288,
},
{
476,
1727537288,
},
{
477,
1727537288,
},
{
478,
1727537288,
},
{
479,
1727537288,
},
{
99,
1727538013,
},
{
150,
1727538013,
},
{
271,
1727538013,
},
{
288,
1727538013,
},
{
100,
1727538532,
},
{
218,
1727539037,
},
{
219,
1727539037,
},
{
220,
1727539037,
},
{
224,
1727539037,
},
{
231,
1727539037,
},
{
149,
1727539906,
},
{
152,
1727539906,
},
{
219,
1727540620,
},
{
301,
1727540620,
},
{
331,
1727540620,
},
{
348,
1727540620,
},
{
368,
1727540620,
},
{
369,
1727540620,
},
{
376,
1727540620,
},
{
377,
1727540620,
},
{
379,
1727540620,
},
{
389,
1727540620,
},
{
226,
1727541370,
},
{
227,
1727541370,
},
{
317,
1727541370,
},
{
325,
1727541370,
},
{
328,
1727541370,
},
{
337,
1727541370,
},
{
397,
1727541370,
},
{
506,
1727541370,
},
{
519,
1727541370,
},
{
520,
1727541370,
},
{
522,
1727541370,
},
{
265,
1727541980,
},
{
266,
1727541980,
},
{
283,
1727541980,
},
{
291,
1727541980,
},
{
320,
1727541980,
},
{
435,
1727541980,
},
{
451,
1727541980,
},
{
467,
1727541980,
},
},
["Ленточка Прелести"] = {
{
162,
1726506330,
},
},
["Нестабильная смесь"] = {
{
3,
1726504232,
},
{
37,
1726504232,
},
{
57,
1726504232,
},
{
77,
1726504232,
},
{
97,
1726504232,
},
{
117,
1726504232,
},
{
137,
1726504232,
},
{
157,
1726504232,
},
{
177,
1726504232,
},
{
208,
1726504232,
},
{
228,
1726504232,
},
{
248,
1726504232,
},
{
268,
1726504232,
},
{
288,
1726504232,
},
{
308,
1726504232,
},
{
3,
1726504934,
},
{
37,
1726504934,
},
{
57,
1726504934,
},
{
77,
1726504934,
},
{
97,
1726504934,
},
{
117,
1726504934,
},
{
137,
1726504934,
},
{
157,
1726504934,
},
{
177,
1726504934,
},
{
208,
1726504934,
},
{
228,
1726504934,
},
{
248,
1726504934,
},
{
268,
1726504934,
},
{
288,
1726504934,
},
{
308,
1726504934,
},
{
328,
1726504934,
},
{
348,
1726504934,
},
{
377,
1726504934,
},
{
397,
1726504934,
},
{
417,
1726504934,
},
{
437,
1726504934,
},
{
457,
1726504934,
},
{
3,
1726505199,
},
{
38,
1726505199,
},
{
3,
1726505609,
},
{
37,
1726505609,
},
{
57,
1726505609,
},
{
77,
1726505609,
},
{
97,
1726505609,
},
{
117,
1726505609,
},
{
137,
1726505609,
},
{
157,
1726505609,
},
{
4,
1726506330,
},
{
38,
1726506330,
},
{
58,
1726506330,
},
{
78,
1726506330,
},
{
98,
1726506330,
},
{
118,
1726506330,
},
{
138,
1726506330,
},
{
158,
1726506330,
},
{
178,
1726506330,
},
{
209,
1726506330,
},
{
229,
1726506330,
},
{
249,
1726506330,
},
{
269,
1726506330,
},
{
289,
1726506330,
},
{
309,
1726506330,
},
{
329,
1726506330,
},
{
349,
1726506330,
},
{
380,
1726506330,
},
{
400,
1726506330,
},
{
420,
1726506330,
},
{
440,
1726506330,
},
{
460,
1726506330,
},
{
3,
1726506580,
},
{
36,
1726506580,
},
{
3,
1726507123,
},
{
37,
1726507123,
},
{
57,
1726507123,
},
{
77,
1726507123,
},
{
97,
1726507123,
},
{
117,
1726507123,
},
{
137,
1726507123,
},
{
157,
1726507123,
},
{
177,
1726507123,
},
{
208,
1726507123,
},
{
228,
1726507123,
},
{
248,
1726507123,
},
{
268,
1726507123,
},
{
288,
1726507123,
},
{
308,
1726507123,
},
{
328,
1726507123,
},
{
348,
1726507123,
},
{
379,
1726507123,
},
{
399,
1726507123,
},
{
419,
1726507123,
},
{
3,
1726507531,
},
{
37,
1726507531,
},
{
57,
1726507531,
},
{
77,
1726507531,
},
{
97,
1726507531,
},
{
117,
1726507531,
},
{
137,
1726507531,
},
{
158,
1726507531,
},
{
177,
1726507531,
},
{
207,
1726507531,
},
{
227,
1726507531,
},
{
247,
1726507531,
},
{
267,
1726507531,
},
{
3,
1726507998,
},
{
37,
1726507998,
},
{
57,
1726507998,
},
{
77,
1726507998,
},
{
97,
1726507998,
},
{
117,
1726507998,
},
{
137,
1726507998,
},
{
3,
1726508742,
},
{
37,
1726508742,
},
{
57,
1726508742,
},
{
77,
1726508742,
},
{
97,
1726508742,
},
{
117,
1726508742,
},
{
137,
1726508742,
},
{
157,
1726508742,
},
{
177,
1726508742,
},
{
4,
1726509321,
},
{
39,
1726509321,
},
{
59,
1726509321,
},
{
79,
1726509321,
},
{
99,
1726509321,
},
{
119,
1726509321,
},
{
139,
1726509321,
},
{
159,
1726509321,
},
{
179,
1726509321,
},
{
211,
1726509321,
},
{
231,
1726509321,
},
{
251,
1726509321,
},
{
271,
1726509321,
},
{
291,
1726509321,
},
{
311,
1726509321,
},
{
3,
1726509555,
},
{
38,
1726509555,
},
{
58,
1726509555,
},
{
3,
1726509990,
},
{
37,
1726509990,
},
{
57,
1726509990,
},
{
77,
1726509990,
},
{
3,
1726510946,
},
{
37,
1726510946,
},
{
57,
1726510946,
},
{
77,
1726510946,
},
{
97,
1726510946,
},
{
3,
1726511805,
},
{
37,
1726511805,
},
{
57,
1726511805,
},
{
77,
1726511805,
},
{
97,
1726511805,
},
{
117,
1726511805,
},
{
137,
1726511805,
},
{
157,
1726511805,
},
{
177,
1726511805,
},
{
208,
1726511805,
},
{
228,
1726511805,
},
{
248,
1726511805,
},
{
4,
1726513590,
},
{
39,
1726513590,
},
{
59,
1726513590,
},
{
79,
1726513590,
},
{
99,
1726513590,
},
{
119,
1726513590,
},
{
3,
1726514074,
},
{
38,
1726514074,
},
{
58,
1726514074,
},
{
78,
1726514074,
},
{
98,
1726514074,
},
{
118,
1726514074,
},
{
138,
1726514074,
},
{
158,
1726514074,
},
{
178,
1726514074,
},
{
3,
1726515164,
},
{
39,
1726515164,
},
{
59,
1726515164,
},
{
79,
1726515164,
},
{
99,
1726515164,
},
{
119,
1726515164,
},
{
139,
1726515164,
},
{
159,
1726515164,
},
{
179,
1726515164,
},
{
209,
1726515164,
},
{
229,
1726515164,
},
{
249,
1726515164,
},
{
269,
1726515164,
},
{
289,
1726515164,
},
{
309,
1726515164,
},
{
329,
1726515164,
},
{
349,
1726515164,
},
{
381,
1726515164,
},
{
401,
1726515164,
},
{
3,
1726515435,
},
{
39,
1726515435,
},
{
59,
1726515435,
},
{
79,
1726515435,
},
{
99,
1726515435,
},
{
119,
1726515435,
},
{
139,
1726515435,
},
{
159,
1726515435,
},
{
3,
1726516070,
},
{
39,
1726516070,
},
{
59,
1726516070,
},
{
79,
1726516070,
},
{
99,
1726516070,
},
{
119,
1726516070,
},
{
139,
1726516070,
},
{
159,
1726516070,
},
{
179,
1726516070,
},
{
208,
1726516070,
},
{
228,
1726516070,
},
{
248,
1726516070,
},
{
268,
1726516070,
},
{
288,
1726516070,
},
{
308,
1726516070,
},
{
328,
1726516070,
},
{
348,
1726516070,
},
{
379,
1726516070,
},
{
399,
1726516070,
},
{
419,
1726516070,
},
{
439,
1726516070,
},
{
459,
1726516070,
},
{
4,
1726516840,
},
{
39,
1726516840,
},
{
59,
1726516840,
},
{
79,
1726516840,
},
{
99,
1726516840,
},
{
119,
1726516840,
},
{
139,
1726516840,
},
{
159,
1726516840,
},
{
179,
1726516840,
},
{
208,
1726516840,
},
{
228,
1726516840,
},
{
248,
1726516840,
},
{
268,
1726516840,
},
{
288,
1726516840,
},
{
308,
1726516840,
},
{
328,
1726516840,
},
{
348,
1726516840,
},
{
380,
1726516840,
},
{
400,
1726516840,
},
{
420,
1726516840,
},
{
440,
1726516840,
},
{
3,
1726517121,
},
{
38,
1726517121,
},
{
58,
1726517121,
},
{
3,
1726517715,
},
{
39,
1726517715,
},
{
59,
1726517715,
},
{
79,
1726517715,
},
{
99,
1726517715,
},
{
119,
1726517715,
},
{
139,
1726517715,
},
{
159,
1726517715,
},
{
179,
1726517715,
},
{
211,
1726517715,
},
{
231,
1726517715,
},
{
251,
1726517715,
},
{
271,
1726517715,
},
{
291,
1726517715,
},
{
311,
1726517715,
},
{
331,
1726517715,
},
{
351,
1726517715,
},
{
382,
1726517715,
},
{
402,
1726517715,
},
{
422,
1726517715,
},
{
442,
1726517715,
},
{
462,
1726517715,
},
{
482,
1726517715,
},
{
3,
1726836034,
},
{
37,
1726836034,
},
{
57,
1726836034,
},
{
77,
1726836034,
},
{
97,
1726836034,
},
{
3,
1726836980,
},
{
37,
1726836980,
},
{
57,
1726836980,
},
{
77,
1726836980,
},
{
97,
1726836980,
},
{
117,
1726836980,
},
{
137,
1726836980,
},
{
157,
1726836980,
},
{
177,
1726836980,
},
{
205,
1726836980,
},
{
225,
1726836980,
},
{
245,
1726836980,
},
{
265,
1726836980,
},
{
285,
1726836980,
},
{
305,
1726836980,
},
{
325,
1726836980,
},
{
345,
1726836980,
},
{
3,
1726857543,
},
{
36,
1726857543,
},
{
56,
1726857543,
},
{
76,
1726857543,
},
{
96,
1726857543,
},
{
116,
1726857543,
},
{
136,
1726857543,
},
{
156,
1726857543,
},
{
176,
1726857543,
},
{
205,
1726857543,
},
{
225,
1726857543,
},
{
245,
1726857543,
},
{
265,
1726857543,
},
{
285,
1726857543,
},
{
305,
1726857543,
},
{
3,
1726858252,
},
{
35,
1726858252,
},
{
56,
1726858252,
},
{
76,
1726858252,
},
{
95,
1726858252,
},
{
115,
1726858252,
},
{
135,
1726858252,
},
{
155,
1726858252,
},
{
176,
1726858252,
},
{
203,
1726858252,
},
{
223,
1726858252,
},
{
243,
1726858252,
},
{
263,
1726858252,
},
{
283,
1726858252,
},
{
303,
1726858252,
},
{
323,
1726858252,
},
{
343,
1726858252,
},
{
372,
1726858252,
},
{
392,
1726858252,
},
{
412,
1726858252,
},
{
432,
1726858252,
},
{
452,
1726858252,
},
{
3,
1727016093,
},
{
36,
1727016093,
},
{
56,
1727016093,
},
{
76,
1727016093,
},
{
96,
1727016093,
},
{
116,
1727016093,
},
{
136,
1727016093,
},
{
3,
1727016526,
},
{
36,
1727016526,
},
{
56,
1727016526,
},
{
76,
1727016526,
},
{
96,
1727016526,
},
{
116,
1727016526,
},
{
136,
1727016526,
},
{
156,
1727016526,
},
{
3,
1727016989,
},
{
38,
1727016989,
},
{
58,
1727016989,
},
{
78,
1727016989,
},
{
98,
1727016989,
},
{
118,
1727016989,
},
{
138,
1727016989,
},
{
158,
1727016989,
},
{
178,
1727016989,
},
{
209,
1727016989,
},
{
3,
1727017314,
},
{
38,
1727017314,
},
{
58,
1727017314,
},
{
78,
1727017314,
},
{
98,
1727017314,
},
{
118,
1727017314,
},
{
138,
1727017314,
},
{
3,
1727018146,
},
{
39,
1727018146,
},
{
59,
1727018146,
},
{
79,
1727018146,
},
{
99,
1727018146,
},
{
120,
1727018146,
},
{
150,
1727018146,
},
{
159,
1727018146,
},
{
179,
1727018146,
},
{
210,
1727018146,
},
{
229,
1727018146,
},
{
3,
1727027680,
},
{
38,
1727027680,
},
{
58,
1727027680,
},
{
78,
1727027680,
},
{
98,
1727027680,
},
{
118,
1727027680,
},
{
138,
1727027680,
},
{
158,
1727027680,
},
{
178,
1727027680,
},
{
209,
1727027680,
},
{
229,
1727027680,
},
{
249,
1727027680,
},
{
269,
1727027680,
},
{
289,
1727027680,
},
{
309,
1727027680,
},
{
329,
1727027680,
},
{
349,
1727027680,
},
{
380,
1727027680,
},
{
400,
1727027680,
},
{
420,
1727027680,
},
{
439,
1727027680,
},
{
3,
1727028360,
},
{
40,
1727028360,
},
{
60,
1727028360,
},
{
80,
1727028360,
},
{
100,
1727028360,
},
{
120,
1727028360,
},
{
140,
1727028360,
},
{
160,
1727028360,
},
{
3,
1727028771,
},
{
39,
1727028771,
},
{
59,
1727028771,
},
{
79,
1727028771,
},
{
99,
1727028771,
},
{
119,
1727028771,
},
{
139,
1727028771,
},
{
159,
1727028771,
},
{
3,
1727029280,
},
{
38,
1727029280,
},
{
58,
1727029280,
},
{
78,
1727029280,
},
{
98,
1727029280,
},
{
118,
1727029280,
},
{
138,
1727029280,
},
{
158,
1727029280,
},
{
178,
1727029280,
},
{
210,
1727029280,
},
{
230,
1727029280,
},
{
250,
1727029280,
},
{
270,
1727029280,
},
{
290,
1727029280,
},
{
310,
1727029280,
},
{
330,
1727029280,
},
{
350,
1727029280,
},
{
382,
1727029280,
},
{
3,
1727535106,
},
{
37,
1727535106,
},
{
57,
1727535106,
},
{
77,
1727535106,
},
{
97,
1727535106,
},
{
117,
1727535106,
},
{
137,
1727535106,
},
{
157,
1727535106,
},
{
177,
1727535106,
},
{
209,
1727535106,
},
{
229,
1727535106,
},
{
249,
1727535106,
},
{
269,
1727535106,
},
{
289,
1727535106,
},
{
309,
1727535106,
},
{
329,
1727535106,
},
{
349,
1727535106,
},
{
379,
1727535106,
},
{
399,
1727535106,
},
{
419,
1727535106,
},
{
439,
1727535106,
},
{
459,
1727535106,
},
{
479,
1727535106,
},
{
499,
1727535106,
},
{
3,
1727535544,
},
{
37,
1727535544,
},
{
57,
1727535544,
},
{
77,
1727535544,
},
{
97,
1727535544,
},
{
117,
1727535544,
},
{
3,
1727536065,
},
{
37,
1727536065,
},
{
57,
1727536065,
},
{
77,
1727536065,
},
{
97,
1727536065,
},
{
117,
1727536065,
},
{
137,
1727536065,
},
{
157,
1727536065,
},
{
177,
1727536065,
},
{
209,
1727536065,
},
{
229,
1727536065,
},
{
249,
1727536065,
},
{
269,
1727536065,
},
{
289,
1727536065,
},
{
309,
1727536065,
},
{
329,
1727536065,
},
{
349,
1727536065,
},
{
380,
1727536065,
},
{
3,
1727536600,
},
{
37,
1727536600,
},
{
57,
1727536600,
},
{
77,
1727536600,
},
{
97,
1727536600,
},
{
117,
1727536600,
},
{
137,
1727536600,
},
{
157,
1727536600,
},
{
3,
1727537288,
},
{
36,
1727537288,
},
{
56,
1727537288,
},
{
76,
1727537288,
},
{
96,
1727537288,
},
{
116,
1727537288,
},
{
136,
1727537288,
},
{
156,
1727537288,
},
{
176,
1727537288,
},
{
209,
1727537288,
},
{
229,
1727537288,
},
{
249,
1727537288,
},
{
269,
1727537288,
},
{
289,
1727537288,
},
{
309,
1727537288,
},
{
329,
1727537288,
},
{
349,
1727537288,
},
{
383,
1727537288,
},
{
403,
1727537288,
},
{
423,
1727537288,
},
{
443,
1727537288,
},
{
463,
1727537288,
},
{
3,
1727538013,
},
{
37,
1727538013,
},
{
57,
1727538013,
},
{
77,
1727538013,
},
{
97,
1727538013,
},
{
117,
1727538013,
},
{
137,
1727538013,
},
{
157,
1727538013,
},
{
177,
1727538013,
},
{
205,
1727538013,
},
{
225,
1727538013,
},
{
245,
1727538013,
},
{
266,
1727538013,
},
{
285,
1727538013,
},
{
305,
1727538013,
},
{
325,
1727538013,
},
{
345,
1727538013,
},
{
381,
1727538013,
},
{
3,
1727538532,
},
{
38,
1727538532,
},
{
58,
1727538532,
},
{
78,
1727538532,
},
{
98,
1727538532,
},
{
118,
1727538532,
},
{
138,
1727538532,
},
{
158,
1727538532,
},
{
178,
1727538532,
},
{
205,
1727538532,
},
{
3,
1727539037,
},
{
37,
1727539037,
},
{
57,
1727539037,
},
{
77,
1727539037,
},
{
97,
1727539037,
},
{
117,
1727539037,
},
{
137,
1727539037,
},
{
157,
1727539037,
},
{
177,
1727539037,
},
{
208,
1727539037,
},
{
228,
1727539037,
},
{
3,
1727539906,
},
{
36,
1727539906,
},
{
56,
1727539906,
},
{
76,
1727539906,
},
{
96,
1727539906,
},
{
116,
1727539906,
},
{
136,
1727539906,
},
{
4,
1727540620,
},
{
36,
1727540620,
},
{
56,
1727540620,
},
{
76,
1727540620,
},
{
96,
1727540620,
},
{
116,
1727540620,
},
{
136,
1727540620,
},
{
156,
1727540620,
},
{
176,
1727540620,
},
{
207,
1727540620,
},
{
227,
1727540620,
},
{
247,
1727540620,
},
{
267,
1727540620,
},
{
287,
1727540620,
},
{
307,
1727540620,
},
{
327,
1727540620,
},
{
347,
1727540620,
},
{
378,
1727540620,
},
{
3,
1727541370,
},
{
37,
1727541370,
},
{
57,
1727541370,
},
{
77,
1727541370,
},
{
97,
1727541370,
},
{
117,
1727541370,
},
{
137,
1727541370,
},
{
157,
1727541370,
},
{
177,
1727541370,
},
{
206,
1727541370,
},
{
226,
1727541370,
},
{
246,
1727541370,
},
{
266,
1727541370,
},
{
286,
1727541370,
},
{
306,
1727541370,
},
{
326,
1727541370,
},
{
346,
1727541370,
},
{
376,
1727541370,
},
{
396,
1727541370,
},
{
416,
1727541370,
},
{
436,
1727541370,
},
{
456,
1727541370,
},
{
476,
1727541370,
},
{
496,
1727541370,
},
{
516,
1727541370,
},
{
3,
1727541980,
},
{
36,
1727541980,
},
{
56,
1727541980,
},
{
76,
1727541980,
},
{
96,
1727541980,
},
{
116,
1727541980,
},
{
136,
1727541980,
},
{
156,
1727541980,
},
{
176,
1727541980,
},
{
204,
1727541980,
},
{
224,
1727541980,
},
{
244,
1727541980,
},
{
264,
1727541980,
},
{
284,
1727541980,
},
{
304,
1727541980,
},
{
324,
1727541980,
},
{
344,
1727541980,
},
{
373,
1727541980,
},
{
393,
1727541980,
},
{
413,
1727541980,
},
{
433,
1727541980,
},
{
453,
1727541980,
},
{
473,
1727541980,
},
},
["Кровавый потоп"] = {
{
114,
1726504232,
},
{
144,
1726504232,
},
{
154,
1726504232,
},
{
179,
1726504232,
},
{
214,
1726504232,
},
{
215,
1726504232,
},
{
217,
1726504232,
},
{
289,
1726504232,
},
{
290,
1726504232,
},
{
294,
1726504232,
},
{
305,
1726504232,
},
{
101,
1726504934,
},
{
229,
1726504934,
},
{
230,
1726504934,
},
{
312,
1726504934,
},
{
328,
1726504934,
},
{
330,
1726504934,
},
{
331,
1726504934,
},
{
332,
1726504934,
},
{
334,
1726504934,
},
{
395,
1726504934,
},
{
398,
1726504934,
},
{
399,
1726504934,
},
{
139,
1726505609,
},
{
149,
1726505609,
},
{
151,
1726505609,
},
{
153,
1726505609,
},
{
154,
1726505609,
},
{
155,
1726505609,
},
{
156,
1726505609,
},
{
157,
1726505609,
},
{
158,
1726505609,
},
{
159,
1726505609,
},
{
160,
1726505609,
},
{
161,
1726505609,
},
{
162,
1726505609,
},
{
163,
1726505609,
},
{
164,
1726505609,
},
{
165,
1726505609,
},
{
166,
1726505609,
},
{
167,
1726505609,
},
{
168,
1726505609,
},
{
169,
1726505609,
},
{
170,
1726505609,
},
{
171,
1726505609,
},
{
173,
1726505609,
},
{
174,
1726505609,
},
{
175,
1726505609,
},
{
177,
1726505609,
},
{
178,
1726505609,
},
{
179,
1726505609,
},
{
145,
1726506330,
},
{
146,
1726506330,
},
{
171,
1726506330,
},
{
320,
1726506330,
},
{
325,
1726506330,
},
{
326,
1726506330,
},
{
392,
1726506330,
},
{
393,
1726506330,
},
{
394,
1726506330,
},
{
396,
1726506330,
},
{
398,
1726506330,
},
{
399,
1726506330,
},
{
401,
1726506330,
},
{
403,
1726506330,
},
{
404,
1726506330,
},
{
39,
1726506580,
},
{
44,
1726506580,
},
{
139,
1726507123,
},
{
148,
1726507123,
},
{
151,
1726507123,
},
{
179,
1726507123,
},
{
260,
1726507123,
},
{
330,
1726507123,
},
{
390,
1726507123,
},
{
391,
1726507123,
},
{
392,
1726507123,
},
{
412,
1726507123,
},
{
45,
1726507531,
},
{
47,
1726507531,
},
{
61,
1726507531,
},
{
66,
1726507531,
},
{
128,
1726507531,
},
{
209,
1726507531,
},
{
210,
1726507531,
},
{
247,
1726507531,
},
{
253,
1726507531,
},
{
254,
1726507531,
},
{
256,
1726507531,
},
{
257,
1726507531,
},
{
258,
1726507531,
},
{
260,
1726507531,
},
{
261,
1726507531,
},
{
262,
1726507531,
},
{
264,
1726507531,
},
{
265,
1726507531,
},
{
266,
1726507531,
},
{
268,
1726507531,
},
{
75,
1726507998,
},
{
117,
1726507998,
},
{
118,
1726507998,
},
{
119,
1726507998,
},
{
120,
1726507998,
},
{
121,
1726507998,
},
{
122,
1726507998,
},
{
123,
1726507998,
},
{
124,
1726507998,
},
{
125,
1726507998,
},
{
126,
1726507998,
},
{
128,
1726507998,
},
{
131,
1726507998,
},
{
141,
1726508742,
},
{
142,
1726508742,
},
{
57,
1726509321,
},
{
149,
1726509321,
},
{
150,
1726509321,
},
{
241,
1726509321,
},
{
242,
1726509321,
},
{
275,
1726509321,
},
{
287,
1726509321,
},
{
319,
1726509321,
},
{
322,
1726509321,
},
{
325,
1726509321,
},
{
326,
1726509321,
},
{
61,
1726509555,
},
{
67,
1726509555,
},
{
70,
1726509555,
},
{
74,
1726509555,
},
{
61,
1726509990,
},
{
67,
1726509990,
},
{
71,
1726509990,
},
{
74,
1726509990,
},
{
76,
1726509990,
},
{
78,
1726509990,
},
{
82,
1726509990,
},
{
84,
1726509990,
},
{
85,
1726509990,
},
{
86,
1726509990,
},
{
87,
1726509990,
},
{
100,
1726509990,
},
{
88,
1726510946,
},
{
90,
1726510946,
},
{
249,
1726511805,
},
{
252,
1726511805,
},
{
253,
1726511805,
},
{
254,
1726511805,
},
{
256,
1726511805,
},
{
110,
1726513590,
},
{
112,
1726513590,
},
{
114,
1726513590,
},
{
115,
1726513590,
},
{
116,
1726513590,
},
{
117,
1726513590,
},
{
118,
1726513590,
},
{
119,
1726513590,
},
{
120,
1726513590,
},
{
121,
1726513590,
},
{
122,
1726513590,
},
{
123,
1726513590,
},
{
124,
1726513590,
},
{
125,
1726513590,
},
{
126,
1726513590,
},
{
127,
1726513590,
},
{
129,
1726513590,
},
{
130,
1726513590,
},
{
132,
1726513590,
},
{
136,
1726513590,
},
{
142,
1726514074,
},
{
143,
1726514074,
},
{
159,
1726514074,
},
{
160,
1726514074,
},
{
161,
1726514074,
},
{
162,
1726514074,
},
{
164,
1726514074,
},
{
168,
1726514074,
},
{
170,
1726514074,
},
{
172,
1726514074,
},
{
173,
1726514074,
},
{
176,
1726514074,
},
{
177,
1726514074,
},
{
178,
1726514074,
},
{
180,
1726514074,
},
{
182,
1726514074,
},
{
183,
1726514074,
},
{
184,
1726514074,
},
{
187,
1726514074,
},
{
120,
1726515164,
},
{
144,
1726515164,
},
{
159,
1726515164,
},
{
160,
1726515164,
},
{
229,
1726515164,
},
{
264,
1726515164,
},
{
265,
1726515164,
},
{
292,
1726515164,
},
{
314,
1726515164,
},
{
316,
1726515164,
},
{
317,
1726515164,
},
{
326,
1726515164,
},
{
330,
1726515164,
},
{
343,
1726515164,
},
{
410,
1726515164,
},
{
103,
1726515435,
},
{
106,
1726515435,
},
{
155,
1726515435,
},
{
157,
1726515435,
},
{
158,
1726515435,
},
{
159,
1726515435,
},
{
160,
1726515435,
},
{
161,
1726515435,
},
{
162,
1726515435,
},
{
163,
1726515435,
},
{
164,
1726515435,
},
{
165,
1726515435,
},
{
166,
1726515435,
},
{
167,
1726515435,
},
{
168,
1726515435,
},
{
169,
1726515435,
},
{
170,
1726515435,
},
{
171,
1726515435,
},
{
172,
1726515435,
},
{
173,
1726515435,
},
{
174,
1726515435,
},
{
175,
1726515435,
},
{
176,
1726515435,
},
{
177,
1726515435,
},
{
178,
1726515435,
},
{
179,
1726515435,
},
{
180,
1726515435,
},
{
181,
1726515435,
},
{
182,
1726515435,
},
{
183,
1726515435,
},
{
184,
1726515435,
},
{
185,
1726515435,
},
{
187,
1726515435,
},
{
188,
1726515435,
},
{
282,
1726516070,
},
{
283,
1726516070,
},
{
284,
1726516070,
},
{
285,
1726516070,
},
{
286,
1726516070,
},
{
287,
1726516070,
},
{
288,
1726516070,
},
{
348,
1726516070,
},
{
438,
1726516070,
},
{
148,
1726516840,
},
{
151,
1726516840,
},
{
153,
1726516840,
},
{
287,
1726516840,
},
{
335,
1726516840,
},
{
343,
1726516840,
},
{
345,
1726516840,
},
{
425,
1726516840,
},
{
60,
1726517121,
},
{
61,
1726517121,
},
{
62,
1726517121,
},
{
65,
1726517121,
},
{
67,
1726517121,
},
{
69,
1726517121,
},
{
75,
1726517121,
},
{
113,
1726517715,
},
{
114,
1726517715,
},
{
115,
1726517715,
},
{
137,
1726517715,
},
{
144,
1726517715,
},
{
151,
1726517715,
},
{
152,
1726517715,
},
{
307,
1726517715,
},
{
314,
1726517715,
},
{
315,
1726517715,
},
{
316,
1726517715,
},
{
317,
1726517715,
},
{
319,
1726517715,
},
{
345,
1726517715,
},
{
406,
1726517715,
},
{
408,
1726517715,
},
{
426,
1726517715,
},
{
456,
1726517715,
},
{
485,
1726517715,
},
{
486,
1726517715,
},
{
487,
1726517715,
},
{
488,
1726517715,
},
{
489,
1726517715,
},
{
490,
1726517715,
},
{
492,
1726517715,
},
{
493,
1726517715,
},
{
53,
1726836034,
},
{
89,
1726836034,
},
{
92,
1726836034,
},
{
93,
1726836034,
},
{
94,
1726836034,
},
{
95,
1726836034,
},
{
96,
1726836034,
},
{
97,
1726836034,
},
{
99,
1726836034,
},
{
100,
1726836034,
},
{
101,
1726836034,
},
{
103,
1726836034,
},
{
104,
1726836034,
},
{
105,
1726836034,
},
{
106,
1726836034,
},
{
107,
1726836034,
},
{
108,
1726836034,
},
{
109,
1726836034,
},
{
111,
1726836034,
},
{
112,
1726836034,
},
{
113,
1726836034,
},
{
221,
1726836980,
},
{
226,
1726836980,
},
{
228,
1726836980,
},
{
232,
1726836980,
},
{
335,
1726836980,
},
{
340,
1726836980,
},
{
342,
1726836980,
},
{
343,
1726836980,
},
{
344,
1726836980,
},
{
345,
1726836980,
},
{
346,
1726836980,
},
{
347,
1726836980,
},
{
349,
1726836980,
},
{
217,
1726857543,
},
{
219,
1726857543,
},
{
221,
1726857543,
},
{
226,
1726857543,
},
{
228,
1726857543,
},
{
289,
1726857543,
},
{
311,
1726857543,
},
{
312,
1726857543,
},
{
313,
1726857543,
},
{
315,
1726857543,
},
{
316,
1726857543,
},
{
317,
1726857543,
},
{
318,
1726857543,
},
{
319,
1726857543,
},
{
320,
1726857543,
},
{
322,
1726857543,
},
{
278,
1726858252,
},
{
288,
1726858252,
},
{
302,
1726858252,
},
{
308,
1726858252,
},
{
393,
1726858252,
},
{
449,
1726858252,
},
{
450,
1726858252,
},
{
132,
1727016093,
},
{
135,
1727016093,
},
{
137,
1727016093,
},
{
138,
1727016093,
},
{
139,
1727016093,
},
{
140,
1727016093,
},
{
142,
1727016093,
},
{
143,
1727016093,
},
{
144,
1727016093,
},
{
145,
1727016093,
},
{
146,
1727016093,
},
{
148,
1727016093,
},
{
156,
1727016526,
},
{
169,
1727016526,
},
{
170,
1727016526,
},
{
173,
1727016526,
},
{
54,
1727016989,
},
{
52,
1727017314,
},
{
138,
1727017314,
},
{
139,
1727017314,
},
{
141,
1727017314,
},
{
142,
1727017314,
},
{
143,
1727017314,
},
{
145,
1727017314,
},
{
147,
1727017314,
},
{
151,
1727017314,
},
{
153,
1727017314,
},
{
76,
1727018146,
},
{
173,
1727018146,
},
{
227,
1727018146,
},
{
236,
1727018146,
},
{
237,
1727018146,
},
{
163,
1727027680,
},
{
164,
1727027680,
},
{
279,
1727027680,
},
{
283,
1727027680,
},
{
309,
1727027680,
},
{
310,
1727027680,
},
{
313,
1727027680,
},
{
327,
1727027680,
},
{
398,
1727027680,
},
{
402,
1727027680,
},
{
403,
1727027680,
},
{
435,
1727027680,
},
{
166,
1727028360,
},
{
55,
1727028771,
},
{
56,
1727028771,
},
{
156,
1727028771,
},
{
160,
1727028771,
},
{
167,
1727028771,
},
{
169,
1727028771,
},
{
170,
1727028771,
},
{
171,
1727028771,
},
{
172,
1727028771,
},
{
174,
1727028771,
},
{
177,
1727028771,
},
{
183,
1727028771,
},
{
127,
1727029280,
},
{
241,
1727029280,
},
{
256,
1727029280,
},
{
313,
1727029280,
},
{
314,
1727029280,
},
{
321,
1727029280,
},
{
341,
1727029280,
},
{
342,
1727029280,
},
{
346,
1727029280,
},
{
348,
1727029280,
},
{
382,
1727029280,
},
{
90,
1727535106,
},
{
91,
1727535106,
},
{
92,
1727535106,
},
{
135,
1727535106,
},
{
168,
1727535106,
},
{
173,
1727535106,
},
{
223,
1727535106,
},
{
224,
1727535106,
},
{
230,
1727535106,
},
{
231,
1727535106,
},
{
315,
1727535106,
},
{
320,
1727535106,
},
{
321,
1727535106,
},
{
334,
1727535106,
},
{
336,
1727535106,
},
{
424,
1727535106,
},
{
465,
1727535106,
},
{
466,
1727535106,
},
{
489,
1727535106,
},
{
491,
1727535106,
},
{
498,
1727535106,
},
{
71,
1727535544,
},
{
101,
1727535544,
},
{
103,
1727535544,
},
{
113,
1727535544,
},
{
114,
1727535544,
},
{
115,
1727535544,
},
{
116,
1727535544,
},
{
117,
1727535544,
},
{
118,
1727535544,
},
{
119,
1727535544,
},
{
123,
1727535544,
},
{
273,
1727536065,
},
{
300,
1727536065,
},
{
301,
1727536065,
},
{
304,
1727536065,
},
{
306,
1727536065,
},
{
308,
1727536065,
},
{
332,
1727536065,
},
{
337,
1727536065,
},
{
339,
1727536065,
},
{
53,
1727536600,
},
{
56,
1727536600,
},
{
58,
1727536600,
},
{
59,
1727536600,
},
{
61,
1727536600,
},
{
92,
1727536600,
},
{
93,
1727536600,
},
{
128,
1727536600,
},
{
129,
1727536600,
},
{
130,
1727536600,
},
{
131,
1727536600,
},
{
132,
1727536600,
},
{
133,
1727536600,
},
{
134,
1727536600,
},
{
135,
1727536600,
},
{
136,
1727536600,
},
{
137,
1727536600,
},
{
138,
1727536600,
},
{
139,
1727536600,
},
{
140,
1727536600,
},
{
141,
1727536600,
},
{
142,
1727536600,
},
{
143,
1727536600,
},
{
145,
1727536600,
},
{
148,
1727536600,
},
{
96,
1727537288,
},
{
312,
1727537288,
},
{
315,
1727537288,
},
{
335,
1727537288,
},
{
337,
1727537288,
},
{
344,
1727537288,
},
{
345,
1727537288,
},
{
347,
1727537288,
},
{
348,
1727537288,
},
{
349,
1727537288,
},
{
352,
1727537288,
},
{
353,
1727537288,
},
{
354,
1727537288,
},
{
355,
1727537288,
},
{
393,
1727537288,
},
{
401,
1727537288,
},
{
403,
1727537288,
},
{
407,
1727537288,
},
{
450,
1727537288,
},
{
451,
1727537288,
},
{
452,
1727537288,
},
{
468,
1727537288,
},
{
135,
1727538013,
},
{
214,
1727538013,
},
{
224,
1727538013,
},
{
282,
1727538013,
},
{
283,
1727538013,
},
{
303,
1727538013,
},
{
309,
1727538013,
},
{
310,
1727538013,
},
{
311,
1727538013,
},
{
354,
1727538013,
},
{
363,
1727538013,
},
{
365,
1727538013,
},
{
366,
1727538013,
},
{
367,
1727538013,
},
{
369,
1727538013,
},
{
370,
1727538013,
},
{
371,
1727538013,
},
{
213,
1727538532,
},
{
214,
1727538532,
},
{
215,
1727538532,
},
{
216,
1727538532,
},
{
217,
1727538532,
},
{
218,
1727538532,
},
{
48,
1727540620,
},
{
50,
1727540620,
},
{
57,
1727540620,
},
{
299,
1727540620,
},
{
302,
1727540620,
},
{
304,
1727540620,
},
{
305,
1727540620,
},
{
326,
1727540620,
},
{
46,
1727541370,
},
{
153,
1727541370,
},
{
390,
1727541370,
},
{
392,
1727541370,
},
{
465,
1727541370,
},
{
495,
1727541370,
},
{
496,
1727541370,
},
{
505,
1727541370,
},
{
510,
1727541370,
},
{
514,
1727541370,
},
{
517,
1727541370,
},
{
519,
1727541370,
},
{
523,
1727541370,
},
{
38,
1727541980,
},
{
139,
1727541980,
},
{
304,
1727541980,
},
{
307,
1727541980,
},
{
309,
1727541980,
},
{
311,
1727541980,
},
{
313,
1727541980,
},
{
314,
1727541980,
},
{
315,
1727541980,
},
{
317,
1727541980,
},
{
318,
1727541980,
},
{
319,
1727541980,
},
{
320,
1727541980,
},
{
416,
1727541980,
},
{
420,
1727541980,
},
},
["Кислотная реакция"] = {
{
297,
1726504232,
},
{
469,
1726506330,
},
{
126,
1726507998,
},
{
181,
1726508742,
},
{
183,
1726508742,
},
{
128,
1726513590,
},
{
183,
1726514074,
},
{
184,
1726515435,
},
{
470,
1726516070,
},
{
471,
1726517715,
},
{
74,
1726836034,
},
{
295,
1726836980,
},
{
296,
1726857543,
},
{
73,
1727016093,
},
{
125,
1727016093,
},
{
125,
1727016526,
},
{
126,
1727016526,
},
{
182,
1727016989,
},
{
126,
1727017314,
},
{
185,
1727018146,
},
{
131,
1727028360,
},
{
130,
1727028771,
},
{
183,
1727028771,
},
{
354,
1727029280,
},
{
127,
1727535106,
},
{
300,
1727535106,
},
{
75,
1727535544,
},
{
183,
1727536065,
},
{
300,
1727536065,
},
{
180,
1727537288,
},
{
474,
1727537288,
},
{
349,
1727538013,
},
{
351,
1727538013,
},
{
127,
1727538532,
},
{
126,
1727540620,
},
{
296,
1727540620,
},
{
350,
1727540620,
},
{
468,
1727541370,
},
{
513,
1727541370,
},
{
521,
1727541370,
},
},
["Мутация: некротизация"] = {
{
152,
1726505609,
},
{
159,
1726505609,
},
{
121,
1726507998,
},
{
184,
1726508742,
},
{
323,
1726509321,
},
{
129,
1726513590,
},
{
184,
1726514074,
},
{
157,
1726515435,
},
{
470,
1726516070,
},
{
68,
1726517121,
},
{
320,
1726857543,
},
{
74,
1727016093,
},
{
126,
1727016526,
},
{
183,
1727016989,
},
{
153,
1727017314,
},
{
131,
1727028360,
},
{
130,
1727028771,
},
{
164,
1727028771,
},
{
355,
1727029280,
},
{
300,
1727535106,
},
{
75,
1727535544,
},
{
114,
1727535544,
},
{
183,
1727536065,
},
{
181,
1727537288,
},
{
128,
1727538532,
},
{
126,
1727540620,
},
{
514,
1727541370,
},
},
["Липкая паутина"] = {
{
14,
1726504232,
},
{
49,
1726504232,
},
{
79,
1726504232,
},
{
109,
1726504232,
},
{
139,
1726504232,
},
{
169,
1726504232,
},
{
219,
1726504232,
},
{
249,
1726504232,
},
{
279,
1726504232,
},
{
309,
1726504232,
},
{
14,
1726504934,
},
{
49,
1726504934,
},
{
79,
1726504934,
},
{
109,
1726504934,
},
{
139,
1726504934,
},
{
169,
1726504934,
},
{
219,
1726504934,
},
{
249,
1726504934,
},
{
279,
1726504934,
},
{
309,
1726504934,
},
{
339,
1726504934,
},
{
388,
1726504934,
},
{
418,
1726504934,
},
{
448,
1726504934,
},
{
15,
1726505199,
},
{
14,
1726505609,
},
{
49,
1726505609,
},
{
79,
1726505609,
},
{
109,
1726505609,
},
{
139,
1726505609,
},
{
169,
1726505609,
},
{
15,
1726506330,
},
{
49,
1726506330,
},
{
79,
1726506330,
},
{
109,
1726506330,
},
{
139,
1726506330,
},
{
169,
1726506330,
},
{
221,
1726506330,
},
{
251,
1726506330,
},
{
281,
1726506330,
},
{
311,
1726506330,
},
{
341,
1726506330,
},
{
391,
1726506330,
},
{
421,
1726506330,
},
{
451,
1726506330,
},
{
14,
1726506580,
},
{
47,
1726506580,
},
{
15,
1726507123,
},
{
49,
1726507123,
},
{
79,
1726507123,
},
{
109,
1726507123,
},
{
139,
1726507123,
},
{
169,
1726507123,
},
{
220,
1726507123,
},
{
250,
1726507123,
},
{
280,
1726507123,
},
{
310,
1726507123,
},
{
340,
1726507123,
},
{
390,
1726507123,
},
{
420,
1726507123,
},
{
15,
1726507531,
},
{
49,
1726507531,
},
{
79,
1726507531,
},
{
109,
1726507531,
},
{
139,
1726507531,
},
{
169,
1726507531,
},
{
218,
1726507531,
},
{
248,
1726507531,
},
{
278,
1726507531,
},
{
15,
1726507998,
},
{
49,
1726507998,
},
{
79,
1726507998,
},
{
109,
1726507998,
},
{
139,
1726507998,
},
{
14,
1726508742,
},
{
49,
1726508742,
},
{
79,
1726508742,
},
{
109,
1726508742,
},
{
139,
1726508742,
},
{
169,
1726508742,
},
{
15,
1726509321,
},
{
51,
1726509321,
},
{
81,
1726509321,
},
{
111,
1726509321,
},
{
141,
1726509321,
},
{
171,
1726509321,
},
{
222,
1726509321,
},
{
252,
1726509321,
},
{
282,
1726509321,
},
{
312,
1726509321,
},
{
14,
1726509555,
},
{
49,
1726509555,
},
{
15,
1726509990,
},
{
49,
1726509990,
},
{
79,
1726509990,
},
{
109,
1726509990,
},
{
14,
1726510946,
},
{
48,
1726510946,
},
{
78,
1726510946,
},
{
14,
1726511805,
},
{
48,
1726511805,
},
{
78,
1726511805,
},
{
108,
1726511805,
},
{
138,
1726511805,
},
{
168,
1726511805,
},
{
220,
1726511805,
},
{
250,
1726511805,
},
{
15,
1726513590,
},
{
51,
1726513590,
},
{
81,
1726513590,
},
{
111,
1726513590,
},
{
141,
1726513590,
},
{
15,
1726514074,
},
{
50,
1726514074,
},
{
80,
1726514074,
},
{
110,
1726514074,
},
{
140,
1726514074,
},
{
170,
1726514074,
},
{
15,
1726515164,
},
{
50,
1726515164,
},
{
80,
1726515164,
},
{
110,
1726515164,
},
{
140,
1726515164,
},
{
170,
1726515164,
},
{
221,
1726515164,
},
{
251,
1726515164,
},
{
281,
1726515164,
},
{
311,
1726515164,
},
{
341,
1726515164,
},
{
392,
1726515164,
},
{
15,
1726515435,
},
{
50,
1726515435,
},
{
80,
1726515435,
},
{
110,
1726515435,
},
{
140,
1726515435,
},
{
170,
1726515435,
},
{
15,
1726516070,
},
{
50,
1726516070,
},
{
80,
1726516070,
},
{
110,
1726516070,
},
{
140,
1726516070,
},
{
170,
1726516070,
},
{
219,
1726516070,
},
{
249,
1726516070,
},
{
280,
1726516070,
},
{
309,
1726516070,
},
{
339,
1726516070,
},
{
390,
1726516070,
},
{
420,
1726516070,
},
{
450,
1726516070,
},
{
15,
1726516840,
},
{
50,
1726516840,
},
{
80,
1726516840,
},
{
110,
1726516840,
},
{
140,
1726516840,
},
{
170,
1726516840,
},
{
219,
1726516840,
},
{
249,
1726516840,
},
{
280,
1726516840,
},
{
309,
1726516840,
},
{
339,
1726516840,
},
{
391,
1726516840,
},
{
421,
1726516840,
},
{
15,
1726517121,
},
{
50,
1726517121,
},
{
15,
1726517715,
},
{
51,
1726517715,
},
{
81,
1726517715,
},
{
111,
1726517715,
},
{
141,
1726517715,
},
{
171,
1726517715,
},
{
222,
1726517715,
},
{
252,
1726517715,
},
{
282,
1726517715,
},
{
312,
1726517715,
},
{
342,
1726517715,
},
{
394,
1726517715,
},
{
424,
1726517715,
},
{
454,
1726517715,
},
{
484,
1726517715,
},
{
14,
1726836034,
},
{
48,
1726836034,
},
{
78,
1726836034,
},
{
108,
1726836034,
},
{
14,
1726836980,
},
{
48,
1726836980,
},
{
78,
1726836980,
},
{
108,
1726836980,
},
{
138,
1726836980,
},
{
168,
1726836980,
},
{
217,
1726836980,
},
{
247,
1726836980,
},
{
277,
1726836980,
},
{
307,
1726836980,
},
{
337,
1726836980,
},
{
14,
1726857543,
},
{
47,
1726857543,
},
{
78,
1726857543,
},
{
107,
1726857543,
},
{
137,
1726857543,
},
{
168,
1726857543,
},
{
216,
1726857543,
},
{
246,
1726857543,
},
{
276,
1726857543,
},
{
306,
1726857543,
},
{
14,
1726858252,
},
{
47,
1726858252,
},
{
77,
1726858252,
},
{
107,
1726858252,
},
{
137,
1726858252,
},
{
167,
1726858252,
},
{
215,
1726858252,
},
{
245,
1726858252,
},
{
275,
1726858252,
},
{
305,
1726858252,
},
{
335,
1726858252,
},
{
384,
1726858252,
},
{
414,
1726858252,
},
{
444,
1726858252,
},
{
14,
1727016093,
},
{
47,
1727016093,
},
{
77,
1727016093,
},
{
107,
1727016093,
},
{
137,
1727016093,
},
{
15,
1727016526,
},
{
47,
1727016526,
},
{
77,
1727016526,
},
{
107,
1727016526,
},
{
137,
1727016526,
},
{
167,
1727016526,
},
{
14,
1727016989,
},
{
49,
1727016989,
},
{
79,
1727016989,
},
{
109,
1727016989,
},
{
139,
1727016989,
},
{
169,
1727016989,
},
{
14,
1727017314,
},
{
49,
1727017314,
},
{
79,
1727017314,
},
{
109,
1727017314,
},
{
139,
1727017314,
},
{
15,
1727018146,
},
{
50,
1727018146,
},
{
80,
1727018146,
},
{
110,
1727018146,
},
{
151,
1727018146,
},
{
171,
1727018146,
},
{
221,
1727018146,
},
{
14,
1727027680,
},
{
49,
1727027680,
},
{
79,
1727027680,
},
{
109,
1727027680,
},
{
139,
1727027680,
},
{
169,
1727027680,
},
{
221,
1727027680,
},
{
251,
1727027680,
},
{
281,
1727027680,
},
{
311,
1727027680,
},
{
341,
1727027680,
},
{
391,
1727027680,
},
{
421,
1727027680,
},
{
451,
1727027680,
},
{
15,
1727028360,
},
{
51,
1727028360,
},
{
81,
1727028360,
},
{
111,
1727028360,
},
{
141,
1727028360,
},
{
14,
1727028771,
},
{
50,
1727028771,
},
{
80,
1727028771,
},
{
110,
1727028771,
},
{
140,
1727028771,
},
{
170,
1727028771,
},
{
14,
1727029280,
},
{
49,
1727029280,
},
{
79,
1727029280,
},
{
109,
1727029280,
},
{
139,
1727029280,
},
{
169,
1727029280,
},
{
221,
1727029280,
},
{
251,
1727029280,
},
{
281,
1727029280,
},
{
311,
1727029280,
},
{
341,
1727029280,
},
{
15,
1727535106,
},
{
49,
1727535106,
},
{
79,
1727535106,
},
{
109,
1727535106,
},
{
139,
1727535106,
},
{
169,
1727535106,
},
{
220,
1727535106,
},
{
250,
1727535106,
},
{
280,
1727535106,
},
{
310,
1727535106,
},
{
340,
1727535106,
},
{
391,
1727535106,
},
{
421,
1727535106,
},
{
451,
1727535106,
},
{
481,
1727535106,
},
{
14,
1727535544,
},
{
49,
1727535544,
},
{
79,
1727535544,
},
{
109,
1727535544,
},
{
15,
1727536065,
},
{
49,
1727536065,
},
{
79,
1727536065,
},
{
109,
1727536065,
},
{
139,
1727536065,
},
{
169,
1727536065,
},
{
220,
1727536065,
},
{
250,
1727536065,
},
{
280,
1727536065,
},
{
310,
1727536065,
},
{
340,
1727536065,
},
{
14,
1727536600,
},
{
49,
1727536600,
},
{
79,
1727536600,
},
{
109,
1727536600,
},
{
139,
1727536600,
},
{
15,
1727537288,
},
{
47,
1727537288,
},
{
77,
1727537288,
},
{
107,
1727537288,
},
{
137,
1727537288,
},
{
167,
1727537288,
},
{
220,
1727537288,
},
{
250,
1727537288,
},
{
280,
1727537288,
},
{
310,
1727537288,
},
{
340,
1727537288,
},
{
394,
1727537288,
},
{
424,
1727537288,
},
{
454,
1727537288,
},
{
15,
1727538013,
},
{
49,
1727538013,
},
{
79,
1727538013,
},
{
109,
1727538013,
},
{
139,
1727538013,
},
{
169,
1727538013,
},
{
217,
1727538013,
},
{
247,
1727538013,
},
{
277,
1727538013,
},
{
307,
1727538013,
},
{
337,
1727538013,
},
{
15,
1727538532,
},
{
49,
1727538532,
},
{
79,
1727538532,
},
{
109,
1727538532,
},
{
139,
1727538532,
},
{
169,
1727538532,
},
{
216,
1727538532,
},
{
15,
1727539037,
},
{
49,
1727539037,
},
{
79,
1727539037,
},
{
109,
1727539037,
},
{
139,
1727539037,
},
{
169,
1727539037,
},
{
219,
1727539037,
},
{
15,
1727539906,
},
{
47,
1727539906,
},
{
77,
1727539906,
},
{
107,
1727539906,
},
{
137,
1727539906,
},
{
15,
1727540620,
},
{
48,
1727540620,
},
{
78,
1727540620,
},
{
108,
1727540620,
},
{
138,
1727540620,
},
{
168,
1727540620,
},
{
218,
1727540620,
},
{
248,
1727540620,
},
{
278,
1727540620,
},
{
308,
1727540620,
},
{
338,
1727540620,
},
{
390,
1727540620,
},
{
15,
1727541370,
},
{
49,
1727541370,
},
{
79,
1727541370,
},
{
109,
1727541370,
},
{
139,
1727541370,
},
{
169,
1727541370,
},
{
218,
1727541370,
},
{
248,
1727541370,
},
{
278,
1727541370,
},
{
308,
1727541370,
},
{
338,
1727541370,
},
{
388,
1727541370,
},
{
418,
1727541370,
},
{
448,
1727541370,
},
{
478,
1727541370,
},
{
508,
1727541370,
},
{
14,
1727541980,
},
{
47,
1727541980,
},
{
77,
1727541980,
},
{
107,
1727541980,
},
{
137,
1727541980,
},
{
167,
1727541980,
},
{
215,
1727541980,
},
{
245,
1727541980,
},
{
275,
1727541980,
},
{
305,
1727541980,
},
{
335,
1727541980,
},
{
384,
1727541980,
},
{
414,
1727541980,
},
{
444,
1727541980,
},
{
474,
1727541980,
},
},
["Глоток черной крови"] = {
{
19,
1726504232,
},
{
189,
1726504232,
},
{
19,
1726504934,
},
{
189,
1726504934,
},
{
358,
1726504934,
},
{
20,
1726505199,
},
{
19,
1726505609,
},
{
19,
1726506330,
},
{
191,
1726506330,
},
{
361,
1726506330,
},
{
17,
1726506580,
},
{
19,
1726507123,
},
{
190,
1726507123,
},
{
360,
1726507123,
},
{
19,
1726507531,
},
{
188,
1726507531,
},
{
19,
1726507998,
},
{
19,
1726508742,
},
{
190,
1726508742,
},
{
21,
1726509321,
},
{
192,
1726509321,
},
{
19,
1726509555,
},
{
19,
1726509990,
},
{
18,
1726510946,
},
{
18,
1726511805,
},
{
190,
1726511805,
},
{
21,
1726513590,
},
{
20,
1726514074,
},
{
20,
1726515164,
},
{
191,
1726515164,
},
{
362,
1726515164,
},
{
20,
1726515435,
},
{
20,
1726516070,
},
{
189,
1726516070,
},
{
360,
1726516070,
},
{
20,
1726516840,
},
{
189,
1726516840,
},
{
361,
1726516840,
},
{
20,
1726517121,
},
{
21,
1726517715,
},
{
192,
1726517715,
},
{
364,
1726517715,
},
{
18,
1726836034,
},
{
18,
1726836980,
},
{
187,
1726836980,
},
{
358,
1726836980,
},
{
17,
1726857543,
},
{
186,
1726857543,
},
{
17,
1726858252,
},
{
185,
1726858252,
},
{
354,
1726858252,
},
{
17,
1727016093,
},
{
17,
1727016526,
},
{
19,
1727016989,
},
{
191,
1727016989,
},
{
19,
1727017314,
},
{
20,
1727018146,
},
{
190,
1727018146,
},
{
19,
1727027680,
},
{
191,
1727027680,
},
{
361,
1727027680,
},
{
21,
1727028360,
},
{
20,
1727028771,
},
{
19,
1727029280,
},
{
191,
1727029280,
},
{
363,
1727029280,
},
{
19,
1727535106,
},
{
190,
1727535106,
},
{
361,
1727535106,
},
{
19,
1727535544,
},
{
19,
1727536065,
},
{
190,
1727536065,
},
{
362,
1727536065,
},
{
19,
1727536600,
},
{
17,
1727537288,
},
{
190,
1727537288,
},
{
364,
1727537288,
},
{
19,
1727538013,
},
{
187,
1727538013,
},
{
362,
1727538013,
},
{
19,
1727538532,
},
{
186,
1727538532,
},
{
19,
1727539037,
},
{
189,
1727539037,
},
{
17,
1727539906,
},
{
18,
1727540620,
},
{
188,
1727540620,
},
{
360,
1727540620,
},
{
18,
1727541370,
},
{
188,
1727541370,
},
{
358,
1727541370,
},
{
17,
1727541980,
},
{
185,
1727541980,
},
{
354,
1727541980,
},
},
["Экспериментальная доза"] = {
{
35,
1726504232,
},
{
85,
1726504232,
},
{
135,
1726504232,
},
{
206,
1726504232,
},
{
256,
1726504232,
},
{
306,
1726504232,
},
{
35,
1726504934,
},
{
85,
1726504934,
},
{
135,
1726504934,
},
{
206,
1726504934,
},
{
256,
1726504934,
},
{
306,
1726504934,
},
{
375,
1726504934,
},
{
425,
1726504934,
},
{
36,
1726505199,
},
{
35,
1726505609,
},
{
85,
1726505609,
},
{
135,
1726505609,
},
{
36,
1726506330,
},
{
86,
1726506330,
},
{
136,
1726506330,
},
{
207,
1726506330,
},
{
257,
1726506330,
},
{
307,
1726506330,
},
{
378,
1726506330,
},
{
428,
1726506330,
},
{
34,
1726506580,
},
{
35,
1726507123,
},
{
85,
1726507123,
},
{
135,
1726507123,
},
{
206,
1726507123,
},
{
256,
1726507123,
},
{
306,
1726507123,
},
{
377,
1726507123,
},
{
427,
1726507123,
},
{
35,
1726507531,
},
{
85,
1726507531,
},
{
135,
1726507531,
},
{
205,
1726507531,
},
{
255,
1726507531,
},
{
35,
1726507998,
},
{
85,
1726507998,
},
{
135,
1726507998,
},
{
35,
1726508742,
},
{
85,
1726508742,
},
{
135,
1726508742,
},
{
37,
1726509321,
},
{
87,
1726509321,
},
{
137,
1726509321,
},
{
209,
1726509321,
},
{
259,
1726509321,
},
{
309,
1726509321,
},
{
36,
1726509555,
},
{
35,
1726509990,
},
{
85,
1726509990,
},
{
35,
1726510946,
},
{
85,
1726510946,
},
{
35,
1726511805,
},
{
85,
1726511805,
},
{
135,
1726511805,
},
{
206,
1726511805,
},
{
256,
1726511805,
},
{
37,
1726513590,
},
{
87,
1726513590,
},
{
137,
1726513590,
},
{
36,
1726514074,
},
{
86,
1726514074,
},
{
136,
1726514074,
},
{
37,
1726515164,
},
{
87,
1726515164,
},
{
137,
1726515164,
},
{
207,
1726515164,
},
{
257,
1726515164,
},
{
307,
1726515164,
},
{
379,
1726515164,
},
{
37,
1726515435,
},
{
87,
1726515435,
},
{
137,
1726515435,
},
{
37,
1726516070,
},
{
87,
1726516070,
},
{
137,
1726516070,
},
{
206,
1726516070,
},
{
256,
1726516070,
},
{
306,
1726516070,
},
{
377,
1726516070,
},
{
427,
1726516070,
},
{
37,
1726516840,
},
{
87,
1726516840,
},
{
137,
1726516840,
},
{
206,
1726516840,
},
{
256,
1726516840,
},
{
306,
1726516840,
},
{
378,
1726516840,
},
{
428,
1726516840,
},
{
36,
1726517121,
},
{
37,
1726517715,
},
{
87,
1726517715,
},
{
137,
1726517715,
},
{
209,
1726517715,
},
{
259,
1726517715,
},
{
309,
1726517715,
},
{
380,
1726517715,
},
{
430,
1726517715,
},
{
480,
1726517715,
},
{
35,
1726836034,
},
{
85,
1726836034,
},
{
35,
1726836980,
},
{
85,
1726836980,
},
{
135,
1726836980,
},
{
203,
1726836980,
},
{
253,
1726836980,
},
{
303,
1726836980,
},
{
34,
1726857543,
},
{
84,
1726857543,
},
{
134,
1726857543,
},
{
203,
1726857543,
},
{
253,
1726857543,
},
{
303,
1726857543,
},
{
33,
1726858252,
},
{
84,
1726858252,
},
{
133,
1726858252,
},
{
201,
1726858252,
},
{
251,
1726858252,
},
{
301,
1726858252,
},
{
370,
1726858252,
},
{
420,
1726858252,
},
{
34,
1727016093,
},
{
83,
1727016093,
},
{
134,
1727016093,
},
{
34,
1727016526,
},
{
84,
1727016526,
},
{
134,
1727016526,
},
{
36,
1727016989,
},
{
86,
1727016989,
},
{
136,
1727016989,
},
{
207,
1727016989,
},
{
36,
1727017314,
},
{
86,
1727017314,
},
{
136,
1727017314,
},
{
37,
1727018146,
},
{
87,
1727018146,
},
{
148,
1727018146,
},
{
207,
1727018146,
},
{
36,
1727027680,
},
{
86,
1727027680,
},
{
136,
1727027680,
},
{
207,
1727027680,
},
{
257,
1727027680,
},
{
307,
1727027680,
},
{
377,
1727027680,
},
{
427,
1727027680,
},
{
38,
1727028360,
},
{
88,
1727028360,
},
{
138,
1727028360,
},
{
37,
1727028771,
},
{
87,
1727028771,
},
{
137,
1727028771,
},
{
36,
1727029280,
},
{
86,
1727029280,
},
{
136,
1727029280,
},
{
208,
1727029280,
},
{
258,
1727029280,
},
{
308,
1727029280,
},
{
380,
1727029280,
},
{
35,
1727535106,
},
{
85,
1727535106,
},
{
135,
1727535106,
},
{
207,
1727535106,
},
{
257,
1727535106,
},
{
307,
1727535106,
},
{
377,
1727535106,
},
{
427,
1727535106,
},
{
477,
1727535106,
},
{
35,
1727535544,
},
{
85,
1727535544,
},
{
35,
1727536065,
},
{
85,
1727536065,
},
{
135,
1727536065,
},
{
207,
1727536065,
},
{
257,
1727536065,
},
{
307,
1727536065,
},
{
378,
1727536065,
},
{
35,
1727536600,
},
{
85,
1727536600,
},
{
135,
1727536600,
},
{
34,
1727537288,
},
{
84,
1727537288,
},
{
134,
1727537288,
},
{
207,
1727537288,
},
{
257,
1727537288,
},
{
307,
1727537288,
},
{
381,
1727537288,
},
{
431,
1727537288,
},
{
35,
1727538013,
},
{
85,
1727538013,
},
{
135,
1727538013,
},
{
203,
1727538013,
},
{
253,
1727538013,
},
{
303,
1727538013,
},
{
379,
1727538013,
},
{
36,
1727538532,
},
{
86,
1727538532,
},
{
136,
1727538532,
},
{
203,
1727538532,
},
{
35,
1727539037,
},
{
85,
1727539037,
},
{
135,
1727539037,
},
{
206,
1727539037,
},
{
34,
1727539906,
},
{
84,
1727539906,
},
{
134,
1727539906,
},
{
34,
1727540620,
},
{
84,
1727540620,
},
{
134,
1727540620,
},
{
205,
1727540620,
},
{
255,
1727540620,
},
{
305,
1727540620,
},
{
376,
1727540620,
},
{
35,
1727541370,
},
{
85,
1727541370,
},
{
135,
1727541370,
},
{
204,
1727541370,
},
{
254,
1727541370,
},
{
304,
1727541370,
},
{
374,
1727541370,
},
{
424,
1727541370,
},
{
474,
1727541370,
},
{
34,
1727541980,
},
{
84,
1727541980,
},
{
134,
1727541980,
},
{
202,
1727541980,
},
{
252,
1727541980,
},
{
302,
1727541980,
},
{
371,
1727541980,
},
{
421,
1727541980,
},
{
471,
1727541980,
},
},
["Мутация: ускорение"] = {
{
298,
1726504232,
},
{
299,
1726504232,
},
{
307,
1726504232,
},
{
330,
1726504934,
},
{
175,
1726505609,
},
{
330,
1726506330,
},
{
464,
1726506330,
},
{
470,
1726506330,
},
{
474,
1726506330,
},
{
266,
1726507531,
},
{
182,
1726508742,
},
{
183,
1726508742,
},
{
185,
1726508742,
},
{
324,
1726509321,
},
{
329,
1726509321,
},
{
330,
1726509321,
},
{
251,
1726511805,
},
{
252,
1726511805,
},
{
170,
1726514074,
},
{
177,
1726514074,
},
{
183,
1726514074,
},
{
186,
1726514074,
},
{
187,
1726514074,
},
{
188,
1726514074,
},
{
191,
1726514074,
},
{
308,
1726515164,
},
{
329,
1726515164,
},
{
338,
1726515164,
},
{
363,
1726515164,
},
{
185,
1726515435,
},
{
186,
1726515435,
},
{
188,
1726515435,
},
{
472,
1726516070,
},
{
335,
1726516840,
},
{
336,
1726516840,
},
{
337,
1726516840,
},
{
340,
1726516840,
},
{
472,
1726517715,
},
{
473,
1726517715,
},
{
490,
1726517715,
},
{
491,
1726517715,
},
{
493,
1726517715,
},
{
98,
1726836034,
},
{
100,
1726836034,
},
{
101,
1726836034,
},
{
102,
1726836034,
},
{
107,
1726836034,
},
{
110,
1726836034,
},
{
111,
1726836034,
},
{
114,
1726836034,
},
{
115,
1726836034,
},
{
116,
1726836034,
},
{
229,
1726836980,
},
{
296,
1726836980,
},
{
298,
1726836980,
},
{
301,
1726836980,
},
{
315,
1726836980,
},
{
324,
1726836980,
},
{
328,
1726836980,
},
{
330,
1726836980,
},
{
335,
1726836980,
},
{
339,
1726836980,
},
{
340,
1726836980,
},
{
341,
1726836980,
},
{
347,
1726836980,
},
{
350,
1726836980,
},
{
351,
1726836980,
},
{
352,
1726836980,
},
{
353,
1726836980,
},
{
355,
1726836980,
},
{
360,
1726836980,
},
{
369,
1726836980,
},
{
222,
1726857543,
},
{
297,
1726857543,
},
{
300,
1726857543,
},
{
303,
1726857543,
},
{
320,
1726857543,
},
{
321,
1726857543,
},
{
323,
1726857543,
},
{
446,
1726858252,
},
{
448,
1726858252,
},
{
456,
1726858252,
},
{
458,
1726858252,
},
{
466,
1726858252,
},
{
146,
1727016093,
},
{
147,
1727016093,
},
{
170,
1727016526,
},
{
175,
1727016526,
},
{
178,
1727016526,
},
{
183,
1727016989,
},
{
144,
1727017314,
},
{
151,
1727017314,
},
{
154,
1727017314,
},
{
186,
1727018146,
},
{
188,
1727018146,
},
{
229,
1727018146,
},
{
182,
1727027680,
},
{
169,
1727028360,
},
{
156,
1727028771,
},
{
160,
1727028771,
},
{
169,
1727028771,
},
{
173,
1727028771,
},
{
180,
1727028771,
},
{
181,
1727028771,
},
{
326,
1727029280,
},
{
328,
1727029280,
},
{
342,
1727029280,
},
{
348,
1727029280,
},
{
389,
1727029280,
},
{
163,
1727535106,
},
{
471,
1727535106,
},
{
483,
1727535106,
},
{
485,
1727535106,
},
{
494,
1727535106,
},
{
500,
1727535106,
},
{
124,
1727535544,
},
{
301,
1727536065,
},
{
303,
1727536065,
},
{
306,
1727536065,
},
{
339,
1727536065,
},
{
341,
1727536065,
},
{
319,
1727537288,
},
{
320,
1727537288,
},
{
321,
1727537288,
},
{
322,
1727537288,
},
{
337,
1727537288,
},
{
349,
1727537288,
},
{
460,
1727537288,
},
{
474,
1727537288,
},
{
475,
1727537288,
},
{
477,
1727537288,
},
{
478,
1727537288,
},
{
480,
1727537288,
},
{
271,
1727538013,
},
{
296,
1727540620,
},
{
297,
1727540620,
},
{
319,
1727540620,
},
{
351,
1727540620,
},
{
324,
1727541370,
},
{
332,
1727541370,
},
{
496,
1727541370,
},
{
506,
1727541370,
},
{
510,
1727541370,
},
{
519,
1727541370,
},
{
525,
1727541370,
},
{
527,
1727541370,
},
{
530,
1727541370,
},
{
531,
1727541370,
},
{
316,
1727541980,
},
{
322,
1727541980,
},
{
488,
1727541980,
},
},
},
["2920-14"] = {
["Раздирание Бездны"] = {
{
11,
1726085481,
},
{
12,
1726085481,
},
{
41,
1726085481,
},
{
42,
1726085481,
},
{
71,
1726085481,
},
{
72,
1726085481,
},
{
12,
1726085846,
},
{
12,
1726085846,
},
{
13,
1726085846,
},
{
42,
1726085846,
},
{
42,
1726085846,
},
{
43,
1726085846,
},
{
72,
1726085846,
},
{
72,
1726085846,
},
{
73,
1726085846,
},
{
142,
1726085846,
},
{
142,
1726085846,
},
{
143,
1726085846,
},
{
172,
1726085846,
},
{
172,
1726085846,
},
{
173,
1726085846,
},
{
202,
1726085846,
},
{
202,
1726085846,
},
{
203,
1726085846,
},
{
11,
1726697102,
},
{
12,
1726697102,
},
{
41,
1726697102,
},
{
42,
1726697102,
},
{
71,
1726697102,
},
{
72,
1726697102,
},
{
141,
1726697102,
},
{
142,
1726697102,
},
{
171,
1726697102,
},
{
172,
1726697102,
},
},
["Ликвидация"] = {
{
8,
1726085481,
},
{
15,
1726085481,
},
{
16,
1726085481,
},
{
9,
1726085846,
},
{
16,
1726085846,
},
{
17,
1726085846,
},
{
139,
1726085846,
},
{
146,
1726085846,
},
{
147,
1726085846,
},
{
148,
1726085846,
},
{
8,
1726697102,
},
{
16,
1726697102,
},
{
16,
1726697102,
},
{
17,
1726697102,
},
{
138,
1726697102,
},
{
146,
1726697102,
},
{
146,
1726697102,
},
{
147,
1726697102,
},
},
["Беззвездная ночь"] = {
{
101,
1726085481,
},
{
101,
1726085846,
},
{
231,
1726085846,
},
{
101,
1726697102,
},
},
["Кинжалы Нексуса"] = {
{
47,
1726085481,
},
{
48,
1726085481,
},
{
49,
1726085481,
},
{
77,
1726085481,
},
{
78,
1726085481,
},
{
79,
1726085481,
},
{
48,
1726085846,
},
{
49,
1726085846,
},
{
50,
1726085846,
},
{
78,
1726085846,
},
{
79,
1726085846,
},
{
80,
1726085846,
},
{
178,
1726085846,
},
{
179,
1726085846,
},
{
180,
1726085846,
},
{
181,
1726085846,
},
{
208,
1726085846,
},
{
209,
1726085846,
},
{
210,
1726085846,
},
{
211,
1726085846,
},
{
47,
1726697102,
},
{
48,
1726697102,
},
{
49,
1726697102,
},
{
77,
1726697102,
},
{
78,
1726697102,
},
{
79,
1726697102,
},
},
["Жнец"] = {
{
0,
1726085481,
},
{
0,
1726085846,
},
{
0,
1726697102,
},
},
["Разлом Пустоты"] = {
{
26,
1726085481,
},
{
26,
1726085481,
},
{
56,
1726085481,
},
{
56,
1726085481,
},
{
86,
1726085481,
},
{
86,
1726085481,
},
{
26,
1726085846,
},
{
26,
1726085846,
},
{
27,
1726085846,
},
{
56,
1726085846,
},
{
56,
1726085846,
},
{
57,
1726085846,
},
{
86,
1726085846,
},
{
86,
1726085846,
},
{
87,
1726085846,
},
{
156,
1726085846,
},
{
156,
1726085846,
},
{
157,
1726085846,
},
{
186,
1726085846,
},
{
186,
1726085846,
},
{
187,
1726085846,
},
{
216,
1726085846,
},
{
216,
1726085846,
},
{
217,
1726085846,
},
{
26,
1726697102,
},
{
26,
1726697102,
},
{
56,
1726697102,
},
{
56,
1726697102,
},
{
86,
1726697102,
},
{
86,
1726697102,
},
{
156,
1726697102,
},
{
156,
1726697102,
},
},
["Сумеречная резня"] = {
{
34,
1726085481,
},
{
35,
1726085481,
},
{
40,
1726085481,
},
{
64,
1726085481,
},
{
65,
1726085481,
},
{
70,
1726085481,
},
{
35,
1726085846,
},
{
36,
1726085846,
},
{
41,
1726085846,
},
{
65,
1726085846,
},
{
66,
1726085846,
},
{
71,
1726085846,
},
{
165,
1726085846,
},
{
166,
1726085846,
},
{
171,
1726085846,
},
{
195,
1726085846,
},
{
196,
1726085846,
},
{
201,
1726085846,
},
{
34,
1726697102,
},
{
35,
1726697102,
},
{
36,
1726697102,
},
{
40,
1726697102,
},
{
41,
1726697102,
},
{
64,
1726697102,
},
{
65,
1726697102,
},
{
66,
1726697102,
},
{
70,
1726697102,
},
{
71,
1726697102,
},
{
164,
1726697102,
},
{
165,
1726697102,
},
{
166,
1726697102,
},
{
170,
1726697102,
},
{
171,
1726697102,
},
},
},
["2902-15"] = {
["Тяжелое сокрушение"] = {
{
95,
1726344199,
},
{
96,
1726344199,
},
{
265,
1726344199,
},
{
266,
1726344199,
},
{
94,
1726832646,
},
{
95,
1726832646,
},
{
260,
1726832646,
},
{
261,
1726832646,
},
{
95,
1727531633,
},
{
96,
1727531633,
},
{
95,
1727876381,
},
{
96,
1727876381,
},
{
266,
1727876381,
},
},
["Скрежещущий рой"] = {
{
99,
1726344199,
},
{
270,
1726344199,
},
{
98,
1726832646,
},
{
264,
1726832646,
},
{
100,
1727531633,
},
{
100,
1727876381,
},
},
["Паутина ловчего"] = {
{
11,
1726344199,
},
{
56,
1726344199,
},
{
181,
1726344199,
},
{
226,
1726344199,
},
{
349,
1726344199,
},
{
394,
1726344199,
},
{
10,
1726832646,
},
{
55,
1726832646,
},
{
177,
1726832646,
},
{
222,
1726832646,
},
{
56,
1727530807,
},
{
12,
1727531633,
},
{
57,
1727531633,
},
{
178,
1727531633,
},
{
223,
1727531633,
},
{
11,
1727876381,
},
{
56,
1727876381,
},
{
182,
1727876381,
},
{
227,
1727876381,
},
},
["Ядовитая плеть"] = {
{
7,
1726344199,
},
{
31,
1726344199,
},
{
60,
1726344199,
},
{
177,
1726344199,
},
{
202,
1726344199,
},
{
230,
1726344199,
},
{
345,
1726344199,
},
{
370,
1726344199,
},
{
398,
1726344199,
},
{
6,
1726832646,
},
{
31,
1726832646,
},
{
59,
1726832646,
},
{
172,
1726832646,
},
{
197,
1726832646,
},
{
225,
1726832646,
},
{
6,
1727530807,
},
{
31,
1727530807,
},
{
59,
1727530807,
},
{
7,
1727531633,
},
{
32,
1727531633,
},
{
60,
1727531633,
},
{
173,
1727531633,
},
{
198,
1727531633,
},
{
226,
1727531633,
},
{
7,
1727876381,
},
{
32,
1727876381,
},
{
60,
1727876381,
},
{
178,
1727876381,
},
{
203,
1727876381,
},
{
231,
1727876381,
},
},
["Безжалостное сокрушение"] = {
{
3,
1726344199,
},
{
18,
1726344199,
},
{
33,
1726344199,
},
{
52,
1726344199,
},
{
67,
1726344199,
},
{
174,
1726344199,
},
{
188,
1726344199,
},
{
203,
1726344199,
},
{
222,
1726344199,
},
{
238,
1726344199,
},
{
341,
1726344199,
},
{
356,
1726344199,
},
{
371,
1726344199,
},
{
390,
1726344199,
},
{
405,
1726344199,
},
{
3,
1726832646,
},
{
18,
1726832646,
},
{
33,
1726832646,
},
{
52,
1726832646,
},
{
67,
1726832646,
},
{
169,
1726832646,
},
{
184,
1726832646,
},
{
199,
1726832646,
},
{
218,
1726832646,
},
{
233,
1726832646,
},
{
3,
1727530807,
},
{
18,
1727530807,
},
{
33,
1727530807,
},
{
67,
1727530807,
},
{
4,
1727531633,
},
{
19,
1727531633,
},
{
34,
1727531633,
},
{
53,
1727531633,
},
{
68,
1727531633,
},
{
170,
1727531633,
},
{
185,
1727531633,
},
{
200,
1727531633,
},
{
219,
1727531633,
},
{
234,
1727531633,
},
{
4,
1727876381,
},
{
19,
1727876381,
},
{
34,
1727876381,
},
{
53,
1727876381,
},
{
68,
1727876381,
},
{
175,
1727876381,
},
{
190,
1727876381,
},
{
205,
1727876381,
},
{
224,
1727876381,
},
{
239,
1727876381,
},
},
["Желудочный сок"] = {
{
16,
1726344199,
},
{
64,
1726344199,
},
{
187,
1726344199,
},
{
234,
1726344199,
},
{
355,
1726344199,
},
{
402,
1726344199,
},
{
16,
1726832646,
},
{
63,
1726832646,
},
{
182,
1726832646,
},
{
229,
1726832646,
},
{
16,
1727530807,
},
{
63,
1727530807,
},
{
17,
1727531633,
},
{
64,
1727531633,
},
{
183,
1727531633,
},
{
230,
1727531633,
},
{
17,
1727876381,
},
{
64,
1727876381,
},
{
188,
1727876381,
},
{
235,
1727876381,
},
},
["Голодный рев"] = {
{
154,
1726344199,
},
{
161,
1726344199,
},
{
324,
1726344199,
},
{
331,
1726344199,
},
{
153,
1726832646,
},
{
160,
1726832646,
},
{
155,
1727531633,
},
{
162,
1727531633,
},
{
155,
1727876381,
},
{
162,
1727876381,
},
},
["Игра хищника"] = {
{
34,
1726344199,
},
{
70,
1726344199,
},
{
204,
1726344199,
},
{
240,
1726344199,
},
{
372,
1726344199,
},
{
408,
1726344199,
},
{
33,
1726832646,
},
{
69,
1726832646,
},
{
199,
1726832646,
},
{
235,
1726832646,
},
{
33,
1727530807,
},
{
34,
1727531633,
},
{
70,
1727531633,
},
{
200,
1727531633,
},
{
236,
1727531633,
},
{
34,
1727876381,
},
{
70,
1727876381,
},
{
205,
1727876381,
},
{
241,
1727876381,
},
},
["Потрошение"] = {
{
117,
1726344199,
},
{
121,
1726344199,
},
{
131,
1726344199,
},
{
132,
1726344199,
},
{
134,
1726344199,
},
{
135,
1726344199,
},
{
137,
1726344199,
},
{
138,
1726344199,
},
{
291,
1726344199,
},
{
294,
1726344199,
},
{
296,
1726344199,
},
{
299,
1726344199,
},
{
300,
1726344199,
},
{
301,
1726344199,
},
{
304,
1726344199,
},
{
306,
1726344199,
},
{
308,
1726344199,
},
{
309,
1726344199,
},
{
310,
1726344199,
},
{
311,
1726344199,
},
{
313,
1726344199,
},
{
119,
1726832646,
},
{
120,
1726832646,
},
{
124,
1726832646,
},
{
131,
1726832646,
},
{
134,
1726832646,
},
{
137,
1726832646,
},
{
121,
1727531633,
},
{
122,
1727531633,
},
{
127,
1727531633,
},
{
128,
1727531633,
},
{
131,
1727531633,
},
{
136,
1727531633,
},
{
142,
1727531633,
},
{
118,
1727876381,
},
{
121,
1727876381,
},
{
123,
1727876381,
},
{
134,
1727876381,
},
{
135,
1727876381,
},
{
136,
1727876381,
},
},
["Смена фаз"] = {
{
90,
1726344199,
},
{
166,
1726344199,
},
{
260,
1726344199,
},
{
332,
1726344199,
},
{
89,
1726832646,
},
{
161,
1726832646,
},
{
255,
1726832646,
},
{
90,
1727531633,
},
{
162,
1727531633,
},
{
256,
1727531633,
},
{
90,
1727876381,
},
{
166,
1727876381,
},
{
261,
1727876381,
},
},
["Поглощающий мрак"] = {
{
142,
1726344199,
},
{
312,
1726344199,
},
{
141,
1726832646,
},
{
143,
1727531633,
},
{
143,
1727876381,
},
},
["Неумолимый рывок"] = {
{
106,
1726344199,
},
{
110,
1726344199,
},
{
117,
1726344199,
},
{
124,
1726344199,
},
{
132,
1726344199,
},
{
277,
1726344199,
},
{
281,
1726344199,
},
{
288,
1726344199,
},
{
296,
1726344199,
},
{
303,
1726344199,
},
{
105,
1726832646,
},
{
110,
1726832646,
},
{
117,
1726832646,
},
{
124,
1726832646,
},
{
131,
1726832646,
},
{
107,
1727531633,
},
{
112,
1727531633,
},
{
119,
1727531633,
},
{
126,
1727531633,
},
{
133,
1727531633,
},
{
107,
1727876381,
},
{
112,
1727876381,
},
{
119,
1727876381,
},
{
126,
1727876381,
},
{
133,
1727876381,
},
},
},
["2918-16"] = {
["Кислотный град"] = {
{
57,
1728497799,
},
{
61,
1728497799,
},
{
58,
1728498129,
},
{
62,
1728498129,
},
{
66,
1728498129,
},
{
68,
1728498129,
},
{
127,
1728498129,
},
{
132,
1728498129,
},
{
58,
1728498656,
},
{
62,
1728498656,
},
{
66,
1728498656,
},
{
68,
1728498656,
},
{
128,
1728498656,
},
{
132,
1728498656,
},
{
193,
1728498656,
},
{
198,
1728498656,
},
{
258,
1728498656,
},
{
262,
1728498656,
},
{
323,
1728498656,
},
{
328,
1728498656,
},
{
58,
1728498979,
},
{
63,
1728498979,
},
{
123,
1728498979,
},
{
127,
1728498979,
},
{
58,
1728499400,
},
{
63,
1728499400,
},
{
123,
1728499400,
},
{
128,
1728499400,
},
{
58,
1728499776,
},
{
63,
1728499776,
},
{
123,
1728499776,
},
{
128,
1728499776,
},
{
189,
1728499776,
},
{
195,
1728499776,
},
{
57,
1728500430,
},
{
61,
1728500430,
},
{
122,
1728500430,
},
{
127,
1728500430,
},
{
188,
1728500430,
},
{
194,
1728500430,
},
{
57,
1728501203,
},
{
61,
1728501203,
},
{
122,
1728501203,
},
{
127,
1728501203,
},
{
187,
1728501203,
},
{
192,
1728501203,
},
{
197,
1728501203,
},
{
57,
1728501746,
},
{
62,
1728501746,
},
{
122,
1728501746,
},
{
126,
1728501746,
},
{
58,
1728502026,
},
{
62,
1728502026,
},
{
123,
1728502026,
},
{
127,
1728502026,
},
{
57,
1728502338,
},
{
61,
1728502338,
},
{
122,
1728502338,
},
{
127,
1728502338,
},
{
57,
1728503126,
},
{
62,
1728503126,
},
{
123,
1728503126,
},
{
128,
1728503126,
},
{
187,
1728503126,
},
{
194,
1728503126,
},
{
198,
1728503126,
},
{
200,
1728503126,
},
{
57,
1728503478,
},
{
62,
1728503478,
},
{
123,
1728503478,
},
{
128,
1728503478,
},
{
133,
1728503478,
},
{
134,
1728503478,
},
{
195,
1728503478,
},
{
200,
1728503478,
},
{
205,
1728503478,
},
{
58,
1729976741,
},
{
62,
1729976741,
},
{
123,
1729976741,
},
{
128,
1729976741,
},
{
188,
1729976741,
},
{
194,
1729976741,
},
{
58,
1729977227,
},
{
62,
1729977227,
},
{
123,
1729977227,
},
{
128,
1729977227,
},
{
189,
1729977227,
},
{
194,
1729977227,
},
{
255,
1729977227,
},
{
259,
1729977227,
},
{
58,
1729977688,
},
{
62,
1729977688,
},
{
122,
1729977688,
},
{
127,
1729977688,
},
{
187,
1729977688,
},
{
193,
1729977688,
},
{
197,
1729977688,
},
{
199,
1729977688,
},
{
58,
1729978056,
},
{
61,
1729978056,
},
{
122,
1729978056,
},
{
126,
1729978056,
},
{
187,
1729978056,
},
{
192,
1729978056,
},
{
253,
1729978056,
},
{
257,
1729978056,
},
{
262,
1729978056,
},
{
263,
1729978056,
},
{
58,
1729978241,
},
{
63,
1729978241,
},
{
67,
1729978241,
},
{
69,
1729978241,
},
{
58,
1729978683,
},
{
62,
1729978683,
},
{
122,
1729978683,
},
{
126,
1729978683,
},
{
186,
1729978683,
},
{
192,
1729978683,
},
{
252,
1729978683,
},
{
257,
1729978683,
},
{
318,
1729978683,
},
{
322,
1729978683,
},
},
["Зараженный укус"] = {
{
24,
1728497799,
},
{
83,
1728497799,
},
{
89,
1728497799,
},
{
90,
1728497799,
},
{
24,
1728498129,
},
{
25,
1728498129,
},
{
89,
1728498129,
},
{
90,
1728498129,
},
{
98,
1728498129,
},
{
104,
1728498129,
},
{
24,
1728498656,
},
{
25,
1728498656,
},
{
31,
1728498656,
},
{
90,
1728498656,
},
{
96,
1728498656,
},
{
219,
1728498656,
},
{
220,
1728498656,
},
{
225,
1728498656,
},
{
226,
1728498656,
},
{
227,
1728498656,
},
{
231,
1728498656,
},
{
232,
1728498656,
},
{
234,
1728498656,
},
{
238,
1728498656,
},
{
239,
1728498656,
},
{
240,
1728498656,
},
{
245,
1728498656,
},
{
246,
1728498656,
},
{
252,
1728498656,
},
{
285,
1728498656,
},
{
292,
1728498656,
},
{
293,
1728498656,
},
{
310,
1728498656,
},
{
317,
1728498656,
},
{
24,
1728498979,
},
{
25,
1728498979,
},
{
85,
1728498979,
},
{
90,
1728498979,
},
{
91,
1728498979,
},
{
24,
1728499400,
},
{
25,
1728499400,
},
{
85,
1728499400,
},
{
86,
1728499400,
},
{
92,
1728499400,
},
{
24,
1728499776,
},
{
25,
1728499776,
},
{
26,
1728499776,
},
{
85,
1728499776,
},
{
86,
1728499776,
},
{
91,
1728499776,
},
{
92,
1728499776,
},
{
24,
1728500430,
},
{
84,
1728500430,
},
{
90,
1728500430,
},
{
95,
1728500430,
},
{
96,
1728500430,
},
{
24,
1728501203,
},
{
83,
1728501203,
},
{
84,
1728501203,
},
{
89,
1728501203,
},
{
95,
1728501203,
},
{
101,
1728501203,
},
{
108,
1728501203,
},
{
24,
1728501746,
},
{
30,
1728501746,
},
{
84,
1728501746,
},
{
85,
1728501746,
},
{
90,
1728501746,
},
{
91,
1728501746,
},
{
96,
1728501746,
},
{
97,
1728501746,
},
{
24,
1728502026,
},
{
25,
1728502026,
},
{
31,
1728502026,
},
{
84,
1728502026,
},
{
85,
1728502026,
},
{
90,
1728502026,
},
{
91,
1728502026,
},
{
24,
1728502338,
},
{
84,
1728502338,
},
{
89,
1728502338,
},
{
90,
1728502338,
},
{
95,
1728502338,
},
{
96,
1728502338,
},
{
102,
1728502338,
},
{
24,
1728503126,
},
{
25,
1728503126,
},
{
30,
1728503126,
},
{
85,
1728503126,
},
{
90,
1728503126,
},
{
91,
1728503126,
},
{
92,
1728503126,
},
{
24,
1728503478,
},
{
25,
1728503478,
},
{
85,
1728503478,
},
{
86,
1728503478,
},
{
91,
1728503478,
},
{
92,
1728503478,
},
{
25,
1729976741,
},
{
85,
1729976741,
},
{
86,
1729976741,
},
{
216,
1729976741,
},
{
217,
1729976741,
},
{
223,
1729976741,
},
{
236,
1729976741,
},
{
237,
1729976741,
},
{
242,
1729976741,
},
{
247,
1729976741,
},
{
249,
1729976741,
},
{
250,
1729976741,
},
{
24,
1729977227,
},
{
25,
1729977227,
},
{
85,
1729977227,
},
{
216,
1729977227,
},
{
217,
1729977227,
},
{
223,
1729977227,
},
{
236,
1729977227,
},
{
237,
1729977227,
},
{
243,
1729977227,
},
{
244,
1729977227,
},
{
24,
1729977688,
},
{
25,
1729977688,
},
{
84,
1729977688,
},
{
85,
1729977688,
},
{
92,
1729977688,
},
{
25,
1729978056,
},
{
83,
1729978056,
},
{
84,
1729978056,
},
{
91,
1729978056,
},
{
215,
1729978056,
},
{
235,
1729978056,
},
{
240,
1729978056,
},
{
241,
1729978056,
},
{
242,
1729978056,
},
{
247,
1729978056,
},
{
248,
1729978056,
},
{
253,
1729978056,
},
{
255,
1729978056,
},
{
259,
1729978056,
},
{
25,
1729978241,
},
{
31,
1729978241,
},
{
24,
1729978683,
},
{
25,
1729978683,
},
{
84,
1729978683,
},
{
90,
1729978683,
},
{
214,
1729978683,
},
{
215,
1729978683,
},
{
234,
1729978683,
},
{
235,
1729978683,
},
{
242,
1729978683,
},
{
279,
1729978683,
},
{
280,
1729978683,
},
{
304,
1729978683,
},
{
305,
1729978683,
},
},
["Разлив кислоты"] = {
{
36,
1728497799,
},
{
37,
1728498129,
},
{
112,
1728498129,
},
{
153,
1728498129,
},
{
37,
1728498656,
},
{
112,
1728498656,
},
{
152,
1728498656,
},
{
287,
1728498656,
},
{
37,
1728498979,
},
{
107,
1728498979,
},
{
37,
1728499400,
},
{
108,
1728499400,
},
{
148,
1728499400,
},
{
37,
1728499776,
},
{
108,
1728499776,
},
{
149,
1728499776,
},
{
37,
1728500430,
},
{
106,
1728500430,
},
{
148,
1728500430,
},
{
36,
1728501203,
},
{
106,
1728501203,
},
{
147,
1728501203,
},
{
36,
1728501746,
},
{
107,
1728501746,
},
{
37,
1728502026,
},
{
107,
1728502026,
},
{
148,
1728502026,
},
{
36,
1728502338,
},
{
106,
1728502338,
},
{
147,
1728502338,
},
{
36,
1728503126,
},
{
107,
1728503126,
},
{
147,
1728503126,
},
{
37,
1728503478,
},
{
108,
1728503478,
},
{
154,
1728503478,
},
{
37,
1729976741,
},
{
108,
1729976741,
},
{
147,
1729976741,
},
{
37,
1729977227,
},
{
107,
1729977227,
},
{
148,
1729977227,
},
{
37,
1729977688,
},
{
107,
1729977688,
},
{
146,
1729977688,
},
{
37,
1729978056,
},
{
106,
1729978056,
},
{
146,
1729978056,
},
{
37,
1729978241,
},
{
37,
1729978683,
},
{
106,
1729978683,
},
{
146,
1729978683,
},
{
282,
1729978683,
},
},
["Паутинные нити"] = {
{
15,
1728497799,
},
{
16,
1728498129,
},
{
105,
1728498129,
},
{
155,
1728498129,
},
{
170,
1728498129,
},
{
16,
1728498656,
},
{
106,
1728498656,
},
{
155,
1728498656,
},
{
170,
1728498656,
},
{
220,
1728498656,
},
{
347,
1728498656,
},
{
16,
1728498979,
},
{
101,
1728498979,
},
{
16,
1728499400,
},
{
101,
1728499400,
},
{
150,
1728499400,
},
{
166,
1728499400,
},
{
16,
1728499776,
},
{
101,
1728499776,
},
{
151,
1728499776,
},
{
166,
1728499776,
},
{
16,
1728500430,
},
{
100,
1728500430,
},
{
150,
1728500430,
},
{
166,
1728500430,
},
{
16,
1728501203,
},
{
99,
1728501203,
},
{
149,
1728501203,
},
{
165,
1728501203,
},
{
16,
1728501746,
},
{
100,
1728501746,
},
{
16,
1728502026,
},
{
100,
1728502026,
},
{
150,
1728502026,
},
{
166,
1728502026,
},
{
15,
1728502338,
},
{
100,
1728502338,
},
{
150,
1728502338,
},
{
165,
1728502338,
},
{
16,
1728503126,
},
{
101,
1728503126,
},
{
150,
1728503126,
},
{
165,
1728503126,
},
{
16,
1728503478,
},
{
101,
1728503478,
},
{
157,
1728503478,
},
{
172,
1728503478,
},
{
17,
1729976741,
},
{
101,
1729976741,
},
{
150,
1729976741,
},
{
165,
1729976741,
},
{
217,
1729976741,
},
{
16,
1729977227,
},
{
100,
1729977227,
},
{
151,
1729977227,
},
{
166,
1729977227,
},
{
217,
1729977227,
},
{
16,
1729977688,
},
{
100,
1729977688,
},
{
149,
1729977688,
},
{
164,
1729977688,
},
{
16,
1729978056,
},
{
99,
1729978056,
},
{
149,
1729978056,
},
{
164,
1729978056,
},
{
215,
1729978056,
},
{
16,
1729978241,
},
{
16,
1729978683,
},
{
100,
1729978683,
},
{
149,
1729978683,
},
{
164,
1729978683,
},
{
215,
1729978683,
},
},
["Зараженное порождение"] = {
{
20,
1728497799,
},
{
79,
1728497799,
},
{
21,
1728498129,
},
{
86,
1728498129,
},
{
21,
1728498656,
},
{
87,
1728498656,
},
{
216,
1728498656,
},
{
236,
1728498656,
},
{
282,
1728498656,
},
{
306,
1728498656,
},
{
21,
1728498979,
},
{
82,
1728498979,
},
{
21,
1728499400,
},
{
82,
1728499400,
},
{
21,
1728499776,
},
{
82,
1728499776,
},
{
21,
1728500430,
},
{
81,
1728500430,
},
{
21,
1728501203,
},
{
80,
1728501203,
},
{
21,
1728501746,
},
{
81,
1728501746,
},
{
21,
1728502026,
},
{
81,
1728502026,
},
{
21,
1728502338,
},
{
80,
1728502338,
},
{
21,
1728503126,
},
{
81,
1728503126,
},
{
21,
1728503478,
},
{
82,
1728503478,
},
{
21,
1729976741,
},
{
82,
1729976741,
},
{
213,
1729976741,
},
{
233,
1729976741,
},
{
21,
1729977227,
},
{
81,
1729977227,
},
{
213,
1729977227,
},
{
233,
1729977227,
},
{
278,
1729977227,
},
{
21,
1729977688,
},
{
81,
1729977688,
},
{
21,
1729978056,
},
{
80,
1729978056,
},
{
212,
1729978056,
},
{
231,
1729978056,
},
{
21,
1729978241,
},
{
21,
1729978683,
},
{
81,
1729978683,
},
{
211,
1729978683,
},
{
231,
1729978683,
},
{
276,
1729978683,
},
{
301,
1729978683,
},
},
["Рассекание паутины"] = {
{
70,
1728497799,
},
{
77,
1728498129,
},
{
142,
1728498129,
},
{
77,
1728498656,
},
{
142,
1728498656,
},
{
207,
1728498656,
},
{
272,
1728498656,
},
{
338,
1728498656,
},
{
72,
1728498979,
},
{
73,
1728499400,
},
{
137,
1728499400,
},
{
73,
1728499776,
},
{
138,
1728499776,
},
{
71,
1728500430,
},
{
138,
1728500430,
},
{
71,
1728501203,
},
{
136,
1728501203,
},
{
72,
1728501746,
},
{
137,
1728501746,
},
{
72,
1728502026,
},
{
137,
1728502026,
},
{
71,
1728502338,
},
{
137,
1728502338,
},
{
72,
1728503126,
},
{
137,
1728503126,
},
{
73,
1728503478,
},
{
144,
1728503478,
},
{
73,
1729976741,
},
{
137,
1729976741,
},
{
204,
1729976741,
},
{
72,
1729977227,
},
{
138,
1729977227,
},
{
204,
1729977227,
},
{
269,
1729977227,
},
{
72,
1729977688,
},
{
136,
1729977688,
},
{
71,
1729978056,
},
{
136,
1729978056,
},
{
202,
1729978056,
},
{
71,
1729978683,
},
{
136,
1729978683,
},
{
202,
1729978683,
},
{
267,
1729978683,
},
},
["Кислотное извержение"] = {
{
65,
1728498129,
},
{
65,
1728498656,
},
{
130,
1728498979,
},
{
198,
1728499776,
},
{
197,
1728500430,
},
{
195,
1728501203,
},
{
197,
1728503126,
},
{
131,
1728503478,
},
{
203,
1728503478,
},
{
196,
1729977688,
},
{
260,
1729978056,
},
{
66,
1729978241,
},
{
72,
1729978241,
},
},
["Разъедающие брызги"] = {
{
9,
1728497799,
},
{
49,
1728497799,
},
{
88,
1728497799,
},
{
10,
1728498129,
},
{
49,
1728498129,
},
{
94,
1728498129,
},
{
119,
1728498129,
},
{
160,
1728498129,
},
{
10,
1728498656,
},
{
50,
1728498656,
},
{
95,
1728498656,
},
{
120,
1728498656,
},
{
160,
1728498656,
},
{
185,
1728498656,
},
{
225,
1728498656,
},
{
250,
1728498656,
},
{
290,
1728498656,
},
{
315,
1728498656,
},
{
10,
1728498979,
},
{
50,
1728498979,
},
{
90,
1728498979,
},
{
115,
1728498979,
},
{
9,
1728499400,
},
{
49,
1728499400,
},
{
90,
1728499400,
},
{
115,
1728499400,
},
{
155,
1728499400,
},
{
180,
1728499400,
},
{
9,
1728499776,
},
{
49,
1728499776,
},
{
90,
1728499776,
},
{
115,
1728499776,
},
{
156,
1728499776,
},
{
181,
1728499776,
},
{
9,
1728500430,
},
{
49,
1728500430,
},
{
89,
1728500430,
},
{
114,
1728500430,
},
{
155,
1728500430,
},
{
180,
1728500430,
},
{
9,
1728501203,
},
{
49,
1728501203,
},
{
89,
1728501203,
},
{
114,
1728501203,
},
{
154,
1728501203,
},
{
179,
1728501203,
},
{
9,
1728501746,
},
{
49,
1728501746,
},
{
89,
1728501746,
},
{
114,
1728501746,
},
{
9,
1728502026,
},
{
49,
1728502026,
},
{
89,
1728502026,
},
{
114,
1728502026,
},
{
155,
1728502026,
},
{
9,
1728502338,
},
{
49,
1728502338,
},
{
89,
1728502338,
},
{
114,
1728502338,
},
{
155,
1728502338,
},
{
9,
1728503126,
},
{
49,
1728503126,
},
{
90,
1728503126,
},
{
115,
1728503126,
},
{
154,
1728503126,
},
{
179,
1728503126,
},
{
9,
1728503478,
},
{
49,
1728503478,
},
{
90,
1728503478,
},
{
115,
1728503478,
},
{
162,
1728503478,
},
{
187,
1728503478,
},
{
10,
1729976741,
},
{
50,
1729976741,
},
{
90,
1729976741,
},
{
115,
1729976741,
},
{
154,
1729976741,
},
{
179,
1729976741,
},
{
221,
1729976741,
},
{
246,
1729976741,
},
{
10,
1729977227,
},
{
49,
1729977227,
},
{
90,
1729977227,
},
{
115,
1729977227,
},
{
155,
1729977227,
},
{
180,
1729977227,
},
{
221,
1729977227,
},
{
247,
1729977227,
},
{
10,
1729977688,
},
{
50,
1729977688,
},
{
89,
1729977688,
},
{
114,
1729977688,
},
{
154,
1729977688,
},
{
179,
1729977688,
},
{
10,
1729978056,
},
{
50,
1729978056,
},
{
88,
1729978056,
},
{
113,
1729978056,
},
{
153,
1729978056,
},
{
178,
1729978056,
},
{
220,
1729978056,
},
{
245,
1729978056,
},
{
10,
1729978241,
},
{
50,
1729978241,
},
{
9,
1729978683,
},
{
49,
1729978683,
},
{
89,
1729978683,
},
{
114,
1729978683,
},
{
153,
1729978683,
},
{
178,
1729978683,
},
{
219,
1729978683,
},
{
244,
1729978683,
},
{
284,
1729978683,
},
{
309,
1729978683,
},
},
["Дикий натиск"] = {
{
6,
1728497799,
},
{
29,
1728497799,
},
{
31,
1728497799,
},
{
44,
1728497799,
},
{
46,
1728497799,
},
{
74,
1728497799,
},
{
76,
1728497799,
},
{
94,
1728497799,
},
{
7,
1728498129,
},
{
30,
1728498129,
},
{
32,
1728498129,
},
{
44,
1728498129,
},
{
47,
1728498129,
},
{
80,
1728498129,
},
{
82,
1728498129,
},
{
101,
1728498129,
},
{
103,
1728498129,
},
{
114,
1728498129,
},
{
117,
1728498129,
},
{
146,
1728498129,
},
{
148,
1728498129,
},
{
166,
1728498129,
},
{
168,
1728498129,
},
{
180,
1728498129,
},
{
7,
1728498656,
},
{
30,
1728498656,
},
{
32,
1728498656,
},
{
45,
1728498656,
},
{
47,
1728498656,
},
{
81,
1728498656,
},
{
83,
1728498656,
},
{
101,
1728498656,
},
{
103,
1728498656,
},
{
115,
1728498656,
},
{
117,
1728498656,
},
{
146,
1728498656,
},
{
148,
1728498656,
},
{
166,
1728498656,
},
{
168,
1728498656,
},
{
180,
1728498656,
},
{
182,
1728498656,
},
{
211,
1728498656,
},
{
213,
1728498656,
},
{
231,
1728498656,
},
{
233,
1728498656,
},
{
244,
1728498656,
},
{
247,
1728498656,
},
{
276,
1728498656,
},
{
278,
1728498656,
},
{
296,
1728498656,
},
{
298,
1728498656,
},
{
310,
1728498656,
},
{
312,
1728498656,
},
{
342,
1728498656,
},
{
7,
1728498979,
},
{
30,
1728498979,
},
{
32,
1728498979,
},
{
45,
1728498979,
},
{
47,
1728498979,
},
{
76,
1728498979,
},
{
78,
1728498979,
},
{
96,
1728498979,
},
{
98,
1728498979,
},
{
110,
1728498979,
},
{
112,
1728498979,
},
{
7,
1728499400,
},
{
29,
1728499400,
},
{
31,
1728499400,
},
{
44,
1728499400,
},
{
47,
1728499400,
},
{
76,
1728499400,
},
{
78,
1728499400,
},
{
96,
1728499400,
},
{
98,
1728499400,
},
{
110,
1728499400,
},
{
113,
1728499400,
},
{
141,
1728499400,
},
{
143,
1728499400,
},
{
161,
1728499400,
},
{
163,
1728499400,
},
{
175,
1728499400,
},
{
177,
1728499400,
},
{
7,
1728499776,
},
{
29,
1728499776,
},
{
31,
1728499776,
},
{
44,
1728499776,
},
{
47,
1728499776,
},
{
76,
1728499776,
},
{
78,
1728499776,
},
{
97,
1728499776,
},
{
99,
1728499776,
},
{
110,
1728499776,
},
{
113,
1728499776,
},
{
142,
1728499776,
},
{
144,
1728499776,
},
{
162,
1728499776,
},
{
164,
1728499776,
},
{
176,
1728499776,
},
{
178,
1728499776,
},
{
7,
1728500430,
},
{
29,
1728500430,
},
{
31,
1728500430,
},
{
44,
1728500430,
},
{
46,
1728500430,
},
{
75,
1728500430,
},
{
77,
1728500430,
},
{
95,
1728500430,
},
{
97,
1728500430,
},
{
109,
1728500430,
},
{
111,
1728500430,
},
{
141,
1728500430,
},
{
143,
1728500430,
},
{
161,
1728500430,
},
{
163,
1728500430,
},
{
175,
1728500430,
},
{
178,
1728500430,
},
{
6,
1728501203,
},
{
29,
1728501203,
},
{
31,
1728501203,
},
{
44,
1728501203,
},
{
46,
1728501203,
},
{
75,
1728501203,
},
{
77,
1728501203,
},
{
95,
1728501203,
},
{
97,
1728501203,
},
{
109,
1728501203,
},
{
111,
1728501203,
},
{
140,
1728501203,
},
{
142,
1728501203,
},
{
160,
1728501203,
},
{
162,
1728501203,
},
{
174,
1728501203,
},
{
176,
1728501203,
},
{
6,
1728501746,
},
{
29,
1728501746,
},
{
31,
1728501746,
},
{
44,
1728501746,
},
{
46,
1728501746,
},
{
75,
1728501746,
},
{
77,
1728501746,
},
{
95,
1728501746,
},
{
97,
1728501746,
},
{
109,
1728501746,
},
{
112,
1728501746,
},
{
7,
1728502026,
},
{
29,
1728502026,
},
{
31,
1728502026,
},
{
44,
1728502026,
},
{
47,
1728502026,
},
{
76,
1728502026,
},
{
78,
1728502026,
},
{
96,
1728502026,
},
{
98,
1728502026,
},
{
109,
1728502026,
},
{
112,
1728502026,
},
{
141,
1728502026,
},
{
143,
1728502026,
},
{
161,
1728502026,
},
{
163,
1728502026,
},
{
175,
1728502026,
},
{
6,
1728502338,
},
{
29,
1728502338,
},
{
31,
1728502338,
},
{
44,
1728502338,
},
{
46,
1728502338,
},
{
75,
1728502338,
},
{
77,
1728502338,
},
{
95,
1728502338,
},
{
97,
1728502338,
},
{
109,
1728502338,
},
{
111,
1728502338,
},
{
141,
1728502338,
},
{
143,
1728502338,
},
{
161,
1728502338,
},
{
163,
1728502338,
},
{
6,
1728503126,
},
{
29,
1728503126,
},
{
31,
1728503126,
},
{
44,
1728503126,
},
{
46,
1728503126,
},
{
76,
1728503126,
},
{
78,
1728503126,
},
{
96,
1728503126,
},
{
98,
1728503126,
},
{
110,
1728503126,
},
{
112,
1728503126,
},
{
140,
1728503126,
},
{
142,
1728503126,
},
{
160,
1728503126,
},
{
162,
1728503126,
},
{
174,
1728503126,
},
{
177,
1728503126,
},
{
7,
1728503478,
},
{
29,
1728503478,
},
{
31,
1728503478,
},
{
44,
1728503478,
},
{
47,
1728503478,
},
{
76,
1728503478,
},
{
78,
1728503478,
},
{
97,
1728503478,
},
{
99,
1728503478,
},
{
110,
1728503478,
},
{
113,
1728503478,
},
{
148,
1728503478,
},
{
150,
1728503478,
},
{
168,
1728503478,
},
{
170,
1728503478,
},
{
182,
1728503478,
},
{
184,
1728503478,
},
{
7,
1729976741,
},
{
30,
1729976741,
},
{
32,
1729976741,
},
{
45,
1729976741,
},
{
47,
1729976741,
},
{
76,
1729976741,
},
{
78,
1729976741,
},
{
96,
1729976741,
},
{
98,
1729976741,
},
{
110,
1729976741,
},
{
113,
1729976741,
},
{
141,
1729976741,
},
{
143,
1729976741,
},
{
161,
1729976741,
},
{
163,
1729976741,
},
{
174,
1729976741,
},
{
177,
1729976741,
},
{
207,
1729976741,
},
{
209,
1729976741,
},
{
227,
1729976741,
},
{
229,
1729976741,
},
{
241,
1729976741,
},
{
244,
1729976741,
},
{
7,
1729977227,
},
{
29,
1729977227,
},
{
31,
1729977227,
},
{
44,
1729977227,
},
{
47,
1729977227,
},
{
76,
1729977227,
},
{
78,
1729977227,
},
{
96,
1729977227,
},
{
98,
1729977227,
},
{
110,
1729977227,
},
{
112,
1729977227,
},
{
141,
1729977227,
},
{
143,
1729977227,
},
{
162,
1729977227,
},
{
164,
1729977227,
},
{
175,
1729977227,
},
{
178,
1729977227,
},
{
208,
1729977227,
},
{
210,
1729977227,
},
{
228,
1729977227,
},
{
230,
1729977227,
},
{
241,
1729977227,
},
{
244,
1729977227,
},
{
274,
1729977227,
},
{
7,
1729977688,
},
{
30,
1729977688,
},
{
32,
1729977688,
},
{
44,
1729977688,
},
{
47,
1729977688,
},
{
75,
1729977688,
},
{
77,
1729977688,
},
{
95,
1729977688,
},
{
97,
1729977688,
},
{
109,
1729977688,
},
{
112,
1729977688,
},
{
140,
1729977688,
},
{
142,
1729977688,
},
{
160,
1729977688,
},
{
162,
1729977688,
},
{
174,
1729977688,
},
{
176,
1729977688,
},
{
7,
1729978056,
},
{
30,
1729978056,
},
{
32,
1729978056,
},
{
45,
1729978056,
},
{
47,
1729978056,
},
{
75,
1729978056,
},
{
77,
1729978056,
},
{
94,
1729978056,
},
{
96,
1729978056,
},
{
108,
1729978056,
},
{
111,
1729978056,
},
{
140,
1729978056,
},
{
142,
1729978056,
},
{
160,
1729978056,
},
{
162,
1729978056,
},
{
173,
1729978056,
},
{
176,
1729978056,
},
{
206,
1729978056,
},
{
208,
1729978056,
},
{
226,
1729978056,
},
{
228,
1729978056,
},
{
240,
1729978056,
},
{
242,
1729978056,
},
{
7,
1729978241,
},
{
30,
1729978241,
},
{
32,
1729978241,
},
{
45,
1729978241,
},
{
47,
1729978241,
},
{
7,
1729978683,
},
{
29,
1729978683,
},
{
31,
1729978683,
},
{
44,
1729978683,
},
{
47,
1729978683,
},
{
75,
1729978683,
},
{
77,
1729978683,
},
{
95,
1729978683,
},
{
97,
1729978683,
},
{
109,
1729978683,
},
{
111,
1729978683,
},
{
139,
1729978683,
},
{
141,
1729978683,
},
{
159,
1729978683,
},
{
161,
1729978683,
},
{
173,
1729978683,
},
{
176,
1729978683,
},
{
205,
1729978683,
},
{
207,
1729978683,
},
{
225,
1729978683,
},
{
227,
1729978683,
},
{
239,
1729978683,
},
{
242,
1729978683,
},
{
270,
1729978683,
},
{
272,
1729978683,
},
{
290,
1729978683,
},
{
292,
1729978683,
},
{
304,
1729978683,
},
{
307,
1729978683,
},
},
["Смертельный кошмар"] = {
{
91,
1728497799,
},
{
123,
1728498979,
},
{
125,
1728498979,
},
{
189,
1728501203,
},
{
196,
1728501203,
},
{
197,
1728501203,
},
{
198,
1728501203,
},
{
194,
1729977688,
},
{
195,
1729977688,
},
{
196,
1729977688,
},
{
69,
1729978241,
},
},
["Опутывающие сети"] = {
{
39,
1728497799,
},
{
40,
1728497799,
},
{
41,
1728497799,
},
{
83,
1728497799,
},
{
85,
1728497799,
},
{
40,
1728498129,
},
{
41,
1728498129,
},
{
90,
1728498129,
},
{
91,
1728498129,
},
{
175,
1728498129,
},
{
176,
1728498129,
},
{
177,
1728498129,
},
{
40,
1728498656,
},
{
41,
1728498656,
},
{
90,
1728498656,
},
{
92,
1728498656,
},
{
175,
1728498656,
},
{
175,
1728498656,
},
{
176,
1728498656,
},
{
240,
1728498656,
},
{
241,
1728498656,
},
{
301,
1728498656,
},
{
40,
1728498979,
},
{
41,
1728498979,
},
{
42,
1728498979,
},
{
85,
1728498979,
},
{
87,
1728498979,
},
{
88,
1728498979,
},
{
40,
1728499400,
},
{
40,
1728499400,
},
{
41,
1728499400,
},
{
86,
1728499400,
},
{
87,
1728499400,
},
{
88,
1728499400,
},
{
170,
1728499400,
},
{
171,
1728499400,
},
{
172,
1728499400,
},
{
40,
1728499776,
},
{
86,
1728499776,
},
{
171,
1728499776,
},
{
173,
1728499776,
},
{
39,
1728500430,
},
{
41,
1728500430,
},
{
84,
1728500430,
},
{
85,
1728500430,
},
{
86,
1728500430,
},
{
171,
1728500430,
},
{
171,
1728500430,
},
{
39,
1728501203,
},
{
40,
1728501203,
},
{
41,
1728501203,
},
{
84,
1728501203,
},
{
169,
1728501203,
},
{
170,
1728501203,
},
{
171,
1728501203,
},
{
39,
1728501746,
},
{
40,
1728501746,
},
{
41,
1728501746,
},
{
85,
1728501746,
},
{
86,
1728501746,
},
{
87,
1728501746,
},
{
40,
1728502026,
},
{
41,
1728502026,
},
{
85,
1728502026,
},
{
86,
1728502026,
},
{
170,
1728502026,
},
{
171,
1728502026,
},
{
39,
1728502338,
},
{
84,
1728502338,
},
{
86,
1728502338,
},
{
170,
1728502338,
},
{
39,
1728503126,
},
{
40,
1728503126,
},
{
85,
1728503126,
},
{
87,
1728503126,
},
{
170,
1728503126,
},
{
171,
1728503126,
},
{
40,
1728503478,
},
{
40,
1728503478,
},
{
41,
1728503478,
},
{
86,
1728503478,
},
{
88,
1728503478,
},
{
177,
1728503478,
},
{
178,
1728503478,
},
{
40,
1729976741,
},
{
41,
1729976741,
},
{
86,
1729976741,
},
{
87,
1729976741,
},
{
88,
1729976741,
},
{
170,
1729976741,
},
{
237,
1729976741,
},
{
40,
1729977227,
},
{
41,
1729977227,
},
{
85,
1729977227,
},
{
86,
1729977227,
},
{
171,
1729977227,
},
{
172,
1729977227,
},
{
237,
1729977227,
},
{
238,
1729977227,
},
{
40,
1729977688,
},
{
85,
1729977688,
},
{
86,
1729977688,
},
{
87,
1729977688,
},
{
169,
1729977688,
},
{
170,
1729977688,
},
{
40,
1729978056,
},
{
84,
1729978056,
},
{
85,
1729978056,
},
{
169,
1729978056,
},
{
170,
1729978056,
},
{
235,
1729978056,
},
{
237,
1729978056,
},
{
238,
1729978056,
},
{
40,
1729978241,
},
{
41,
1729978241,
},
{
42,
1729978241,
},
{
40,
1729978683,
},
{
84,
1729978683,
},
{
169,
1729978683,
},
{
170,
1729978683,
},
{
235,
1729978683,
},
{
295,
1729978683,
},
{
295,
1729978683,
},
{
296,
1729978683,
},
},
["Липкий выброс"] = {
{
92,
1728498129,
},
{
180,
1728498129,
},
{
183,
1728498129,
},
{
92,
1728498656,
},
{
88,
1728499776,
},
{
41,
1728501203,
},
{
171,
1728501203,
},
{
87,
1728502338,
},
{
88,
1728503126,
},
{
88,
1728503478,
},
},
},
["2918-15"] = {
["Кислотный град"] = {
{
87,
1726349042,
},
{
90,
1726349042,
},
{
99,
1726349042,
},
{
103,
1726349042,
},
{
193,
1726349042,
},
{
196,
1726349042,
},
{
205,
1726349042,
},
{
295,
1726349042,
},
{
298,
1726349042,
},
{
308,
1726349042,
},
{
397,
1726349042,
},
{
400,
1726349042,
},
{
410,
1726349042,
},
{
414,
1726349042,
},
{
87,
1726349845,
},
{
90,
1726349845,
},
{
99,
1726349845,
},
{
190,
1726349845,
},
{
192,
1726349845,
},
{
202,
1726349845,
},
{
291,
1726349845,
},
{
294,
1726349845,
},
{
305,
1726349845,
},
{
395,
1726349845,
},
{
399,
1726349845,
},
{
410,
1726349845,
},
{
415,
1726349845,
},
{
87,
1726835359,
},
{
90,
1726835359,
},
{
99,
1726835359,
},
{
189,
1726835359,
},
{
193,
1726835359,
},
{
201,
1726835359,
},
{
292,
1726835359,
},
{
295,
1726835359,
},
{
87,
1727878635,
},
{
90,
1727878635,
},
{
98,
1727878635,
},
{
188,
1727878635,
},
{
191,
1727878635,
},
{
199,
1727878635,
},
},
["Зараженный укус"] = {
{
65,
1726349042,
},
{
71,
1726349042,
},
{
72,
1726349042,
},
{
77,
1726349042,
},
{
151,
1726349042,
},
{
152,
1726349042,
},
{
157,
1726349042,
},
{
158,
1726349042,
},
{
164,
1726349042,
},
{
228,
1726349042,
},
{
229,
1726349042,
},
{
234,
1726349042,
},
{
235,
1726349042,
},
{
258,
1726349042,
},
{
264,
1726349042,
},
{
265,
1726349042,
},
{
266,
1726349042,
},
{
269,
1726349042,
},
{
271,
1726349042,
},
{
278,
1726349042,
},
{
279,
1726349042,
},
{
284,
1726349042,
},
{
285,
1726349042,
},
{
290,
1726349042,
},
{
297,
1726349042,
},
{
356,
1726349042,
},
{
361,
1726349042,
},
{
362,
1726349042,
},
{
363,
1726349042,
},
{
364,
1726349042,
},
{
367,
1726349042,
},
{
368,
1726349042,
},
{
370,
1726349042,
},
{
374,
1726349042,
},
{
65,
1726349845,
},
{
70,
1726349845,
},
{
71,
1726349845,
},
{
148,
1726349845,
},
{
149,
1726349845,
},
{
154,
1726349845,
},
{
155,
1726349845,
},
{
225,
1726349845,
},
{
231,
1726349845,
},
{
255,
1726349845,
},
{
260,
1726349845,
},
{
261,
1726349845,
},
{
275,
1726349845,
},
{
281,
1726349845,
},
{
354,
1726349845,
},
{
355,
1726349845,
},
{
360,
1726349845,
},
{
361,
1726349845,
},
{
65,
1726835359,
},
{
66,
1726835359,
},
{
71,
1726835359,
},
{
72,
1726835359,
},
{
148,
1726835359,
},
{
157,
1726835359,
},
{
225,
1726835359,
},
{
226,
1726835359,
},
{
255,
1726835359,
},
{
261,
1726835359,
},
{
275,
1726835359,
},
{
276,
1726835359,
},
{
281,
1726835359,
},
{
64,
1727878635,
},
{
65,
1727878635,
},
{
70,
1727878635,
},
{
71,
1727878635,
},
{
146,
1727878635,
},
{
147,
1727878635,
},
{
222,
1727878635,
},
{
223,
1727878635,
},
{
252,
1727878635,
},
{
253,
1727878635,
},
},
["Разлив кислоты"] = {
{
43,
1726349042,
},
{
124,
1726349042,
},
{
154,
1726349042,
},
{
174,
1726349042,
},
{
270,
1726349042,
},
{
372,
1726349042,
},
{
434,
1726349042,
},
{
43,
1726349845,
},
{
120,
1726349845,
},
{
151,
1726349845,
},
{
170,
1726349845,
},
{
267,
1726349845,
},
{
371,
1726349845,
},
{
436,
1726349845,
},
{
43,
1726835359,
},
{
120,
1726835359,
},
{
150,
1726835359,
},
{
170,
1726835359,
},
{
267,
1726835359,
},
{
43,
1727878635,
},
{
119,
1727878635,
},
{
149,
1727878635,
},
{
169,
1727878635,
},
},
["Зараженное порождение"] = {
{
61,
1726349042,
},
{
148,
1726349042,
},
{
225,
1726349042,
},
{
254,
1726349042,
},
{
275,
1726349042,
},
{
352,
1726349042,
},
{
61,
1726349845,
},
{
145,
1726349845,
},
{
221,
1726349845,
},
{
251,
1726349845,
},
{
271,
1726349845,
},
{
350,
1726349845,
},
{
61,
1726835359,
},
{
144,
1726835359,
},
{
221,
1726835359,
},
{
251,
1726835359,
},
{
271,
1726835359,
},
{
61,
1727878635,
},
{
143,
1727878635,
},
{
219,
1727878635,
},
{
248,
1727878635,
},
},
["Кислотное извержение"] = {
{
102,
1726349042,
},
{
413,
1726349042,
},
{
413,
1726349845,
},
},
["Разъедающие брызги"] = {
{
4,
1726349042,
},
{
34,
1726349042,
},
{
78,
1726349042,
},
{
140,
1726349042,
},
{
184,
1726349042,
},
{
242,
1726349042,
},
{
286,
1726349042,
},
{
344,
1726349042,
},
{
388,
1726349042,
},
{
4,
1726349845,
},
{
34,
1726349845,
},
{
78,
1726349845,
},
{
136,
1726349845,
},
{
181,
1726349845,
},
{
238,
1726349845,
},
{
283,
1726349845,
},
{
342,
1726349845,
},
{
387,
1726349845,
},
{
452,
1726349845,
},
{
4,
1726835359,
},
{
34,
1726835359,
},
{
78,
1726835359,
},
{
136,
1726835359,
},
{
180,
1726835359,
},
{
238,
1726835359,
},
{
283,
1726835359,
},
{
4,
1727878635,
},
{
33,
1727878635,
},
{
78,
1727878635,
},
{
135,
1727878635,
},
{
179,
1727878635,
},
{
236,
1727878635,
},
},
["Дикий натиск"] = {
{
11,
1726349042,
},
{
26,
1726349042,
},
{
49,
1726349042,
},
{
56,
1726349042,
},
{
71,
1726349042,
},
{
117,
1726349042,
},
{
132,
1726349042,
},
{
156,
1726349042,
},
{
162,
1726349042,
},
{
177,
1726349042,
},
{
180,
1726349042,
},
{
219,
1726349042,
},
{
234,
1726349042,
},
{
258,
1726349042,
},
{
264,
1726349042,
},
{
279,
1726349042,
},
{
282,
1726349042,
},
{
322,
1726349042,
},
{
336,
1726349042,
},
{
360,
1726349042,
},
{
366,
1726349042,
},
{
381,
1726349042,
},
{
385,
1726349042,
},
{
11,
1726349845,
},
{
26,
1726349845,
},
{
49,
1726349845,
},
{
56,
1726349845,
},
{
71,
1726349845,
},
{
114,
1726349845,
},
{
129,
1726349845,
},
{
153,
1726349845,
},
{
159,
1726349845,
},
{
173,
1726349845,
},
{
177,
1726349845,
},
{
216,
1726349845,
},
{
231,
1726349845,
},
{
255,
1726349845,
},
{
260,
1726349845,
},
{
275,
1726349845,
},
{
279,
1726349845,
},
{
320,
1726349845,
},
{
335,
1726349845,
},
{
358,
1726349845,
},
{
364,
1726349845,
},
{
379,
1726349845,
},
{
383,
1726349845,
},
{
430,
1726349845,
},
{
445,
1726349845,
},
{
12,
1726835359,
},
{
27,
1726835359,
},
{
50,
1726835359,
},
{
56,
1726835359,
},
{
71,
1726835359,
},
{
114,
1726835359,
},
{
129,
1726835359,
},
{
152,
1726835359,
},
{
158,
1726835359,
},
{
173,
1726835359,
},
{
177,
1726835359,
},
{
216,
1726835359,
},
{
231,
1726835359,
},
{
255,
1726835359,
},
{
261,
1726835359,
},
{
275,
1726835359,
},
{
279,
1726835359,
},
{
11,
1727878635,
},
{
26,
1727878635,
},
{
49,
1727878635,
},
{
56,
1727878635,
},
{
71,
1727878635,
},
{
112,
1727878635,
},
{
127,
1727878635,
},
{
151,
1727878635,
},
{
157,
1727878635,
},
{
172,
1727878635,
},
{
175,
1727878635,
},
{
213,
1727878635,
},
{
228,
1727878635,
},
{
252,
1727878635,
},
},
["Паутинные нити"] = {
{
16,
1726349042,
},
{
45,
1726349042,
},
{
66,
1726349042,
},
{
166,
1726349042,
},
{
249,
1726349042,
},
{
326,
1726349042,
},
{
356,
1726349042,
},
{
376,
1726349042,
},
{
16,
1726349845,
},
{
45,
1726349845,
},
{
65,
1726349845,
},
{
163,
1726349845,
},
{
245,
1726349845,
},
{
324,
1726349845,
},
{
354,
1726349845,
},
{
374,
1726349845,
},
{
16,
1726835359,
},
{
46,
1726835359,
},
{
66,
1726835359,
},
{
162,
1726835359,
},
{
246,
1726835359,
},
{
15,
1727878635,
},
{
45,
1727878635,
},
{
65,
1727878635,
},
{
161,
1727878635,
},
{
243,
1727878635,
},
},
["Рассекание паутины"] = {
{
114,
1726349042,
},
{
215,
1726349042,
},
{
318,
1726349042,
},
{
424,
1726349042,
},
{
110,
1726349845,
},
{
212,
1726349845,
},
{
316,
1726349845,
},
{
426,
1726349845,
},
{
110,
1726835359,
},
{
212,
1726835359,
},
{
108,
1727878635,
},
{
210,
1727878635,
},
},
["Липкий выброс"] = {
{
426,
1726349042,
},
},
},
},
["deathsOccurrences"] = {
["2922-14"] = {
[170] = {
1726699888,
},
[91] = {
1726161980,
1726161980,
1726161980,
1726161980,
1726161980,
1726699888,
},
[63] = {
1726163864,
},
[155] = {
1726163264,
},
[310] = {
1726164361,
},
[35] = {
1726161473,
1726161473,
1726161473,
1726161473,
1726161473,
1726161709,
1726161709,
1726161709,
1726161709,
1726161709,
1726699214,
},
[167] = {
1726163864,
1726163864,
},
[175] = {
1726163864,
1726699214,
},
[148] = {
1726163864,
},
[80] = {
1726699214,
},
[172] = {
1726162513,
},
[210] = {
1726162513,
1726162513,
},
[317] = {
1726164361,
},
[125] = {
1726698706,
1726698706,
1726698706,
},
[185] = {
1726163264,
},
[154] = {
1726162513,
1726163264,
},
[53] = {
1726699888,
},
[173] = {
1726162513,
1726699214,
1726699214,
},
[338] = {
1726164899,
},
[315] = {
1726164361,
1726164361,
1726164361,
},
[108] = {
1726163264,
},
[79] = {
1726163264,
},
[189] = {
1726699888,
},
[126] = {
1726698706,
1726698706,
1726699888,
},
},
["2898-16"] = {
[178] = {
1728496261,
},
[155] = {
1728495358,
},
[68] = {
1728495059,
},
[144] = {
1728495746,
1729975956,
},
[76] = {
1728495358,
},
[245] = {
1729975956,
},
[187] = {
1728496739,
},
[133] = {
1728496739,
},
[35] = {
1728495059,
1729187711,
},
[145] = {
1728495746,
1728496261,
},
[148] = {
1729975956,
},
[153] = {
1728495358,
1728495746,
},
[33] = {
1729975956,
},
[175] = {
1728496261,
},
[74] = {
1728495059,
1728495059,
1728495059,
1729187711,
1729187711,
1729187711,
1729187711,
},
[53] = {
1728495746,
1728495746,
},
[173] = {
1728496261,
},
[177] = {
1728496261,
},
[77] = {
1728495358,
},
[269] = {
1729975956,
},
[147] = {
1728495358,
1728496739,
1728496739,
},
[217] = {
1728496739,
},
},
["2921-14"] = {
[255] = {
1726159866,
},
[340] = {
1726698185,
},
[95] = {
1726087120,
1726087853,
},
[66] = {
1726087566,
},
[99] = {
1726087566,
1726087566,
1726158880,
},
[233] = {
1726088983,
1726088983,
1726088983,
1726088983,
1726088983,
},
[38] = {
1726158880,
},
[214] = {
1726159866,
},
[42] = {
1726087566,
},
[86] = {
1726158880,
},
[98] = {
1726087120,
1726087120,
},
[100] = {
1726087120,
1726087120,
1726087853,
1726087853,
1726087853,
1726087853,
1726158880,
1726158880,
},
[97] = {
1726088467,
},
[235] = {
1726088467,
},
[253] = {
1726087566,
},
[181] = {
1726159866,
},
[237] = {
1726088467,
1726088467,
1726088467,
},
[193] = {
1726698185,
},
[199] = {
1726698185,
},
},
["2902-16"] = {
[0] = {
1727892484,
},
[122] = {
1727625015,
},
[361] = {
1727985140,
},
[247] = {
1727623206,
},
[125] = {
1727623466,
1727624668,
1727625604,
1727985140,
1729973842,
},
[126] = {
1727625015,
1727625015,
1727625015,
1727625604,
1729184813,
},
[127] = {
1727623466,
},
[128] = {
1727622447,
1727623466,
1727625015,
1727625604,
},
[132] = {
1727987450,
},
[134] = {
1727624668,
1728492773,
},
[148] = {
1727987450,
},
[298] = {
1729971251,
},
[306] = {
1728492773,
1728492773,
},
[310] = {
1727623206,
},
[318] = {
1727985140,
},
[330] = {
1727622447,
},
[43] = {
1727892646,
},
[11] = {
1727892484,
1727892484,
},
[46] = {
1727621948,
1727893601,
},
[47] = {
1727628606,
1727892646,
1729184813,
1729970361,
1729970361,
1729971251,
1729971251,
},
[188] = {
1727622447,
},
[13] = {
1727623466,
1727624668,
1727628873,
1727628873,
1727893601,
},
[283] = {
1729185356,
},
[291] = {
1729185356,
1729973842,
1729973842,
},
[299] = {
1727622447,
1727987450,
1727987450,
},
[218] = {
1727892316,
1728492773,
},
[14] = {
1727892484,
},
[224] = {
1727623206,
},
[226] = {
1727624668,
},
[230] = {
1727894099,
},
[234] = {
1727623206,
},
[64] = {
1727628873,
},
[65] = {
1727628873,
1729970361,
},
[66] = {
1727892646,
1729970361,
},
[133] = {
1727631159,
1727631159,
1727631159,
1727631159,
},
[69] = {
1727894099,
},
[70] = {
1727628606,
1727628606,
1727628873,
1727631850,
1729971251,
},
[141] = {
1727894099,
1727986257,
},
[74] = {
1727892646,
},
[75] = {
1727892646,
},
[304] = {
1729973842,
},
[308] = {
1727986257,
},
[79] = {
1727628606,
},
[80] = {
1727621948,
1727628606,
},
[81] = {
1727893601,
},
[82] = {
1727892316,
},
[83] = {
1727621948,
1727985140,
1729184813,
},
[84] = {
1727893601,
},
[22] = {
1727892484,
},
[177] = {
1727624051,
1727894099,
},
[183] = {
1727892316,
},
[93] = {
1727893601,
},
[307] = {
1729973842,
},
[374] = {
1729185356,
},
[58] = {
1729184813,
},
[573] = {
1727631850,
},
[469] = {
1727988274,
},
[71] = {
1727621948,
1727623466,
},
[199] = {
1727624051,
},
[201] = {
1727624051,
},
[404] = {
1727631850,
},
[276] = {
1727988274,
1727988274,
},
[170] = {
1727894099,
},
[293] = {
1728492773,
},
[420] = {
1727623206,
},
[112] = {
1727624051,
1729970361,
},
[220] = {
1727986257,
},
[249] = {
1727625604,
1727986257,
},
[129] = {
1727624668,
},
[111] = {
1727631159,
1729184813,
},
[223] = {
1727892316,
},
[448] = {
1727988274,
},
[185] = {
1727625604,
},
[329] = {
1727622447,
},
[231] = {
1727892316,
},
[12] = {
1727987450,
1729971251,
},
[118] = {
1727621948,
1727624051,
1727985140,
1727986257,
},
[455] = {
1727988274,
},
[349] = {
1727631850,
},
[78] = {
1728490934,
1728490934,
1728490934,
1728490934,
1728490934,
},
},
["2917-16"] = {
[147] = {
1729186747,
},
[179] = {
1729186151,
1729186151,
1729186151,
1729186151,
},
[75] = {
1727989882,
1727989882,
1727989882,
1727989882,
},
[46] = {
1727990937,
1727990937,
1727990937,
},
[54] = {
1727989655,
},
[182] = {
1729974802,
},
[108] = {
1729186151,
},
[39] = {
1727989433,
1728493898,
},
[184] = {
1729186747,
},
[55] = {
1727991218,
},
[28] = {
1727989210,
},
[40] = {
1727989433,
},
[48] = {
1727990743,
1727991218,
1727991218,
1727991387,
1727991387,
1727991387,
1729974802,
},
[56] = {
1729186358,
},
[127] = {
1729974802,
},
[65] = {
1729186358,
},
[81] = {
1727990743,
},
[255] = {
1728493898,
1728493898,
},
[57] = {
1727991218,
},
[50] = {
1727990743,
1727990743,
},
[58] = {
1727989655,
},
[35] = {
1727990937,
},
[47] = {
1729974802,
},
[71] = {
1727989882,
},
[70] = {
1729186358,
1729186358,
1729186358,
},
[233] = {
1728493898,
},
[102] = {
1727989210,
},
[275] = {
1729187138,
1729187138,
},
[203] = {
1729186747,
1729186747,
},
[235] = {
1728493898,
},
[202] = {
1729186747,
},
[173] = {
1729187138,
},
[105] = {
1727989210,
1727989210,
1727989210,
},
[237] = {
1729187138,
},
[206] = {
1729187138,
},
[238] = {
1729975188,
},
[37] = {
1727989433,
},
[45] = {
1727991387,
1727991387,
},
[53] = {
1727991218,
},
[36] = {
1727989433,
1727989433,
1729974802,
},
[74] = {
1727989655,
1727989655,
1727989655,
},
[41] = {
1727990937,
},
[49] = {
1727990743,
},
},
["2898-15"] = {
[105] = {
1727878065,
},
[50] = {
1726834749,
},
[14] = {
1726834080,
},
[28] = {
1726834080,
},
[193] = {
1726834749,
1727878065,
},
[32] = {
1726834080,
},
[194] = {
1727878065,
},
[47] = {
1726834749,
},
[98] = {
1726348058,
},
[36] = {
1726834080,
1726834749,
},
[331] = {
1726348058,
},
[11] = {
1726834080,
},
[95] = {
1726834749,
},
[44] = {
1726348058,
},
[96] = {
1726348058,
1726348058,
},
},
["2898-14"] = {
[154] = {
1726084146,
},
[195] = {
1726084146,
},
},
["2902-14"] = {
[45] = {
1726694733,
},
},
["2919-14"] = {
[194] = {
1726697614,
},
},
["2920-15"] = {
[241] = {
1726500523,
},
[122] = {
1726499229,
},
[31] = {
1726854173,
},
[124] = {
1726431974,
1726433063,
1727542626,
},
[125] = {
1726430864,
1726433784,
1726434867,
1726500017,
},
[253] = {
1726430601,
},
[142] = {
1726430864,
},
[286] = {
1726433784,
1726434292,
1726434292,
1727543781,
1727879504,
},
[302] = {
1727879504,
},
[156] = {
1726428578,
1727542626,
},
[158] = {
1726429616,
1726430864,
1726500017,
},
[160] = {
1726430864,
},
[170] = {
1726434867,
},
[172] = {
1726499229,
},
[350] = {
1726501502,
},
[178] = {
1726431742,
},
[180] = {
1726430143,
1726431742,
1726432508,
1726432508,
1726433063,
1726434560,
1726434560,
1726499229,
},
[186] = {
1726429051,
1726430143,
1726430143,
},
[188] = {
1727543267,
},
[192] = {
1726434560,
},
[49] = {
1726431742,
1726433218,
1726433218,
1726499652,
},
[50] = {
1727543267,
},
[200] = {
1726433063,
},
[51] = {
1726431974,
},
[287] = {
1726501502,
1726855442,
1727543781,
1727879504,
},
[210] = {
1726429051,
1726500523,
},
[212] = {
1726433784,
},
[216] = {
1727879504,
},
[57] = {
1726433218,
1726433352,
1726433352,
1726854173,
1726854173,
1726854173,
},
[351] = {
1726501502,
},
[246] = {
1726429616,
1726430601,
1726433784,
},
[248] = {
1726434292,
},
[250] = {
1726429616,
1726501502,
},
[66] = {
1726433352,
},
[72] = {
1726500017,
},
[288] = {
1726855442,
},
[77] = {
1726432194,
},
[308] = {
1726855442,
},
[79] = {
1726431208,
1726432194,
1726432508,
1727542626,
},
[80] = {
1726499652,
1726854173,
},
[81] = {
1727542626,
},
[82] = {
1727543267,
},
[173] = {
1726434292,
},
[177] = {
1726434560,
},
[179] = {
1726428578,
},
[181] = {
1727543267,
},
[185] = {
1726431742,
1726434560,
},
[187] = {
1726430143,
1726430143,
1726431742,
1726432508,
1726434867,
},
[73] = {
1726432194,
},
[155] = {
1726430864,
1726434292,
},
[201] = {
1726430601,
1726434867,
},
[26] = {
1726499652,
1726500017,
},
[103] = {
1726499652,
},
[207] = {
1726429051,
1726499229,
},
[209] = {
1726429051,
1726430601,
1726431208,
1726499229,
1726501502,
},
[211] = {
1726500523,
},
[27] = {
1726432194,
},
[118] = {
1726429616,
1726433063,
1726433784,
1727542626,
},
[217] = {
1727879504,
},
[309] = {
1726855442,
1726855442,
1727543781,
},
[305] = {
1727543781,
},
[202] = {
1726430601,
},
[208] = {
1726429051,
1726431208,
1726433063,
},
[157] = {
1726431208,
1726432508,
1726500017,
1726500523,
},
[115] = {
1727543267,
},
[116] = {
1726428578,
1726500523,
},
[121] = {
1726428578,
1726431974,
},
[235] = {
1726431208,
},
[106] = {
1726431974,
1726499652,
},
[120] = {
1726428578,
1726429616,
},
[310] = {
1727543781,
},
},
["2917-14"] = {
[203] = {
1726083408,
},
[239] = {
1726082945,
1726082945,
},
[128] = {
1726082945,
},
[164] = {
1726082945,
},
[136] = {
1726082945,
},
[127] = {
1726695414,
},
},
["2921-15"] = {
[409] = {
1727104149,
1727104149,
1727104149,
},
[205] = {
1727103485,
},
[178] = {
1727883194,
},
[32] = {
1727882226,
},
[403] = {
1727104149,
},
[99] = {
1727104418,
1727104418,
1727104418,
1727104418,
1727104418,
1727104743,
1727104743,
1727104743,
1727104743,
1727881304,
1727882226,
1727882226,
1727882226,
1727882226,
},
[38] = {
1726856654,
},
[41] = {
1726856654,
1726856654,
1726856654,
1726856654,
},
[42] = {
1726857059,
1726857059,
1726857059,
1726857059,
1726857059,
1727881714,
1727881714,
1727881714,
1727881714,
1727881714,
},
[475] = {
1727103485,
1727103485,
},
[137] = {
1727883194,
},
[406] = {
1727104149,
},
[98] = {
1727881304,
},
[100] = {
1727881304,
1727881304,
1727881304,
},
[138] = {
1727883194,
},
[105] = {
1727104743,
},
[404] = {
1727105692,
},
[261] = {
1727103485,
1727103485,
},
[216] = {
1727883194,
1727883194,
},
[401] = {
1727105692,
},
[405] = {
1727105692,
},
},
["2917-15"] = {
{
1726345930,
},
[131] = {
1726345500,
},
[85] = {
1726345500,
1727532236,
},
[93] = {
1726345500,
},
[136] = {
1726346455,
},
[37] = {
1726344996,
1726344996,
1727532653,
},
[38] = {
1726345930,
},
[39] = {
1726345930,
},
[41] = {
1726345930,
},
[82] = {
1726833220,
},
[43] = {
1726344996,
},
[86] = {
1726346455,
1727877031,
},
[229] = {
1727877031,
},
[149] = {
1726346455,
1726346455,
},
[81] = {
1726833220,
1726833220,
1727532236,
},
[193] = {
1727877031,
},
[235] = {
1727532653,
1727877031,
},
[134] = {
1726345500,
},
[71] = {
1726345930,
1727532236,
},
[104] = {
1727532236,
},
[54] = {
1726344996,
1726344996,
1726833220,
},
[212] = {
1727877031,
},
[47] = {
1726833220,
},
[57] = {
1726346455,
1727532236,
},
[148] = {
1726345500,
},
},
["2919-15"] = {
{
1727535106,
},
[33] = {
1726506580,
1726506580,
},
[139] = {
1727016526,
1727536600,
},
[147] = {
1727028360,
1727028360,
1727028360,
1727028771,
1727028771,
1727028771,
},
[155] = {
1726516070,
},
[45] = {
1726509555,
},
[47] = {
1726505609,
1726506330,
1726511805,
1727536600,
},
[389] = {
1727541980,
},
[53] = {
1726508742,
1726509555,
1726517121,
},
[55] = {
1726504232,
1726509555,
1726517121,
},
[57] = {
1726508742,
1726509321,
1726515435,
1726517121,
},
[235] = {
1726507531,
},
[485] = {
1727541370,
},
[63] = {
1726509990,
1726509990,
1726509990,
},
[66] = {
1726510946,
},
[70] = {
1726514074,
},
[310] = {
1726857543,
},
[342] = {
1726506330,
},
[94] = {
1726510946,
},
[98] = {
1726507998,
1726836034,
1727535106,
},
[102] = {
1727535544,
1727541370,
},
[106] = {
1726507998,
},
[438] = {
1726858252,
},
[122] = {
1726507998,
1726507998,
},
[126] = {
1726513590,
1726513590,
},
[140] = {
1727539906,
},
[148] = {
1726507531,
1727028360,
},
[311] = {
1726857543,
},
[327] = {
1727027680,
1727541370,
},
[391] = {
1727537288,
},
[204] = {
1727016989,
1727016989,
},
[212] = {
1727539037,
},
[220] = {
1727537288,
},
[228] = {
1726836980,
},
[236] = {
1726511805,
1726511805,
},
[244] = {
1726511805,
},
[376] = {
1726515164,
1727029280,
1727029280,
},
[141] = {
1727017314,
1727017314,
1727017314,
1727017314,
1727536600,
},
[157] = {
1727018146,
},
[165] = {
1726515435,
},
[345] = {
1726517715,
},
[197] = {
1726504934,
},
[221] = {
1727539037,
1727539037,
1727539037,
},
[237] = {
1726507531,
},
[266] = {
1727541370,
},
[298] = {
1726509321,
},
[5] = {
1726505199,
},
[87] = {
1726510946,
},
[99] = {
1726505609,
1727540620,
},
[103] = {
1727016093,
1727016093,
},
[107] = {
1726517715,
},
[111] = {
1727016093,
1727016093,
1727536600,
},
[123] = {
1726505609,
},
[142] = {
1727539906,
},
[150] = {
1726505609,
1726514074,
},
[10] = {
1726505199,
},
[166] = {
1726514074,
},
[12] = {
1726505199,
1726505199,
},
[411] = {
1726517715,
},
[222] = {
1726504232,
},
[300] = {
1726509321,
},
[20] = {
1726506580,
},
[348] = {
1726515164,
},
[23] = {
1726513590,
},
[24] = {
1726351254,
},
[29] = {
1726506580,
1727016093,
},
[30] = {
1727536065,
},
[32] = {
1726507998,
},
[143] = {
1727016526,
},
[38] = {
1726506580,
},
[159] = {
1726505609,
},
[167] = {
1726514074,
1727028771,
1727028771,
},
[365] = {
1727540620,
1727540620,
},
[48] = {
1726351254,
1726508742,
1727538013,
},
[199] = {
1727027680,
},
[207] = {
1726516840,
},
[215] = {
1727018146,
},
[56] = {
1726517121,
},
[58] = {
1726836034,
},
[64] = {
1726510946,
},
[318] = {
1727537288,
},
[84] = {
1726836034,
},
[96] = {
1726510946,
},
[104] = {
1726517715,
1727017314,
},
[108] = {
1727535544,
},
[446] = {
1726858252,
1726858252,
},
[478] = {
1727541980,
},
[124] = {
1726513590,
},
[144] = {
1727016526,
1727016526,
1727535106,
1727539906,
},
[319] = {
1726836980,
},
[168] = {
1726515435,
},
[367] = {
1727540620,
},
[216] = {
1726504232,
1726504232,
1726511805,
1727018146,
1727535106,
},
[447] = {
1726858252,
},
[368] = {
1726515164,
1727029280,
},
[384] = {
1726507123,
},
[137] = {
1727016526,
},
[145] = {
1727028360,
1727538532,
1727538532,
1727538532,
},
[321] = {
1727027680,
1727027680,
},
[353] = {
1727538013,
},
[185] = {
1726508742,
1726508742,
},
[385] = {
1726506330,
1726507123,
1726516070,
},
[201] = {
1726516070,
},
[217] = {
1727018146,
1727018146,
1727537288,
},
[225] = {
1726504232,
},
[73] = {
1726513590,
},
[85] = {
1726836034,
1726836034,
1727535544,
},
[354] = {
1727538013,
1727538013,
1727538013,
},
[370] = {
1727029280,
},
[386] = {
1726516070,
1726516070,
},
[101] = {
1726516840,
1727536065,
},
[105] = {
1727016989,
1727535544,
1727535544,
},
[125] = {
1727539906,
},
[138] = {
1727539906,
},
[146] = {
1727538532,
1727538532,
},
[309] = {
1726857543,
1726857543,
1726857543,
},
[162] = {
1726515435,
},
[173] = {
1726514074,
},
[59] = {
1726517121,
},
[371] = {
1727027680,
},
[387] = {
1726507123,
1726507123,
},
[202] = {
1726504934,
1727016989,
1727535106,
},
[210] = {
1727539037,
},
[196] = {
1727016989,
},
[226] = {
1726507531,
},
[426] = {
1726517715,
},
[483] = {
1727541370,
},
[54] = {
1726506330,
1726509555,
1726509990,
},
[52] = {
1726351254,
1726351254,
1726506330,
1726509555,
1727536600,
},
[160] = {
1726515435,
},
[13] = {
1726505199,
},
[224] = {
1726507531,
},
[50] = {
1726351254,
1726509990,
},
[340] = {
1726836980,
1726836980,
},
[390] = {
1726504934,
1726504934,
1726507123,
},
[374] = {
1726515164,
1726515164,
1727029280,
},
[388] = {
1726504934,
1726858252,
},
[314] = {
1726836980,
},
[97] = {
1727536065,
},
[316] = {
1726516840,
1726516840,
1727536065,
1727536065,
},
[193] = {
1727537288,
},
[357] = {
1726516840,
},
[317] = {
1727540620,
},
[278] = {
1726509321,
1726509321,
},
},
["2920-14"] = {
[57] = {
1726085846,
},
[186] = {
1726085846,
},
[46] = {
1726085481,
},
[56] = {
1726085481,
1726085481,
1726085481,
1726085481,
},
[27] = {
1726697102,
1726697102,
},
},
["2902-15"] = {
[13] = {
1727530807,
},
[7] = {
1727530807,
1727530807,
},
[132] = {
1727876381,
},
[15] = {
1727530807,
},
[45] = {
1726344199,
},
[18] = {
1727530807,
},
[3] = {
1727531633,
},
[227] = {
1726344199,
},
[12] = {
1727876381,
},
[182] = {
1726832646,
},
},
["2918-16"] = {
[106] = {
1729978056,
},
[46] = {
1728499400,
},
[107] = {
1728500430,
},
[123] = {
1728500430,
},
[92] = {
1728498129,
1728498656,
},
[108] = {
1728498979,
1728499400,
1728499776,
1728499776,
1728499776,
1728499776,
1728501203,
1728501203,
1728502338,
1728503126,
},
[124] = {
1728503126,
},
[109] = {
1729977227,
},
[303] = {
1729978683,
},
[24] = {
1728499776,
},
[155] = {
1729976741,
1729977688,
1729977688,
},
[156] = {
1728502026,
1729977688,
},
[95] = {
1728502338,
},
[111] = {
1728498656,
},
[94] = {
1728500430,
},
[221] = {
1729976741,
1729977227,
},
[129] = {
1728498129,
1728503126,
},
[159] = {
1728498129,
},
[128] = {
1728498129,
},
[160] = {
1728498129,
},
[97] = {
1728502338,
},
[151] = {
1729978056,
},
[130] = {
1728501203,
},
[225] = {
1729977227,
},
[131] = {
1728500430,
1728501203,
1728503478,
1728503478,
},
[114] = {
1728498656,
1728501746,
1728502338,
},
[132] = {
1728503478,
},
[219] = {
1729976741,
1729976741,
1729978056,
},
[157] = {
1728502026,
1729977227,
},
[58] = {
1728501746,
},
[117] = {
1728501746,
},
[171] = {
1729977688,
},
[203] = {
1729977227,
},
[104] = {
1728498979,
1728502026,
},
[136] = {
1728499400,
},
[43] = {
1728499400,
1729978241,
},
[137] = {
1728502026,
1728502338,
1728503126,
1729977688,
},
[59] = {
1729978241,
},
[88] = {
1728498979,
},
[233] = {
1729978056,
},
[102] = {
1728501203,
},
[118] = {
1728501746,
1728501746,
},
[140] = {
1728503478,
},
[172] = {
1729978056,
},
[52] = {
1729978241,
},
[236] = {
1729978683,
},
[103] = {
1728502026,
},
[174] = {
1728498656,
},
[143] = {
1728503478,
},
[60] = {
1729978241,
},
[86] = {
1728498979,
},
[89] = {
1728500430,
1728503126,
},
[182] = {
1728498656,
},
[91] = {
1728498979,
},
[74] = {
1728497799,
1728497799,
1728497799,
1728497799,
1728497799,
},
[23] = {
1728499400,
1729978241,
},
[218] = {
1729976741,
},
},
["2918-15"] = {
[93] = {
1726835359,
},
[162] = {
1726349042,
},
[215] = {
1726349042,
1726349042,
},
[253] = {
1727878635,
},
[252] = {
1727878635,
},
[194] = {
1726835359,
},
[358] = {
1726349845,
},
[94] = {
1726349042,
1726835359,
},
[51] = {
1726349845,
},
[378] = {
1726349845,
},
[75] = {
1726835359,
},
[167] = {
1726349042,
},
[109] = {
1726835359,
},
[255] = {
1726349845,
},
},
},
["encounterInfo"] = {
[2917] = {
["encounterName"] = "Скованный кровью ужас",
["encounterId"] = 2917,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907281,
},
[2918] = {
["encounterName"] = "Раша'нан",
["encounterId"] = 2918,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907275,
},
[2898] = {
["encounterName"] = "Капитан суреки Сикран",
["encounterId"] = 2898,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = "",
},
[2920] = {
["encounterName"] = "Принцесса Нексуса Ки'веза",
["encounterId"] = 2920,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907269,
},
[2921] = {
["encounterName"] = "Шелковый двор",
["encounterId"] = 2921,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907285,
},
[2922] = {
["encounterName"] = "Королева Ансурек",
["encounterId"] = 2922,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907274,
},
[2902] = {
["encounterName"] = "Улгракс Пожиратель",
["encounterId"] = 2902,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907286,
},
[2919] = {
["encounterName"] = "Исказитель яиц Ови'накс",
["encounterId"] = 2919,
["zoneId"] = 2657,
["zoneName"] = "Неруб'арский дворец",
["bossIcon"] = 5907255,
},
},
}
DeathGraphsDBEndurance = {
["2902-15"] = {
["hash"] = "2902-15",
["type"] = "endurance",
["name"] = "Улгракс Пожиратель",
["id"] = "2902-15",
["diff"] = 15,
["unixtime"] = 1727876381,
["player_db"] = {
["Candlydark-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Yatsufusa-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Goolix-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Stele-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Smea-Pozzodell'Eternità"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Thaldronell-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Restoine-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Chéers-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Okasham-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Zerosixtyøne-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Elauria-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Kiyose-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Cíel-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Milissata-KirinTor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Marsupulami-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Вротмнемёд-ВечнаяПесня"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Рогсвета-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Deadbycorona-TarrenMill"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
182.7800000000279,
"Сеть ловчего |cFFFF3333145,776|r",
},
},
},
["Вольтчара"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Cjlol-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Guldarak-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Kalëor-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zaxl-Mal'Ganis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Bayly-DunModr"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
7.728999999992084,
"Ядовитая плеть |cFFFF3333343,961|r",
},
},
["class"] = "PALADIN",
},
["Квадрик-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
13.65399999999499,
"Желудочный сок |cFFFF3333441,584|r",
},
},
["class"] = "ROGUE",
},
["Ignizion-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Rhanati-Aegwynn"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Чудоскуф-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Wàrsek-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Salarash-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Cptmarizzel-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Czelious-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Friggster-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Dreddfred-Nagrand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
3.13300000000163,
"Безжалостное сокрушение |cFFFF33333,451,046|r",
},
},
["class"] = "PALADIN",
},
["Lissándra-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Dingusdingle-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Ponyo-Quel'Thalas"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Terasime-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Cedrack-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Spaceboogie-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Usurpator-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Badmachine-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Neleza-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Qtroll-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Mefancy-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Torrijas-Sanguino"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
132.5860000000102,
"Неумолимый рывок |cFFFF33333,075,172|r",
},
},
},
["Itzab-Alleria"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Norskhunter-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Kolohnel-Dalaran"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kinan-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Loggo-Antonidas"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Cc-Ghostlands"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Xinz-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Terrivre-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Knasn-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Monkkesis-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Muddifriert-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Holyhornie-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Rihhis-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Walik-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Kementtari-MarécagedeZangar"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "HUNTER",
["deaths"] = {
{
0,
12.5109999999986,
"Паутина ловчего |cFFFF33331,690,023|r",
},
},
},
["Emblair-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
7.547000000005937,
"Ядовитая плеть |cFFFF3333328,709|r",
},
},
["class"] = "PALADIN",
},
["Tanderbloom-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Chibbster-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Holyshiv-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Badeschaum-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Huntahdk-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kasgor-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Xeljus-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Аринве-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Marinkonk-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Noctroll-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Гонча"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
45.20100000000093,
"Пожирание |cFFFF3333961,664|r",
},
},
["class"] = "WARRIOR",
},
["Yadi-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Abc-Frostmane"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Vådnuddel-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Xç-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Wilkzpriest-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Dkbfd-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Tschamane-Blackhand"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
227.9379999999946,
"Паутина ловчего |cFFFF33332,434,947|r",
},
},
["class"] = "SHAMAN",
},
["Sevátar-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zerrox-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
},
},
["2898-16"] = {
["hash"] = "2898-16",
["type"] = "endurance",
["name"] = "Капитан суреки Сикран",
["id"] = "2898-16",
["diff"] = 16,
["player_db"] = {
["Harlö-Drak'thul"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
76.04899999999907,
"Фазовые клинки(ДоТ) |cFFFF3333354,209|r",
},
{
0,
147.150999999998,
"Коллапсирующая вспышка |cFFFF333312,566|r",
},
},
["class"] = "WARRIOR",
},
["Asmonbald-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "MONK",
["deaths"] = {
{
0,
35.40000000002328,
"Фазовый выпад |cFFFF33339,314,699|r",
},
},
},
["Monkeypîe-Draenor"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "ROGUE",
["deaths"] = {
{
0,
148.3459999999614,
"Град стрел |cFFFF33332,699,302|r",
},
},
},
["Cocogatel-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Ködex-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Brbinstagram-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Nerforc-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Dumbaldore-Stormscale"] = {
["encounters"] = 6,
["points"] = 570,
["deaths"] = {
{
0,
145.5380000000005,
"Град стрел |cFFFF33333,178,189|r",
},
{
0,
173.6820000000007,
"Коллапсирующая вспышка |cFFFF3333910,598|r",
},
},
["class"] = "MAGE",
},
["Bearnabeu-TarrenMill"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DRUID",
["deaths"] = {
{
0,
33.2609999999986,
"Град стрел |cFFFF33332,888,464|r",
},
},
},
["Feycc-Kazzak"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "ROGUE",
["deaths"] = {
{
0,
74.65500000002794,
"Коллапсирующая вспышка |cFFFF33339,338|r",
},
},
},
["Bouhn-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Haadige-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Lazyshammy-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Finskröv-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Kelissane-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Barada-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Snóòky-Kazzak"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
77.15799999999581,
"Космические осколки |cFFFF3333308,796|r",
},
},
["class"] = "PALADIN",
},
["Shenhé-Draenor"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "PRIEST",
["deaths"] = {
{
0,
144.3679999999586,
"Град стрел |cFFFF33333,452,233|r",
},
},
},
["Jïgen-Thrall"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
175.1650000000082,
"Космические осколки |cFFFF333334,848|r",
},
},
["class"] = "MONK",
},
["Raminthunder-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Aldrîna-Blackmoore"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
35.46899999999732,
"Фазовый выпад |cFFFF33333,318,524|r",
},
{
0,
133.8830000000016,
"Фазовый выпад |cFFFF333315,447,909|r",
},
},
["class"] = "DEMONHUNTER",
},
["Sourdoughbun-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Meshtities-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Dreamblaze-Stormreaver"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Шинрюжди-Гордунни"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Cikomenttvv-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Succar-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Dempp-TarrenMill"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
53.86100000000442,
"Истребление |cFFFF3333291,433|r",
},
},
["class"] = "WARRIOR",
},
["Sankhadri-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Scarwave-Kazzak"] = {
["encounters"] = 6,
["points"] = 570,
["deaths"] = {
{
0,
53.88900000001013,
"Космические осколки |cFFFF3333315,931|r",
},
{
0,
144.9220000000059,
"Град стрел |cFFFF33333,006,669|r",
},
},
["class"] = "SHAMAN",
},
["Falkao-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Zavious-TwistingNether"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
147.8369999999995,
"Коллапсирующая вспышка |cFFFF3333517,371|r",
},
{
0,
147.7350000000006,
"Град стрел |cFFFF33332,250,278|r",
},
},
["class"] = "WARLOCK",
},
["Вольтчара"] = {
["encounters"] = 7,
["points"] = 700,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Sagoya-Stormscale"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Rag-Quel'Thalas"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
68.49199999999837,
"Град стрел |cFFFF3333460,392|r",
},
},
["class"] = "SHAMAN",
},
["Ryxxe-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DRUID",
},
["Drukkar-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Thánátøs-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Thorstein-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Mürza-Stormscale"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Lgrtha-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Defone-TarrenMill"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Holdetqt-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Rotlips-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Wìntér-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Semulock-DefiasBrotherhood"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Madapes-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Âë-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Apodruid-Zul'jin"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Zamlio-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Dunkkis-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Tahk-CultedelaRivenoire"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Bùstian-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Nexicdruid-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Lovedeluxe-Draenor"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "MONK",
},
["Geetha-TarrenMill"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
74.04799999999523,
"Космические осколки |cFFFF3333141,923|r",
},
},
["class"] = "EVOKER",
},
["Wazabbi-Kazzak"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
74.65500000002794,
"Коллапсирующая вспышка |cFFFF3333806,618|r",
},
},
},
},
["unixtime"] = 1729975956,
},
["2921-14"] = {
["hash"] = "2921-14",
["type"] = "endurance",
["name"] = "Шелковый двор",
["id"] = "2921-14",
["player_db"] = {
["Ckxs-Hyjal"] = {
["encounters"] = 5,
["points"] = 460,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
98.9199999999837,
"Подземное извержение |cFFFF333360,189|r",
},
{
0,
99.41899999999441,
"Опутывающая паутина |cFFFF3333100,880|r",
},
{
0,
95.49199999999837,
"Ядовитый дождь |cFFFF3333216,026|r",
},
{
0,
233.31700000001,
"Жалящий взрыв |cFFFF3333367,255|r",
},
},
},
["Olöfpalme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Evaug-Ysondre"] = {
["encounters"] = 6,
["points"] = 570,
["class"] = "EVOKER",
["deaths"] = {
{
0,
97.1710000000021,
"Подземное извержение |cFFFF3333162,807|r",
},
{
0,
235.6440000000002,
"Энтропия катаклизма |cFFFF33332,821,164|r",
},
},
},
["Foxburger-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 3,
["points"] = 290,
["class"] = "MAGE",
["deaths"] = {
{
0,
66.00500000000466,
"Пронзание |cFFFF3333558,918|r",
},
},
},
["Chaostoilet-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Erelieva-BurningBlade"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Erdashpels-Draenor"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
38.1359999999986,
"Опутывающая паутина |cFFFF3333149,623|r",
},
},
},
["Exxy-Frostmane"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
181.2980000000025,
"Энтропическая паутина |cFFFF333330,942|r",
},
},
},
["Ikne-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Bonso-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Jhwh-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Duranin-BurningBlade"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Sunwalker-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Gelul-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Amateratzu-Stormscale"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "MAGE",
["deaths"] = {
{
0,
255.3830000000016,
"Атака ближнего боя |cFFFF3333300,604|r",
},
},
},
["Elenthasa-Draenor"] = {
["encounters"] = 5,
["points"] = 480,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
98.9199999999837,
"Подземное извержение |cFFFF3333203,839|r",
},
{
0,
42.86499999999069,
"Подземное извержение |cFFFF3333173,239|r",
},
},
},
["Ninasharp-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Amunet-BurningBlade"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Arkantosa-Kazzak"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
214.7719999999972,
"Жалящий взрыв |cFFFF3333184,141|r",
},
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 5,
["points"] = 470,
["class"] = "MAGE",
["deaths"] = {
{
0,
95.1929999999993,
"Ядовитый дождь |cFFFF3333107,520|r",
},
{
0,
237.6549999999988,
"Энтропия катаклизма |cFFFF3333397,611|r",
},
{
0,
233.195000000007,
"Энтропия катаклизма |cFFFF33331,732,327|r",
},
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Jalmage-Nordrassil"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
193.9710000000196,
"Энтропическое опустошение |cFFFF3333145,281|r",
},
},
["class"] = "DEMONHUNTER",
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Nonamenibba-Bloodfeather"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "PRIEST",
["deaths"] = {
{
0,
100.252999999997,
"Безрассудный удар |cFFFF33332,851,020|r",
},
},
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Shaeltis-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 5,
["points"] = 480,
["class"] = "MAGE",
["deaths"] = {
{
0,
100.252999999997,
"Безрассудный удар |cFFFF33332,688,834|r",
},
{
0,
233.31700000001,
"Жалящий взрыв |cFFFF3333373,053|r",
},
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Grant-Eredar"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Galrenir-Silvermoon"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
86.14999999999418,
"Ядовитый дождь |cFFFF33331,098,844|r",
},
},
},
["Anexus-Eredar"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Yugíxx-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Playmoré-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Unstabledudu-Outland"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "DRUID",
["deaths"] = {
},
},
["Miroan-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Wanheda-Dalaran"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
199.8930000000401,
"Жалящий взрыв |cFFFF3333608,053|r",
},
},
["class"] = "ROGUE",
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Solæry-Hyjal"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Jentilmen-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
99.73500000000058,
"Безрассудный рывок |cFFFF33331,518,006|r",
},
},
},
["Tsknight-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
340.8560000000289,
"Извержение шипов |cFFFF33331,301,505|r",
},
},
["class"] = "WARRIOR",
},
["Aiaiath-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Alynara-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Cripzi-Eredar"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Xreaver-Doomhammer"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Klimax-DefiasBrotherhood"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["ßyew-Hyjal"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Devoks-ArgentDawn"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Titaan-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
},
["unixtime"] = 1726698185,
["diff"] = 14,
},
["2920-14"] = {
["hash"] = "2920-14",
["type"] = "endurance",
["name"] = "Принцесса Нексуса Ки'веза",
["id"] = "2920-14",
["player_db"] = {
["Anexus-Eredar"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "HUNTER",
["deaths"] = {
{
0,
46.84299999999348,
"Жнец |cFFFF3333453,915|r",
},
{
0,
186.7740000000049,
"Дезинтеграция |cFFFF3333398,382|r",
},
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
27.40700000000652,
"Дезинтеграция |cFFFF33331,042,095|r",
},
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
56.40599999998813,
"Дезинтеграция |cFFFF3333246,537|r",
},
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
27.16500000003725,
"Дезинтеграция |cFFFF33332,092,923|r",
},
},
["class"] = "MONK",
},
["Grant-Eredar"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Вольтчара"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Playmoré-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Unstabledudu-Outland"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Solæry-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Ckxs-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Cripzi-Eredar"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "ROGUE",
["deaths"] = {
{
0,
56.40599999998813,
"Дезинтеграция |cFFFF3333273,253|r",
},
},
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
57.28800000000047,
"Дезинтеграция |cFFFF33331,063,557|r",
},
},
},
["Elenthasa-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Xreaver-Doomhammer"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["ßyew-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Yugíxx-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Evaug-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
},
["unixtime"] = 1726697102,
["diff"] = 14,
},
["2918-15"] = {
["hash"] = "2918-15",
["type"] = "endurance",
["name"] = "Раша'нан",
["id"] = "2918-15",
["diff"] = 15,
["unixtime"] = 1727878635,
["player_db"] = {
["Candlydark-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Yatsufusa-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Goolix-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Stele-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Smea-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Restoine-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
75.72200000006706,
"Зараженный укус |cFFFF3333477,354|r",
},
},
},
["Chéers-Blackhand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
167.8849999999802,
"Зараженный укус |cFFFF3333509,197|r",
},
},
["class"] = "DRUID",
},
["Okasham-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Emblair-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "MAGE",
["deaths"] = {
{
0,
252.7229999999981,
"Зараженное порождение |cFFFF3333816,067|r",
},
},
},
["Elauria-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Kiyose-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Cíel-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Milissata-KirinTor"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
93.28200000000652,
"Лужи кислоты(ДоТ) |cFFFF3333284,157|r",
},
},
},
["Marsupulami-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Loggo-Antonidas"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Cc-Ghostlands"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Deadbycorona-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Cjlol-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Guldarak-Blackmoore"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
94.36599999997998,
"Лужи кислоты(ДоТ) |cFFFF3333472,264|r",
},
{
0,
51.16699999998673,
"Паутинные нити |cFFFF3333253,734|r",
},
},
["class"] = "HUNTER",
},
["Kalëor-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "MONK",
["deaths"] = {
{
0,
253.0389999999898,
"Длительная эрозия |cFFFF3333225,214|r",
},
},
},
["Bayly-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Ignizion-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Rhanati-Aegwynn"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Чудоскуф-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Salarash-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Thelnar-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Kasgor-Blackmoore"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
255.4389999999839,
"Зараженный укус |cFFFF3333880,623|r",
},
},
["class"] = "MAGE",
},
["Czelious-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Abc-Frostmane"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Dreddfred-Nagrand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Lissándra-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Xinz-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Гонча"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
358.627999999997,
"Длительная эрозия(ДоТ) |cFFFF3333176,249|r",
},
},
["class"] = "WARRIOR",
},
["Terasime-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Spaceboogie-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Usurpator-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Neleza-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Chikie-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Dkbfd-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Muddifriert-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Norskhunter-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Kolohnel-Dalaran"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kinan-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Cedrack-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Terrivre-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Vîgald-Illidan"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Monkkesis-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Badmachine-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Qtroll-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Rihhis-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Walik-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Itzab-Alleria"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Torrijas-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Lenel-Mal'Ganis"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Vådnuddel-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Holyshiv-Stormscale"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "PRIEST",
["deaths"] = {
{
0,
94.17399999999907,
"Лужи кислоты(ДоТ) |cFFFF3333188,271|r",
},
},
},
["Shamesh-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Huntahdk-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Holyhornie-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Stronkaf-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Аринве-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Dingusdingle-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Noctroll-Blackrock"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
162.4619999999995,
"Коррозия(ДоТ) |cFFFF3333160,477|r",
},
},
["class"] = "MONK",
},
["Xzinne-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Zerosixtyøne-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Mefancy-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Marinkonk-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Xç-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Wilkzpriest-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Knasn-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Scindi-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Sevátar-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zerrox-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
},
},
["2898-15"] = {
["hash"] = "2898-15",
["type"] = "endurance",
["name"] = "Капитан суреки Сикран",
["id"] = "2898-15",
["diff"] = 15,
["unixtime"] = 1727878065,
["player_db"] = {
["Candlydark-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Yatsufusa-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Goolix-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Stele-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Smea-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Restoine-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Chéers-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Okasham-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Emblair-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Elauria-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Kiyose-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
47.77000000001863,
"Космические осколки |cFFFF3333994,051|r",
},
},
},
["Cíel-Eredar"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Milissata-KirinTor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Marsupulami-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Loggo-Antonidas"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Cc-Ghostlands"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Deadbycorona-TarrenMill"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
28.85700000007637,
"Атака ближнего боя |cFFFF33330|r",
},
{
0,
36.45400000002701,
"Космический симулякр |cFFFF333351,944|r",
},
},
},
["Вольтчара"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
11.13699999998789,
"Фазовый выпад |cFFFF33332,211,433|r",
},
},
["class"] = "SHAMAN",
},
["Cjlol-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Guldarak-Blackmoore"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
96.98200000001816,
"Космические осколки |cFFFF3333690,694|r",
},
},
["class"] = "HUNTER",
},
["Kalëor-Ysondre"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
105.6570000000065,
"Фазовый выпад |cFFFF33333,145,999|r",
},
},
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Bayly-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Ignizion-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Rhanati-Aegwynn"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Чудоскуф-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Salarash-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Thelnar-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Kasgor-Blackmoore"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
44.59400000001187,
"Истребление |cFFFF3333674,357|r",
},
},
["class"] = "MAGE",
},
["Czelious-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Abc-Frostmane"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "DRUID",
["deaths"] = {
{
0,
14.00400000007357,
"Атака ближнего боя |cFFFF33334,942,319|r",
},
},
},
["Dreddfred-Nagrand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Lissándra-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Xinz-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Гонча"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
96.98200000001816,
"Космические осколки |cFFFF3333852,664|r",
},
},
["class"] = "WARRIOR",
},
["Terasime-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Spaceboogie-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Usurpator-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Neleza-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Chikie-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Dkbfd-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Muddifriert-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Norskhunter-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Kolohnel-Dalaran"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kinan-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Terrivre-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Knasn-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Monkkesis-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Cedrack-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Badmachine-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Rihhis-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Walik-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Qtroll-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Torrijas-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Lenel-Mal'Ganis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Huntahdk-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Holyshiv-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Badeschaum-Blackhand"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Vådnuddel-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Dingusdingle-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Holyhornie-DunModr"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "PRIEST",
["deaths"] = {
{
0,
194.4940000000061,
"Град стрел |cFFFF33331,061,537|r",
},
},
},
["Аринве-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Itzab-Alleria"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
193.2969999999623,
"Разрушительный взмах |cFFFF33332,712,142|r",
},
},
},
["Noctroll-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Xzinne-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Mefancy-Kazzak"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "PRIEST",
["deaths"] = {
{
0,
50.78099999995902,
"Космические осколки |cFFFF33331,309,192|r",
},
},
},
["Marinkonk-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Shamesh-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Xç-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Wilkzpriest-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Vîgald-Illidan"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Zerosixtyøne-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Sevátar-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zerrox-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
},
},
["2898-14"] = {
["hash"] = "2898-14",
["type"] = "endurance",
["name"] = "Капитан суреки Сикран",
["id"] = "2898-14",
["player_db"] = {
["Anexus-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Wavemaker-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Grant-Eredar"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
154.3759999999893,
"Космический симулякр |cFFFF333349,744|r",
},
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Evaug-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Playmoré-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Unstabledudu-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Solæry-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Elenthasa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Ckxs-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Xreaver-Doomhammer"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Cripzi-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["ßyew-Hyjal"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
195.25,
"Космические осколки |cFFFF3333375,307|r",
},
},
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Yugíxx-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
},
["unixtime"] = 1726696030,
["diff"] = 14,
},
["2902-14"] = {
["hash"] = "2902-14",
["type"] = "endurance",
["name"] = "Улгракс Пожиратель",
["id"] = "2902-14",
["player_db"] = {
["Anexus-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Evaug-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
45.48699999996461,
"Пожирание |cFFFF33331,343,765|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Grant-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Вольтчара"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Unstabledudu-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Solæry-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Elenthasa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Cripzi-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Xreaver-Doomhammer"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Ckxs-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Chernomorska-Quel'Thalas"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["ßyew-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Raylebtw-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
},
["unixtime"] = 1726694733,
["diff"] = 14,
},
["2917-15"] = {
["hash"] = "2917-15",
["type"] = "endurance",
["name"] = "Скованный кровью ужас",
["id"] = "2917-15",
["diff"] = 15,
["unixtime"] = 1727877471,
["player_db"] = {
["Candlydark-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Yatsufusa-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Goolix-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Stele-Nemesis"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Smea-Pozzodell'Eternità"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Restoine-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Chéers-Blackhand"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DRUID",
},
["Okasham-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
86.1030000000028,
"Брызгающее кровотечение |cFFFF33336,634,050|r",
},
},
},
["Zerosixtyøne-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
212.2629999999772,
"Атака ближнего боя |cFFFF33331,965,331|r",
},
},
},
["Rfaâ-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Kiyose-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
81.64899999997579,
"Потусторонняя хватка |cFFFF33331,634,917|r",
},
},
},
["Cíel-Eredar"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Milissata-KirinTor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Marsupulami-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
47.4429999999702,
"Брызгающее кровотечение |cFFFF33333,789,525|r",
},
},
},
["Вротмнемёд-ВечнаяПесня"] = {
["encounters"] = 2,
["points"] = 170,
["deaths"] = {
{
0,
57.86199999999371,
"Потусторонняя хватка |cFFFF33332,000,868|r",
},
{
0,
81.83499999999185,
"Потусторонняя хватка |cFFFF33332,277,316|r",
},
},
["class"] = "PRIEST",
},
["Рогсвета-Гордунни"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
1.691999999980908,
"Атака ближнего боя |cFFFF33333,198,695|r",
},
},
["class"] = "PALADIN",
},
["Deadbycorona-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 12,
["points"] = 1170,
["deaths"] = {
{
0,
57.61999999999534,
"Брызгающее кровотечение |cFFFF33336,332,658|r",
},
{
0,
86.33199999999488,
"Брызгающее кровотечение |cFFFF33335,514,346|r",
},
},
["class"] = "SHAMAN",
},
["Cjlol-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Guldarak-Blackmoore"] = {
["encounters"] = 5,
["points"] = 470,
["deaths"] = {
{
0,
43.97199999997974,
"Брызгающее кровотечение |cFFFF33334,018,777|r",
},
{
0,
93.85999999998603,
"Брызгающее кровотечение |cFFFF33334,871,414|r",
},
{
0,
136.6579999999958,
"Черная кровь |cFFFF3333488,661|r",
},
},
["class"] = "HUNTER",
},
["Kalëor-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zaxl-Mal'Ganis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Bayly-DunModr"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Квадрик-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
235.0439999999944,
"Брызгающее кровотечение |cFFFF3333424,820|r",
},
},
["class"] = "ROGUE",
},
["Ignizion-Sanguino"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
193.9369999999763,
"Атака ближнего боя |cFFFF3333204,010|r",
},
},
},
["Rhanati-Aegwynn"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Чудоскуф-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Wàrsek-Blackhand"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Salarash-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Kasgor-Blackmoore"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "MAGE",
},
["Czelious-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Cedrack-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Shamesh-Sanguino"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Friggster-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Dreddfred-Nagrand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
71.91199999999662,
"Отвратительная отрыжка |cFFFF33336,544,214|r",
},
},
["class"] = "PALADIN",
},
["Lissándra-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Badmachine-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Dingusdingle-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Гонча"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Terasime-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Qtroll-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Spaceboogie-Ragnaros"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Usurpator-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Itzab-Alleria"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Neleza-Ragnaros"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Chikie-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Dkbfd-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Muddifriert-Thrall"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Loggo-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Norskhunter-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Kolohnel-Dalaran"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kinan-Nemesis"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Cc-Ghostlands"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Torrijas-Sanguino"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Xinz-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Terrivre-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Knasn-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Monkkesis-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MONK",
["deaths"] = {
{
0,
54.79099999996834,
"Черная кровь |cFFFF3333130,303|r",
},
},
},
["Holyhornie-DunModr"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Elauria-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Vîgald-Illidan"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Rihhis-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Walik-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Tanderbloom-Draenor"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
37.08699999999953,
"Брызгающее кровотечение |cFFFF33335,199,948|r",
},
},
["class"] = "DRUID",
},
["Chibbster-Blackrock"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
39.71299999998882,
"Брызгающее кровотечение |cFFFF33337,603,164|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Cptmarizzel-Blackrock"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
37.06899999998859,
"Брызгающее кровотечение |cFFFF33334,390,955|r",
},
},
["class"] = "WARLOCK",
},
["Huntahdk-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Holyshiv-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Badeschaum-Blackhand"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Xeljus-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Marinkonk-TarrenMill"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "MONK",
},
["Mefancy-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Аринве-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Emblair-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Noctroll-Blackrock"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
85.73099999999977,
"Брызгающее кровотечение |cFFFF33333,109,298|r",
},
},
["class"] = "MONK",
},
["Xzinne-TarrenMill"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Yadi-Eredar"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
38.76399999999558,
"Брызгающее кровотечение |cFFFF33335,257,185|r",
},
},
["class"] = "PALADIN",
},
["Vådnuddel-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Abc-Frostmane"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Xç-Archimonde"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
131.0169999999926,
"Черная кровь |cFFFF3333611,508|r",
},
},
["class"] = "WARRIOR",
},
["Wilkzpriest-Ragnaros"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
37.06899999998859,
"Брызгающее кровотечение |cFFFF33334,286,750|r",
},
},
["class"] = "PRIEST",
},
["Lenel-Mal'Ganis"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Tschamane-Blackhand"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Sevátar-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zerrox-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
},
},
["2918-14"] = {
["hash"] = "2918-14",
["type"] = "endurance",
["name"] = "Раша'нан",
["id"] = "2918-14",
["player_db"] = {
["Anexus-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Wavemaker-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Grant-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Evaug-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Playmoré-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Unstabledudu-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Solæry-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Elenthasa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Ckxs-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Xreaver-Doomhammer"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Cripzi-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["ßyew-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Yugíxx-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
},
["unixtime"] = 1726696503,
["diff"] = 14,
},
["2920-15"] = {
["hash"] = "2920-15",
["type"] = "endurance",
["name"] = "Принцесса Нексуса Ки'веза",
["id"] = "2920-15",
["unixtime"] = 1727879504,
["player_db"] = {
["Tishcyrus-TwistingNether"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
57.10499999998137,
"Дезинтеграция |cFFFF33332,290,015|r",
},
},
},
["Hulkbabe-Silvermoon"] = {
["encounters"] = 12,
["points"] = 1130,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
27.40600000001723,
"Дезинтеграция |cFFFF3333882,898|r",
},
{
0,
118.7920000000158,
"Затмение |cFFFF33334,175,599|r",
},
{
0,
118.8969999999972,
"Затмение |cFFFF33333,682,272|r",
},
{
0,
125.0250000000233,
"Затмение |cFFFF33331,276,942|r",
},
{
0,
248.5189999999711,
"Затмение |cFFFF33333,559,740|r",
},
{
0,
187.8549999999814,
"Дезинтеграция |cFFFF33331,239,605|r",
},
},
},
["Doyodex-Blackmoore"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
81.51299999999173,
"Темные внутренности |cFFFF33332,824,449|r",
},
},
["class"] = "WARRIOR",
},
["Mallwina-Drak'thul"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Stele-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Blightman-Draenor"] = {
["encounters"] = 18,
["points"] = 1800,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Shinigãmi-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Kamshika-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Егевлун-Гордунни"] = {
["encounters"] = 7,
["points"] = 690,
["class"] = "PALADIN",
["deaths"] = {
{
0,
125.2609999999986,
"Жнец |cFFFF3333652,514|r",
},
},
},
["Férxxo-Sanguino"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
217.4099999999744,
"Дезинтеграция |cFFFF33331,963,824|r",
},
},
},
["Jacuzzi-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Farmassist-Stormscale"] = {
["encounters"] = 7,
["points"] = 680,
["class"] = "MAGE",
["deaths"] = {
{
0,
116.2039999999688,
"Затмение |cFFFF33332,448,861|r",
},
{
0,
118.1209999999846,
"Жнец |cFFFF3333485,309|r",
},
},
},
["Haaribel-TarrenMill"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Romuless-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Stunoshka-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Bunglez-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Spenstlock-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Foi-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Demonbeast-Kazzak"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
72.96799999999348,
"Жнец |cFFFF3333728,248|r",
},
},
},
["Martyr-Ner'zhul"] = {
["encounters"] = 18,
["points"] = 1770,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
207.9519999999902,
"Погибель королев |cFFFF3333283,914|r",
},
{
0,
155.0370000000112,
"Жнец |cFFFF3333435,324|r",
},
{
0,
180.9380000000238,
"Жнец |cFFFF3333449,860|r",
},
},
},
["Triczm-Teldrassil"] = {
["encounters"] = 4,
["points"] = 380,
["class"] = "MONK",
["deaths"] = {
{
0,
180.4729999999981,
"Темные внутренности |cFFFF33332,500,653|r",
},
{
0,
26.57799999997951,
"Крадущиеся тени |cFFFF33336,401|r",
},
},
},
["Docrol-Kazzak"] = {
["encounters"] = 5,
["points"] = 480,
["class"] = "DRUID",
["deaths"] = {
{
0,
122.0329999999958,
"Затмение |cFFFF33332,434,475|r",
},
{
0,
210.2930000000051,
"Кинжалы Нексуса |cFFFF33332,914,331|r",
},
},
},
["Scoobydo-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "MONK",
["deaths"] = {
{
0,
286.9949999999953,
"Темные внутренности |cFFFF33331,583,862|r",
},
},
},
["Ptibec-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Lassmage-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Kürtaklesh-Nemesis"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Porkî-Eredar"] = {
["encounters"] = 18,
["points"] = 1780,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
57.34799999999814,
"Дезинтеграция |cFFFF33331,370,404|r",
},
{
0,
180.5050000000047,
"Жнец |cFFFF33331,015,521|r",
},
},
},
["Fluid-Kael'thas"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
286.4649999999965,
"Дезинтеграция |cFFFF33333,756,661|r",
},
},
["class"] = "WARLOCK",
},
["Davers-Norgannon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Flæ-Ravencrest"] = {
["encounters"] = 7,
["points"] = 680,
["class"] = "ROGUE",
["deaths"] = {
{
0,
158.3459999999614,
"Жнец |cFFFF3333387,372|r",
},
{
0,
209.5740000000224,
"Кинжалы Нексуса |cFFFF33331,389,000|r",
},
},
},
["Almalik-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Flaykrose-Hyjal"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "PALADIN",
["deaths"] = {
{
0,
125.2359999999753,
"Затмение |cFFFF33332,389,549|r",
},
},
},
["Kenøpsia-Draenor"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
57.10499999998137,
"Дезинтеграция |cFFFF33331,764,828|r",
},
},
},
["Melewin-ArgentDawn"] = {
["encounters"] = 5,
["points"] = 480,
["class"] = "MAGE",
["deaths"] = {
{
0,
116.7530000000261,
"Жнец |cFFFF3333580,559|r",
},
{
0,
250.9969999999739,
"Цареубийство |cFFFF33332,096,827|r",
},
},
},
["Shandriz-TwistingNether"] = {
["encounters"] = 4,
["points"] = 380,
["class"] = "HUNTER",
["deaths"] = {
{
0,
26.66200000001118,
"Дезинтеграция |cFFFF33331,331,248|r",
},
{
0,
157.0109999999986,
"Жнец |cFFFF3333335,262|r",
},
},
},
["Агренордемон-Ревущийфьорд"] = {
["encounters"] = 18,
["points"] = 1790,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
66.03200000000652,
"Жнец |cFFFF3333766,833|r",
},
},
},
["Fjallelujah-Draenor"] = {
["encounters"] = 11,
["points"] = 1080,
["class"] = "PRIEST",
["deaths"] = {
{
0,
180.1160000000382,
"Темные внутренности |cFFFF33332,676,485|r",
},
{
0,
177.8160000000498,
"Погибель королев |cFFFF3333853,130|r",
},
},
},
["Faskilight-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Prebi-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Muddifriert-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Odeliks-Ravencrest"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
209.9949999999953,
"Жнец |cFFFF3333731,954|r",
},
},
},
["Thunderforce-Drak'thul"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
118.7179999999935,
"Затмение |cFFFF33333,612,728|r",
},
},
["class"] = "SHAMAN",
},
["Zerataul-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Erhabi-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Gootoohell-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Nulare-BurningLegion"] = {
["encounters"] = 7,
["points"] = 700,
["class"] = "MAGE",
["deaths"] = {
},
},
["Vassili-Antonidas"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Dsora-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Muntyage-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Silentgale-Draenor"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Эшкар-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Kivertqtya-Doomhammer"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Mangocrumble-TarrenMill"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "MAGE",
["deaths"] = {
{
0,
49.42399999999907,
"Темные внутренности |cFFFF33332,234,861|r",
},
},
},
["Alchydragon-Kilrogg"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Bazgasht-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Lazidemon-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Qguea-BurningLegion"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Merxr-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Pizzaqq-Draenor"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
288.7579999999143,
"Жнец |cFFFF3333129,791|r",
},
},
},
["Xellon-Dalaran"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
79.53199999999197,
"Жнец |cFFFF333389,226|r",
},
},
["class"] = "PALADIN",
},
["Apagando-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Mega-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Hambare-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Taiss-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Hrj-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Usel-ShatteredHand"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Cc-Ghostlands"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 29,
["points"] = 2880,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
121.2850000000326,
"Затмение |cFFFF33332,223,304|r",
},
{
0,
49.46100000001025,
"Темные внутренности |cFFFF33331,342,023|r",
},
},
},
["Bazoka-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Anyx-Draenor"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "EVOKER",
["deaths"] = {
{
0,
287.7920000000158,
"Дезинтеграция |cFFFF3333975,374|r",
},
},
},
["Fipow-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Триппидру-ВечнаяПесня"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "DRUID",
["deaths"] = {
{
0,
31.59600000001956,
"Дезинтеграция |cFFFF33331,255,226|r",
},
},
},
["Mehteou-Dalaran"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Thirteenthxx-Terokkar"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Smoth-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Nasrp-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Hoofboy-Kazzak"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "DRUID",
["deaths"] = {
{
0,
172.4020000000019,
"Жнец |cFFFF33331,062,696|r",
},
},
},
["Esmeralde-Draenor"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "MAGE",
["deaths"] = {
},
},
["Itzab-Alleria"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
216.9170000000158,
"Дезинтеграция |cFFFF33333,868,338|r",
},
},
},
["Lueshan-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Eyeless-ShatteredHand"] = {
["encounters"] = 6,
["points"] = 590,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
308.2749999999069,
"Жнец |cFFFF3333606,868|r",
},
},
},
["Mök-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Guldiny-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Tchongman-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Darkilumine-Elune"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Kombìnation-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Elauria-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Malgenix-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Кумыславер-Гордунни"] = {
["encounters"] = 7,
["points"] = 700,
["class"] = "DRUID",
["deaths"] = {
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Aohh-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Badmachine-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Qtroll-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Torrijas-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Ignizion-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Monomer-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Navá-TarrenMill"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "PRIEST",
["deaths"] = {
{
0,
287.99099999998,
"Жнец |cFFFF3333678,000|r",
},
},
},
["Corpuscorax-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Henior-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Kymaro-Hyjal"] = {
["encounters"] = 18,
["points"] = 1770,
["class"] = "DRUID",
["deaths"] = {
{
0,
142.5659999999916,
"Раздирание Бездны |cFFFF3333870,292|r",
},
{
0,
178.6959999999963,
"Жнец |cFFFF33331,031,094|r",
},
{
0,
57.48999999999069,
"Дезинтеграция |cFFFF33333,011,024|r",
},
},
},
["Exproofdrood-Hyjal"] = {
["encounters"] = 18,
["points"] = 1760,
["class"] = "DRUID",
["deaths"] = {
{
0,
120.5259999999544,
"Беззвездная ночь |cFFFF3333100,955|r",
},
{
0,
51.08199999999488,
"Темные внутренности |cFFFF33332,167,493|r",
},
{
0,
49.46100000001025,
"Темные внутренности |cFFFF33332,019,080|r",
},
{
0,
212.640000000014,
"Темные внутренности |cFFFF33332,646,612|r",
},
},
},
["Yearlling-Hyjal"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "MAGE",
["deaths"] = {
},
},
["Sektum-Kazzak"] = {
["encounters"] = 7,
["points"] = 690,
["class"] = "PALADIN",
["deaths"] = {
{
0,
180.4340000000084,
"Крадущиеся тени |cFFFF333366,740|r",
},
},
},
["Cjlol-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Noixdepecan-Hyjal"] = {
["encounters"] = 11,
["points"] = 1090,
["class"] = "MAGE",
["deaths"] = {
{
0,
49.41800000000512,
"Жнец |cFFFF3333371,356|r",
},
},
},
["Holyhornie-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Kalëor-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Loggo-Antonidas"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Solð-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Maunó-Hellfire"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Cucksters-Draenor"] = {
["encounters"] = 18,
["points"] = 1760,
["class"] = "MONK",
["deaths"] = {
{
0,
186.8640000000014,
"Дезинтеграция |cFFFF33332,622,112|r",
},
{
0,
186.859999999986,
"Дезинтеграция |cFFFF33333,335,908|r",
},
{
0,
73.02100000000792,
"Жнец |cFFFF3333478,417|r",
},
{
0,
157.5580000000191,
"Темные внутренности |cFFFF33332,303,989|r",
},
},
},
["Drachenlord-Proudmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Destrodrag-Hyjal"] = {
["encounters"] = 18,
["points"] = 1760,
["class"] = "EVOKER",
["deaths"] = {
{
0,
157.350999999966,
"Темные внутренности |cFFFF33332,555,962|r",
},
{
0,
106.3190000000177,
"Затмение |cFFFF33333,118,801|r",
},
{
0,
124.7289999999921,
"Затмение |cFFFF33333,733,761|r",
},
{
0,
173.9400000000023,
"Погибель королев |cFFFF3333138,258|r",
},
},
},
["Фескари-Гордунни"] = {
["encounters"] = 7,
["points"] = 690,
["class"] = "PRIEST",
["deaths"] = {
{
0,
120.9699999999721,
"Цареубийство |cFFFF33332,023,933|r",
},
},
},
["Miyaseki-Archimonde"] = {
["encounters"] = 18,
["points"] = 1770,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
208.5270000000019,
"Жнец |cFFFF3333841,669|r",
},
{
0,
155.6199999999953,
"Дезинтеграция |cFFFF33332,716,965|r",
},
{
0,
125.3269999999902,
"Жнец |cFFFF3333872,635|r",
},
},
},
["Kimjongkook-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Flackong-Silvermoon"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
287.9499999999971,
"Жнец |cFFFF3333278,144|r",
},
},
["class"] = "MAGE",
},
["Velyr-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Bestclicker-TwistingNether"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
82.3350000000064,
"Жнец |cFFFF3333268,050|r",
},
},
["class"] = "PRIEST",
},
["Whispr-Ravencrest"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
115.6150000000052,
"Затмение |cFFFF33333,879,587|r",
},
},
["class"] = "PALADIN",
},
["Spampyro-TwistingNether"] = {
["encounters"] = 7,
["points"] = 690,
["class"] = "MAGE",
["deaths"] = {
{
0,
202.3720000000321,
"Темные внутренности |cFFFF33332,100,141|r",
},
},
},
["Nörden-TarrenMill"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Shifogi-Silvermoon"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Wildcyclone-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Legendaryace-Silvermoon"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
50.73400000001129,
"Темные внутренности |cFFFF33332,460,886|r",
},
},
["class"] = "MONK",
},
["Happyperiod-Silvermoon"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
305.6820000000007,
"Жнец |cFFFF3333804,164|r",
},
},
["class"] = "DRUID",
},
["Tâssp-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pandzie-Silvermoon"] = {
["encounters"] = 18,
["points"] = 1720,
["class"] = "MONK",
["deaths"] = {
{
0,
121.7440000000061,
"Жнец |cFFFF3333388,349|r",
},
{
0,
208.38400000002,
"Жнец |cFFFF3333480,359|r",
},
{
0,
186.859999999986,
"Дезинтеграция |cFFFF33332,813,888|r",
},
{
0,
79.4319999999716,
"Погибель королев |cFFFF33331,026,747|r",
},
{
0,
77.73300000000745,
"Жнец |cFFFF3333715,624|r",
},
{
0,
79.41899999999441,
"Темные внутренности |cFFFF33331,570,810|r",
},
{
0,
180.00900000002,
"Жнец |cFFFF3333233,273|r",
},
{
0,
170.1630000000005,
"Сумеречная резня |cFFFF33331,554,612|r",
},
},
},
["Monakkô-Blackhand"] = {
["encounters"] = 5,
["points"] = 490,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
80.27899999998044,
"Темные внутренности |cFFFF33332,478,005|r",
},
},
},
["Kehbabe-Hyjal"] = {
["encounters"] = 18,
["points"] = 1770,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
201.0070000000414,
"Жнец |cFFFF3333410,492|r",
},
{
0,
180.265000000014,
"Жнец |cFFFF3333298,942|r",
},
{
0,
57.06199999997625,
"Дезинтеграция |cFFFF33334,198,642|r",
},
},
},
["Shamesh-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
},
["diff"] = 15,
},
["2917-14"] = {
["hash"] = "2917-14",
["type"] = "endurance",
["name"] = "Скованный кровью ужас",
["id"] = "2917-14",
["player_db"] = {
["Anexus-Eredar"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "HUNTER",
["deaths"] = {
{
0,
136.3799999999756,
"Кровавый союз |cFFFF3333540,386|r",
},
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
127.9120000000112,
"Брызги крови |cFFFF33334,212,809|r",
},
},
["class"] = "DEMONHUNTER",
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
203.8120000000054,
"Потусторонняя хватка |cFFFF3333892,513|r",
},
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Xalvien-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Grant-Eredar"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Вольтчара"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
128.0419999999867,
"Брызги крови |cFFFF33339,612,052|r",
},
},
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Solæry-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Unstabledudu-Outland"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Elenthasa-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
164.0239999999758,
"Атака ближнего боя |cFFFF3333382,311|r",
},
},
},
["Cripzi-Eredar"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Xreaver-Doomhammer"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Ckxs-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["ßyew-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Raylebtw-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Playmoré-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Evaug-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
},
["unixtime"] = 1726695414,
["diff"] = 14,
},
["2921-15"] = {
["hash"] = "2921-15",
["type"] = "endurance",
["name"] = "Шелковый двор",
["id"] = "2921-15",
["unixtime"] = 1727883194,
["player_db"] = {
["Lazidemon-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
42.07600000000093,
"Безрассудный удар |cFFFF33332,216,562|r",
},
},
},
["Bloomingice-Magtheridon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Intonraiha-KultderVerdammten"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Llj-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Yhodas-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Madapes-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Gzez-ChamberofAspects"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Âce-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Mega-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Férxxo-Sanguino"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
100.0119999999879,
"Безрассудный удар |cFFFF33333,403,220|r",
},
},
},
["Warswen-Sargeras"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Gordepon-C'Thun"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Slowme-Kazzak"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
99.86899999994785,
"Безрассудный удар |cFFFF33333,573,420|r",
},
},
["class"] = "MAGE",
},
["Usel-ShatteredHand"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Loggo-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Spenstlock-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Cc-Ghostlands"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Huunbii-Ragnaros"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "EVOKER",
["deaths"] = {
{
0,
38.71899999992456,
"Паутинная бомба |cFFFF3333824,563|r",
},
},
},
["Вольтчара"] = {
["encounters"] = 12,
["points"] = 1200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Bazoka-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Alidori-Blackmoore"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Warlockaza-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Atrainbaby-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Daskull-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Senys-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Myrie-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Ilovelatinas-Kazzak"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
99.15300000004936,
"Безрассудный удар |cFFFF33333,888,309|r",
},
},
["class"] = "MAGE",
},
["Flötenkopf-Blackhand"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Bonkko-Ravencrest"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DRUID",
},
["Vanillalce-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Adj-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Lueshan-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Mök-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Darklmnt-Hellfire"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
138.804999999993,
"Ядовитый дождь |cFFFF3333385,593|r",
},
},
},
["Bazgasht-Kazzak"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "DRUID",
["deaths"] = {
{
0,
41.92099999997299,
"Безрассудный удар |cFFFF33333,214,217|r",
},
{
0,
42.07600000000093,
"Безрассудный удар |cFFFF33334,013,365|r",
},
},
},
["Dartharm-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Papasharkz-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Xristodoulas-Chromaggus"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
261.0529999999562,
"Опутывающая паутина |cFFFF3333197,705|r",
},
},
["class"] = "PRIEST",
},
["Maradenlock-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Kalëor-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Memelord-Thunderhorn"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
99.15300000004936,
"Безрассудный удар |cFFFF33333,598,342|r",
},
{
0,
404.7060000000056,
"Вихрь паутины |cFFFF3333328,385|r",
},
},
["class"] = "HUNTER",
},
["Bàphometh-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Darnock-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Darkilumine-Elune"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Kagerou-Chromaggus"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Nooeen-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Tanqs-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Ouija-Kazzak"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "MAGE",
["deaths"] = {
{
0,
99.60500000003958,
"Безрассудный удар |cFFFF33333,673,291|r",
},
{
0,
178.0829999999842,
"Раскол мироздания |cFFFF33331,597,037|r",
},
},
},
["Dæhli-ArgentDawn"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
32.55800000001909,
"Опутывающая паутина |cFFFF3333218,083|r",
},
{
0,
137.3329999999842,
"Раскол мироздания |cFFFF33331,721,721|r",
},
},
},
["Muntyage-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Zakkü-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Mantrax-Madmortem"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
406.8329999999842,
"Опутывающая паутина |cFFFF3333113,759|r",
},
{
0,
405.2070000000531,
"Опутывающая паутина |cFFFF3333200,934|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Rougelet-Ravencrest"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Xcalvins-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Faskilight-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Elmavodka-Magtheridon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Loststeps-Ravencrest"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Döömzday-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
99.60500000003958,
"Безрассудный удар |cFFFF33333,503,443|r",
},
},
},
["Holyhornie-DunModr"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "PRIEST",
["deaths"] = {
{
0,
98.65200000000186,
"Опутывающая паутина |cFFFF3333166,721|r",
},
},
},
["Södermunk-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Grimreapurr-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Prîmecut-Blackmoore"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Thnpanagiaa-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Badmachine-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Stele-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Torrijas-Sanguino"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Ignizion-Sanguino"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Muddifriert-Thrall"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
42.04300000000512,
"Безрассудный удар |cFFFF33333,448,480|r",
},
},
},
["Cjlol-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Silyse-ArgentDawn"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Adalaer-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Solð-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Merxr-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Drogdure-Archimonde"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
99.55400000000373,
"Безрассудный рывок |cFFFF33331,421,279|r",
},
{
0,
42.04300000000512,
"Безрассудный удар |cFFFF33331,065,370|r",
},
},
},
["Fiman-Silvermoon"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
42.04300000000512,
"Безрассудный удар |cFFFF33333,403,913|r",
},
},
},
["Adriank-Proudmoore"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Bullweìh-Blackhand"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Keeliyio-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Таладриэн-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Gèhrman-Nemesis"] = {
["encounters"] = 5,
["points"] = 460,
["deaths"] = {
{
0,
205.064000000013,
"Энтропическое опустошение |cFFFF3333966,939|r",
},
{
0,
403.3669999999693,
"Опутывающая паутина |cFFFF333393,379|r",
},
{
0,
99.15300000004936,
"Безрассудный удар |cFFFF33331,423,788|r",
},
{
0,
99.86899999994785,
"Безрассудный удар |cFFFF33331,671,099|r",
},
},
["class"] = "HUNTER",
},
["Stuffy-Zenedar"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Рейст-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Schneckprist-Blackhand"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
401.2490000000689,
"Подземное извержение |cFFFF3333726,927|r",
},
},
["class"] = "PRIEST",
},
["Denixbiceps-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Thraxe-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Shamesh-Sanguino"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Melawarri-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Monomer-Kazzak"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
41.92099999997299,
"Безрассудный удар |cFFFF33331,631,202|r",
},
{
0,
42.07600000000093,
"Безрассудный удар |cFFFF33333,494,140|r",
},
},
},
["Shellie-Drak'thul"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
409.4370000000345,
"Безрассудный удар |cFFFF33334,455,113|r",
},
},
["class"] = "PRIEST",
},
["Nerama-Nordrassil"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Shannarocold-Ragnaros"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
261.0289999999804,
"Вихрь паутины |cFFFF3333523,057|r",
},
},
["class"] = "PRIEST",
},
["Intèrnet-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Rykotsuseì-Silvermoon"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
99.86899999994785,
"Безрассудный удар |cFFFF33333,757,604|r",
},
},
["class"] = "EVOKER",
},
["Teetho-Turalyon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
},
["diff"] = 15,
},
["2919-14"] = {
["hash"] = "2919-14",
["type"] = "endurance",
["name"] = "Исказитель яиц Ови'накс",
["id"] = "2919-14",
["player_db"] = {
["Anexus-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
194.0509999999777,
"Мерзкий выброс |cFFFF3333411,629|r",
},
},
["class"] = "MONK",
},
["Sathrovarr-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Pryv-Teldrassil"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Kyrris-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Evaug-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Naanji-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Livhx-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Wárstyle-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tåård-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Chaostoilet-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lightheaven-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Vairhoult-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Праддмаг-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Maykelhero-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Starnovaa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Grant-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Вольтчара"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Рыцарьволк-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Playmoré-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Solæry-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Unstabledudu-Outland"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Ødïñ-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Ckxs-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Haralambie-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Elenthasa-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Tondsa-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Xreaver-Doomhammer"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Cripzi-Eredar"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["ßyew-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Yugíxx-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nemesme-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
},
["unixtime"] = 1726697614,
["diff"] = 14,
},
["2919-15"] = {
["hash"] = "2919-15",
["type"] = "endurance",
["name"] = "Исказитель яиц Ови'накс",
["id"] = "2919-15",
["diff"] = 15,
["unixtime"] = 1727880509,
["player_db"] = {
["Nothgard-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
193.1049999999959,
"Мерзкий выброс |cFFFF3333309,251|r",
},
},
["class"] = "PALADIN",
},
["Varaldor-Eldre'Thalas"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Iñðóri-KhazModan"] = {
["encounters"] = 9,
["points"] = 890,
["class"] = "PALADIN",
["deaths"] = {
{
0,
55.34700000000885,
"Атака ближнего боя |cFFFF33333,422,995|r",
},
},
},
["Mallwina-Drak'thul"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Stronkaf-TarrenMill"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
50.32899999999791,
"Атака ближнего боя |cFFFF33333,817,534|r",
},
},
["class"] = "DRUID",
},
["Stele-Nemesis"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Nerfio-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Sewý-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
141.2010000000009,
"Нестабильная смесь |cFFFF33331,594,165|r",
},
},
["class"] = "MAGE",
},
["Tatzzô-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Restoine-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
84.69099999999162,
"Кислотная реакция |cFFFF3333515,267|r",
},
},
},
["Neziaðrooð-Dalaran"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
196.7920000000158,
"Кислотная реакция |cFFFF3333711,008|r",
},
},
["class"] = "DRUID",
},
["Adsoraka-Frostwhisper"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Truit-Blackhand"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "DRUID",
["deaths"] = {
},
},
["Zerosixtyøne-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
1,
319.4259999999777,
"Заражение |cFFFF3333263,999|r",
},
},
},
["Goxer-Ysondre"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "MAGE",
},
["Контекст-Ревущийфьорд"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Huntahdk-Kazzak"] = {
["encounters"] = 6,
["points"] = 590,
["deaths"] = {
{
0,
111.9040000000096,
"Атака ближнего боя |cFFFF3333818,076|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Âzalée-Archimonde"] = {
["encounters"] = 10,
["points"] = 980,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
47.74599999998463,
"Атака ближнего боя |cFFFF33333,626,395|r",
},
{
0,
148.0540000000037,
"Атака ближнего боя |cFFFF33333,575,923|r",
},
},
},
["Lockfree-Frostwolf"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
309.890000000014,
"Нестабильная смесь |cFFFF33331,915,761|r",
},
},
},
["Ilkar-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
143.2680000000401,
"Кислотная реакция |cFFFF3333929,474|r",
},
},
["class"] = "PRIEST",
},
["Намокшая-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
66.6030000000028,
"Атака ближнего боя |cFFFF33332,336,423|r",
},
},
},
["Kiyose-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Xç-Archimonde"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Hollowdreams-Silvermoon"] = {
["encounters"] = 9,
["points"] = 900,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Flámme-Ravencrest"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "MAGE",
["deaths"] = {
{
0,
56.09399999998277,
"Атака ближнего боя |cFFFF33334,764,999|r",
},
},
},
["Marsupulami-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
1,
228.3690000000643,
"Атака ближнего боя |cFFFF33332,253,862|r",
},
},
},
["Garkhau-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Blurf-Hyjal"] = {
["encounters"] = 5,
["points"] = 470,
["deaths"] = {
{
0,
321.9440000000177,
"Атака ближнего боя |cFFFF33332,198,298|r",
},
{
0,
147.9139999999898,
"Кислотная реакция |cFFFF3333431,006|r",
},
{
0,
374.1680000000633,
"Заражение |cFFFF3333214,507|r",
},
},
["class"] = "DEMONHUNTER",
},
["Xavvz-Zul'jin"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "MONK",
["deaths"] = {
{
0,
124.8189999999595,
"Кровавый потоп |cFFFF333381,601|r",
},
},
},
["Loggo-Antonidas"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Bobazer-Archimonde"] = {
["encounters"] = 11,
["points"] = 1080,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
123.3850000000093,
"Нестабильная смесь |cFFFF33331,346,896|r",
},
{
0,
53.08600000001025,
"Атака ближнего боя |cFFFF33332,540,230|r",
},
},
},
["Shiftyjhin-Silvermoon"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
370.6280000000261,
"Кислотная реакция |cFFFF333345,472|r",
},
},
["class"] = "DRUID",
},
["Xolati-Ragnaros"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
278.8240000000224,
"Нестабильная смесь |cFFFF33331,978,149|r",
},
},
},
["Jayjaý-TarrenMill"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "MAGE",
["deaths"] = {
{
0,
166.8520000000135,
"Нестабильная смесь |cFFFF3333888,350|r",
},
},
},
["Guldarak-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Pingôux-Dalaran"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Greenwy-Arathor"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
139.9570000000531,
"Липкая паутина(ДоТ) |cFFFF3333139,711|r",
},
},
["class"] = "MAGE",
},
["Yasuoxd-Draenor"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
105.7760000000708,
"Атака ближнего боя |cFFFF33332,697,848|r",
},
},
["class"] = "WARRIOR",
},
["Fiman-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Tortoise-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Mightyvokeaf-Thrall"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Damagebox-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Hôka-Eldre'Thalas"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
385.6089999999967,
"Мерзкий выброс |cFFFF33331,041,994|r",
},
},
},
["Дуювсуши-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Mmdv-Kazzak"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
102.8059999999969,
"Выброс яда |cFFFF33331,307,271|r",
},
{
0,
30.59000000001106,
"Мерзкий выброс |cFFFF33331,106,497|r",
},
},
["class"] = "HUNTER",
},
["Zeiss-Ysondre"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
365.9029999999912,
"Кислотная реакция |cFFFF3333256,336|r",
},
},
["class"] = "EVOKER",
},
["Hexmyflex-Silvermoon"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
147.9420000000391,
"Нестабильная смесь |cFFFF33332,427,747|r",
},
},
["class"] = "SHAMAN",
},
["Keyr-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Hughlaurie-Zul'jin"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
2,
215.5470000000205,
"Заражение |cFFFF3333170,576|r",
},
},
["class"] = "MAGE",
},
["Dripbozo-Drak'thul"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
199.8930000000401,
"Мерзкий выброс |cFFFF3333280,440|r",
},
},
["class"] = "WARRIOR",
},
["Gruselgerd-Eredar"] = {
["encounters"] = 4,
["points"] = 380,
["deaths"] = {
{
0,
317.5989999999874,
"Кислотная реакция |cFFFF3333191,780|r",
},
{
0,
266.6330000000016,
"Мерзкий выброс |cFFFF33331,086,399|r",
},
},
["class"] = "WARLOCK",
},
["Joraal-Archimonde"] = {
["encounters"] = 8,
["points"] = 770,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
201.454000000027,
"Мерзкий выброс |cFFFF3333340,211|r",
},
{
0,
55.96700000000419,
"Атака ближнего боя |cFFFF33335,199,749|r",
},
{
0,
345.7909999999683,
"Мерзкий выброс |cFFFF3333395,479|r",
},
},
},
["Chopimonk-Hyjal"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MONK",
["deaths"] = {
{
0,
150.9660000000149,
"Мерзкий выброс |cFFFF3333356,232|r",
},
},
},
["Eiserli-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Saphisto-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Phru-Blackrock"] = {
["encounters"] = 4,
["points"] = 380,
["deaths"] = {
{
0,
354.8089999999938,
"Кислотная реакция |cFFFF3333523,487|r",
},
{
3,
145.351999999999,
"Нестабильная смесь |cFFFF33332,337,870|r",
},
},
["class"] = "MAGE",
},
["Badmachine-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Мыркалка-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Lenel-Mal'Ganis"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Palmangue-DunModr"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
125.7810000000027,
"Атака ближнего боя |cFFFF3333266,053|r",
},
},
["class"] = "PALADIN",
},
["Rihhis-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Bismila-Eitrigg"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "PALADIN",
["deaths"] = {
{
0,
47.02899999998044,
"Атака ближнего боя |cFFFF33332,799,457|r",
},
},
},
["Серегапобеда-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Chichlock-Hyjal"] = {
["encounters"] = 7,
["points"] = 680,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
374.8999999999651,
"Заражение |cFFFF3333164,544|r",
},
{
0,
107.3329999999842,
"Атака ближнего боя |cFFFF33334,778,432|r",
},
},
},
["Usurpator-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Myroox-Eredar"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "MAGE",
["deaths"] = {
},
},
["Tobbos-KirinTor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Cystronc-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Rasman-Ragnaros"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Abc-Frostmane"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Marinkonk-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Shamesh-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Aliski-Antonidas"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
478.0270000000019,
"Мерзкий выброс |cFFFF3333743,952|r",
},
},
["class"] = "DRUID",
},
["Vîgald-Illidan"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "MONK",
},
["Dingusdingle-TwistingNether"] = {
["encounters"] = 6,
["points"] = 580,
["deaths"] = {
{
0,
101.0540000000037,
"Атака ближнего боя |cFFFF33335,705,749|r",
},
{
0,
217.5920000000042,
"Нестабильная смесь |cFFFF3333935,776|r",
},
},
["class"] = "WARRIOR",
},
["Södermunk-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Terasime-Archimonde"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Synhepa-Archimonde"] = {
["encounters"] = 4,
["points"] = 380,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
48.24300000001676,
"Атака ближнего боя |cFFFF33333,857,072|r",
},
{
0,
50.71100000001025,
"Яростный укус |cFFFF3333709,254|r",
},
},
},
["Barneycheng-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Trèsdin-Hyjal"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "PALADIN",
["deaths"] = {
{
0,
309.8429999999935,
"Нестабильная смесь |cFFFF3333154,352|r",
},
},
},
["Sertral-Draenor"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MAGE",
},
["Akrodemo-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
87.61199999996461,
"Мерзкий выброс |cFFFF3333334,467|r",
},
},
},
["Chikie-Ravencrest"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Finnfairway-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Muddifriert-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Veronická-Drak'thul"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DRUID",
["deaths"] = {
},
},
["Holyhornie-DunModr"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Ltisenrage-Stormscale"] = {
["encounters"] = 3,
["points"] = 280,
["deaths"] = {
{
0,
147.9139999999898,
"Кислотная реакция |cFFFF3333421,053|r",
},
{
0,
368.4590000000317,
"Заражение |cFFFF3333260,272|r",
},
},
["class"] = "WARRIOR",
},
["Naoken-Hyjal"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
2,
157.0180000000401,
"Атака ближнего боя |cFFFF33333,381,594|r",
},
},
["class"] = "MONK",
},
["Джимбич-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Hollowsoup-Hyjal"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
389.5100000000093,
"Извержение паутины |cFFFF3333895,959|r",
},
},
["class"] = "PRIEST",
},
["Norolemodelz-Ravencrest"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Terrivre-Ravencrest"] = {
["encounters"] = 6,
["points"] = 580,
["deaths"] = {
{
0,
98.17499999998836,
"Атака ближнего боя |cFFFF33334,622,605|r",
},
{
0,
353.0469999999914,
"Нестабильная смесь |cFFFF33331,387,229|r",
},
},
["class"] = "MAGE",
},
["Царрапкка-Гордунни"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
220.6030000000028,
"Нестабильное вливание |cFFFF33330|r",
},
},
["class"] = "ROGUE",
},
["Dakiss-Ysondre"] = {
["encounters"] = 9,
["points"] = 870,
["class"] = "ROGUE",
["deaths"] = {
{
0,
197.3520000000135,
"Мерзкий выброс |cFFFF33331,035,069|r",
},
{
0,
33.13699999998789,
"Мерзкий выброс |cFFFF3333897,882|r",
},
{
0,
32.51399999996647,
"Мерзкий выброс |cFFFF3333413,122|r",
},
},
},
["Jïrren-Archimonde"] = {
["encounters"] = 12,
["points"] = 1170,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
388.8550000000396,
"Нестабильное вливание |cFFFF333354,871|r",
},
{
0,
10.19099999999162,
"Атака ближнего боя |cFFFF33331,361,920|r",
},
{
0,
226.8020000000252,
"Выброс яда |cFFFF33331,144,834|r",
},
},
},
["Wønkä-Hyjal"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DRUID",
["deaths"] = {
},
},
["Adonius-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Relenia-Eredar"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Célïne-Hyjal"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "EVOKER",
["deaths"] = {
{
0,
368.5869999999995,
"Заражение |cFFFF3333229,158|r",
},
},
},
["Dreyløl-Thrall"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
138.3649999999907,
"Нестабильное вливание |cFFFF3333150,662|r",
},
},
["class"] = "SHAMAN",
},
["Secretpush-Kazzak"] = {
["encounters"] = 9,
["points"] = 890,
["class"] = "ROGUE",
["deaths"] = {
{
0,
20.66800000000512,
"Глоток черной крови |cFFFF3333500,724|r",
},
},
},
["Auximausi-Blackhand"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
162.7880000000005,
"Нестабильная смесь |cFFFF33332,563,911|r",
},
},
},
["Серхиоперец-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Holyshiv-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Doisuck-Silvermoon"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
147.9420000000391,
"Нестабильная смесь |cFFFF33332,067,832|r",
},
{
0,
147.4050000000279,
"Яростный укус |cFFFF3333212,840|r",
},
},
["class"] = "DEMONHUNTER",
},
["Apaçhe-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Torrijas-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Pantheøn-Zul'jin"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
99.44999999999709,
"Атака ближнего боя |cFFFF33332,765,407|r",
},
{
0,
102.778999999995,
"Атака ближнего боя |cFFFF33336,851,866|r",
},
},
["class"] = "WARRIOR",
},
["Vådnuddel-TarrenMill"] = {
["encounters"] = 6,
["points"] = 580,
["deaths"] = {
{
0,
1.029999999998836,
"Атака ближнего боя |cFFFF33335,467,097|r",
},
{
0,
47.07700000000477,
"Атака ближнего боя |cFFFF33332,361,633|r",
},
},
["class"] = "DEMONHUNTER",
},
["Pewpewcider-Blackrock"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
103.8680000000168,
"Нестабильная смесь |cFFFF33332,093,274|r",
},
},
["class"] = "HUNTER",
},
["Noctroll-Blackrock"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Chukia-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Grosmalus-KhazModan"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Sâikâ-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "PALADIN",
["deaths"] = {
{
0,
216.1780000000144,
"Нестабильная смесь |cFFFF33331,479,411|r",
},
},
},
["Sewerslvt-DefiasBrotherhood"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Bezarro-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Ictaluridae-Silvermoon"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Neleza-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Vychcaney-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Ædden-Blackrock"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "DRUID",
["deaths"] = {
{
0,
278.8240000000224,
"Нестабильная смесь |cFFFF33331,311,594|r",
},
},
},
["Cedrack-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Melifecent-Stormscale"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Filantrop-Hyjal"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
57.47299999999814,
"Атака ближнего боя |cFFFF33334,213,386|r",
},
},
},
["Qtroll-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Necrodon-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Mijalord-DunModr"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "MAGE",
["deaths"] = {
{
0,
202.8330000000424,
"Мерзкий выброс |cFFFF3333495,968|r",
},
},
},
["Néva-Uldaman"] = {
["encounters"] = 9,
["points"] = 880,
["class"] = "PALADIN",
["deaths"] = {
{
0,
216.4640000000363,
"Нестабильная смесь |cFFFF3333712,753|r",
},
{
0,
385.8010000000359,
"Мерзкий выброс |cFFFF3333354,995|r",
},
},
},
["Shîzunka-Drak'thul"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DRUID",
["deaths"] = {
},
},
["Schala-DunModr"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Yatsufusa-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Electrocutr-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Slòtherus-Blackhand"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "PALADIN",
["deaths"] = {
{
0,
45.82000000000699,
"Атака ближнего боя |cFFFF33333,564,948|r",
},
},
},
["Rëgi-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
64.37799999996787,
"Нестабильная смесь |cFFFF33331,743,124|r",
},
},
},
["Trevils-Pozzodell'Eternità"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
103.8680000000168,
"Нестабильная смесь |cFFFF33331,716,700|r",
},
{
0,
137.2399999999907,
"Кислотная реакция |cFFFF3333950,137|r",
},
},
["class"] = "MAGE",
},
["Eowhyn-ArgentDawn"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Niaz-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Ráncour-Blackhand"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
98.51899999997113,
"Атака ближнего боя |cFFFF33333,555,204|r",
},
},
},
["Hogmandir-Silvermoon"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Zeldo-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Shesa-Archimonde"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
29.6589999999851,
"Мерзкий выброс |cFFFF33331,030,309|r",
},
},
["class"] = "HUNTER",
},
["Emblair-TarrenMill"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Chevrepinard-KhazModan"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Farangis-Blackhand"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "MAGE",
["deaths"] = {
},
},
["Elérine-Dalaran"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Dêecy-Dalaran"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Goglad-Dalaran"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Teritaures-Blackrock"] = {
["encounters"] = 9,
["points"] = 830,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
73.84699999995064,
"Атака ближнего боя |cFFFF33331,225,034|r",
},
{
0,
70.39600000000792,
"Яростный укус |cFFFF3333901,329|r",
},
{
0,
57.9089999999851,
"Атака ближнего боя |cFFFF3333697,951|r",
},
{
0,
160.5939999999828,
"Кровавый потоп |cFFFF333389,905|r",
},
{
0,
53.95600000000559,
"Яростный укус |cFFFF3333140,686|r",
},
{
0,
104.2209999999614,
"Атака ближнего боя |cFFFF33331,287,768|r",
},
},
},
["Rujiao-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
104.6239999999525,
"Нестабильная смесь |cFFFF3333679,249|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Savymage-Drak'thul"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "MAGE",
["deaths"] = {
{
0,
53.20400000002701,
"Атака ближнего боя |cFFFF33331,758,325|r",
},
},
},
["Cíel-Eredar"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
58.04100000008475,
"Липкая паутина(ДоТ) |cFFFF333372,408|r",
},
},
},
["Мадислав"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Deadbycorona-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Milissata-KirinTor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Øptimusprìme-Stormscale"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "PRIEST",
["deaths"] = {
{
0,
216.4640000000363,
"Нестабильная смесь |cFFFF33331,240,599|r",
},
},
},
["Czelious-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Kasgor-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Zyroxxzz-KhazModan"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Zxxnder-Ragnaros"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "MAGE",
["deaths"] = {
{
0,
348.63400000002,
"Заражение |cFFFF3333215,130|r",
},
{
0,
101.3289999999688,
"Атака ближнего боя |cFFFF33334,731,980|r",
},
},
},
["Lorakruul-Sanguino"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "MAGE",
},
["Velø-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Onidia-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Cjlol-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Justinfusion-Ysondre"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
4,
210.9339999999938,
"Нестабильное вливание |cFFFF3333279,067|r",
},
},
["class"] = "PRIEST",
},
["Itsjukez-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Zandalori-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Kalëor-Ysondre"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Zalestis-Ragnaros"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
327.9250000000029,
"Заражение |cFFFF3333326,531|r",
},
},
["class"] = "DEMONHUNTER",
},
["Venomshot-Quel'Thalas"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Ignizion-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Salarash-Blackmoore"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Nörden-Sylvanas"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
140.9789999999921,
"Нестабильная смесь |cFFFF3333427,726|r",
},
},
["class"] = "WARRIOR",
},
["Bumur-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Treghold-Silvermoon"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Milleniudk-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Käellthas-DunModr"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
4,
212.9409999999916,
"Экспериментальная доза |cFFFF3333690,918|r",
},
},
["class"] = "PRIEST",
},
["Mootiesu-BurningLegion"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "DRUID",
["deaths"] = {
{
0,
54.51799999998184,
"Атака ближнего боя |cFFFF33334,838,439|r",
},
},
},
["Gredush-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Ashama-Eldre'Thalas"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "PRIEST",
["deaths"] = {
{
0,
316.2479999999632,
"Нестабильная смесь |cFFFF33331,175,221|r",
},
},
},
["Bayly-DunModr"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Prdnjava-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Ендж-ВечнаяПесня"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Waroù-Hyjal"] = {
["encounters"] = 5,
["points"] = 460,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
99.83399999997346,
"Атака ближнего боя |cFFFF33333,402,153|r",
},
{
0,
54.49400000000605,
"Атака ближнего боя |cFFFF33332,882,198|r",
},
{
0,
384.7960000000312,
"Экспериментальная доза |cFFFF33331,017,887|r",
},
{
0,
224.274000000034,
"Извержение паутины |cFFFF3333696,942|r",
},
},
},
["Rhanati-Aegwynn"] = {
["encounters"] = 7,
["points"] = 670,
["deaths"] = {
{
0,
52.69600000001083,
"Атака ближнего боя |cFFFF33333,522,430|r",
},
{
0,
48.83799999998882,
"Атака ближнего боя |cFFFF33332,814,607|r",
},
{
3,
145.351999999999,
"Нестабильная смесь |cFFFF33331,166,653|r",
},
},
["class"] = "WARRIOR",
},
["Чудоскуф-Ревущийфьорд"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Eraddak-Eldre'Thalas"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Twoninety-Nemesis"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Tjaswexdlol-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Thelnar-Outland"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Ajindo-TarrenMill"] = {
["encounters"] = 9,
["points"] = 900,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Howyoudie-BurningLegion"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Mooladin-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Ardarik-TarrenMill"] = {
["encounters"] = 9,
["points"] = 890,
["class"] = "PALADIN",
["deaths"] = {
{
0,
387.0200000000186,
"Нестабильная смесь |cFFFF33331,362,010|r",
},
},
},
["Xofehanse-TwistingNether"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "DRUID",
},
["Вайнрэд-Гордунни"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
2,
216.9290000000037,
"Заражение |cFFFF3333340,076|r",
},
},
["class"] = "MAGE",
},
["Proudmoorree-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
236.1060000000289,
"Нестабильная смесь |cFFFF33331,402,995|r",
},
},
},
["Вольтчара"] = {
["encounters"] = 47,
["points"] = 4690,
["deaths"] = {
{
0,
29.12599999998929,
"Мерзкий выброс |cFFFF3333583,745|r",
},
},
["class"] = "SHAMAN",
},
["Cc-Ghostlands"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Dreddfred-Nagrand"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Mixxuif-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Raktharv-Pozzodell'Eternità"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Heisemb-Archimonde"] = {
["encounters"] = 13,
["points"] = 1280,
["class"] = "HUNTER",
["deaths"] = {
{
0,
12.09499999997206,
"Нестабильная смесь |cFFFF3333279,067|r",
},
{
0,
57.0010000000475,
"Атака ближнего боя |cFFFF33335,127,607|r",
},
},
},
["Xinz-Blackrock"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
105.0650000000023,
"Нестабильная смесь |cFFFF33331,334,965|r",
},
},
["class"] = "MAGE",
},
["Гонча"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
48.45199999999022,
"Атака ближнего боя |cFFFF33332,085,916|r",
},
},
["class"] = "WARRIOR",
},
["Lavazero-Silvermoon"] = {
["encounters"] = 9,
["points"] = 890,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
47.82000000000699,
"Атака ближнего боя |cFFFF33333,769,854|r",
},
},
},
["Kirishadow-Sargeras"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "PRIEST",
["deaths"] = {
{
0,
5.593999999982771,
"Атака ближнего боя |cFFFF33335,058,639|r",
},
},
},
["Restfett-Blackrock"] = {
["encounters"] = 8,
["points"] = 770,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
23.29699999996228,
"Мерзкий выброс |cFFFF33331,192,212|r",
},
{
0,
155.3230000000331,
"Атака ближнего боя |cFFFF33333,927,633|r",
},
{
0,
207.9639999999781,
"Мерзкий выброс |cFFFF3333889,940|r",
},
},
},
["Iralespeed-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Candlydark-TarrenMill"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Boki-Blackhand"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Radopal-Drak'thul"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "PALADIN",
["deaths"] = {
{
0,
63.15200000000186,
"Нестабильная смесь |cFFFF33331,998,527|r",
},
},
},
["Scindi-Kazzak"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "MAGE",
},
["Zorotar-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Chamú-Sanguino"] = {
["encounters"] = 9,
["points"] = 900,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Roccanar-KhazModan"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Kolohnel-Dalaran"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Naralaks-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Gojover-Outland"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Elpistølero-Draenor"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "PRIEST",
["deaths"] = {
{
0,
446.2630000000354,
"Заражение |cFFFF3333428,942|r",
},
},
},
["Zeldrône-Stormscale"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
438.5410000000848,
"Заражение |cFFFF3333300,733|r",
},
},
},
["Kinan-Nemesis"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Knasn-TarrenMill"] = {
["encounters"] = 7,
["points"] = 680,
["deaths"] = {
{
0,
85.01800000001094,
"Нестабильная смесь |cFFFF33332,156,151|r",
},
{
3,
145.351999999999,
"Нестабильная смесь |cFFFF33332,412,629|r",
},
},
["class"] = "MAGE",
},
["Mefancy-Kazzak"] = {
["encounters"] = 2,
["points"] = 180,
["class"] = "PRIEST",
["deaths"] = {
{
0,
85.30300000007264,
"Нестабильная смесь |cFFFF3333855,365|r",
},
{
1,
314.9660000000149,
"Заражение |cFFFF3333216,570|r",
},
},
},
["Gharus-Kael'thas"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Mutumbo-Hyjal"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
4,
221.224000000002,
"Извержение паутины |cFFFF3333243,482|r",
},
},
["class"] = "PRIEST",
},
["Sólde-Zul'jin"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Мактанан-Ревущийфьорд"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Dkbfd-Silvermoon"] = {
["encounters"] = 9,
["points"] = 900,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Mickjack-Drak'thul"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Lissándra-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Koreig-Sargeras"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MONK",
["deaths"] = {
{
0,
309.890000000014,
"Нестабильная смесь |cFFFF33331,570,014|r",
},
},
},
["Делюженичё-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Sneakypoli-Silvermoon"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
321.8930000000401,
"Мерзкий выброс |cFFFF3333452,811|r",
},
},
["class"] = "ROGUE",
},
["Cptnchaos-Blackmoore"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
388.5550000000512,
"Заражение |cFFFF3333447,979|r",
},
},
},
["Bingadinga-Silvermoon"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
145.6990000000224,
"Экспериментальная доза |cFFFF33331,103,793|r",
},
},
["class"] = "WARLOCK",
},
["Screalth-TwistingNether"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Piattocaldo-Pozzodell'Eternità"] = {
["encounters"] = 9,
["points"] = 890,
["class"] = "DRUID",
["deaths"] = {
{
0,
52.51800000004005,
"Атака ближнего боя |cFFFF33333,613,048|r",
},
},
},
["Аринве-Ревущийфьорд"] = {
["encounters"] = 6,
["points"] = 590,
["deaths"] = {
{
0,
97.1929999999993,
"Атака ближнего боя |cFFFF33334,733,694|r",
},
},
["class"] = "HUNTER",
},
["Orelia-Aegwynn"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
202.7950000000419,
"Кислотная реакция |cFFFF3333741,287|r",
},
},
["class"] = "PALADIN",
},
["Goolix-TwistingNether"] = {
["encounters"] = 6,
["points"] = 590,
["deaths"] = {
{
0,
144.9079999999958,
"Нестабильная смесь |cFFFF33331,255,480|r",
},
},
["class"] = "DRUID",
},
["Xzinne-TarrenMill"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
24.6140000000014,
"Мерзкий выброс |cFFFF333354,137|r",
},
},
["class"] = "PALADIN",
},
["Nt-Turalyon"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Vulpi-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Carridven-BurningLegion"] = {
["encounters"] = 5,
["points"] = 480,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
106.0360000000219,
"Атака ближнего боя |cFFFF33333,642,602|r",
},
{
0,
52.00500000000466,
"Атака ближнего боя |cFFFF33333,195,261|r",
},
},
},
["Haassaki-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Jøøsettee-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
141.2010000000009,
"Нестабильная смесь |cFFFF33332,168,975|r",
},
},
["class"] = "EVOKER",
},
["Férxxo-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Smea-Pozzodell'Eternità"] = {
["encounters"] = 6,
["points"] = 600,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Samdixonn-Hyjal"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Zerrox-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
},
},
["2902-16"] = {
["hash"] = "2902-16",
["type"] = "endurance",
["name"] = "Улгракс Пожиратель",
["id"] = "2902-16",
["diff"] = 16,
["unixtime"] = 1729973842,
["player_db"] = {
["Malawel-Doomhammer"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Aeriilyn-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Осадчийофдес"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Shaderuid-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
70.34199999997509,
"Желудочный сок |cFFFF3333741,036|r",
},
},
["class"] = "DRUID",
},
["Mylili-TwistingNether"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
132.4139999999898,
"Неумолимый рывок |cFFFF33334,991,400|r",
},
{
0,
276.5829999999842,
"Неумолимый рывок |cFFFF33337,035,138|r",
},
},
["class"] = "SHAMAN",
},
["Excidios-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
12.98800000001211,
"Паутина ловчего |cFFFF33332,385,987|r",
},
},
["class"] = "WARLOCK",
},
["Ködex-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Deelock-Blackhand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
70.7050000000163,
"Желудочный сок |cFFFF3333542,564|r",
},
},
["class"] = "WARLOCK",
},
["Nektharillon-Ysondre"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
12.70699999999488,
"Паутина ловчего |cFFFF33331,523,411|r",
},
},
["class"] = "PALADIN",
},
["Demoniça-Saurfang"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Lundmark-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Ezrynis-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Frostcharge-Turalyon"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Faelarin-Vek'nilash"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Pandadwalin-Blackrock"] = {
["encounters"] = 10,
["points"] = 1000,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Chiecho-Thrall"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
46.90600000001723,
"Пожирание |cFFFF33332,486,077|r",
},
},
["class"] = "WARRIOR",
},
["Ssuntzu-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Shéeèsh-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Dreamblaze-Stormreaver"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Шинрюжди-Гордунни"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Fanboyajnouu-KirinTor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Rodizenp-Draenor"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
148.9910000000382,
"Паутина ловчего |cFFFF33332,641,190|r",
},
},
["class"] = "PALADIN",
},
["Sagoya-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Ragnár-Silvermoon"] = {
["encounters"] = 12,
["points"] = 1170,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
13.80999999999767,
"Сеть ловчего |cFFFF3333364,669|r",
},
{
0,
125.1480000000156,
"Атака ближнего боя |cFFFF33331,491,550|r",
},
{
0,
122.2169999999751,
"Укрепленная сеть(ДоТ) |cFFFF3333150,139|r",
},
},
},
["Sleepzeezon-Ravencrest"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MAGE",
},
["Classkosh-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
13.4320000000007,
"Паутина ловчего |cFFFF3333879,596|r",
},
},
["class"] = "HUNTER",
},
["Raiden-Aegwynn"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Odrian-Ahn'Qiraj"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Mürza-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Prodighy-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Greenwy-Arathor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Khanzeer-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Kryer-Blackhand"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Avenguard-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Shamylord-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Sûrviv-Blackmoore"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Lovedeluxe-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Pridepope-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Eiserli-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Reeze-Destromath"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Legände-Blackhand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
141.4329999999609,
"Неумолимый рывок |cFFFF3333211,385|r",
},
},
["class"] = "PRIEST",
},
["Akina-Taerar"] = {
["encounters"] = 10,
["points"] = 960,
["class"] = "MONK",
["deaths"] = {
{
0,
128.505999999994,
"Биоактивные иглы |cFFFF3333718,921|r",
},
{
0,
71.05000000001746,
"Желудочный сок |cFFFF3333995,755|r",
},
{
0,
13.44000000000233,
"Паутина ловчего |cFFFF33331,498,863|r",
},
{
0,
126.9339999999793,
"Неумолимый рывок |cFFFF33335,765,371|r",
},
},
},
["Walppo-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Dumbaldore-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Saiimone-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Radmagetwo-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Matrix-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Docantle-Kazzak"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
141.0920000000042,
"Атака ближнего боя |cFFFF3333533,624|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Brojob-Area52"] = {
["encounters"] = 10,
["points"] = 1000,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Ezilol-Blackhand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
133.698000000004,
"Неумолимый рывок |cFFFF33335,260,860|r",
},
},
["class"] = "SHAMAN",
},
["Blastd-Ysondre"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
125.9759999999078,
"Неумолимый рывок |cFFFF33335,164,224|r",
},
},
["class"] = "MAGE",
},
["Faxxenpala-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Pantsuwizard-Blackmoore"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
224.7110000000102,
"Пожирание |cFFFF33333,305,101|r",
},
},
},
["Shenhé-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Stormhammer-DieNachtwache"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
13.36699999999837,
"Сеть ловчего |cFFFF3333285,301|r",
},
},
["class"] = "WARRIOR",
},
["Apodruid-Zul'jin"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Igudk-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Sourdoughbun-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
78.1730000000025,
"Игра хищника |cFFFF33338,051,818|r",
},
},
["class"] = "ROGUE",
},
["Balín-Antonidas"] = {
["encounters"] = 3,
["points"] = 270,
["deaths"] = {
{
0,
276.6390000000829,
"Неумолимый рывок |cFFFF33336,544,939|r",
},
{
0,
448.6369999999879,
"Неумолимый рывок |cFFFF33336,233,279|r",
},
},
["class"] = "PALADIN",
},
["Adrïna-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Kebabshop-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Karvaranne-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Albac-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Nomsayin-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Ololop-Blackhand"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "EVOKER",
["deaths"] = {
{
0,
112.292999999976,
"Неумолимый рывок |cFFFF33336,117,956|r",
},
{
0,
126.0350000000035,
"Неумолимый рывок |cFFFF33332,801,992|r",
},
},
},
["Succar-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
83.3410000000149,
"Пожирание |cFFFF33331,207,600|r",
},
},
},
["Mastariani-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Edknight-Aszune"] = {
["encounters"] = 5,
["points"] = 470,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
71.10399999999208,
"Желудочный сок |cFFFF3333552,259|r",
},
{
0,
299.5419999999867,
"Неумолимый рывок |cFFFF33336,302,082|r",
},
{
0,
125.6320000000123,
"Неумолимый рывок |cFFFF3333211,369|r",
},
},
},
["Wotiz-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Cherriboy-Silvermoon"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
47.33199999999488,
"Пожирание |cFFFF33334,651,539|r",
},
{
0,
47.15299999999115,
"Пожирание |cFFFF33336,028,875|r",
},
},
["class"] = "PRIEST",
},
["Jodu-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Nerforc-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Gluedrinker-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
64.57200000001467,
"Желудочный сок |cFFFF33331,072,885|r",
},
},
["class"] = "WARLOCK",
},
["Barada-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Falkao-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Kelissane-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Wìntér-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Lazyshammy-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Brbinstagram-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Gageyey-Stormscale"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Gnomebisrace-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Sikiusledélu-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Rimez-Kazzak"] = {
["encounters"] = 3,
["points"] = 280,
["deaths"] = {
{
0,
11.69599999999628,
"Ядовитая плеть |cFFFF3333843,041|r",
},
{
0,
43.59199999994598,
"Пожирание |cFFFF33332,972,256|r",
},
},
["class"] = "WARRIOR",
},
["Haadige-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Asmonbald-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Feycc-Kazzak"] = {
["encounters"] = 3,
["points"] = 260,
["class"] = "ROGUE",
["deaths"] = {
{
0,
47.28799999994226,
"Пожирание |cFFFF33331,771,069|r",
},
{
0,
283.9670000000624,
"Неумолимый рывок |cFFFF33334,825,623|r",
},
{
0,
374.3420000000624,
"Игра хищника |cFFFF33332,761,423|r",
},
},
},
["Wazabbi-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Artúro-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Gløuille-Dalaran"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Zavious-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Paladìon-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Ddoukavv-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Shibéz-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MONK",
},
["Bobbyimhey-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Madapes-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Necrotroll-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Cracktastic-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Eskánor-Ravencrest"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "MONK",
["deaths"] = {
},
},
["Rag-Quel'Thalas"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Semulock-DefiasBrotherhood"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Machumage-Ravencrest"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MAGE",
},
["Amourante-Cho'gall"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "MONK",
["deaths"] = {
{
0,
234.9239999999991,
"Паутина ловчего |cFFFF33332,452,403|r",
},
},
},
["Grínddaddy-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
83.27399999997579,
"Пожирание |cFFFF33332,676,762|r",
},
},
["class"] = "PALADIN",
},
["Sânny-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Rònde-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Swiftsight-TarrenMill"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Phirelion-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Armagedo-DunModr"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
47.52599999998347,
"Игра хищника |cFFFF3333443,315|r",
},
},
["class"] = "PALADIN",
},
["Faëlyna-Ysondre"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Oiseth-TarrenMill"] = {
["encounters"] = 3,
["points"] = 280,
["deaths"] = {
{
0,
82.78200000000652,
"Пожирание |cFFFF3333840,667|r",
},
{
0,
66.96099999995204,
"Желудочный сок |cFFFF33331,139,526|r",
},
},
["class"] = "DRUID",
},
["Shinkri-Aegwynn"] = {
["encounters"] = 10,
["points"] = 990,
["class"] = "PALADIN",
["deaths"] = {
{
0,
126.8789999999863,
"Неумолимый рывок |cFFFF33334,057,150|r",
},
},
},
["Cahleg-Blackhand"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "PALADIN",
["deaths"] = {
{
0,
118.8089999999793,
"Неумолимый рывок |cFFFF33335,045,023|r",
},
},
},
["Drukkar-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Dempp-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Meshtities-Silvermoon"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MONK",
["deaths"] = {
},
},
["Cikomenttvv-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Endoshami-Blackhand"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Xaser-Blackhand"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "MAGE",
["deaths"] = {
{
0,
128.4940000000061,
"Биоактивные иглы |cFFFF33331,043,805|r",
},
},
},
["Cocogatel-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Thorstein-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Dunkkis-Ravencrest"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "MAGE",
["deaths"] = {
},
},
["Demoniack-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Вольтчара"] = {
["encounters"] = 28,
["points"] = 2800,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Æquitâ-Blackhand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
170.8850000000093,
"Голодный рев |cFFFF3333651,311|r",
},
},
["class"] = "WARRIOR",
},
["Liendro-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nibberezt-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Asünaa-Hyjal"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
118.0050000000047,
"Неумолимый рывок |cFFFF33336,101,974|r",
},
},
["class"] = "PALADIN",
},
["Fremymage-Terokkar"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Thánátøs-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Drarkanis-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Hotdemongirl-Ragnaros"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
0.5549999999930151,
"Атака ближнего боя |cFFFF33336,040,628|r",
},
},
["class"] = "DEMONHUNTER",
},
["Kjøttbollen-Kazzak"] = {
["encounters"] = 2,
["points"] = 180,
["deaths"] = {
{
0,
111.9809999999998,
"Неумолимый рывок |cFFFF33334,469,964|r",
},
{
0,
404.6100000000151,
"Желудочный сок |cFFFF3333767,394|r",
},
},
["class"] = "WARRIOR",
},
["Holdetqt-Outland"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Sankhadri-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Авохд-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
220.5400000000373,
"Ядовитая плеть |cFFFF3333846,829|r",
},
},
["class"] = "DRUID",
},
["Aldrîna-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Rhaell-TwistingNether"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
70.39599999997881,
"Желудочный сок |cFFFF3333258,325|r",
},
},
["class"] = "SHAMAN",
},
["Âë-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MAGE",
["deaths"] = {
{
0,
291.8270000000484,
"Неумолимый рывок |cFFFF33331,136,537|r",
},
},
},
["Kirrach-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
11.82000000000699,
"Ядовитая плеть |cFFFF3333797,178|r",
},
},
["class"] = "SHAMAN",
},
["Madox-Hyjal"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Bùstian-Ragnaros"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Deallanbrax-Norgannon"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
69.42399999999907,
"Атака ближнего боя |cFFFF33332,075,686|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Fluffyagnar-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Делюженх-Ревущийфьорд"] = {
["encounters"] = 3,
["points"] = 290,
["class"] = "PRIEST",
["deaths"] = {
{
0,
129.1650000000082,
"Биоактивные иглы |cFFFF3333928,784|r",
},
},
},
["Binksy-Archimonde"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Zamlio-Stormscale"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
58.52599999995437,
"Паутина ловчего |cFFFF3333748,651|r",
},
},
},
["Scarwave-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Niemka-Blackmoore"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "PALADIN",
["deaths"] = {
{
0,
80.98099999999977,
"Пожирание |cFFFF33332,621,193|r",
},
{
0,
188.2330000000075,
"Паутина ловчего |cFFFF33332,626,260|r",
},
},
},
["Zylandrias-Blackrock"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Monkeypîe-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Taloula-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
47.21899999998277,
"Пожирание |cFFFF33331,802,725|r",
},
},
["class"] = "SHAMAN",
},
["Steparu-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Petdetective-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
47.7160000000149,
"Игра хищника |cFFFF3333222,911|r",
},
},
["class"] = "HUNTER",
},
["Darkplates-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Harlö-Drak'thul"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Eoghansco-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Herpngrip-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Jokkø-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Reichfeld-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Fafuniru-Kazzak"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "EVOKER",
["deaths"] = {
},
},
["Juîcé-Sylvanas"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Digiman-Aggramar"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Bearnabeu-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Braindéad-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Tarjâxx-Archimonde"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
65.60499999998137,
"Ядовитая плеть |cFFFF3333728,902|r",
},
},
["class"] = "MONK",
},
["Aneria-Ravencrest"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Ceece-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Finskröv-TwistingNether"] = {
["encounters"] = 2,
["points"] = 170,
["class"] = "MAGE",
["deaths"] = {
{
0,
125.820000000007,
"Неумолимый рывок |cFFFF33336,241,566|r",
},
{
0,
291.5,
"Неумолимый рывок |cFFFF33335,861,218|r",
},
},
},
["Nexicdruid-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Ireath-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Dragonair-Aggramar"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Libii-Blackhand"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "DRUID",
["deaths"] = {
{
0,
177.755999999994,
"Ядовитая плеть |cFFFF3333318,848|r",
},
},
},
["Odesza-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Raminthunder-Kazzak"] = {
["encounters"] = 3,
["points"] = 270,
["deaths"] = {
{
0,
134.625,
"Неумолимый рывок |cFFFF3333784,264|r",
},
{
0,
293.2189999999973,
"Биоактивные иглы |cFFFF33331,006,338|r",
},
},
["class"] = "SHAMAN",
},
["Merçedesa-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Banzaail-Archimonde"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Rotumbrick-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Мэддимон-Ревущийфьорд"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Blueruby-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Baldursgate-Stormscale"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Blackdru-Sanguino"] = {
["encounters"] = 1,
["points"] = 100,
["class"] = "DRUID",
["deaths"] = {
},
},
["Lyneià-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Satoshix-Blackhand"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Iloveetien-Blackhand"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
13.86000000004424,
"Паутина ловчего |cFFFF33332,853,033|r",
},
},
["class"] = "MONK",
},
["Promega-Kazzak"] = {
["encounters"] = 5,
["points"] = 480,
["deaths"] = {
{
0,
218.7189999999828,
"Пожирание |cFFFF33335,826,822|r",
},
{
0,
47.02799999999115,
"Пожирание |cFFFF33335,619,685|r",
},
},
["class"] = "PRIEST",
},
["Heligahudvig-Stormscale"] = {
["encounters"] = 10,
["points"] = 970,
["class"] = "PRIEST",
["deaths"] = {
{
0,
46.0339999999851,
"Пожирание |cFFFF33331,992,647|r",
},
{
0,
125.9260000000068,
"Неумолимый рывок |cFFFF33335,697,294|r",
},
{
0,
349.1830000000191,
"Паутина ловчего |cFFFF33332,786,179|r",
},
},
},
["Jïgen-Thrall"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
218.7619999999952,
"Пожирание |cFFFF33331,415,715|r",
},
},
["class"] = "MONK",
},
["Kedigözü-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Jimmypreach-Drak'thul"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Adamalysz-BurningLegion"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Dangerøss-TarrenMill"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
118.23199999996,
"Неумолимый рывок |cFFFF33336,124,288|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Defone-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Ryxxe-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DRUID",
},
["Bouhn-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Geetha-TarrenMill"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
78.1730000000025,
"Игра хищника |cFFFF333322,609,089|r",
},
},
["class"] = "EVOKER",
},
["Drøødalia-Ysondre"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
81.68499999999767,
"Пожирание |cFFFF33332,397,484|r",
},
},
["class"] = "DRUID",
},
["Suvacry-Antonidas"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Rotlips-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
78.1730000000025,
"Игра хищника |cFFFF33337,196,757|r",
},
},
["class"] = "PRIEST",
},
["Braadenk-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Leggionnare-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Seraphdk-Archimonde"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
183.1639999999898,
"Ядовитая плеть |cFFFF3333599,690|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Discohedel-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Maseraty-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Lgrtha-Silvermoon"] = {
["encounters"] = 1,
["points"] = 90,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
291.4149999999791,
"Неумолимый рывок |cFFFF33334,985,821|r",
},
},
},
["Imtrapzy-Nethersturm"] = {
["encounters"] = 2,
["points"] = 190,
["deaths"] = {
{
0,
133.698000000004,
"Неумолимый рывок |cFFFF33334,892,050|r",
},
},
["class"] = "SHAMAN",
},
["Tahk-CultedelaRivenoire"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Vandamme-Archimonde"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MONK",
},
["Snekloen-Ravencrest"] = {
["encounters"] = 5,
["points"] = 500,
["class"] = "HUNTER",
["deaths"] = {
},
},
["Snóòky-Kazzak"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Bellebrat-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Seleri-Blackhand"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
247.4280000000144,
"Желудочный сок |cFFFF3333760,474|r",
},
},
},
},
},
["2922-14"] = {
["hash"] = "2922-14",
["type"] = "endurance",
["name"] = "Королева Ансурек",
["id"] = "2922-14",
["unixtime"] = 1726699888,
["player_db"] = {
["Arkantosa-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Baihu-Auchindoun"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
80.29100000008475,
"Паутинные клинки |cFFFF3333943,969|r",
},
},
["class"] = "MONK",
},
["Pryv-Teldrassil"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Arrowtooth-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Jalmage-Nordrassil"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "MAGE",
["deaths"] = {
{
0,
35.11200000000099,
"Кольцо яда |cFFFF33334,335,824|r",
},
},
},
["Greaterdemon-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Kyrris-Ysondre"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MONK",
},
["Demonjææger-Silvermoon"] = {
["encounters"] = 3,
["points"] = 280,
["deaths"] = {
{
0,
125.9729999999981,
"Пожирание |cFFFF33333,020,031|r",
},
{
0,
91.0679999999702,
"Кольцо яда |cFFFF33333,940,591|r",
},
},
["class"] = "DEMONHUNTER",
},
["Варин-Ревущийфьорд"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
108.6189999999988,
"Разжижение |cFFFF33331,133|r",
},
},
},
["Caratacos-BurningLegion"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "DRUID",
["deaths"] = {
},
},
["Redeal-Sanguino"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Falkénaugé-Blackrock"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
173.4090000001015,
"Кислотная стрела |cFFFF3333131,809|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Klimax-DefiasBrotherhood"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "HUNTER",
["deaths"] = {
{
0,
310.6640000000043,
"Лужа мрака |cFFFF33331,419,874|r",
},
},
},
["Livhx-Blackrock"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Ithiris-Silvermoon"] = {
["encounters"] = 5,
["points"] = 490,
["deaths"] = {
{
0,
154.1390000000029,
"Пожирание |cFFFF33332,881,543|r",
},
},
["class"] = "PALADIN",
},
["Tåård-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Randin-Pozzodell'Eternità"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MONK",
},
["Chaostoilet-TwistingNether"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Pirrogongo-Nemesis"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Erelieva-BurningBlade"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
91.16500000000087,
"Кольцо яда |cFFFF33333,910,198|r",
},
},
},
["Erdashpels-Draenor"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "MAGE",
["deaths"] = {
},
},
["Exxy-Frostmane"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
35.11200000000099,
"Кольцо яда |cFFFF33334,851,890|r",
},
{
0,
167.4360000000015,
"Пожирание |cFFFF33333,458,791|r",
},
},
},
["Shaeltis-Hyjal"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "PALADIN",
["deaths"] = {
{
0,
63.62600000000384,
"Шелковая гробница |cFFFF3333856,840|r",
},
},
},
["Amunet-BurningBlade"] = {
["encounters"] = 8,
["points"] = 800,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Jentilmen-TwistingNether"] = {
["encounters"] = 8,
["points"] = 790,
["class"] = "WARLOCK",
["deaths"] = {
{
0,
315.8270000000048,
"Мрачный детеныш |cFFFF3333440,448|r",
},
},
},
["Miroan-Silvermoon"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Kurokatsu-TwistingNether"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Limonce-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["deaths"] = {
},
["class"] = "MAGE",
},
["Maldmeister-Ravencrest"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Aiaiath-Hyjal"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
35.11200000000099,
"Кольцо яда |cFFFF33338,370,157|r",
},
{
0,
154.8970000000045,
"Пожирание |cFFFF333331,191,395|r",
},
},
},
["Tobleron-TarrenMill"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
148.3740000000034,
"Пожирание |cFFFF33333,369,351|r",
},
},
["class"] = "SHAMAN",
},
["Alcalinaa-TwistingNether"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Вольтчара"] = {
["encounters"] = 11,
["points"] = 1100,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Nonamenibba-Bloodfeather"] = {
["encounters"] = 3,
["points"] = 280,
["class"] = "PRIEST",
["deaths"] = {
{
0,
35.18100000000413,
"Кольцо яда |cFFFF33335,488,241|r",
},
{
0,
91.16500000000087,
"Кольцо яда |cFFFF33334,672,057|r",
},
},
},
["Bolqrinat-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Duranin-BurningBlade"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "PALADIN",
["deaths"] = {
{
0,
35.18100000000413,
"Кольцо яда |cFFFF33336,871,572|r",
},
{
0,
338.2350000000006,
"Ужасающее присутствие |cFFFF333395,316|r",
},
},
},
["Jhwh-Blackrock"] = {
["encounters"] = 8,
["points"] = 760,
["class"] = "PALADIN",
["deaths"] = {
{
0,
35.18100000000413,
"Кольцо яда |cFFFF33333,854,992|r",
},
{
0,
91.16500000000087,
"Кольцо яда |cFFFF33333,826,178|r",
},
{
0,
173.1030000000028,
"Пожирание |cFFFF33332,842,479|r",
},
{
0,
315.0030000000043,
"Мрачный детеныш |cFFFF3333878,164|r",
},
},
},
["Secondbase-Kazzak"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
125.6610000000801,
"Пожирание |cFFFF33334,243,815|r",
},
},
["class"] = "WARRIOR",
},
["Filetmignøn-Blackrock"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
125.9729999999981,
"Пожирание |cFFFF33333,235,719|r",
},
},
["class"] = "WARRIOR",
},
["Bigcocklock-TwistingNether"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Ødïñ-Blackrock"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Paksenarrion-Deathwing"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Zalmon-TheMaelstrom"] = {
["encounters"] = 3,
["points"] = 300,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Galrenir-Silvermoon"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "MAGE",
["deaths"] = {
},
},
["Bumbitroll-Kazzak"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
53.09899999992922,
"Кислота |cFFFF3333434,346|r",
},
},
["class"] = "DRUID",
},
["Starnovaa-Draenor"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
35.02199999999721,
"Кольцо яда |cFFFF33334,398,511|r",
},
},
["class"] = "MONK",
},
["Bigmouthgirl-TarrenMill"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Nemesme-TarrenMill"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Vairhoult-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Playmoré-TarrenMill"] = {
["encounters"] = 3,
["points"] = 290,
["deaths"] = {
{
0,
126.1030000000028,
"Пожирание |cFFFF33333,437,279|r",
},
},
["class"] = "SHAMAN",
},
["Tondsa-TwistingNether"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Exlimitedx-BronzeDragonflight"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MAGE",
},
["Starzyk-Alonsus"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Lovestospoon-Stormscale"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Yugíxx-Kazzak"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "MAGE",
},
["Sparkstar-Ragnaros"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Titaan-Blackhand"] = {
["encounters"] = 8,
["points"] = 780,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
172.9639999999999,
"Пожирание |cFFFF33333,213,399|r",
},
{
0,
79.91100000000006,
"Паутинные клинки |cFFFF33331,246,175|r",
},
},
},
},
["diff"] = 14,
},
["2918-16"] = {
["hash"] = "2918-16",
["type"] = "endurance",
["name"] = "Раша'нан",
["id"] = "2918-16",
["diff"] = 16,
["player_db"] = {
["Jïgen-Thrall"] = {
["encounters"] = 8,
["points"] = 780,
["deaths"] = {
{
0,
74.14599999999336,
"Длительная эрозия |cFFFF3333179,158|r",
},
{
0,
108.4679999999935,
"Липкие нити |cFFFF33334,732,086|r",
},
},
["class"] = "MONK",
},
["Monkeypîe-Draenor"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Ködex-TwistingNether"] = {
["encounters"] = 6,
["points"] = 590,
["class"] = "DRUID",
["deaths"] = {
{
0,
203.8889999999665,
"Рассекание паутины |cFFFF33332,010,889|r",
},
},
},
["Snus-ZirkeldesCenarius"] = {
["encounters"] = 3,
["points"] = 300,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Dumbaldore-Stormscale"] = {
["encounters"] = 13,
["points"] = 1280,
["deaths"] = {
{
0,
23.6140000000014,
"Зараженное порождение |cFFFF33332,123,762|r",
},
{
0,
97.875,
"Дикий натиск |cFFFF33336,144,491|r",
},
},
["class"] = "MAGE",
},
["Bearnabeu-TarrenMill"] = {
["encounters"] = 6,
["points"] = 580,
["class"] = "DRUID",
["deaths"] = {
{
0,
218.1529999999912,
"Зараженный укус |cFFFF33331,122,301|r",
},
{
0,
43.74800000002142,
"Лужи кислоты(ДоТ) |cFFFF3333788,190|r",
},
},
},
["Finskröv-TwistingNether"] = {
["encounters"] = 6,
["points"] = 580,
["class"] = "MAGE",
["deaths"] = {
{
0,
155.8319999999949,
"Паутинный разрыв |cFFFF3333437,220|r",
},
{
0,
236.8859999999986,
"Зараженный укус |cFFFF33331,249,504|r",
},
},
},
["Lazyshammy-Ragnaros"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Shenhé-Draenor"] = {
["encounters"] = 6,
["points"] = 570,
["class"] = "PRIEST",
["deaths"] = {
{
0,
155.1959999999963,
"Лужи кислоты(ДоТ) |cFFFF33331,342,671|r",
},
{
0,
172.429999999993,
"Лужи кислоты(ДоТ) |cFFFF33331,013,930|r",
},
{
0,
303.6469999999972,
"Зараженное порождение |cFFFF33331,979,240|r",
},
},
},
["Raminthunder-Kazzak"] = {
["encounters"] = 13,
["points"] = 1270,
["deaths"] = {
{
0,
108.0890000000072,
"Кислотное оцепенение |cFFFF33332,409,407|r",
},
{
0,
89.21899999999732,
"Лужи кислоты(ДоТ) |cFFFF3333530,280|r",
},
{
0,
131.8149999999878,
"Кислотное извержение |cFFFF33332,854,658|r",
},
},
["class"] = "SHAMAN",
},
["Aldrîna-Blackmoore"] = {
["encounters"] = 13,
["points"] = 1270,
["deaths"] = {
{
0,
129.9429999999993,
"Лужи кислоты(ДоТ) |cFFFF3333462,641|r",
},
{
0,
94.05600000001141,
"Лужи кислоты(ДоТ) |cFFFF3333235,800|r",
},
{
0,
124.8719999999885,
"Жестокая рана |cFFFF33331,330,492|r",
},
},
["class"] = "DEMONHUNTER",
},
["Sourdoughbun-Kazzak"] = {
["encounters"] = 13,
["points"] = 1290,
["deaths"] = {
{
0,
86.56900000000314,
"Опутывающие сети |cFFFF3333558,620|r",
},
},
["class"] = "ROGUE",
},
["Шинрюжди-Гордунни"] = {
["encounters"] = 13,
["points"] = 1260,
["deaths"] = {
{
0,
128.551999999996,
"Коррозия(ДоТ) |cFFFF3333361,732|r",
},
{
0,
88.87099999999919,
"Зараженный укус |cFFFF33331,088,099|r",
},
{
0,
117.224000000002,
"Коррозия(ДоТ) |cFFFF3333607,952|r",
},
{
0,
104.9790000000066,
"Паутинные нити |cFFFF3333366,333|r",
},
},
["class"] = "PALADIN",
},
["Dempp-TarrenMill"] = {
["encounters"] = 13,
["points"] = 1250,
["deaths"] = {
{
0,
74.14599999999336,
"Длительная эрозия |cFFFF3333179,614|r",
},
{
0,
92.44599999999627,
"Зараженный укус |cFFFF33331,088,967|r",
},
{
0,
92.63300000000163,
"Липкий выброс |cFFFF3333870,138|r",
},
{
0,
102.9219999999914,
"Паутинные нити |cFFFF3333429,219|r",
},
{
0,
131.8149999999878,
"Кислотное извержение |cFFFF33331,938,517|r",
},
},
["class"] = "WARRIOR",
},
["Sankhadri-Hyjal"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Scarwave-Kazzak"] = {
["encounters"] = 13,
["points"] = 1300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Falkao-TwistingNether"] = {
["encounters"] = 6,
["points"] = 580,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
109.210000000021,
"Длительная эрозия |cFFFF333391,139|r",
},
{
0,
137.685999999987,
"Лужи кислоты(ДоТ) |cFFFF33331,025,447|r",
},
},
},
["Zavious-TwistingNether"] = {
["encounters"] = 13,
["points"] = 1280,
["deaths"] = {
{
0,
108.3699999999953,
"Паутинный разрыв |cFFFF3333465,026|r",
},
{
0,
103.9919999999984,
"Паутинные нити |cFFFF3333430,034|r",
},
},
["class"] = "WARLOCK",
},
["Haadige-Kazzak"] = {
["encounters"] = 6,
["points"] = 580,
["class"] = "MONK",
["deaths"] = {
{
0,
106.7079999999842,
"Длительная эрозия |cFFFF333391,637|r",
},
{
0,
23.90499999996973,
"Длительная эрозия |cFFFF333390,167|r",
},
},
},
["Dunkkis-Ravencrest"] = {
["encounters"] = 6,
["points"] = 590,
["class"] = "MAGE",
["deaths"] = {
{
0,
155.4389999999548,
"Лужи кислоты(ДоТ) |cFFFF3333940,771|r",
},
},
},
["Barada-Silvermoon"] = {
["encounters"] = 6,
["points"] = 590,
["class"] = "PALADIN",
["deaths"] = {
{
0,
151.5249999999651,
"Паутинные нити |cFFFF3333514,832|r",
},
},
},
["Nerforc-TwistingNether"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Ryxxe-Kazzak"] = {
["encounters"] = 13,
["points"] = 1290,
["deaths"] = {
{
0,
58.69000000000233,
"Жестокая рана |cFFFF33331,070,726|r",
},
},
["class"] = "DRUID",
},
["Mürza-Stormscale"] = {
["encounters"] = 13,
["points"] = 1300,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Lgrtha-Silvermoon"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 19,
["points"] = 1890,
["deaths"] = {
{
0,
89.35199999999895,
"Разъедающие брызги |cFFFF3333831,357|r",
},
},
["class"] = "SHAMAN",
},
["Defone-TarrenMill"] = {
["encounters"] = 13,
["points"] = 1260,
["deaths"] = {
{
0,
91.25199999999313,
"Лужи кислоты(ДоТ) |cFFFF3333539,419|r",
},
{
0,
43.95699999999488,
"Дикий натиск |cFFFF33331,231,650|r",
},
{
0,
108.4679999999935,
"Липкие нити |cFFFF33335,168,509|r",
},
{
0,
95.86599999999453,
"Дикий натиск |cFFFF3333815,927|r",
},
},
["class"] = "SHAMAN",
},
["Rotlips-Kazzak"] = {
["encounters"] = 12,
["points"] = 1200,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Nexicdruid-Blackmoore"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "DRUID",
["deaths"] = {
},
},
["Harlö-Drak'thul"] = {
["encounters"] = 10,
["points"] = 970,
["deaths"] = {
{
0,
74.14599999999336,
"Длительная эрозия |cFFFF3333171,726|r",
},
{
0,
111.6560000000027,
"Лужи кислоты(ДоТ) |cFFFF3333700,039|r",
},
{
0,
46.4890000000014,
"Жестокая рана |cFFFF3333206,861|r",
},
},
["class"] = "WARRIOR",
},
["Wìntér-Draenor"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Rag-Quel'Thalas"] = {
["encounters"] = 13,
["points"] = 1300,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Imnotdarab-Kazzak"] = {
["encounters"] = 5,
["points"] = 500,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Sagoya-Stormscale"] = {
["encounters"] = 13,
["points"] = 1290,
["deaths"] = {
{
0,
108.3389999999927,
"Лужи кислоты(ДоТ) |cFFFF3333874,248|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Kelissane-Hyjal"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Thánátøs-Draenor"] = {
["encounters"] = 6,
["points"] = 590,
["class"] = "DEATHKNIGHT",
["deaths"] = {
{
0,
157.359999999986,
"Липкие нити |cFFFF33334,549,102|r",
},
},
},
["Bùstian-Ragnaros"] = {
["encounters"] = 6,
["points"] = 600,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Geetha-TarrenMill"] = {
["encounters"] = 13,
["points"] = 1240,
["deaths"] = {
{
0,
114.7719999999972,
"Лужи кислоты(ДоТ) |cFFFF3333358,949|r",
},
{
0,
24.04399999999441,
"Зараженное порождение |cFFFF33332,599,532|r",
},
{
0,
107.2569999999978,
"Лужи кислоты(ДоТ) |cFFFF3333519,833|r",
},
{
0,
114.6910000000062,
"Коррозия(ДоТ) |cFFFF33331,179,626|r",
},
{
0,
108.8669999999984,
"Кислотное оцепенение |cFFFF33332,518,774|r",
},
{
0,
132.2079999999987,
"Лужи кислоты(ДоТ) |cFFFF3333484,689|r",
},
},
["class"] = "EVOKER",
},
["Snóòky-Kazzak"] = {
["encounters"] = 13,
["points"] = 1290,
["deaths"] = {
{
0,
137.9429999999993,
"Длительная эрозия |cFFFF3333147,386|r",
},
},
["class"] = "PALADIN",
},
["Lovedeluxe-Draenor"] = {
["encounters"] = 13,
["points"] = 1300,
["deaths"] = {
},
["class"] = "MONK",
},
["Meshtities-Silvermoon"] = {
["encounters"] = 6,
["points"] = 580,
["class"] = "MONK",
["deaths"] = {
{
0,
219.0480000000098,
"Жестокая рана |cFFFF333394,039|r",
},
{
0,
52.62400000001071,
"Жестокая рана |cFFFF333393,913|r",
},
},
},
},
["unixtime"] = 1729978683,
},
["2917-16"] = {
["hash"] = "2917-16",
["type"] = "endurance",
["name"] = "Скованный кровью ужас",
["id"] = "2917-16",
["diff"] = 16,
["unixtime"] = 1729975188,
["player_db"] = {
["Geetha-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "EVOKER",
},
["Asmonbald-Silvermoon"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "MONK",
["deaths"] = {
},
},
["Mylili-TwistingNether"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Excidios-TwistingNether"] = {
["encounters"] = 8,
["points"] = 780,
["deaths"] = {
{
0,
54.68900000001304,
"Потусторонняя хватка |cFFFF33332,806,068|r",
},
{
0,
75.09599999990314,
"Свертывание крови |cFFFF33331,293,928|r",
},
},
["class"] = "WARLOCK",
},
["Ködex-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Brbinstagram-Draenor"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Bobbyimhey-Ravencrest"] = {
["encounters"] = 8,
["points"] = 780,
["deaths"] = {
{
0,
36.7269999999553,
"Черная кровь |cFFFF33331,109,510|r",
},
{
0,
71.22899999993388,
"Свертывание крови |cFFFF33331,350,082|r",
},
},
["class"] = "PRIEST",
},
["Madapes-Ragnaros"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Necrotroll-Ragnaros"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
58.13399999996182,
"Брызгающее кровотечение |cFFFF33335,323,162|r",
},
},
["class"] = "DEATHKNIGHT",
},
["Feycc-Kazzak"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "ROGUE",
["deaths"] = {
{
0,
56.25,
"Брызгающее кровотечение |cFFFF33334,130,124|r",
},
},
},
["Bouhn-TarrenMill"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "MAGE",
["deaths"] = {
},
},
["Kelissane-Hyjal"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "WARRIOR",
["deaths"] = {
{
0,
36.48700000002282,
"Брызгающее кровотечение |cFFFF3333503,448|r",
},
},
},
["Faëlyna-Ysondre"] = {
["encounters"] = 8,
["points"] = 770,
["deaths"] = {
{
0,
74.1809999999823,
"Свертывание крови |cFFFF33331,448,245|r",
},
{
0,
49.39600000006612,
"Кровавый союз |cFFFF3333885,945|r",
},
{
0,
48.09099999989849,
"Свертывание крови |cFFFF33331,298,715|r",
},
},
["class"] = "PRIEST",
},
["Shéeèsh-TwistingNether"] = {
["encounters"] = 8,
["points"] = 780,
["deaths"] = {
{
0,
102.1840000000084,
"Брызгающее кровотечение |cFFFF3333897,284|r",
},
{
0,
45.56299999996554,
"Свертывание крови |cFFFF3333713,197|r",
},
},
["class"] = "WARRIOR",
},
["Dreamblaze-Stormreaver"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "EVOKER",
["deaths"] = {
{
0,
179.5509999999777,
"Кровавый союз |cFFFF3333560,847|r",
},
},
},
["Шинрюжди-Гордунни"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Cikomenttvv-TwistingNether"] = {
["encounters"] = 5,
["points"] = 470,
["class"] = "PRIEST",
["deaths"] = {
{
0,
147.1320000000997,
"Отвратительная отрыжка |cFFFF33337,061,951|r",
},
{
0,
202.859000000055,
"Свертывание крови |cFFFF33331,664,978|r",
},
},
},
["Rodizenp-Draenor"] = {
["encounters"] = 8,
["points"] = 790,
["deaths"] = {
{
0,
48.12599999993108,
"Свертывание крови |cFFFF3333874,870|r",
},
},
["class"] = "PALADIN",
},
["Dempp-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARRIOR",
},
["Dunkkis-Ravencrest"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Вольтчара"] = {
["encounters"] = 15,
["points"] = 1480,
["deaths"] = {
{
0,
36.8070000000298,
"Черная кровь |cFFFF3333373,594|r",
},
{
0,
75.09599999990314,
"Свертывание крови |cFFFF3333446,600|r",
},
},
["class"] = "SHAMAN",
},
["Thorstein-Stormscale"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Mürza-Stormscale"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
39.5480000000025,
"Брызгающее кровотечение |cFFFF33334,499,366|r",
},
},
["class"] = "EVOKER",
},
["Katunado-Blackhand"] = {
["encounters"] = 4,
["points"] = 380,
["deaths"] = {
{
0,
48.62100000004284,
"Отвратительная отрыжка(ДоТ) |cFFFF3333479,522|r",
},
{
0,
41.97299999999814,
"Кровавый союз |cFFFF3333965,126|r",
},
},
["class"] = "HUNTER",
},
["Holdetqt-Outland"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Rag-Quel'Thalas"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Zamlio-Stormscale"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "DEMONHUNTER",
["deaths"] = {
{
0,
108.7139999999199,
"Черная кровь |cFFFF3333878,786|r",
},
},
},
["Bùstian-Ragnaros"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "PALADIN",
["deaths"] = {
{
0,
47.21899999998277,
"Свертывание крови |cFFFF3333869,300|r",
},
},
},
["Lovedeluxe-Draenor"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
["Pridepope-Kazzak"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
105.7129999999888,
"Брызгающее кровотечение |cFFFF33333,498,015|r",
},
},
["class"] = "PRIEST",
},
["Harlö-Drak'thul"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
233.8090000000011,
"Отвратительная отрыжка |cFFFF333314,728|r",
},
},
["class"] = "WARRIOR",
},
["Monkeypîe-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "ROGUE",
["deaths"] = {
},
},
["Cocogatel-Silvermoon"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Nerforc-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Dumbaldore-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MAGE",
},
["Nexicdruid-Blackmoore"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "DRUID",
["deaths"] = {
{
0,
238.1840000000084,
"Потусторонняя хватка |cFFFF33332,142,626|r",
},
},
},
["Bearnabeu-TarrenMill"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DRUID",
["deaths"] = {
},
},
["Blueruby-TwistingNether"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Lgrtha-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Faxxenpala-Kazzak"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "PALADIN",
["deaths"] = {
{
0,
179.5860000000102,
"Кровавый союз |cFFFF3333576,739|r",
},
},
},
["Eoghansco-TwistingNether"] = {
["encounters"] = 8,
["points"] = 770,
["deaths"] = {
{
0,
28.67200000002049,
"Атака ближнего боя |cFFFF33335,857,859|r",
},
{
0,
48.06599999999162,
"Свертывание крови |cFFFF33331,455,153|r",
},
{
0,
45.50599999993574,
"Черная кровь |cFFFF3333279,541|r",
},
},
["class"] = "WARRIOR",
},
["Shenhé-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PRIEST",
["deaths"] = {
},
},
["Fatrog-Eitrigg"] = {
["encounters"] = 4,
["points"] = 400,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Raminthunder-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Aldrîna-Blackmoore"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEMONHUNTER",
},
["Sourdoughbun-Kazzak"] = {
["encounters"] = 1,
["points"] = 90,
["deaths"] = {
{
0,
235.7870000000039,
"Отвратительная отрыжка |cFFFF333363,910|r",
},
},
["class"] = "ROGUE",
},
["Balín-Antonidas"] = {
["encounters"] = 8,
["points"] = 790,
["deaths"] = {
{
0,
46.49599999992643,
"Свертывание крови |cFFFF3333382,354|r",
},
},
["class"] = "PALADIN",
},
["Barada-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "PALADIN",
["deaths"] = {
},
},
["Lazyshammy-Ragnaros"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "SHAMAN",
["deaths"] = {
},
},
["Thánátøs-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Haadige-Kazzak"] = {
["encounters"] = 2,
["points"] = 190,
["class"] = "MONK",
["deaths"] = {
{
0,
48.09000000002561,
"Отвратительная отрыжка(ДоТ) |cFFFF3333150,640|r",
},
},
},
["Finskröv-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MAGE",
["deaths"] = {
},
},
["Sankhadri-Hyjal"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEMONHUNTER",
["deaths"] = {
},
},
["Scarwave-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Falkao-TwistingNether"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "WARRIOR",
["deaths"] = {
},
},
["Meshtities-Silvermoon"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "MONK",
["deaths"] = {
},
},
["Succar-TwistingNether"] = {
["encounters"] = 4,
["points"] = 380,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
184.6050000000978,
"Брызгающее кровотечение |cFFFF33331,317,517|r",
},
{
0,
206.1020000000717,
"Отвратительная отрыжка |cFFFF33338,051,582|r",
},
},
},
["Wazabbi-Kazzak"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
70.66099999996368,
"Кровавый союз |cFFFF3333758,913|r",
},
},
},
["Donayahuasca-Outland"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
35.53599999996368,
"Брызгающее кровотечение |cFFFF33335,995,197|r",
},
},
["class"] = "SHAMAN",
},
["Mastariani-Silvermoon"] = {
["encounters"] = 4,
["points"] = 390,
["deaths"] = {
{
0,
37.96199999994133,
"Брызгающее кровотечение |cFFFF33335,089,480|r",
},
},
["class"] = "DEMONHUNTER",
},
["Drukkar-TwistingNether"] = {
["encounters"] = 5,
["points"] = 470,
["class"] = "SHAMAN",
["deaths"] = {
{
0,
173.0829999999842,
"Отвратительная отрыжка(ДоТ) |cFFFF3333483,392|r",
},
{
0,
237.3950000000186,
"Черная кровь |cFFFF33331,024,585|r",
},
},
},
["Ryxxe-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DRUID",
},
["Semulock-DefiasBrotherhood"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "WARLOCK",
["deaths"] = {
},
},
["Adamalysz-BurningLegion"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Ireath-Kazzak"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "ROGUE",
},
["Wìntér-Draenor"] = {
["encounters"] = 2,
["points"] = 200,
["class"] = "DEATHKNIGHT",
["deaths"] = {
},
},
["Suvacry-Antonidas"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "MAGE",
},
["Rotlips-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PRIEST",
},
["Defone-TarrenMill"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "SHAMAN",
},
["Darkplates-TwistingNether"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Panahyahudi-Elune"] = {
["encounters"] = 4,
["points"] = 380,
["deaths"] = {
{
0,
50.65399999998044,
"Отвратительная отрыжка(ДоТ) |cFFFF333377,077|r",
},
{
0,
53.02599999995437,
"Отвратительная отрыжка(ДоТ) |cFFFF3333408,705|r",
},
},
["class"] = "HUNTER",
},
["Gnomebisrace-Ravencrest"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Maseraty-TarrenMill"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Apodruid-Zul'jin"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "DRUID",
["deaths"] = {
},
},
["Satoshix-Blackhand"] = {
["encounters"] = 8,
["points"] = 800,
["deaths"] = {
},
["class"] = "HUNTER",
},
["Tahk-CultedelaRivenoire"] = {
["encounters"] = 4,
["points"] = 390,
["class"] = "DRUID",
["deaths"] = {
{
0,
65.78799999994226,
"Кровавый союз |cFFFF3333551,112|r",
},
},
},
["Zavious-TwistingNether"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "WARLOCK",
},
["Sagoya-Stormscale"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "DEATHKNIGHT",
},
["Snóòky-Kazzak"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "PALADIN",
},
["Âë-Kazzak"] = {
["encounters"] = 4,
["points"] = 400,
["class"] = "MAGE",
["deaths"] = {
},
},
["Jïgen-Thrall"] = {
["encounters"] = 1,
["points"] = 100,
["deaths"] = {
},
["class"] = "MONK",
},
},
},
}
