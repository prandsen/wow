
EncounterDetailsDB = {
["chartData"] = {
[124] = {
},
[125] = {
},
[130] = {
},
[138] = {
},
[164] = {
},
[56] = {
},
[57] = {
},
[58] = {
},
[59] = {
},
[60] = {
},
[61] = {
},
[131] = {
},
[133] = {
},
[68] = {
},
[139] = {
},
[76] = {
},
[77] = {
},
[159] = {
},
[161] = {
},
[165] = {
},
[84] = {
},
[85] = {
},
[87] = {
},
[89] = {
},
[92] = {
},
[94] = {
},
[96] = {
},
[67] = {
},
[154] = {
},
[153] = {
},
[103] = {
},
[107] = {
},
[115] = {
},
[116] = {
},
[158] = {
},
},
["encounter_spells"] = {
[423664] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[195776] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[426735] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[423665] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[446694] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Огромный паук",
},
[436971] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[453859] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[384773] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Киракка",
},
[321828] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Призывательница Туманов",
},
[447207] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[401150] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[456420] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[369423] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Прыгучий паук",
},
[104318] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дикий бес",
},
[442604] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[451305] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Потерянный дозорный",
},
[446700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ненасытный червь",
},
[422648] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Свечной Король",
},
[439536] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[321834] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[376080] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[455404] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[442611] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[461547] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сикран",
},
[427260] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый наставник буреклювов",
},
[439031] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[415492] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кругогриб",
},
[373017] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Шторм бушующего пламени",
},
[424704] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Грибной потрошитель",
},
[388882] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Насыщательница-воин стихий",
},
[423682] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[438012] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[196809] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[441084] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[442108] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[196810] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[463602] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[451321] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[415499] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кругогриб",
},
[196811] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Божественный образ",
},
[371489] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ткач Холода Морозной Вспышки",
},
[433411] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Безликий последователь",
},
[397077] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[440576] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[440577] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[114942] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем целительного прилива",
},
[436996] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[196813] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[457467] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[23922] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[463609] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Фантом Пустоты",
},
[423693] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Старый Воскобород",
},
[434441] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[439559] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[443654] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[438025] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бенк Жужжикс",
},
[443655] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[333629] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Возрожденный арбалетчик",
},
[196816] = {
["school"] = 2,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[443656] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[443657] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[451334] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[464640] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[442635] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Брызгающее кровотечение",
},
[426771] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[441612] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[384808] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тиира",
},
[428819] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[464642] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[428820] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[129914] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[443150] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[421146] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Свечной Король",
},
[444687] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[418588] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вы в будущем",
},
[431896] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Томимый жаждой посетитель",
},
[431897] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Томимый жаждой посетитель",
},
[373046] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[320336] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленный маг",
},
[369465] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ткач земли",
},
[424223] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пламекон",
},
[369466] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ткач земли",
},
[439576] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438041] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[444694] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[439577] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[424737] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[444696] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[441626] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[376634] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хан Балакар",
},
[426786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[453909] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[384823] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Шторм бушующего пламени",
},
[426787] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'иккадж",
},
[455447] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Уэйн",
},
[450330] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[433443] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[440608] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[384316] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Яростная буря",
},
[442656] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Брызгающее кровотечение",
},
[439586] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[444704] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[426793] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[317791] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародей из войска мертвых",
},
[260798] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[426283] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый завоеватель",
},
[376644] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хан Балакар",
},
[442660] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[386881] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Телаш Серокрылый",
},
[440104] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хмельной выброс",
},
[425264] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[321891] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[447270] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[440107] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[321893] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[447272] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[321894] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налтор Криомант",
},
[320359] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[389446] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нейтрализующее устройство",
},
[381770] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Разлагающийся слизень",
},
[450345] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[434481] = {
["school"] = 12,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Темная гончая",
},
[388424] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изначальное цунами",
},
[443694] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[448300] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[385356] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пузострелка",
},
[192231] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[434998] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[423228] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[385359] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пузострелка",
},
[427323] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Странник Бездны",
},
[435000] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[275335] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[427325] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[435004] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[427329] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[446776] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Боевая рысь",
},
[435006] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эпическое яйцо Бранна",
},
[589] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Gruiikkheal-Archimonde",
},
[427331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[227291] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нюцзао",
},
[426308] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый завоеватель",
},
[336752] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призывательница Туманов",
},
[438591] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[455479] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Взять",
},
[433475] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сикран",
},
[259277] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кошка",
},
[432965] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[460600] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[382303] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бромач",
},
[426826] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[386910] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Телаш Серокрылый",
},
[443203] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[439621] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[432969] = {
["school"] = 106,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[384353] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пузострелка",
},
[427852] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[434505] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Посетитель из Торговой компании",
},
[143625] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[443718] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[427854] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[440138] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[440650] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[376170] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Гниломаг Око Гнева",
},
[369006] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Тлерон",
},
[445257] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[427346] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Благочестивый жрец",
},
[376683] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хан Балакар",
},
[440141] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[386921] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Драконобойный копьемет",
},
[422233] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[445262] = {
["school"] = 127,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[437586] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[385389] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[440147] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "И'па",
},
[424795] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "ЗАЗУ",
},
[456012] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[437078] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вторящая тень",
},
[440149] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[451408] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[427356] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Благочестивый жрец",
},
[445268] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[437592] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[427869] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[451410] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[382836] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Маруук",
},
[453458] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Яростный снайпер",
},
[438618] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Разъевшийся ползун",
},
[438620] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгустолиция",
},
[441179] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[458067] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[444250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
},
[422245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[377723] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рефти-распорядитель",
},
[439645] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[422246] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Старый Воскобород",
},
[377724] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рефти-распорядитель",
},
[392054] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Strendewolf-DarkmoonFaire",
},
[385916] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гранит",
},
[426345] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[319902] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[445281] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[377732] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Рефти-распорядитель",
},
[435560] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[369033] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тлерон",
},
[322465] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[440168] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[372107] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кокия Пламенное Копыто",
},
[321956] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[3110] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Dagtik",
},
[384391] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[464736] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[422261] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[431985] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый служитель",
},
[381834] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Рира Когтерезка",
},
[372623] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Часовая Талондрас",
},
[436592] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[381835] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рира Когтерезка",
},
[462692] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[462693] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[440177] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[463206] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[440178] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[437620] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[440179] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[118297] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изначальный элементаль огня",
},
[108446] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чекио",
},
[376724] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хан Балакар",
},
[463210] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманный страж",
},
[326574] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[445812] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нестабильный подопытный объект",
},
[445813] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нестабильный подопытный объект",
},
[464748] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[369563] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бейлог",
},
[438139] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантом Пустоты",
},
[376730] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
},
[448887] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[436606] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[445818] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[463218] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[441213] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[445820] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[440191] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438656] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[437121] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[438145] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[423305] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[440193] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438658] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[871] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[322493] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленный маг",
},
[236282] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[77489] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Gruiikkheal-Archimonde",
},
[426892] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Убегающий свеченосец",
},
[427404] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[454527] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гнилозубая гиена",
},
[463227] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[385954] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[460670] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[426896] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Убегающий свеченосец",
},
[454019] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443273] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[442250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[434574] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кровавое чудовище",
},
[443274] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[439692] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[442251] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[389541] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Статуя белого тигра",
},
[434576] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[436624] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голди Барондон",
},
[388008] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Телаш Серокрылый",
},
[464259] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[375215] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голиаф-проглот",
},
[375727] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хронолорд Дейос",
},
[446349] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[434579] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[385963] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Каджин Непреклонная",
},
[439697] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[446351] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[132404] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[423324] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[438677] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[438679] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[423327] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[423839] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[442263] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровавый паразит",
},
[449940] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[438682] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[383925] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[434589] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Архидемон",
},
[404908] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дикий бес",
},
[432031] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Черная кровь",
},
[436637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[386486] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[444826] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Король Торас Троллебой",
},
[435615] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[143924] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[436640] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[439200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[448412] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[369603] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Эрик \"Быстрый\"",
},
[439202] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "И'па",
},
[388539] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[450461] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[436644] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голди Барондон",
},
[369605] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бромач",
},
[435622] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[471445] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[328667] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оживленный маг",
},
[322527] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[434089] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[389056] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Страж Иридий",
},
[438696] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[369610] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сотрясающий тотем",
},
[427439] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[450980] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нитемот Таказдж",
},
[429487] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[434093] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443305] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[425394] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[441772] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[434096] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[326629] = {
["school"] = 40,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[442285] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сгустолиция",
},
[455080] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[429493] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чудище камня Бездны",
},
[421817] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пламекон",
},
[442799] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[424888] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[424889] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[388555] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Konnypan-TarrenMill",
},
[43308] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[321005] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[369110] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тлерон",
},
[423356] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[440246] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[447411] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[441782] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[384978] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мраскул",
},
[323057] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[450483] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[426943] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[327664] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[369116] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тлерон",
},
[1160] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[322548] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[451510] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[372701] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Часовая Талондрас",
},
[322550] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тред'ова",
},
[441788] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[334321] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хирург Трупошов",
},
[435136] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[334322] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[447419] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Предок",
},
[427461] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
},
[448443] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Паутинный генерал Аб'енар",
},
[435138] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[441791] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[448444] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Паутинный генерал Аб'енар",
},
[457144] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[455099] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Преданный служитель",
},
[437700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[322557] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Друст-душеруб",
},
[443842] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434119] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[439749] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[449986] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[450499] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[443847] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[450500] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[424913] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
},
[383974] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пузострелка",
},
[429521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[376811] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Древорот",
},
[372718] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Часовая Талондрас",
},
[451016] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[435152] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[448458] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Преданный служитель",
},
[443342] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[443854] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[432596] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мать Хаоса",
},
[31707] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Элементаль воды",
},
[320012] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[435156] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[447950] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[447439] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[384494] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Киракка",
},
[459210] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[447440] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[454605] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нейтрализующее устройство",
},
[343556] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[424414] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[447443] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[343558] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хирург Трупошов",
},
[451026] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[445909] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровожадный роевик",
},
[423393] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[432605] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[369660] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сотрясающий тотем",
},
[388084] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Телаш Серокрылый",
},
[424419] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[369662] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сотрясающий тотем",
},
[376827] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хан Балакар",
},
[438749] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[369663] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сотрясающий тотем",
},
[372222] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лазурный Клинок",
},
[451032] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[376829] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хан Балакар",
},
[429028] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пробудившийся Бездны",
},
[439776] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[447965] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[428519] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Дорлита",
},
[439778] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[428520] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[443361] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[447967] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[447456] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[437733] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[438245] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[377859] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Древорот",
},
[386559] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Каджин Непреклонная",
},
[374789] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Леймор",
},
[440805] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нерл'атекк Крадущийся",
},
[443364] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[376325] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[436200] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[440806] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нерл'атекк Крадущийся",
},
[115767] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[387585] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Изначальное цунами",
},
[369674] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Геомант из племени Каменного Свода",
},
[439784] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[434155] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[424432] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[369675] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Геомант из племени Каменного Свода",
},
[439785] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[436203] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434668] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Аратийская бомба",
},
[377864] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древорот",
},
[439786] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[369677] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Олаф",
},
[439787] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[448488] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[439789] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[453609] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439792] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[100] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[445422] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[384524] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Страж Иридий",
},
[1604] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Подстрекатель из клана Нокхуд",
},
[428535] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[456170] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[459753] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Фенрир",
},
[445936] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скованный кровью ужас",
},
[432119] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ки'катал Жница",
},
[427002] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[438773] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[386063] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Маруук",
},
[433656] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Укрепленный трутень",
},
[384529] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гнилозубая гиена",
},
[6572] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[453616] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж ужаса",
},
[436217] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[384531] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гнилозубая гиена",
},
[385555] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голиаф-проглот",
},
[427007] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[444408] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Давенрут",
},
[385558] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Эркхарт Кровь Бури",
},
[427011] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[448505] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[428547] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[369696] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Прыгун-падальшик",
},
[325174] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем духовной связи",
},
[432130] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[424966] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[450042] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Прожорливый скарабей",
},
[432132] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[435203] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[443903] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[450045] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[439299] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Королева Ансурек",
},
[439811] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443906] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[444418] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[424460] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[369703] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бромач",
},
[443907] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443396] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439814] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[424462] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[448515] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[323137] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Дроман Ульфарран",
},
[387618] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Насыщательница-воин стихий",
},
[192082] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем ветряного порыва",
},
[439817] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438794] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[320580] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[448006] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[427025] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тьма",
},
[434702] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[430097] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[443403] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[434705] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[443405] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[434706] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Работница дегустационной",
},
[459782] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Космический симулякр",
},
[434707] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Работница дегустационной",
},
[431637] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный странник теней",
},
[444431] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[459273] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Космический симулякр",
},
[459785] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[438804] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[445457] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[464392] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[419870] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[377395] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хронолорд Дейос",
},
[439829] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[419871] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[451600] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[462859] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный снайпер",
},
[438807] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огромный паук",
},
[135029] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Элементаль воды",
},
[430109] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый рокотун",
},
[436762] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[441368] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[437786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[446486] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Разделенная слизь",
},
[320596] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумокост",
},
[369725] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сотрясающий тотем",
},
[451606] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[181089] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мраскул",
},
[451607] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[436255] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[439838] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[322648] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[434722] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[444446] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Давенрут",
},
[434723] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[387131] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Драконобойный копьемет",
},
[436260] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Давенрут",
},
[387133] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Драконобойный копьемет",
},
[441379] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[449568] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Паутинный генерал Аб'енар",
},
[460315] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[429099] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Благочестивый жрец",
},
[436264] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[438823] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дьявольский бес",
},
[441382] = {
["school"] = 16,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пустотелый ледопряд",
},
[372808] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[431660] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный странник теней",
},
[458272] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Космический симулякр",
},
[444456] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[381512] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эркхарт Кровь Бури",
},
[425011] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Вечный огонь",
},
[439852] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439341] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[458277] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[462372] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[432179] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[447532] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[462373] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ловчий из люка",
},
[428086] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[422969] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Барон Браунпайк",
},
[460839] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[436787] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[448046] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[432182] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[449070] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[392778] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[443954] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[387150] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Телаш Серокрылый",
},
[387151] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Телаш Серокрылый",
},
[441397] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пчелка",
},
[387152] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Телаш Серокрылый",
},
[434745] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[369754] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Бромач",
},
[381525] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Киракка",
},
[439865] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[440377] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[381526] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Киракка",
},
[455219] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[320630] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[374364] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Леймор",
},
[438845] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[456245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[442428] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[114893] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем каменной преграды",
},
[270481] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Демонический тиран",
},
[436800] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[461876] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[326263] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[377950] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Лови-тотем",
},
[433731] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[432196] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[126664] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[441408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Посетитель из Торговой компании",
},
[444479] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Преобразованная ярость",
},
[434756] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бугай",
},
[59638] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зеркальное изображение",
},
[456762] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[445504] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[443969] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[440899] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[440900] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439365] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "И'па",
},
[374885] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Астральный служитель",
},
[445507] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Король Торас Троллебой",
},
[464442] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[442437] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[445508] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Назгрим",
},
[376934] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Древорот",
},
[445509] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Назгрим",
},
[440904] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[460351] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[435788] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[163201] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[425554] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[321669] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Иллюзорный клон",
},
[445513] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный инквизитор Вайтмейн",
},
[181113] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вечная сфера",
},
[435791] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[437839] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[5302] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[377965] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лови-тотем",
},
[470592] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Давенрут",
},
[463428] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[470593] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Преобразованная ярость",
},
[425048] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бурестраж Горрен",
},
[384620] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Яростная буря",
},
[455242] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бейлог",
},
[441425] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[460360] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[428120] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[434773] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Посетитель из Торговой компании",
},
[369781] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрик \"Быстрый\"",
},
[435797] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бомба Искроварни",
},
[444497] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[425052] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[450128] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Воскоморд",
},
[434776] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[427100] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[460364] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[461388] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[440407] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[450131] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[444502] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[375416] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зараженный плеточник",
},
[384628] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростная буря",
},
[372858] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кокия Пламенное Копыто",
},
[375929] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хан Балакар",
},
[450133] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[372859] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кокия Пламенное Копыто",
},
[445016] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Потерянный дозорный",
},
[382071] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Часовая Талондрас",
},
[372860] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кокия Пламенное Копыто",
},
[322709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[437342] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[440413] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[451160] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[369792] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрик \"Быстрый\"",
},
[372863] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кокия Пламенное Копыто",
},
[423015] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[432227] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[459350] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[461910] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сфера вознесения",
},
[432229] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[375937] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хан Балакар",
},
[457818] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Безликий последователь",
},
[450142] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Воскоморд",
},
[445537] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[334488] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[30213] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Скверны",
},
[440421] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[450145] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[434281] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Преобразованная ярость",
},
[434793] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Служитель-щелкун",
},
[427629] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный снайпер",
},
[447076] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[445541] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Брокк",
},
[423536] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[157331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изначальный элементаль бури",
},
[434284] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[423538] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[450661] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[461408] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[369806] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Огромный берсерк",
},
[442987] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[441452] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[458340] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[451176] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[463459] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[320170] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[439408] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[434803] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[369811] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Огромный берсерк",
},
[446409] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Потревоженные водоросли",
},
[64695] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем хватки земли",
},
[434695] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Работница дегустационной",
},
[444363] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[433781] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[201754] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Гонн",
},
[441314] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Взбешенный прыгун",
},
[322450] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[423547] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[322614] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тред'ова",
},
[442994] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[442277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[197509] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Кровавый червь",
},
[395197] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Taloot-Draenor",
},
[424798] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Зараженный зверь",
},
[446690] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ненасытный червь",
},
[427357] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Благочестивый жрец",
},
[442484] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[438355] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[458207] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровавый паразит",
},
[434407] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[427616] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[320655] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумокост",
},
[441171] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[458212] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Огромный паук",
},
[456815] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[369818] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огромный берсерк",
},
[373912] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гниломаг Око Гнева",
},
[323138] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ингра Малох",
},
[434299] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Преобразованная ярость",
},
[454472] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Рви-зуб",
},
[437343] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[323250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Дроман Ульфарран",
},
[434779] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[446344] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[437371] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[321006] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[224126] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[463427] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глибб",
},
[439419] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[186254] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Strendewolf-DarkmoonFaire",
},
[115804] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ящер",
},
[461895] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сфера вознесения",
},
[322576] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Друст-душеруб",
},
[333488] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[448632] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[98021] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Тотем духовной связи",
},
[188046] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Обитатель Сна",
},
[333489] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[2580] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[450421] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[225788] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[224125] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[448634] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[455287] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зараженное порождение",
},
[424958] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[387155] = {
["school"] = 0,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гранит",
},
[383061] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[433766] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[427015] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тьма",
},
[333492] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[442495] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[377503] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Хранительница печати",
},
[444414] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумной роевик",
},
[437093] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443612] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[436867] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[369828] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Злобный василиск",
},
[224127] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[448638] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[422382] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Древень",
},
[423051] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[432353] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[321725] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Иллюзорный клон",
},
[436757] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[427583] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[444034] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[444546] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[263840] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Fenryr",
},
[445570] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[450176] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Неруб-тихоступ",
},
[454782] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[372851] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[444507] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[404464] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[434710] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[449154] = {
["school"] = 5,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кузнечный погрузчик",
},
[457465] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[373862] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Blackridge-TarrenMill",
},
[424805] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[446819] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[424212] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[382628] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Яростная буря",
},
[385187] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голиаф-проглот",
},
[381605] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Киракка",
},
[374868] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Астральный служитель",
},
[267997] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Огнедышащая гончая",
},
[446598] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[465717] = {
["school"] = 28,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Предок",
},
[3600] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем оков земли",
},
[382630] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[436799] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[381607] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Киракка",
},
[435341] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[452229] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Gruiikkheal-Archimonde",
},
[123996] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сюэнь",
},
[376723] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Буремант из клана Нокхуд",
},
[373932] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драконья иллюзия",
},
[440134] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бенк Жужжикс",
},
[433740] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[369327] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Рунический защитник",
},
[427378] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[453989] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[385578] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Лазурный Клинок",
},
[320200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[423062] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[450129] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[448650] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[389872] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Изначальное цунами",
},
[378029] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рви-зуб",
},
[369854] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дюжий камнемет",
},
[386029] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[447240] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[386478] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[321226] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[345561] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тиира",
},
[463461] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[372652] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[369400] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Земельник-дозорный",
},
[456841] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[443003] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[425113] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[463464] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[441362] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[426715] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[320717] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[384686] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Яростная буря",
},
[427402] = {
["school"] = 9,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый страж птенцов",
},
[449167] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Дорлита",
},
[466055] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[450191] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[445052] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[369335] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Рунический защитник",
},
[385434] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тиира",
},
[443090] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[471174] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[320208] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Создание Трупошва",
},
[373942] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гниломаг Око Гнева",
},
[441315] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Взбешенный прыгун",
},
[425315] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кругогриб",
},
[369337] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рунический защитник",
},
[439795] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[448147] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Страж зала",
},
[435165] = {
["school"] = 2,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сэр Браунпайк",
},
[432198] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[369061] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тлерон",
},
[439506] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[448660] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[443031] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[434786] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Служитель-щелкун",
},
[396722] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Телаш Серокрылый",
},
[427001] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[429545] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Обращенный глашатай",
},
[451324] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[392883] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Rayids-Kazzak",
},
[426145] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[388283] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гранит",
},
[369853] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Дюжий камнемет",
},
[435410] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[448663] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[426860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[423076] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[423588] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[373915] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Гниломаг Око Гнева",
},
[426136] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[6552] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[341709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призывательница Туманов",
},
[456853] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[458357] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[384185] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Яростная буря",
},
[421665] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Старый Воскобород",
},
[442525] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[461460] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гигантская свеча",
},
[383840] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Страж Иридий",
},
[415403] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "ЗАЗУ",
},
[442526] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[381864] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Киракка",
},
[369791] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрик \"Быстрый\"",
},
[415404] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кругогриб",
},
[321754] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[438200] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[445838] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нестабильный подопытный объект",
},
[456174] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[321755] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[428711] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[427176] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Извивающееся порождение Тьмы",
},
[415406] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кругогриб",
},
[385181] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Голиаф-проглот",
},
[438947] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[452806] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[376079] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[442530] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[443042] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[453773] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[424420] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[428202] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[30153] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Скверны",
},
[439325] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "И'па",
},
[321247] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[448673] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[424431] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[449697] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Стражник королевы Ге'за",
},
[449734] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443081] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[451605] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[316643] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[386660] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Леймор",
},
[440310] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[454589] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Удушающее облако гнили",
},
[437417] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[425489] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[439825] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[322274] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Похитительница с \"Золрамуса\"",
},
[263423] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Kematian",
},
[435403] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[426160] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[434860] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[429999] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[434697] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[421282] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Свечной Король",
},
[434758] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[449702] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[321253] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
},
[441289] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[421638] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[428508] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[438153] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантом Пустоты",
},
[384014] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Страж Иридий",
},
[434829] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[439333] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Изголодавшийся ползун",
},
[443336] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[447170] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[386411] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тиира",
},
[387559] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изначальное цунами",
},
[454311] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[428212] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[433841] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кровавый надсмотрщик",
},
[428161] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Брокк",
},
[6343] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[52042] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[438960] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[427710] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Споровик",
},
[201633] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем земляной стены",
},
[439686] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[383979] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пузострелка",
},
[435012] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[386781] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Телаш Серокрылый",
},
[423246] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[435148] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[444608] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[433845] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кровавый надсмотрщик",
},
[321772] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[450714] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кукловод?",
},
[438708] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[447999] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[384696] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мраскул",
},
[396044] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[384024] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[430013] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[426171] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[426736] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[432117] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[428242] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[437721] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[438966] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[224729] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[388817] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гранит",
},
[420659] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[443061] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[445174] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Забытый глашатай",
},
[439991] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[190456] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[438974] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[444411] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[439992] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[440504] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[443063] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[439481] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[90361] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Aradan",
},
[392151] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тиира",
},
[428735] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[445623] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[386547] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тиира",
},
[455363] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[438971] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хищная золопчела",
},
[55078] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[443325] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[369399] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ткач земли",
},
[439781] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[445996] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[427865] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[446649] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Барон Браунпайк",
},
[376933] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Древорот",
},
[423109] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[385551] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голиаф-проглот",
},
[436923] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[443068] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[424903] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "ЗАЗУ",
},
[377559] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Древорот",
},
[384343] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пузострелка",
},
[438975] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хищная золопчела",
},
[433843] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кровавый надсмотрщик",
},
[438218] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[438801] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[438976] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[424710] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Грибной потрошитель",
},
[444094] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[436950] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[445409] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[320763] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем прилива маны",
},
[434832] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[439794] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[385075] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Мраскул",
},
[382670] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тиира",
},
[438675] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Разъевшийся ползун",
},
[372963] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[423121] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[445632] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[437956] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[444609] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[424421] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[384223] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Лазурный Клинок",
},
[385518] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мелидрусса Истощенная Холодом",
},
[446657] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[436934] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[52212] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[443837] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Давенрут",
},
[384015] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Иридий",
},
[445123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[439780] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[381862] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Киракка",
},
[438471] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[378155] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лови-тотем",
},
[435401] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[369697] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Прыгун-падальшик",
},
[454848] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[385339] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Маруук",
},
[386757] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Каджин Непреклонная",
},
[427635] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Боевая рысь",
},
[438473] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[438949] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[320771] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[2565] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[440521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[439401] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[320772] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[394976] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плеточник Бездны",
},
[385579] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лазурный Клинок",
},
[447175] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[435405] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[317792] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародей из войска мертвых",
},
[438476] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[427180] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тьма",
},
[386743] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Каджин Непреклонная",
},
[432520] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[424148] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[444324] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[415495] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кругогриб",
},
[427894] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер кузни Дамиан",
},
[448888] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443888] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[439502] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[376292] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хронолорд Дейос",
},
[442573] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[435533] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глибб",
},
[433519] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[457877] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[463220] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[424821] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скрипучая вагонетка (кобольды)",
},
[443598] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[443494] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Осколок кристалла",
},
[438481] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[430805] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Распылитель сгущающейся Бездны",
},
[387132] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Драконобойный копьемет",
},
[436749] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[382620] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пузострелка",
},
[426712] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[376049] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хронолорд Дейос",
},
[433877] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[457804] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Безликий последователь",
},
[451277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[439600] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Осколок кристалла",
},
[423200] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скарморак",
},
[439037] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голодное порождение",
},
[451278] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[414944] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Грибной потрошитель",
},
[435222] = {
["school"] = 9,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лапочкаичё-Ревущийфьорд",
},
[372811] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кокия Пламенное Копыто",
},
[455373] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[435415] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[449169] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[424739] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[443092] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[320784] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[427157] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тьма",
},
[373939] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Тотем взрывной гнили",
},
[442432] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[442257] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кровавый паразит",
},
[373917] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гниломаг Око Гнева",
},
[423019] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[430812] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Распылитель сгущающейся Бездны",
},
[438622] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Разъевшийся ползун",
},
[193473] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Щупальце Бездны",
},
[375924] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Олаф",
},
[386916] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Яростная буря",
},
[421277] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[445275] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[327952] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[430814] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Распылитель сгущающейся Бездны",
},
[320788] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налтор Криомант",
},
[369328] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рунический защитник",
},
[331440] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[438343] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[425556] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[374523] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Силовой росток",
},
[451968] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Rayids-Kazzak",
},
[448644] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[437469] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[376727] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хан Балакар",
},
[444702] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[426127] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Свечной Король",
},
[453846] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Gruiikkheal-Archimonde",
},
[444123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[438494] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[451288] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Потерянный дозорный",
},
[439518] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[464923] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438495] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[369409] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Земельник-комендант",
},
[322569] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Друст-душеруб",
},
[317898] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Геомант из племени Каменного Свода",
},
[323177] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[328146] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Червь-трупоед",
},
[328756] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ингра Малох",
},
[323149] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ингра Малох",
},
[323146] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[369411] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Пещерный ловец",
},
[431333] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[461904] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сфера вознесения",
},
[422122] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Старый Воскобород",
},
[439010] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Извивающееся порождение Тьмы",
},
[336759] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[336499] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Призывательница Туманов",
},
[322654] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[322655] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[455953] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[461392] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[326281] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[463767] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кристалл забвения",
},
[439524] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бенк Жужжикс",
},
[320614] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[422125] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[320637] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[320171] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[328664] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оживленный маг",
},
[434408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[333634] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[322563] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[320376] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[322681] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[334476] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[320358] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[320366] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[428269] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгусток Бездны",
},
[426734] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[369602] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Олаф",
},
[320839] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Похитительница с \"Золрамуса\"",
},
},
["emotes"] = {
{
["boss"] = "Налтор Криомант",
},
{
["boss"] = "Хирург Трупошов",
},
{
["boss"] = "Амарт Жнец",
},
},
}
