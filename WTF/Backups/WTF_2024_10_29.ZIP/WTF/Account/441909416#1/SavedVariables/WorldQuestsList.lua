
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[66419] = true,
[52163] = true,
[64531] = true,
[75257] = true,
[51385] = true,
[51626] = true,
[81624] = true,
[53331] = true,
[51665] = true,
[64273] = true,
[76586] = true,
[51586] = true,
},
["VERSION"] = 114,
},
["Сорчистино-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Мальдика-СвежевательДуш"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
[81807] = true,
[80295] = true,
[82456] = true,
[82293] = true,
[83930] = true,
[81822] = true,
[81806] = true,
[82584] = true,
[81624] = true,
[82300] = true,
[76586] = true,
[81656] = true,
},
["Filter"] = 63,
},
["Вольтчара-СвежевательДуш"] = {
["VERSION"] = 114,
["Filter"] = 63,
["Quests"] = {
[51847] = true,
[81825] = true,
[51586] = true,
[53994] = true,
[83718] = true,
[52163] = true,
[81624] = true,
[51671] = true,
[51664] = true,
[51462] = true,
[79959] = true,
[82456] = true,
[82521] = true,
[51296] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Sort"] = 5,
["VERSION"] = 114,
["Алианкано-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Сэйвмэн-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["VERSION"] = 113,
["Quests"] = {
[76586] = true,
[59600] = true,
},
["Filter"] = 63,
},
["Дракобес-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
[60950] = true,
[71164] = true,
[74837] = true,
},
["VERSION"] = 114,
},
["Топмэн-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["SortPrio"] = {
},
["Ignore"] = {
},
["Вантачмэн-Ревущийфьорд"] = {
["VERSION"] = 113,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[74835] = true,
[52196] = true,
[49345] = true,
[73146] = true,
[54896] = true,
[82295] = true,
[51612] = true,
[66551] = true,
[82456] = true,
[82586] = true,
[71180] = true,
[70068] = true,
[55466] = true,
[58747] = true,
[72029] = true,
[82292] = true,
[75280] = true,
[69927] = true,
[51297] = true,
[71140] = true,
[58743] = true,
[50497] = true,
[52756] = true,
},
["Filter"] = 63,
},
["Beamladen-TwistingNether"] = {
["VERSION"] = 113,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Прециза-СвежевательДуш"] = {
["VERSION"] = 112,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["AzeriteFormat"] = 20,
["HideLegion"] = true,
}
