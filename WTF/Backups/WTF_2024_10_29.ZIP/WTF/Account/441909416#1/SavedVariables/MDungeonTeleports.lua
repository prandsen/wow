
MDungeonTeleports = {
["Season1Pos"] = {
["y"] = -219.6185048133411,
["x"] = 498.8574891192693,
},
["PortalLibraryPos"] = {
["y"] = -100,
["x"] = 970,
},
["lastLoginMessageDate"] = "20241029",
["firstLaunch"] = false,
["showTooltips"] = false,
["isPortalLibraryRaidShown"] = false,
["isSeason1PortalsShown"] = true,
["isPortalLibraryShown"] = false,
["selectedFramePack"] = "Interface/Addons/MDungeonTeleports/media/frames/default_frames.blp",
["frameScale"] = 1.200000047683716,
["PortalLibraryRaidPos"] = {
["y"] = -195,
["x"] = 970,
},
["selectedUIPack"] = "Interface/AddOns/MDungeonTeleports/media/ui/default_ui/",
}
