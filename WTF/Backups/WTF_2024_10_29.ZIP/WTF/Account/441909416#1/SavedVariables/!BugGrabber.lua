
BugGrabberDB = {
["session"] = 748,
["lastSanitation"] = 3,
["errors"] = {
{
["message"] = "Ошибка Lua в индикации 'New': Пользовательская текстовая функция\nВерсия WeakAuras: 5.17.3\nТрассировка стака:\n[string \"return function()\"]:4: attempt to call global 'UnitAura' (a nil value)",
["time"] = "2024/10/28 22:40:23",
["locals"] = "a = \"Слово силы: Стойкость\"\nb = 135987\nc = 0\nd = \"Magic\"\ne = 3600.003000\nf = 452031.277000\ng = \"player\"\n(*temporary) = nil\n(*temporary) = \"player\"\n(*temporary) = \"attempt to call global 'UnitAura' (a nil value)\"\n",
["stack"] = "[string \"return function()\"]:4: in function <[string \"return function()\"]:1>\n[string \"=[C]\"]: in function `xpcall'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4983: in function `RunCustomTextFunc'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/Text.lua\"]:246: in function `Update'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4719: in function <Interface/AddOns/WeakAuras/WeakAuras.lua:4716>\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4808: in function <Interface/AddOns/WeakAuras/WeakAuras.lua:4774>\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4918: in function `UpdatedTriggerState'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4638: in function `UpdateFakeStatesFor'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4611: in function `FakeStatesFor'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:3225: in function <Interface/AddOns/WeakAuras/WeakAuras.lua:3076>\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:3249: in function `Add'\n[string \"@Interface/AddOns/WeakAurasOptions/OptionsFrames/TextEditor.lua\"]:1033: in function `Close'\n[string \"@Interface/AddOns/WeakAurasOptions/OptionsFrames/TextEditor.lua\"]:214: in function <...AddOns/WeakAurasOptions/OptionsFrames/TextEditor.lua:213>",
["session"] = 745,
["counter"] = 1,
},
{
["message"] = "[ADDON_ACTION_BLOCKED] Модификация 'WeakAuras' пыталась вызвать защищенную функцию 'Frame:SetPoint()'.",
["time"] = "2024/10/29 00:23:07",
["locals"] = "_ = Frame {\n}\nevent = \"ADDON_ACTION_BLOCKED\"\nevents = <table> {\n}\n",
["stack"] = "[string \"@Interface/AddOns/!BugGrabber/BugGrabber.lua\"]:485: in function <Interface/AddOns/!BugGrabber/BugGrabber.lua:485>\n[string \"=[C]\"]: in function `SetPoint'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:60: in function `SetAnchorPoint'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:1355: in function `DoPositionChildrenPerFrame'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:1516: in function `DoPositionChildren'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:1332: in function `PositionChildren'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:1313: in function `SortUpdatedChildren'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:1113: in function `RunDelayedActions'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/DynamicGroup.lua\"]:1104: in function `Resume'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4814: in function <Interface/AddOns/WeakAuras/WeakAuras.lua:4774>\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4939: in function `UpdatedTriggerState'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:941: in function `ScanEventsInternal'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:878: in function `ScanEvents'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:845: in function `ScanEventsByID'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:2686: in function `SendEventsForSpell'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:2642: in function `CheckSpellCooldown'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:2593: in function `CheckSpellCooldowns'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:3392: in function `CheckCooldownReady'\n[string \"@Interface/AddOns/WeakAuras/GenericTrigger.lua\"]:2817: in function <Interface/AddOns/WeakAuras/GenericTrigger.lua:2775>",
["session"] = 747,
["counter"] = 1,
},
{
["message"] = "[ADDON_ACTION_BLOCKED] Модификация '*** ForceTaint_Strong ***' пыталась вызвать защищенную функцию 'UNKNOWN()'.",
["time"] = "2024/10/29 00:25:36",
["locals"] = "_ = Frame {\n}\nevent = \"ADDON_ACTION_BLOCKED\"\nevents = <table> {\n}\n",
["stack"] = "[string \"@Interface/AddOns/!BugGrabber/BugGrabber.lua\"]:485: in function <Interface/AddOns/!BugGrabber/BugGrabber.lua:485>\n[string \"=[C]\"]: ?\n[string \"=[C]\"]: in function `IsItemInRange'\n[string \"return function() aura_env.harmDistance = function(unit)\"]:14: in function `friendlyDistance'\n[string \"return function()\"]:20: in function <[string \"return function()\"]:1>\n[string \"=[C]\"]: in function `xpcall'\n[string \"@Interface/AddOns/WeakAuras/WeakAuras.lua\"]:4983: in function `RunCustomTextFunc'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/Text.lua\"]:263: in function `?'\n[string \"@Interface/AddOns/WeakAuras/SubscribableObject.lua\"]:94: in function `Notify'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/RegionPrototype.lua\"]:637: in function `?'\n[string \"@Interface/AddOns/WeakAuras/SubscribableObject.lua\"]:94: in function `Notify'\n[string \"@Interface/AddOns/WeakAuras/RegionTypes/RegionPrototype.lua\"]:843: in function <...ace/AddOns/WeakAuras/RegionTypes/RegionPrototype.lua:841>",
["session"] = 748,
["counter"] = 2,
},
},
}
