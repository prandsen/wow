
RaiderIO_Config = {
["replayAlpha"] = 1,
["enableKeystoneTooltips"] = true,
["profilePoint"] = {
["y"] = 0,
["x"] = -16,
["point"] = "TOPLEFT",
},
["enableReplay"] = true,
["enableLFGDropdown"] = true,
["minimapIcon"] = {
["minimapPos"] = 180,
["showInCompartment"] = true,
["hide"] = true,
["lock"] = false,
},
["showMainsScore"] = true,
["showRaidEncountersInProfile"] = true,
["showAverageScore"] = true,
["enableWhoMessages"] = false,
["useEnglishAbbreviations"] = true,
["disableScoreColors"] = false,
["showMainBestScore"] = true,
["allowClientToControlCombatLog"] = false,
["replayBackground"] = {
["a"] = 0.5,
["b"] = 0,
["g"] = 0,
["r"] = 0,
},
["mplusHeadlineMode"] = 0,
["showScoreInCombat"] = true,
["replaySelection"] = "user_best_replay",
["inverseProfileModifier"] = false,
["enableGuildTooltips"] = true,
["enableCombatLogTracking"] = false,
["enableClientEnhancements"] = true,
["enableLFGTooltips"] = true,
["enableFriendsTooltips"] = true,
["enableUnitTooltips"] = true,
["positionProfileAuto"] = true,
["hidePersonalRaiderIOProfile"] = false,
["showDropDownCopyURL"] = true,
["showRoleIcons"] = true,
["enableProfileModifier"] = true,
["showScoreModifier"] = false,
["enableWhoTooltips"] = false,
["lockProfile"] = false,
["showSimpleScoreColors"] = false,
["showRaiderIOProfile"] = true,
["showClientGuildBest"] = true,
}
RaiderIO_LastCharacter = "eu-Бимладен-howling-fjord"
RaiderIO_MissingCharacters = {
["eu-Мумуполицу-howling-fjord"] = true,
["eu-Пёллё-howling-fjord"] = true,
["eu-Берфанг-howling-fjord"] = true,
["eu-Артист-howling-fjord"] = true,
["eu-Карошам-howling-fjord"] = true,
["eu-Лонкс-howling-fjord"] = true,
["eu-Айман-howling-fjord"] = true,
["eu-Найтрэмп-howling-fjord"] = true,
["eu-Сэфарирон-howling-fjord"] = true,
["eu-Ксаноешка-howling-fjord"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
