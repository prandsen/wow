
PremadeGroupsFilterSettings = {
["signupOnEnter"] = false,
["specIcon"] = false,
["ratingInfo"] = true,
["classNamesInTooltip"] = true,
["oneClickSignUp"] = true,
["coloredGroupTexts"] = true,
["leaderCrown"] = false,
["missingRoles"] = false,
["version"] = 3,
["classBar"] = false,
["persistSignUpNote"] = true,
["classCircle"] = false,
["skipSignUpDialog"] = false,
["dialogMovable"] = true,
}
