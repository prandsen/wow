
MythicDungeonToolsDB = {
["profileKeys"] = {
["Бимладен - Ревущий фьорд"] = "Бимладен - Ревущий фьорд",
["Вольтчара - Свежеватель Душ"] = "Вольтчара - Свежеватель Душ",
},
["global"] = {
["minimap"] = {
["showInCompartment"] = true,
},
},
}
