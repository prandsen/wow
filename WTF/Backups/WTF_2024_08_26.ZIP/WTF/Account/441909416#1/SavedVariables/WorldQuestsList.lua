
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 111,
},
["AzeriteFormat"] = 20,
["Scale"] = 0.8,
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Ignore"] = {
},
["Sort"] = 5,
["VERSION"] = 111,
["Вольтчара-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 111,
},
["SortPrio"] = {
},
["HideLegion"] = true,
}
