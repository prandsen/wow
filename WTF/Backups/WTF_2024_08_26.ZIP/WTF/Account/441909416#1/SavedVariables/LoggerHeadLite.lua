
LoggerHeadNDB = {
["profileKeys"] = {
["Бимладен - Ревущий фьорд"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["minimap"] = {
["hide"] = true,
},
},
},
}
