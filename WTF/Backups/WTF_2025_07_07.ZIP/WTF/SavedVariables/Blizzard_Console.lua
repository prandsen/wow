
Blizzard_Console_SavedVars = {
["version"] = 3,
["messageHistory"] = {
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2552 with translation: (0.340088, 0.820068, 1131.33)\n    Location : (2261.36, -2259.76, 562.064)\n    Location in previous map : (2261.02, -2260.58, -569.269)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2552. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2262.53, -2257.64, -570.469)",
0,
},
{
"[Airlock] Preload initiated for map 2552",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2649, level 18, time 1936035",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Starting up hasFrontInterface=\"false\" hasBackInterface=\"false\"",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"Resetting",
0,
},
{
"Initializing",
0,
},
{
"Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Front connected connectionId=\"1\" program=\"WoW\" platform=\"Wn64\" locale=\"ruRU\" version=\"\" usedToken=\"true\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"OnSendLogon result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Logon complete result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\" numGameAccounts=\"3\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Received bnet account state code=\"ERROR_OK (0)\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW1\" numGameAccounts=\"3\" numGameAccountNames=\"0\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW3\" numGameAccounts=\"3\" numGameAccountNames=\"1\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW2\" numGameAccounts=\"3\" numGameAccountNames=\"2\"",
0,
},
{
"Received web credentials  code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Updated game account list, not saving.",
0,
},
{
"Logon complete.",
0,
},
{
"Reconnect token saved;  creationTime=\"1751743023\" expirationTime=\"1751757423\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Requesting realm list ticket",
0,
},
{
"Received realm list ticket code=\"ERROR_OK (0)\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Received sub region list code=\"ERROR_OK (0)\"",
0,
},
{
"Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"23-1-50\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"1\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Received last played char code=\"ERROR_OK (0)\" subRegion=\"3-4-89\" lastPlayedTime=\"1751740468\" numRegions=\"3\" numRegionsWithData=\"2\" realmEntry=\"{\"wowRealmAddress\":50790433,\"cfgTimezonesID\":21,\"populationState\":6,\"cfgCategoriesID\":12,\"version\":{\"versionMajor\":11,\"versionBuild\":61131,\"versionMinor\":1,\"versionRevision\":7},\"cfgRealmsID\":1615,\"flags\":0,\"name\":\"Ревущий фьорд\",\"cfgConfigsID\":1,\"cfgContentSetID\":0,\"cfgLanguagesID\":10}\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"73-1-59\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"3\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Realm list ready.",
0,
},
{
"Found most recently played char. Joining realm. lastPlayedRegion=\"3-4-89\" realmAddress=\"50790433\" lastActiveTime=\"1751740468\"",
0,
},
{
"Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"OnRealmJoin code=\"ERROR_OK (0)\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Received AuthedToWoW result=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Got new connection 2",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Connected to Back. Disconnecting from Front.",
0,
},
{
"Front disconnecting connectionId=\"1\"",
0,
},
{
"Disconnecting from authentication server.",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Disconnected from authentication server.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 7/5/2025 (Sat) 21:16",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 350d 21h 38m 34s",
0,
},
{
"Level: 31d 2h 52m 48s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 10, time 1179811",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Completed challenge mode mapID 2293, level 11, time 1714482",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 0.600000\n",
0,
},
{
"Weather changed to 5, intensity 0.600000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 10, time 1434769",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 1594, level 11, time 1383554",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 7/5/2025 (Sat) 23:44",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 351d 0h 6m 8s",
0,
},
{
"Level: 31d 5h 20m 22s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.155485\n",
0,
},
{
"Weather changed to 2, intensity 0.224966\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 18, time 1752174",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Starting up hasFrontInterface=\"false\" hasBackInterface=\"false\"",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"Resetting",
0,
},
{
"Initializing",
0,
},
{
"Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Front connected connectionId=\"1\" program=\"WoW\" platform=\"Wn64\" locale=\"ruRU\" version=\"\" usedToken=\"true\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"OnSendLogon result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Logon complete result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\" numGameAccounts=\"3\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW3\" numGameAccounts=\"3\" numGameAccountNames=\"0\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW1\" numGameAccounts=\"3\" numGameAccountNames=\"1\"",
0,
},
{
"Received bnet account state code=\"ERROR_OK (0)\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW2\" numGameAccounts=\"3\" numGameAccountNames=\"2\"",
0,
},
{
"Received web credentials  code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Updated game account list, not saving.",
0,
},
{
"Logon complete.",
0,
},
{
"Reconnect token saved;  creationTime=\"1751802848\" expirationTime=\"1751817248\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Requesting realm list ticket",
0,
},
{
"Received realm list ticket code=\"ERROR_OK (0)\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Received sub region list code=\"ERROR_OK (0)\"",
0,
},
{
"Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"23-1-50\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"1\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"73-1-59\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"2\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Received last played char code=\"ERROR_OK (0)\" subRegion=\"3-4-89\" lastPlayedTime=\"1751757040\" numRegions=\"3\" numRegionsWithData=\"3\" realmEntry=\"{\"wowRealmAddress\":50790433,\"cfgTimezonesID\":21,\"populationState\":6,\"cfgCategoriesID\":12,\"version\":{\"versionMajor\":11,\"versionBuild\":61131,\"versionMinor\":1,\"versionRevision\":7},\"cfgRealmsID\":1615,\"flags\":0,\"name\":\"Ревущий фьорд\",\"cfgConfigsID\":1,\"cfgContentSetID\":0,\"cfgLanguagesID\":10}\"",
0,
},
{
"Realm list ready.",
0,
},
{
"Found most recently played char. Joining realm. lastPlayedRegion=\"3-4-89\" realmAddress=\"50790433\" lastActiveTime=\"1751757040\"",
0,
},
{
"Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"OnRealmJoin code=\"ERROR_OK (0)\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Received AuthedToWoW result=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Got new connection 2",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Connected to Back. Disconnecting from Front.",
0,
},
{
"Front disconnecting connectionId=\"1\"",
0,
},
{
"Disconnecting from authentication server.",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 7/6/2025 (Sun) 13:56",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 351d 1h 31m 31s",
0,
},
{
"Level: 31d 6h 45m 45s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Completed challenge mode mapID 2293, level 10, time 1722928",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2097, level 10, time 1306358",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.149894\n",
0,
},
{
"Weather changed to 2, intensity 0.263357\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.263357\n",
0,
},
{
"Weather changed to 2, intensity 0.263357\n",
0,
},
{
"Weather changed to 1, intensity 0.100019\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2773, level 10, time 1296200",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.123834\n",
0,
},
{
"Weather changed to 2, intensity 0.248759\n",
0,
},
{
"Weather changed to 1, intensity 0.169762\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2651, level 10, time 1602444",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.281130\n",
0,
},
{
"Weather changed to 1, intensity 0.177954\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"Session with Battle.net destroyed.",
0,
},
{
"Disconnected from WoW previouslyConnected=\"true\"",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Clearing last error",
0,
},
{
"Clearing last error",
0,
},
{
"Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"Resetting",
0,
},
{
"Destroying isInitialized=\"true\"",
0,
},
{
"Initializing",
0,
},
{
"Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Front connected connectionId=\"2\" program=\"WoW\" platform=\"Wn64\" locale=\"ruRU\" version=\"\" usedToken=\"true\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"OnSendLogon result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"External challenge usedSSO=\"true\"",
0,
},
{
"Fatal error while logging in result=\"( code=\" (308)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Front disconnecting connectionId=\"2\"",
0,
},
{
"Disconnecting from authentication server.",
0,
},
{
"Front disconnected connectionId=\"2\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Disconnected from authentication server.",
0,
},
{
"Destroying isInitialized=\"true\"",
0,
},
{
"Clearing last error",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Starting up hasFrontInterface=\"false\" hasBackInterface=\"false\"",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"Resetting",
0,
},
{
"Initializing",
0,
},
{
"Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Front connected connectionId=\"1\" program=\"WoW\" platform=\"Wn64\" locale=\"ruRU\" version=\"\" usedToken=\"true\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"OnSendLogon result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Logon complete result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\" numGameAccounts=\"3\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW3\" numGameAccounts=\"3\" numGameAccountNames=\"0\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW1\" numGameAccounts=\"3\" numGameAccountNames=\"1\"",
0,
},
{
"Received bnet account state code=\"ERROR_OK (0)\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW2\" numGameAccounts=\"3\" numGameAccountNames=\"2\"",
0,
},
{
"Received web credentials  code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Updated game account list, not saving.",
0,
},
{
"Logon complete.",
0,
},
{
"Reconnect token saved;  creationTime=\"1751816428\" expirationTime=\"1751830828\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Requesting realm list ticket",
0,
},
{
"Received realm list ticket code=\"ERROR_OK (0)\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Received sub region list code=\"ERROR_OK (0)\"",
0,
},
{
"Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"23-1-50\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"1\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Received last played char code=\"ERROR_OK (0)\" subRegion=\"3-4-89\" lastPlayedTime=\"1751803037\" numRegions=\"3\" numRegionsWithData=\"2\" realmEntry=\"{\"wowRealmAddress\":50790433,\"cfgTimezonesID\":21,\"populationState\":6,\"cfgCategoriesID\":12,\"version\":{\"versionMajor\":11,\"versionBuild\":61131,\"versionMinor\":1,\"versionRevision\":7},\"cfgRealmsID\":1615,\"flags\":0,\"name\":\"Ревущий фьорд\",\"cfgConfigsID\":1,\"cfgContentSetID\":0,\"cfgLanguagesID\":10}\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"73-1-59\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"3\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Realm list ready.",
0,
},
{
"Found most recently played char. Joining realm. lastPlayedRegion=\"3-4-89\" realmAddress=\"50790433\" lastActiveTime=\"1751803037\"",
0,
},
{
"Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"OnRealmJoin code=\"ERROR_OK (0)\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Received AuthedToWoW result=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Connected to Back. Disconnecting from Front.",
0,
},
{
"Front disconnecting connectionId=\"1\"",
0,
},
{
"Disconnecting from authentication server.",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Disconnected from authentication server.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 7/6/2025 (Sun) 17:40",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 351d 5h 14m 54s",
0,
},
{
"Level: 31d 10h 29m 8s",
0,
},
{
"Completed challenge mode mapID 1594, level 11, time 1556349",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 10, time 1199423",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Starting up hasFrontInterface=\"false\" hasBackInterface=\"false\"",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"Resetting",
0,
},
{
"Initializing",
0,
},
{
"Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Front connected connectionId=\"1\" program=\"WoW\" platform=\"Wn64\" locale=\"ruRU\" version=\"\" usedToken=\"true\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"OnSendLogon result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Logon complete result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\" numGameAccounts=\"3\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW1\" numGameAccounts=\"3\" numGameAccountNames=\"0\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW3\" numGameAccounts=\"3\" numGameAccountNames=\"1\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW2\" numGameAccounts=\"3\" numGameAccountNames=\"2\"",
0,
},
{
"Received bnet account state code=\"ERROR_OK (0)\"",
0,
},
{
"Received web credentials  code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Updated game account list, not saving.",
0,
},
{
"Logon complete.",
0,
},
{
"Reconnect token saved;  creationTime=\"1751826451\" expirationTime=\"1751840851\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Requesting realm list ticket",
0,
},
{
"Received realm list ticket code=\"ERROR_OK (0)\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Received sub region list code=\"ERROR_OK (0)\"",
0,
},
{
"Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"Received last played char code=\"ERROR_OK (0)\" subRegion=\"3-4-89\" lastPlayedTime=\"1751818827\" numRegions=\"3\" numRegionsWithData=\"1\" realmEntry=\"{\"wowRealmAddress\":50790433,\"cfgTimezonesID\":21,\"populationState\":6,\"cfgCategoriesID\":12,\"version\":{\"versionMajor\":11,\"versionBuild\":61131,\"versionMinor\":1,\"versionRevision\":7},\"cfgRealmsID\":1615,\"flags\":0,\"name\":\"Ревущий фьорд\",\"cfgConfigsID\":1,\"cfgContentSetID\":0,\"cfgLanguagesID\":10}\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"23-1-50\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"2\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"73-1-59\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"3\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Realm list ready.",
0,
},
{
"Found most recently played char. Joining realm. lastPlayedRegion=\"3-4-89\" realmAddress=\"50790433\" lastActiveTime=\"1751818827\"",
0,
},
{
"Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"OnRealmJoin code=\"ERROR_OK (0)\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Received AuthedToWoW result=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Got new connection 2",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Connected to Back. Disconnecting from Front.",
0,
},
{
"Front disconnecting connectionId=\"1\"",
0,
},
{
"Disconnecting from authentication server.",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Disconnected from authentication server.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 7/6/2025 (Sun) 20:32",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.157160\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 351d 5h 54m 39s",
0,
},
{
"Level: 31d 11h 8m 53s",
0,
},
{
"Weather changed to 2, intensity 0.265620\n",
0,
},
{
"Weather changed to 1, intensity 0.140486\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 7/6/2025 (Sun) 20:56, newtime = 7/6/2025 (Sun) 20:58)",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 7/6/2025 (Sun) 21:14",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 351d 6h 36m 51s",
0,
},
{
"Level: 31d 11h 51m 5s",
0,
},
{
"Player-1615-0B536A51 TRAIT_VALIDATION: Config 26544476. Failed to purchase node 94609 entry 117206 rank 0 with fail reason NODE_OP_FAILURE_REASON_MAX_RANK",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 7/6/2025 (Sun) 21:55, newtime = 7/6/2025 (Sun) 21:57)",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
},
["height"] = 299.9999694824219,
["fontHeight"] = 14,
["isShown"] = false,
["commandHistory"] = {
},
}
