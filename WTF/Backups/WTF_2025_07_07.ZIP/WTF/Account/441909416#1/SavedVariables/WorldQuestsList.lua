
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["VERSION"] = 116,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[81624] = true,
[81812] = true,
[81816] = true,
[82254] = true,
[66419] = true,
[82448] = true,
[82580] = true,
[81621] = true,
[50866] = true,
[82470] = true,
[50847] = true,
[81854] = true,
[76586] = true,
[82583] = true,
[75257] = true,
[81767] = true,
[82120] = true,
[81804] = true,
[82257] = true,
[82552] = true,
[83048] = true,
},
["Filter"] = 63,
},
["Сорчистино-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Мальдика-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 116,
},
["Вольтчара-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["Filter"] = 63,
["Quests"] = {
[76586] = true,
},
["VERSION"] = 115,
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Sort"] = 5,
["VERSION"] = 116,
["Алианкано-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Сэйвмэн-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 115,
["Quests"] = {
[76586] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["Дракобес-СвежевательДуш"] = {
["VERSION"] = 115,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Топмэн-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["SortPrio"] = {
},
["Ignore"] = {
},
["Вантачмэн-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[69927] = true,
[50497] = true,
[74835] = true,
[82292] = true,
[70068] = true,
[54896] = true,
[71180] = true,
[73146] = true,
[55466] = true,
[71140] = true,
[58743] = true,
[75280] = true,
[66551] = true,
[58747] = true,
},
["VERSION"] = 116,
},
["Пва-СвежевательДуш"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Beamladen-TwistingNether"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 114,
},
["AzeriteFormat"] = 20,
["Прециза-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["HideLegion"] = true,
}
