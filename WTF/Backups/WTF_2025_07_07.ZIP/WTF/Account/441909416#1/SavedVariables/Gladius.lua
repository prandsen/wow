
Gladius2DB = {
["profileKeys"] = {
["Бимладен - Ревущий фьорд"] = "Бимладен - Ревущий фьорд",
["Вантачмэн - Ревущий фьорд"] = "Вантачмэн - Ревущий фьорд",
},
["profiles"] = {
["Бимладен - Ревущий фьорд"] = {
["auraVersion"] = 1,
["tagsVersion"] = 4,
["locked"] = true,
["y"] = {
["arena1"] = 479.000242086815,
},
["globalFont"] = "ITCAvantGardeGothicDemi",
["announcements"] = {
["health"] = false,
["spec"] = false,
["enemies"] = false,
},
["x"] = {
["arena1"] = 1007.467719659333,
},
},
["Вантачмэн - Ревущий фьорд"] = {
["auraVersion"] = 1,
["tagsVersion"] = 4,
["y"] = {
["arena1"] = 498.2002112422633,
},
["x"] = {
["arena1"] = 885.3338716416038,
},
},
},
}
