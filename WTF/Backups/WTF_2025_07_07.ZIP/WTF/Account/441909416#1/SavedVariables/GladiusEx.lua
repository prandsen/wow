
GladiusExDB = {
["namespaces"] = {
["arena"] = {
["profiles"] = {
["Default"] = {
["y"] = {
["anchor_arena"] = 432.6668566453991,
["arena2"] = 449.8168136287277,
["arena3"] = 384.0168574739037,
["arena1"] = 515.6167697835517,
},
["x"] = {
["anchor_arena"] = 851.8002662556464,
["arena2"] = 896.600265492707,
["arena3"] = 896.600265492707,
["arena1"] = 896.600265492707,
},
},
},
},
["party"] = {
["profiles"] = {
["Default"] = {
["y"] = {
["anchor_party"] = 654.5334422225023,
["player"] = 732.2333981746706,
["party1"] = 669.9333992356333,
["party2"] = 607.6334430212046,
},
["x"] = {
["anchor_party"] = 32.3330385423892,
["player"] = 91.13304288160725,
["party1"] = 91.13304288160725,
["party2"] = 91.13304288160725,
},
},
},
},
},
["profileKeys"] = {
["Вантачмэн - Ревущий фьорд"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["globalFont"] = "ITCAvantGardeGothicDemi",
["showParty"] = false,
["locked"] = true,
},
},
}
