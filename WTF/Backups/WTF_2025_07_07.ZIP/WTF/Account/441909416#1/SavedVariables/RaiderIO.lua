
RaiderIO_Config = {
["replayAlpha"] = 1,
["enableKeystoneTooltips"] = true,
["profilePoint"] = {
["y"] = 0,
["x"] = -16,
["point"] = "TOPLEFT",
},
["enableReplay"] = true,
["enableLFGDropdown"] = true,
["minimapIcon"] = {
["minimapPos"] = 180,
["showInCompartment"] = true,
["lock"] = false,
["hide"] = true,
},
["showMainsScore"] = true,
["showRaidEncountersInProfile"] = true,
["showAverageScore"] = true,
["enableWhoMessages"] = false,
["useEnglishAbbreviations"] = true,
["disableScoreColors"] = false,
["showMainBestScore"] = true,
["allowClientToControlCombatLog"] = false,
["replayBackground"] = {
["a"] = 0.5,
["r"] = 0,
["g"] = 0,
["b"] = 0,
},
["showRaiderIOProfile"] = true,
["showSimpleScoreColors"] = false,
["replaySelection"] = "user_best_replay",
["inverseProfileModifier"] = false,
["enableGuildTooltips"] = true,
["enableWhoTooltips"] = false,
["showScoreModifier"] = false,
["enableProfileModifier"] = true,
["showRoleIcons"] = true,
["enableUnitTooltips"] = true,
["enableFriendsTooltips"] = true,
["hidePersonalRaiderIOProfile"] = false,
["showDropDownCopyURL"] = true,
["positionProfileAuto"] = true,
["enableLFGTooltips"] = true,
["enableClientEnhancements"] = true,
["enableCombatLogTracking"] = false,
["lockProfile"] = false,
["showScoreInCombat"] = true,
["mplusHeadlineMode"] = 0,
["showClientGuildBest"] = true,
}
RaiderIO_LastCharacter = "eu-Бимладен-howling-fjord"
RaiderIO_MissingCharacters = {
["eu-Хаваюснюс-howling-fjord"] = true,
["eu-Карику-howling-fjord"] = true,
["eu-Жесткийдруид-howling-fjord"] = true,
["eu-Крысуник-howling-fjord"] = true,
["eu-Центробежный-howling-fjord"] = true,
["eu-Хдэмойпэт-howling-fjord"] = true,
["eu-Бостардо-howling-fjord"] = true,
["eu-Морпехваншот-howling-fjord"] = true,
["eu-Максимини-howling-fjord"] = true,
["eu-Кхалпрайм-howling-fjord"] = true,
["eu-Пальтишко-howling-fjord"] = true,
["eu-Сутулыйбивен-howling-fjord"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
