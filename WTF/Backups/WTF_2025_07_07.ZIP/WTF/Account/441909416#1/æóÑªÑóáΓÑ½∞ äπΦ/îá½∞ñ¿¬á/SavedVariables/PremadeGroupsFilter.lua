
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c1f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dungeon6"] = false,
["dungeon4"] = false,
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
["act"] = false,
["val"] = 4,
},
["dungeon1"] = true,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
["dungeon3"] = true,
["dungeon8"] = false,
["dungeon5"] = true,
["dungeon7"] = false,
["dungeon2"] = false,
},
},
["c9f8"] = {
["enabled"] = true,
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["val"] = 3,
["act"] = true,
},
["heals"] = {
["max"] = "3",
["min"] = "",
["act"] = true,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "15",
["act"] = true,
},
["expression"] = "",
},
},
["c3f6"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
},
["heals"] = {
["max"] = "",
["act"] = false,
},
["tanks"] = {
["min"] = "",
["act"] = false,
},
["defeated"] = {
},
["dps"] = {
},
["members"] = {
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["version"] = 6,
["c2f101"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c114f6"] = {
["enabled"] = true,
},
["c6f4"] = {
["enabled"] = true,
["role"] = {
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "10",
["act"] = true,
},
["expression"] = "",
},
},
["c114f5"] = {
["enabled"] = true,
},
["c3f165"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
}
