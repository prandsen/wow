
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[70] = 30,
[65] = 40,
[66] = 30,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-09765C91"] = true,
},
["spellRangeCheckRangeEnemy"] = {
[70] = 30,
[65] = 40,
[66] = 30,
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["minimap"] = {
},
}
