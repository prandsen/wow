
NewSettingsSeen = {
["panelItemQualityColorOverrides"] = true,
["assistedCombatHighlight"] = true,
["cooldownViewerEnabled"] = true,
["ASSISTED_COMBAT_ROTATION"] = true,
}
