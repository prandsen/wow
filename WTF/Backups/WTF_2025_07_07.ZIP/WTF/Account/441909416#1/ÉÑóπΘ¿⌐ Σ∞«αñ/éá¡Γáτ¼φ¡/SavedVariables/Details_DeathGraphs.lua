
AdvancedDeathLogsDB = {
["__version"] = 1,
["deathsPerSegment"] = {
},
["spellIdCache"] = {
},
["deathsOccurrences"] = {
},
["enemySpellCasts"] = {
},
["encounterInfo"] = {
},
}
DeathGraphsDBEndurance = {
}
