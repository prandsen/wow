
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[269] = 40,
[270] = 40,
[268] = 30,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1615-0B39792F"] = true,
},
["spellRangeCheckRangeEnemy"] = {
[269] = 40,
[270] = 40,
[268] = 30,
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["minimap"] = {
},
}
