
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 299.9999694824219,
["messageHistory"] = {
{
"Skill 921 increased from 385 to 390",
0,
},
{
"Skill 2730 increased from 385 to 390",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 390 to 395",
0,
},
{
"Skill 183 increased from 390 to 395",
0,
},
{
"Skill 756 increased from 390 to 395",
0,
},
{
"Skill 921 increased from 390 to 395",
0,
},
{
"Skill 2730 increased from 390 to 395",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Skill 118 increased from 395 to 400",
0,
},
{
"Skill 183 increased from 395 to 400",
0,
},
{
"Skill 756 increased from 395 to 400",
0,
},
{
"Skill 921 increased from 395 to 400",
0,
},
{
"Skill 2730 increased from 395 to 400",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000029",
0,
},
{
"Proficiency in item class 4 set to 0x000000002d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000003d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004173",
0,
},
{
"Proficiency in item class 2 set to 0x00000041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000003f",
0,
},
{
"Proficiency in item class 2 set to 0x00000041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000003f",
0,
},
{
"Time set to 8/3/2025 (Sun) 13:31",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Time played:",
0,
},
{
"Total: 3d 13h 13m 8s",
0,
},
{
"Level: 0d 0h 8m 37s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 3d 13h 14m 23s",
0,
},
{
"Level: 0d 0h 9m 52s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 3d 13h 15m 9s",
0,
},
{
"Level: 0d 0h 10m 38s",
0,
},
{
"Player-1604-0AA089D9 TRAIT_VALIDATION: Failure: Config 2937643. 20 pending (including duplicates) after adding all open nodes.",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Skill 118 increased from 300 to 305",
0,
},
{
"Skill 183 increased from 300 to 305",
0,
},
{
"Skill 756 increased from 300 to 305",
0,
},
{
"Skill 796 increased from 300 to 305",
0,
},
{
"Skill 2731 increased from 300 to 305",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 118 increased from 305 to 315",
0,
},
{
"Skill 183 increased from 305 to 315",
0,
},
{
"Skill 756 increased from 305 to 315",
0,
},
{
"Skill 796 increased from 305 to 315",
0,
},
{
"Skill 2731 increased from 305 to 315",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000029",
0,
},
{
"Proficiency in item class 4 set to 0x000000002d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000003d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004173",
0,
},
{
"Proficiency in item class 2 set to 0x00000041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000003f",
0,
},
{
"Proficiency in item class 2 set to 0x00000041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000003f",
0,
},
{
"Time set to 8/3/2025 (Sun) 14:52",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Time played:",
0,
},
{
"Total: 3d 14h 24m 54s",
0,
},
{
"Level: 0d 0h 30m 52s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 315 to 325",
0,
},
{
"Skill 183 increased from 315 to 325",
0,
},
{
"Skill 756 increased from 315 to 325",
0,
},
{
"Skill 796 increased from 315 to 325",
0,
},
{
"Skill 2731 increased from 315 to 325",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Skill 118 increased from 325 to 330",
0,
},
{
"Skill 183 increased from 325 to 330",
0,
},
{
"Skill 756 increased from 325 to 330",
0,
},
{
"Skill 796 increased from 325 to 330",
0,
},
{
"Skill 2731 increased from 325 to 330",
0,
},
{
"Skill 118 increased from 330 to 335",
0,
},
{
"Skill 183 increased from 330 to 335",
0,
},
{
"Skill 756 increased from 330 to 335",
0,
},
{
"Skill 796 increased from 330 to 335",
0,
},
{
"Skill 2731 increased from 330 to 335",
0,
},
{
"Skill 118 increased from 335 to 340",
0,
},
{
"Skill 183 increased from 335 to 340",
0,
},
{
"Skill 756 increased from 335 to 340",
0,
},
{
"Skill 796 increased from 335 to 340",
0,
},
{
"Skill 2731 increased from 335 to 340",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Player-1604-0AA089D9 TRAIT_VALIDATION: Failure: Config 2937643. 12 pending (including duplicates) after adding all open nodes.",
0,
},
{
"Skill 118 increased from 340 to 345",
0,
},
{
"Skill 183 increased from 340 to 345",
0,
},
{
"Skill 756 increased from 340 to 345",
0,
},
{
"Skill 796 increased from 340 to 345",
0,
},
{
"Skill 2731 increased from 340 to 345",
0,
},
{
"Skill 118 increased from 345 to 350",
0,
},
{
"Skill 183 increased from 345 to 350",
0,
},
{
"Skill 756 increased from 345 to 350",
0,
},
{
"Skill 796 increased from 345 to 350",
0,
},
{
"Skill 2731 increased from 345 to 350",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Player-1604-0AA089D9 TRAIT_VALIDATION: Failure: Config 2937643. 10 pending (including duplicates) after adding all open nodes.",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 118 increased from 350 to 355",
0,
},
{
"Skill 183 increased from 350 to 355",
0,
},
{
"Skill 756 increased from 350 to 355",
0,
},
{
"Skill 796 increased from 350 to 355",
0,
},
{
"Skill 2731 increased from 350 to 355",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 355 to 360",
0,
},
{
"Skill 183 increased from 355 to 360",
0,
},
{
"Skill 756 increased from 355 to 360",
0,
},
{
"Skill 796 increased from 355 to 360",
0,
},
{
"Skill 2731 increased from 355 to 360",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 360 to 365",
0,
},
{
"Skill 183 increased from 360 to 365",
0,
},
{
"Skill 756 increased from 360 to 365",
0,
},
{
"Skill 796 increased from 360 to 365",
0,
},
{
"Skill 2731 increased from 360 to 365",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Player-1604-0AA089D9 TRAIT_VALIDATION: Failure: Config 2937643. 7 pending (including duplicates) after adding all open nodes.",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Skill 118 increased from 365 to 370",
0,
},
{
"Skill 183 increased from 365 to 370",
0,
},
{
"Skill 756 increased from 365 to 370",
0,
},
{
"Skill 796 increased from 365 to 370",
0,
},
{
"Skill 2731 increased from 365 to 370",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000029",
0,
},
{
"Proficiency in item class 4 set to 0x000000002d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000003d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004173",
0,
},
{
"Proficiency in item class 2 set to 0x00000041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000003f",
0,
},
{
"Proficiency in item class 2 set to 0x00000041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000003f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 8/3/2025 (Sun) 18:12",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 3d 16h 46m 44s",
0,
},
{
"Level: 0d 0h 43m 6s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 118 increased from 370 to 375",
0,
},
{
"Skill 183 increased from 370 to 375",
0,
},
{
"Skill 756 increased from 370 to 375",
0,
},
{
"Skill 796 increased from 370 to 375",
0,
},
{
"Skill 2731 increased from 370 to 375",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 375 to 380",
0,
},
{
"Skill 183 increased from 375 to 380",
0,
},
{
"Skill 756 increased from 375 to 380",
0,
},
{
"Skill 796 increased from 375 to 380",
0,
},
{
"Skill 2731 increased from 375 to 380",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 380 to 385",
0,
},
{
"Skill 183 increased from 380 to 385",
0,
},
{
"Skill 756 increased from 380 to 385",
0,
},
{
"Skill 796 increased from 380 to 385",
0,
},
{
"Skill 2731 increased from 380 to 385",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 118 increased from 385 to 390",
0,
},
{
"Skill 183 increased from 385 to 390",
0,
},
{
"Skill 756 increased from 385 to 390",
0,
},
{
"Skill 796 increased from 385 to 390",
0,
},
{
"Skill 2731 increased from 385 to 390",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Skill 118 increased from 390 to 395",
0,
},
{
"Skill 183 increased from 390 to 395",
0,
},
{
"Skill 756 increased from 390 to 395",
0,
},
{
"Skill 796 increased from 390 to 395",
0,
},
{
"Skill 2731 increased from 390 to 395",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 118 increased from 395 to 400",
0,
},
{
"Skill 183 increased from 395 to 400",
0,
},
{
"Skill 756 increased from 395 to 400",
0,
},
{
"Skill 796 increased from 395 to 400",
0,
},
{
"Skill 2731 increased from 395 to 400",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000008001",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c001",
0,
},
{
"Proficiency in item class 2 set to 0x000000c003",
0,
},
{
"Proficiency in item class 2 set to 0x000000c403",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x000000c423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 8/3/2025 (Sun) 21:17",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 62d 3h 2m 21s",
0,
},
{
"Level: 14d 5h 49m 31s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 12, time 1421237",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000008000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c000",
0,
},
{
"Proficiency in item class 2 set to 0x000000c400",
0,
},
{
"Proficiency in item class 2 set to 0x000000c480",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Proficiency in item class 2 set to 0x000008c480",
0,
},
{
"Proficiency in item class 2 set to 0x000008c480",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Time set to 8/3/2025 (Sun) 21:47",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Time played:",
0,
},
{
"Total: 35d 14h 19m 56s",
0,
},
{
"Level: 0d 1h 59m 49s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 35d 14h 20m 50s",
0,
},
{
"Level: 0d 2h 0m 43s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 35d 14h 21m 40s",
0,
},
{
"Level: 0d 2h 1m 33s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 35d 14h 22m 24s",
0,
},
{
"Level: 0d 2h 2m 17s",
0,
},
{
"Player-1604-0A5B10F4 TRAIT_VALIDATION: Failure: Config 2937347. 20 pending (including duplicates) after adding all open nodes.",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 444810 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 444810 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"ModifierTree: 296564.  Modifier not supported on client (type=174, asset=82817, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 296564.  Modifier not supported on client (type=174, asset=82817, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 300 to 310",
0,
},
{
"Skill 756 increased from 300 to 310",
0,
},
{
"Skill 849 increased from 300 to 310",
0,
},
{
"Skill 228 increased from 300 to 310",
0,
},
{
"Skill 2732 increased from 300 to 310",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 310 to 315",
0,
},
{
"Skill 756 increased from 310 to 315",
0,
},
{
"Skill 849 increased from 310 to 315",
0,
},
{
"Skill 228 increased from 310 to 315",
0,
},
{
"Skill 2732 increased from 310 to 315",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"ModifierTree: 173907.  Modifier not supported on client (type=80, asset=10000, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 173907.  Modifier not supported on client (type=80, asset=10000, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 173907.  Modifier not supported on client (type=80, asset=10000, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 173907.  Modifier not supported on client (type=80, asset=10000, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Skill 183 increased from 315 to 320",
0,
},
{
"Skill 756 increased from 315 to 320",
0,
},
{
"Skill 849 increased from 315 to 320",
0,
},
{
"Skill 228 increased from 315 to 320",
0,
},
{
"Skill 2732 increased from 315 to 320",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 183 increased from 320 to 330",
0,
},
{
"Skill 756 increased from 320 to 330",
0,
},
{
"Skill 849 increased from 320 to 330",
0,
},
{
"Skill 228 increased from 320 to 330",
0,
},
{
"Skill 2732 increased from 320 to 330",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Player-1604-0A5B10F4 TRAIT_VALIDATION: Failure: Config 2937347. 14 pending (including duplicates) after adding all open nodes.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 330 to 340",
0,
},
{
"Skill 756 increased from 330 to 340",
0,
},
{
"Skill 849 increased from 330 to 340",
0,
},
{
"Skill 228 increased from 330 to 340",
0,
},
{
"Skill 2732 increased from 330 to 340",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Starting up hasFrontInterface=\"false\" hasBackInterface=\"false\"",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"Startup()",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"login\"",
0,
},
{
"Switching to screen=\"AccountLogin\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"Resetting",
0,
},
{
"Initializing",
0,
},
{
"Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Front connected connectionId=\"1\" program=\"WoW\" platform=\"Wn64\" locale=\"ruRU\" version=\"\" usedToken=\"true\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"OnSendLogon result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Logon complete result=\"( code=\"ERROR_OK (0)\" localizedMessage=\"\" debugMessage=\"\")\" numGameAccounts=\"3\"",
0,
},
{
"Waiting for server response.",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW3\" numGameAccounts=\"3\" numGameAccountNames=\"0\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW1\" numGameAccounts=\"3\" numGameAccountNames=\"1\"",
0,
},
{
"Received bnet account state code=\"ERROR_OK (0)\"",
0,
},
{
"Received game account name code=\"ERROR_OK (0)\" name=\"WoW2\" numGameAccounts=\"3\" numGameAccountNames=\"2\"",
0,
},
{
"Received web credentials  code=\"ERROR_OK (0)\" gotCredentials=\"true\"",
0,
},
{
"Updated game account list, not saving.",
0,
},
{
"Logon complete.",
0,
},
{
"Reconnect token saved;  creationTime=\"1754305084\" expirationTime=\"1754319484\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Requesting realm list ticket",
0,
},
{
"Received realm list ticket code=\"ERROR_OK (0)\"",
0,
},
{
"Waiting for realm list.",
0,
},
{
"Received sub region list code=\"ERROR_OK (0)\"",
0,
},
{
"Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"23-1-50\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"1\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Received last played char code=\"ERROR_OK (0)\" subRegion=\"3-4-89\" lastPlayedTime=\"1754254639\" numRegions=\"3\" numRegionsWithData=\"2\" realmEntry=\"{\"wowRealmAddress\":50790418,\"cfgTimezonesID\":21,\"populationState\":2,\"cfgCategoriesID\":12,\"version\":{\"versionMajor\":11,\"versionBuild\":61131,\"versionMinor\":1,\"versionRevision\":7},\"cfgRealmsID\":1604,\"flags\":0,\"name\":\"Свежеватель Душ\",\"cfgConfigsID\":1,\"cfgContentSetID\":0,\"cfgLanguagesID\":10}\"",
0,
},
{
"Received last played char code=\" (309)\" subRegion=\"73-1-59\" lastPlayedTime=\"0\" numRegions=\"3\" numRegionsWithData=\"3\" realmEntry=\"{\"wowRealmAddress\":0,\"cfgTimezonesID\":0,\"populationState\":0,\"cfgCategoriesID\":0,\"version\":{\"versionMajor\":0,\"versionBuild\":0,\"versionMinor\":0,\"versionRevision\":0},\"cfgRealmsID\":0,\"flags\":0,\"name\":\"\",\"cfgConfigsID\":0,\"cfgContentSetID\":0,\"cfgLanguagesID\":0}\"",
0,
},
{
"Realm list ready.",
0,
},
{
"Found most recently played char. Joining realm. lastPlayedRegion=\"3-4-89\" realmAddress=\"50790418\" lastActiveTime=\"1754254639\"",
0,
},
{
"Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"OnRealmJoin code=\"ERROR_OK (0)\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Received AuthedToWoW result=\"ERROR_OK (0)\"",
0,
},
{
"Screen invalid. Changing from=\"login\" to=\"charselect\"",
0,
},
{
"Got new connection 2",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"login\")",
0,
},
{
"From EnsureValidScreen",
0,
},
{
"Connected to Back. Disconnecting from Front.",
0,
},
{
"Front disconnecting connectionId=\"1\"",
0,
},
{
"Disconnecting from authentication server.",
0,
},
{
"Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED (1016)\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"Disconnected from authentication server.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Suspend()",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000008000",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c000",
0,
},
{
"Proficiency in item class 2 set to 0x000000c400",
0,
},
{
"Proficiency in item class 2 set to 0x000000c480",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Proficiency in item class 2 set to 0x000008c480",
0,
},
{
"Proficiency in item class 2 set to 0x000008c480",
0,
},
{
"Proficiency in item class 4 set to 0x0000000023",
0,
},
{
"Time set to 8/4/2025 (Mon) 12:59",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Time played:",
0,
},
{
"Total: 35d 15h 28m 55s",
0,
},
{
"Level: 0d 0h 0m 50s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 340 to 345",
0,
},
{
"Skill 756 increased from 340 to 345",
0,
},
{
"Skill 849 increased from 340 to 345",
0,
},
{
"Skill 228 increased from 340 to 345",
0,
},
{
"Skill 2732 increased from 340 to 345",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Skill 183 increased from 345 to 350",
0,
},
{
"Skill 756 increased from 345 to 350",
0,
},
{
"Skill 849 increased from 345 to 350",
0,
},
{
"Skill 228 increased from 345 to 350",
0,
},
{
"Skill 2732 increased from 345 to 350",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 183 increased from 350 to 355",
0,
},
{
"Skill 756 increased from 350 to 355",
0,
},
{
"Skill 849 increased from 350 to 355",
0,
},
{
"Skill 228 increased from 350 to 355",
0,
},
{
"Skill 2732 increased from 350 to 355",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Player-1604-0A5B10F4 TRAIT_VALIDATION: Failure: Config 2937347. 9 pending (including duplicates) after adding all open nodes.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 355 to 360",
0,
},
{
"Skill 756 increased from 355 to 360",
0,
},
{
"Skill 849 increased from 355 to 360",
0,
},
{
"Skill 228 increased from 355 to 360",
0,
},
{
"Skill 2732 increased from 355 to 360",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Skill 183 increased from 360 to 365",
0,
},
{
"Skill 756 increased from 360 to 365",
0,
},
{
"Skill 849 increased from 360 to 365",
0,
},
{
"Skill 228 increased from 360 to 365",
0,
},
{
"Skill 2732 increased from 360 to 365",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Skill 183 increased from 365 to 370",
0,
},
{
"Skill 756 increased from 365 to 370",
0,
},
{
"Skill 849 increased from 365 to 370",
0,
},
{
"Skill 228 increased from 365 to 370",
0,
},
{
"Skill 2732 increased from 365 to 370",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 370 to 375",
0,
},
{
"Skill 756 increased from 370 to 375",
0,
},
{
"Skill 849 increased from 370 to 375",
0,
},
{
"Skill 228 increased from 370 to 375",
0,
},
{
"Skill 2732 increased from 370 to 375",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 375 to 380",
0,
},
{
"Skill 756 increased from 375 to 380",
0,
},
{
"Skill 849 increased from 375 to 380",
0,
},
{
"Skill 228 increased from 375 to 380",
0,
},
{
"Skill 2732 increased from 375 to 380",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 35d 17h 52m 11s",
0,
},
{
"Level: 0d 0h 7m 29s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 380 to 385",
0,
},
{
"Skill 756 increased from 380 to 385",
0,
},
{
"Skill 849 increased from 380 to 385",
0,
},
{
"Skill 228 increased from 380 to 385",
0,
},
{
"Skill 2732 increased from 380 to 385",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 1\"",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Error requesting content handle. code=\"ERROR_NOT_EXISTS (4)\" request=\"program: 4674137 stream: 1937006964 version: 1920291413\"",
0,
},
{
"Error retrieving content handle. code=\"ERROR_NOT_EXISTS (4)\" program=\"GRY\" localizationKey=\"program: 4674137 stream: 1937006964 localization_id: 0\"",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 116.",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"Weather changed to 2, intensity 0.500000\n",
0,
},
{
"End lightning storm.",
0,
},
{
"Skill 183 increased from 385 to 390",
0,
},
{
"Skill 756 increased from 385 to 390",
0,
},
{
"Skill 849 increased from 385 to 390",
0,
},
{
"Skill 228 increased from 385 to 390",
0,
},
{
"Skill 2732 increased from 385 to 390",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.107001\n",
0,
},
{
"Weather changed to 2, intensity 0.291106\n",
0,
},
{
"Weather changed to 1, intensity 0.153445\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"Weather changed to 2, intensity 0.750000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 390 to 395",
0,
},
{
"Skill 756 increased from 390 to 395",
0,
},
{
"Skill 849 increased from 390 to 395",
0,
},
{
"Skill 228 increased from 390 to 395",
0,
},
{
"Skill 2732 increased from 390 to 395",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 395 to 400",
0,
},
{
"Skill 756 increased from 395 to 400",
0,
},
{
"Skill 849 increased from 395 to 400",
0,
},
{
"Skill 228 increased from 395 to 400",
0,
},
{
"Skill 2732 increased from 395 to 400",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Resume()",
0,
},
{
"Screen invalid. Changing from=\"none\" to=\"charselect\"",
0,
},
{
"Switching to screen=\"CharacterSelect\" (from \"none\")",
0,
},
{
"From EnsureValidScreen",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
