
NewSettingsSeen = {
["ASSISTED_COMBAT_ROTATION"] = true,
["assistedCombatHighlight"] = true,
}
