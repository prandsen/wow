
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c1f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dungeon6"] = false,
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dungeon2"] = false,
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
["val"] = 4,
["act"] = false,
},
["dungeon1"] = false,
["dungeon7"] = false,
["dungeon5"] = false,
["dungeon8"] = false,
["dungeon3"] = false,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
["dungeon4"] = false,
},
},
["c3f165"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c6f4"] = {
["enabled"] = true,
["role"] = {
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "10",
["act"] = true,
},
["expression"] = "",
},
},
["c3f6"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
},
["heals"] = {
["max"] = "",
["act"] = false,
},
["tanks"] = {
["min"] = "",
["act"] = false,
},
["members"] = {
["min"] = "",
["act"] = false,
},
["dps"] = {
},
["defeated"] = {
},
["expression"] = "",
},
},
["version"] = 6,
["c2f101"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["act"] = true,
["val"] = 3,
},
["heals"] = {
["max"] = "3",
["min"] = "",
["act"] = true,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "15",
["act"] = true,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c9f8"] = {
["enabled"] = true,
},
}
