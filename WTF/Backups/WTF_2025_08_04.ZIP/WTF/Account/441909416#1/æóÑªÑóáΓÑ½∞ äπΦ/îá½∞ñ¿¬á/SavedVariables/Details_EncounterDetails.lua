
EncounterDetailsDB = {
["chartData"] = {
},
["encounter_spells"] = {
[423664] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[426735] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[423665] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[446694] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Огромный паук",
},
[436971] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[453859] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[472794] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Торфоморд",
},
[321828] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[447207] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[434926] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[456420] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[448744] = {
["school"] = 6,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[445162] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[104318] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дикий бес",
},
[325413] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Иглобрюх-кислотник",
},
[442604] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[428276] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[451305] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Потерянный дозорный",
},
[446700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ненасытный червь",
},
[422648] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Свечной Король",
},
[439536] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[321834] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[440049] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[324394] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Костяное чудовище",
},
[325418] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Иглобрюх-кислотник",
},
[282943] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Таранный поршень",
},
[317231] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксав Несломленный",
},
[455404] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[442611] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[427260] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый наставник буреклювов",
},
[339751] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эхо наездника на быке",
},
[439031] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[280389] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[162264] = {
["school"] = 127,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[1216745] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кул'тарок",
},
[451315] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[324914] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Туманная хранительница",
},
[76303] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[228537] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[438012] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[196809] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[448248] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[441084] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[442108] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[196810] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[463602] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[339759] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[451321] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[415499] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кругогриб",
},
[196811] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Божественный образ",
},
[455416] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[271698] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Азерокк",
},
[464628] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[440576] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[468723] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[440577] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[114942] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем целительного прилива",
},
[436996] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[472819] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Торфоморд",
},
[196813] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[457467] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[463609] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Фантом Пустоты",
},
[423693] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Старый Воскобород",
},
[199373] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Войско мертвых",
},
[434441] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[439559] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[443654] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[438025] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бенк Жужжикс",
},
[443655] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[333629] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Возрожденный арбалетчик",
},
[196816] = {
["school"] = 2,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[1216815] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксал'атат",
},
[443656] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[464638] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[257459] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[443657] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[451334] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[464640] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[442635] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Брызгающее кровотечение",
},
[426771] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[441612] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[428819] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[451848] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[464642] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[428820] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[458502] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[443150] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[458503] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Quiekel-Frostwolf",
},
[421146] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Свечной Король",
},
[444687] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[1214801] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мехадрон картеля Мрачных Минеров",
},
[440082] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[468741] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
},
[201427] = {
["school"] = 126,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[270183] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[1216858] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ксал'атат",
},
[293724] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Генератор защитного поля",
},
[431897] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Томимый жаждой посетитель",
},
[260279] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[320336] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленный маг",
},
[201428] = {
["school"] = 127,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[440087] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[260280] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф Разданк",
},
[439576] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438041] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[280934] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[439577] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[445207] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Подчиненный Бездной завыватель",
},
[466189] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Гизл Гигабжик",
},
[444696] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[455443] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскун",
},
[441626] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[426786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[437533] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[185311] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[426787] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'иккадж",
},
[447258] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Святое оружие",
},
[256957] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Заклинатель моря из братства Стальных Волн",
},
[455447] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Уэйн",
},
[433443] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[440608] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[447261] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Генерал Умбрисс",
},
[331606] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Подавляющее знамя",
},
[442656] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Брызгающее кровотечение",
},
[275826] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[444704] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[426793] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[317791] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародей из войска мертвых",
},
[422700] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[426283] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый завоеватель",
},
[330586] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Гнилостный мясник",
},
[451871] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный заклинатель земли",
},
[458524] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[442660] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[458525] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[447268] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Генерал Умбрисс",
},
[440104] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хмельной выброс",
},
[324449] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[321891] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[451364] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный громила",
},
[275835] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Захватчик дома Эшвейнов",
},
[440107] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[321893] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[447272] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[275836] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Захватчик дома Эшвейнов",
},
[454437] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[321894] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налтор Криомант",
},
[320359] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[427315] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Разлом Бездны",
},
[464673] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[256709] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер клинков прилива",
},
[450345] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[434481] = {
["school"] = 12,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[450346] = {
["school"] = 72,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[439600] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Осколок кристалла",
},
[448300] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[320365] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[192231] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[320366] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[423228] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[393035] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[427323] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Странник Бездны",
},
[224729] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[427325] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[451378] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный надзиратель",
},
[1217011] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[427329] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[446776] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Боевая рысь",
},
[428866] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[427331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[426308] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый завоеватель",
},
[336752] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призывательница Туманов",
},
[260811] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Шеф Разданк",
},
[472878] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Торфоморд",
},
[455479] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Взять",
},
[455480] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Взять",
},
[433475] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сикран",
},
[259277] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Nether Ray",
},
[444735] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Blastimus-Ragnaros",
},
[432965] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[324986] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманный хищник",
},
[460600] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[444736] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[324987] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Туманный хищник",
},
[426826] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[460602] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Киза Скоропышец",
},
[443203] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[439621] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[432969] = {
["school"] = 106,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[423246] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[427852] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[438599] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Летун-пронзатель",
},
[30451] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Blastimus-Ragnaros",
},
[393054] = {
["school"] = 127,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[443718] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[427854] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[442695] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[428879] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Камнекрушитель",
},
[440138] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[440650] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[455491] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречная гончая",
},
[435533] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глибб",
},
[445257] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[427346] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Благочестивый жрец",
},
[1227316] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Blastimus-Ragnaros",
},
[463169] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Геодезист Торговой компании",
},
[443723] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[440141] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[326021] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Иглобрюх-поглотитель",
},
[160772] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Житель Мерельдара",
},
[326022] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Иглобрюх-поглотитель",
},
[420696] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Свечной Король",
},
[443726] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[462661] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Посланница Бездны",
},
[422233] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[445262] = {
["school"] = 127,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[437586] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[428887] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Камнекрушитель",
},
[283551] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Омега-крушитель\"",
},
[82850] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пробужденный дух пламени Тьмы",
},
[427865] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[454988] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[424795] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "ЗАЗУ",
},
[1215065] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "\"Платиновый лупцеватор\"",
},
[454989] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[437078] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вторящая тень",
},
[440149] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[451408] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[427356] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Благочестивый жрец",
},
[323471] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Изготовитель кадавров",
},
[454991] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Опутанная паутиной жертва",
},
[445268] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[437592] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[280485] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сжимающий ужас",
},
[451410] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[428894] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Отважный страж проклятой кузни",
},
[463182] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[1217138] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сатель Злосчастный",
},
[76711] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный обманщик",
},
[468813] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гизл Гигабжик",
},
[441179] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[458067] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[444250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
},
[422245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[439645] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[1215102] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Платиновый лупцеватор\"",
},
[438622] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Разъевшийся ползун",
},
[445275] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439646] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[319897] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[292264] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "\"Омега-крушитель\"",
},
[283565] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[260829] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Homing Missile Stalker",
},
[426345] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[292267] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "\"Омега-крушитель\"",
},
[452445] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Среброжил",
},
[319902] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[445281] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[325021] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Туманный хищник",
},
[426860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[435560] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[446819] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[1225377] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кул'тарок",
},
[334747] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сборщик трупов",
},
[441703] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[323489] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изготовитель кадавров",
},
[334748] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сборщик трупов",
},
[429422] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Заклинатель проклятой кузни",
},
[337819] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[334749] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сборщик трупов",
},
[321956] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[458082] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
},
[3110] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Bizbis",
},
[433519] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[464736] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[422261] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[431985] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый служитель",
},
[260323] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Шеф Разданк",
},
[424821] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скрипучая вагонетка (кобольды)",
},
[429427] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Заклинатель проклятой кузни",
},
[436592] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[429428] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Тотем земляного взрыва",
},
[323496] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изготовитель кадавров",
},
[440687] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Поставщик маточного молочка",
},
[427382] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай машины",
},
[462693] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[89766] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Страж Скверны",
},
[202497] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[440177] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[448877] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Генерал Умбрисс",
},
[268230] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Матрос корпорации Эшвейнов",
},
[1213140] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Надсмотрщик Аскари",
},
[1213141] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Надсмотрщик Аскари",
},
[437620] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[440179] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[463208] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманный страж",
},
[190984] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[260838] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[118297] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изначальный элементаль огня",
},
[108446] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Матуну",
},
[463210] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманный страж",
},
[448882] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Генерал Умбрисс",
},
[326574] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[427901] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[464748] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[455537] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[438139] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантом Пустоты",
},
[438651] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[333231] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сатель Злосчастный",
},
[452469] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Яркий Камень",
},
[448887] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[468846] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гизл Гигабжик",
},
[448888] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[441213] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[294853] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Главный машинист Искроточец",
},
[269266] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Крушащий ужас",
},
[437632] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[440191] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438656] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[438145] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[423305] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[440193] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[1217294] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Платный разгонятель толпы",
},
[323515] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кроворуб",
},
[451965] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огненный великан",
},
[322493] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленный маг",
},
[427402] = {
["school"] = 9,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проклятый страж птенцов",
},
[432520] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[333241] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Яростный кроворог",
},
[294860] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Непримечательное растение",
},
[426892] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Убегающий свеченосец",
},
[427404] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[441222] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
},
[439687] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[457599] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Желчное порождение",
},
[460158] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Большая МАМА",
},
[438153] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантом Пустоты",
},
[444806] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[451459] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[451971] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огненный великан",
},
[426896] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Убегающий свеченосец",
},
[454019] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[3606] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Опаляющий тотем",
},
[443273] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[446344] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[434574] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кровавое чудовище",
},
[443274] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[439692] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[442251] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[389541] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Статуя белого тигра",
},
[341949] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[434576] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[317898] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Возрожденный воин",
},
[464259] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[153640] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[463236] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманная защитница",
},
[330693] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Отвратительные отходы",
},
[439696] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[268260] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[434579] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[330694] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Отвратительные отходы",
},
[439697] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[446351] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[438675] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Разъевшийся ползун",
},
[462216] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[330697] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зараженный ужас",
},
[423324] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[438677] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[285153] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[462219] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[438679] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[330700] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зараженный ужас",
},
[462220] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[423839] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[449939] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эрудакс",
},
[442263] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровавый паразит",
},
[449940] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[438682] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[330703] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумной изрыгатель слизи",
},
[440218] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[463247] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Туманная защитница",
},
[157228] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[404908] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Назгрим",
},
[432031] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Черная кровь",
},
[463248] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманная защитница",
},
[444826] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Король Торас Троллебой",
},
[31224] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[323542] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сочащиеся ошметки",
},
[143924] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Mudita-Draenor",
},
[100780] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дух огня",
},
[436640] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[213011] = {
["school"] = 4,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[444829] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[439200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[327127] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изготовитель кадавров",
},
[434083] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Прожорливый ползун",
},
[341969] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумной изрыгатель слизи",
},
[328664] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оживленный маг",
},
[451996] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[450461] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[436644] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голди Барондон",
},
[463256] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманная защитница",
},
[435622] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[471445] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изгонятель из зала",
},
[328667] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оживленный маг",
},
[322527] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[339415] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ксав Несломленный",
},
[444324] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[272888] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Разрушитель из дома Эшвейнов",
},
[447395] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[438696] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[424879] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[449444] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[427439] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[341977] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Зараженный ужас",
},
[450980] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нитемот Таказдж",
},
[429487] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[434093] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[443305] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[425394] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[448935] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Неосторожный хмелегоблин",
},
[283640] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[384455] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[449448] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[441772] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[434096] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[449449] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[452008] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[442285] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сгустолиция",
},
[455080] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[429493] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[55078] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[442799] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый потоп",
},
[424888] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[438706] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[424889] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[474018] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[321005] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[438708] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[423356] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[257288] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Рассекатель из братства Стальных Волн",
},
[324589] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник смерти",
},
[260103] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[440246] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[324079] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[447411] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[441782] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[438200] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[445877] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[450483] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[426943] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[327664] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[442808] = {
["school"] = 124,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[283143] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Магнитохват",
},
[322548] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[445880] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[268815] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Подопытная крыса",
},
[451510] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[75328] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Валиона",
},
[257292] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Рассекатель из братства Стальных Волн",
},
[322550] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тред'ова",
},
[441788] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[448953] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Генерал Умбрисс",
},
[435136] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434113] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Паутинные нити",
},
[334322] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[443325] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[427461] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
},
[473519] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кул'тарок",
},
[435138] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[441791] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[457144] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[1215504] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Большая МАМА",
},
[455099] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Преданный служитель",
},
[437700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[462776] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Геодезист Торговой компании",
},
[322557] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Друст-душеруб",
},
[443842] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434119] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[439749] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[449985] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[449474] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[449986] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[291856] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Плазменная сфера",
},
[275992] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рикса Огневерт",
},
[443847] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[450500] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародейский феникс",
},
[443336] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[294929] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "КУ-ДЖ0",
},
[1217589] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Споровик",
},
[429521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[457668] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[271903] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Платный разгонятель толпы",
},
[444363] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[451016] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[455622] = {
["school"] = 5,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пульсирующий тотем",
},
[448458] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Преданный служитель",
},
[471999] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Медведь",
},
[260372] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огнелетчица Торговой компании",
},
[443342] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[443854] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[272418] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Наводчик корпорации Эшвейнов",
},
[432596] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мать Хаоса",
},
[31707] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Water Elemental",
},
[320012] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[435156] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[447950] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[447439] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[439763] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[272421] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Наводчик корпорации Эшвейнов",
},
[448975] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Отважный страж проклятой кузни",
},
[447440] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439764] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[272422] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Наводчик корпорации Эшвейнов",
},
[473540] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кул'тарок",
},
[343556] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[448977] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Неосторожный хмелегоблин",
},
[320839] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Похитительница с \"Золрамуса\"",
},
[424322] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пылающий монстр",
},
[428508] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[447443] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[343558] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хирург Трупошов",
},
[453345] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призванная тень",
},
[451026] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[321041] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Отвратительные отходы",
},
[445909] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровожадный роевик",
},
[421277] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[453856] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Житель Мерельдара",
},
[424212] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[423393] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[442688] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[432605] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[441305] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[440147] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "И'па",
},
[421817] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пламекон",
},
[421665] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Старый Воскобород",
},
[446690] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ненасытный червь",
},
[443694] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[1217653] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Киза Скоропышец",
},
[424419] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[203796] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[1223797] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[148187] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дух земли",
},
[424420] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[428266] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тьма",
},
[444713] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[422246] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Старый Воскобород",
},
[451032] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[1223804] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кул'тарок",
},
[452056] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сурекийская оружейная стойка",
},
[142421] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Древень",
},
[451033] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный головорез",
},
[429028] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пробудившийся Бездны",
},
[469796] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Геодезист Торговой компании",
},
[323608] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[434407] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[429029] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пробудившийся Бездны",
},
[439776] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[468841] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гизл Гигабжик",
},
[321507] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[390137] = {
["school"] = 127,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[447965] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[333845] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Харугия Кровожадная",
},
[428519] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Дорлита",
},
[383997] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[447966] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[455387] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[428520] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[443361] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[447967] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[294954] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[466197] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гизл Гигабжик",
},
[441315] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Взбешенный прыгун",
},
[439780] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438245] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[1236110] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[1216943] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[439781] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[439010] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Извивающееся порождение Тьмы",
},
[451040] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный головорез",
},
[443364] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[422122] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Старый Воскобород",
},
[436200] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[473351] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Большая МАМА",
},
[427357] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Благочестивый жрец",
},
[420659] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[270187] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вик'Гот",
},
[424431] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[453601] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[458207] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кровавый паразит",
},
[434155] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[424432] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[390145] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[439785] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[436203] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[434668] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Аратийская бомба",
},
[460156] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Большая МАМА",
},
[439786] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[294961] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "КУ-ДЖ0",
},
[1214780] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мехадрон картеля Мрачных Минеров",
},
[330784] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Боевой ритуалист",
},
[439787] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[473051] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[472454] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мехадрон картеля Мрачных Минеров",
},
[469981] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Большая МАМА",
},
[390155] = {
["school"] = 126,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[448488] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[227518] = {
["school"] = 127,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[273470] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[458212] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Огромный паук",
},
[428019] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Королевский зажигатель",
},
[268865] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Испытатель экспериментального оружия",
},
[275014] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вик'Гот",
},
[281388] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[321576] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хрупкий воин",
},
[438495] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[441326] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[271784] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Футбомбный хулиган",
},
[439518] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[1236111] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[453609] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439792] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[438494] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[422393] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Снующая тьма",
},
[445422] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[442257] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кровавый паразит",
},
[432117] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[428535] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[441224] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[443888] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[257063] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Заклинатель моря из братства Стальных Волн",
},
[326629] = {
["school"] = 40,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[459753] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Фенрир",
},
[447983] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[432119] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ки'катал Жница",
},
[437733] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[427002] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[294863] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Непримечательное растение",
},
[193315] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[438773] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[474084] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кул'тарок",
},
[433656] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Укрепленный трутень",
},
[422628] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Коридорный ужас",
},
[469479] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Торфоморд",
},
[427011] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[456174] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[440310] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[469480] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Торфоморд",
},
[453616] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж ужаса",
},
[445409] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[436217] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[320050] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ксав Несломленный",
},
[474087] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кул'тарок",
},
[468815] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Гизл Гигабжик",
},
[460782] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[430589] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[427007] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[316981] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ксав Несломленный",
},
[440313] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ксал'атат",
},
[442624] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[422382] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Древень",
},
[276042] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Морской приливный ловец",
},
[460781] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тикающая часовая бомба",
},
[118459] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Темная гончая",
},
[453909] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[460789] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[332670] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[1213142] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Земляной яростень",
},
[269100] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Боевая машина Торговой компании",
},
[275907] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Азерокк",
},
[1215738] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пакиран Заразный",
},
[268880] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гений Торговой компании",
},
[322614] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тред'ова",
},
[1215741] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Дессия Обезглавливательница",
},
[448505] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Преданный служитель",
},
[428547] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[445435] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
},
[325174] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем духовной связи",
},
[432130] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[1215747] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сатель Злосчастный",
},
[424966] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[450042] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Прожорливый скарабей",
},
[391191] = {
["school"] = 124,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[51690] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[436624] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голди Барондон",
},
[1215194] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Платиновый лупцеватор\"",
},
[456696] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный громила",
},
[257326] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[427015] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тьма",
},
[443903] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[164815] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[256493] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Азеритовая футбомба",
},
[291914] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[450045] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[76369] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный обманщик",
},
[1215103] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "\"Платиновый лупцеватор\"",
},
[439299] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Королева Ансурек",
},
[447999] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[441867] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[459779] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бронт",
},
[453599] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[450047] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Прожорливый скарабей",
},
[444418] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[323138] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ингра Малох",
},
[449536] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[443907] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[272471] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[268712] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Бесшабашная подрывница",
},
[443396] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439814] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[448920] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Неосторожный хмелегоблин",
},
[434697] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[257585] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[316995] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ксав Несломленный",
},
[462844] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем каменной преграды",
},
[434089] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[263262] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сланцеед",
},
[323137] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Дроман Ульфарран",
},
[460798] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[463357] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[192082] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем ветряного порыва",
},
[452099] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ожившая тень",
},
[473081] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Торфоморд",
},
[438794] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[320580] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[441865] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[441556] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[320069] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Дессия Обезглавливательница",
},
[427025] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тьма",
},
[291613] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Воздушное судно R-21/X",
},
[448013] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[436749] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[461825] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[7268] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[430097] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[393763] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[443403] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[394195] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[421910] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[435012] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[271456] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Шеф Разданк",
},
[458245] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Thejumpensid-Rexxar",
},
[461513] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[434705] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[443405] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[421638] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[441214] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дегустатор",
},
[340544] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иглобрюх-рогач",
},
[459782] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Космический симулякр",
},
[441289] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[390181] = {
["school"] = 124,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[438801] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[291918] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Летающий кран",
},
[271971] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зловещий охотник",
},
[444431] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[459785] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[291930] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Куб металлолома",
},
[440178] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[323107] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сочащиеся ошметки",
},
[459273] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Космический симулякр",
},
[267367] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Механомиротворец",
},
[57841] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[437721] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[438804] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[445457] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[323149] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ингра Малох",
},
[419870] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[439825] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[470022] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Бронт",
},
[439829] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[419871] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[292332] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Главный машинист Искроточец",
},
[451600] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изгонятель из зала",
},
[430109] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый рокотун",
},
[456718] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мутировавший детеныш",
},
[438807] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Огромный паук",
},
[257593] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Азерокк",
},
[135029] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Wasserelementar",
},
[456719] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мутировавший детеныш",
},
[1215039] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[263725] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[443598] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[460814] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тикающая часовая бомба",
},
[436762] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[441368] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[437786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[326046] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Иглобрюх-рогач",
},
[257544] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Земляной яростень",
},
[320596] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[451098] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Суреки-ополченец",
},
[291928] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Воздушное судно R-21/X",
},
[453140] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[451605] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[57842] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[436637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[453141] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[451606] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[181089] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чудище камня Бездны",
},
[456902] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[322655] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[461842] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[282945] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Свисторез",
},
[436255] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[283534] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Магнитохват",
},
[429091] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Верховная жрица Эмия",
},
[439838] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[460092] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Иглобрюх-рогач",
},
[1966] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[322648] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[441171] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[439586] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[434722] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[429093] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Вагонетка со взрывчаткой",
},
[448028] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[424737] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[434723] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[459799] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бронт",
},
[456900] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[439324] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[269429] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Боевая машина Торговой компании",
},
[291946] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "КУ-ДЖ0",
},
[450077] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[1222949] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кул'тарок",
},
[333292] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сатель Злосчастный",
},
[1223803] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кул'тарок",
},
[435405] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[259474] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Рикса Огневерт",
},
[326092] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Иглобрюх-разоритель",
},
[441379] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[450079] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[394976] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плеточник Бездны",
},
[293683] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Защитник мастерской",
},
[439333] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Изголодавшийся ползун",
},
[460315] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[326090] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иглобрюх-разоритель",
},
[473114] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Торфоморд",
},
[441381] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[323683] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[431309] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сумеречный маг тени",
},
[438823] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дьявольский бес",
},
[441382] = {
["school"] = 16,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пустотелый ледопряд",
},
[423766] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Начинающий подмастерье",
},
[464923] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[438473] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[443430] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Суреки – повелитель шелка",
},
[431660] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный странник теней",
},
[323681] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[444966] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[441384] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[458272] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Космический симулякр",
},
[438623] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Разъевшийся ползун",
},
[471578] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[211545] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[443437] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Глашатай Ансурек",
},
[444456] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[257862] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[443433] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Ансурек",
},
[1215850] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Докигг Изверг",
},
[1490] = {
["school"] = 125,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[471580] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[320614] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[258883] = {
["school"] = 124,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[439202] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "И'па",
},
[440876] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Поставщик маточного молочка",
},
[439341] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[450088] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[321952] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Жительница Тирна Скитта",
},
[451114] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленная тьма",
},
[443436] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Ансурек",
},
[458277] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[473126] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Торфоморд",
},
[453160] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Громадный кровостраж",
},
[1213893] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф Разданк",
},
[423479] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королевский зажигатель",
},
[432179] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[453161] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Громадный кровостраж",
},
[429109] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Кованая целительница",
},
[462373] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ловчий из люка",
},
[428086] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[471585] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Большая МАМА",
},
[429110] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ремонтница проклятой кузни",
},
[343648] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[460839] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[436787] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[448046] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[325226] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Туманный острожал",
},
[432182] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[449070] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[449217] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Quiekel-Frostwolf",
},
[457674] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Blastimus-Ragnaros",
},
[450100] = {
["school"] = 33,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эрудакс",
},
[440168] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[441395] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгустолиция",
},
[450095] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[448560] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[453310] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[257168] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый клинок из братства Стальных Волн",
},
[285150] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[448561] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[427869] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[441397] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пчелка",
},
[382551] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Thejumpensid-Rexxar",
},
[448562] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[444609] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[472755] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Киза Скоропышец",
},
[445632] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[456751] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Валиона",
},
[320114] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксав Несломленный",
},
[285454] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Главный машинист Искроточец",
},
[268362] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бесшабашная подрывница",
},
[320630] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[270481] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Демонический тиран",
},
[194153] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[439865] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[440377] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[431896] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Томимый жаждой посетитель",
},
[291939] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[450101] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[448566] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный дракон",
},
[455219] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[291973] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "КУ-ДЖ0",
},
[450102] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[456245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
},
[455220] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[291972] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "КУ-ДЖ0",
},
[435152] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[394061] = {
["school"] = 72,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[438845] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[320631] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[448057] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[442428] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[114893] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем каменной преграды",
},
[291974] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Король Мехагон",
},
[270484] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вик'Гот",
},
[272528] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Снайпер дома Эшвейнов",
},
[436800] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[461876] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[446012] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[448515] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[326263] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[322681] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[433731] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[432196] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[336499] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Призывательница Туманов",
},
[442250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый паразит",
},
[434655] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[442432] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[77489] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Plebskillz-Kazzak",
},
[465463] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гизл Гигабжик",
},
[59638] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Зеркальное изображение",
},
[432198] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[465462] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Гизл Гигабжик",
},
[445504] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[443969] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[1215600] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сатель Злосчастный",
},
[440899] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[441314] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Взбешенный прыгун",
},
[339573] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[435788] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[440900] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[439365] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "И'па",
},
[257868] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[438974] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[296331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[445507] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Король Торас Троллебой",
},
[464442] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[442437] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[325224] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Туманный острожал",
},
[445508] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Назгрим",
},
[319290] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Зараженный ужас",
},
[268443] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Жуткая пушка",
},
[93402] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Mudita-Draenor",
},
[445509] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Назгрим",
},
[460867] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Киза Скоропышец",
},
[456170] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[440904] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[1223240] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кул'тарок",
},
[433740] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[434702] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[328146] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Червь-трупоед",
},
[320644] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксав Несломленный",
},
[263840] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Fenryr",
},
[439794] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[394050] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[318406] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кроворуб",
},
[425554] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[321669] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Иллюзорный клон",
},
[438860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[445513] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный инквизитор Вайтмейн",
},
[460354] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[272542] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Снайпер дома Эшвейнов",
},
[322563] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[455373] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[454214] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[456773] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Валиона",
},
[435148] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[322465] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тред'ова",
},
[437839] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[436923] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[463427] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глибб",
},
[279709] = {
["school"] = 72,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[435793] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Раша'нан",
},
[394111] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[268963] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[462692] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж зала",
},
[463428] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[428120] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[440504] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[425048] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бурестраж Горрен",
},
[443983] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Хищная золопчела",
},
[463217] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманный страж",
},
[326281] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[461895] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сфера вознесения",
},
[460360] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[438355] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[434773] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Посетитель из Торговой компании",
},
[90361] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Aradan",
},
[435797] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бомба Искроварни",
},
[444497] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[445123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[271526] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Земляной яростень",
},
[75238] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пробужденный дух пламени Тьмы",
},
[8921] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Mudita-Draenor",
},
[269484] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вик'Гот",
},
[320655] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумокост",
},
[439991] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[334476] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[434776] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[317792] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чародей из войска мертвых",
},
[460364] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[445016] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Потерянный дозорный",
},
[449106] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Неосторожный хмелегоблин",
},
[333634] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[436799] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[440407] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[445013] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призванный послушник",
},
[433622] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Бранн Бронзобород",
},
[436757] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[428126] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[434779] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[470090] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Киза Скоропышец",
},
[257882] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[323730] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[468647] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скачущая искра",
},
[1604] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[427616] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[285440] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Главный машинист Искроточец",
},
[318102] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ксав Несломленный",
},
[461904] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сфера вознесения",
},
[257883] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[201754] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Nah'qi",
},
[448176] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[322709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[459350] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[438218] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[442210] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[437342] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[436606] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[444507] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[451160] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[64695] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем хватки земли",
},
[260189] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф Разданк",
},
[439037] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голодное порождение",
},
[342242] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Quiekel-Frostwolf",
},
[423015] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[1236935] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Quiekel-Frostwolf",
},
[432227] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[449115] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Blastimus-Ragnaros",
},
[86392] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[438618] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Разъевшийся ползун",
},
[464980] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[448006] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Перерожденный говорящий с Бездной",
},
[461910] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сфера вознесения",
},
[433766] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[432229] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[423327] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[269493] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Платный разгонятель толпы",
},
[445174] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Забытый глашатай",
},
[52212] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[453212] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[201633] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем земляной стены",
},
[435813] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[260190] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф Разданк",
},
[461401] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Космический симулякр",
},
[445537] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[320637] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[282801] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Платиновый лупцеватор\"",
},
[198013] = {
["school"] = 124,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[334488] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[30213] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Скверны",
},
[440421] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[455084] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Опутанная паутиной жертва",
},
[453173] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[441958] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[423536] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[426605] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[427361] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Начинающий подмастерье",
},
[427629] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный снайпер",
},
[157331] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Большой элементаль бури",
},
[447076] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[445541] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Брокк",
},
[256866] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мастер клинков прилива",
},
[451607] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[324391] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Костяное чудовище",
},
[439401] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[322967] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Друст - злобный коготь",
},
[434284] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[1216178] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[439811] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[423538] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[450661] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[473690] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Киза Скоропышец",
},
[438957] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[320171] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[473694] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[447532] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[439852] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[424564] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[448105] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Валиона",
},
[442987] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[320679] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Непреклонный соперник",
},
[462434] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Смертельный кошмар",
},
[427894] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер кузни Дамиан",
},
[451176] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[424739] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[427583] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[443427] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Суреки – повелитель шелка",
},
[463459] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[432132] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[259940] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рикса Огневерт",
},
[448619] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Неосторожный хмелегоблин",
},
[320170] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[324776] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Туманный культиватор",
},
[1216431] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[463461] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[434803] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[463464] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[427635] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Боевая рысь",
},
[447141] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Переделанный бот-погрузчик",
},
[434710] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[443504] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "[DNT] Beehive Trash Stalker",
},
[433781] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[447456] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[453214] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[1216212] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[423547] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[436950] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[442994] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[256616] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кишкодер из банды Резчиков",
},
[197509] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Кровавый червь",
},
[262347] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Платный разгонятель толпы",
},
[442995] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Сборщица меда из Торговой компании",
},
[445936] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скованный кровью ужас",
},
[458340] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[442484] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[285377] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[325223] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Туманный острожал",
},
[429099] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оживший пехотинец",
},
[328756] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ингра Малох",
},
[460351] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ануб'араш",
},
[257641] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Фузилер из братства Стальных Волн",
},
[427180] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тьма",
},
[115804] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Devilsaur",
},
[326319] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Друст-жнец",
},
[460393] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мехадрон картеля Мрачных Минеров",
},
[276068] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[458357] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[473704] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[30153] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Страж Скверны",
},
[333485] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Тошногнил",
},
[439419] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[320180] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пакиран Заразный",
},
[437371] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фантом Пустоты",
},
[260202] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Шеф Разданк",
},
[429545] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Обращенный глашатай",
},
[434589] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Архидемон",
},
[292035] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "КУ-ДЖ0",
},
[331440] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[428161] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Брокк",
},
[320182] = {
["school"] = 40,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пакиран Заразный",
},
[443003] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[333488] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[276229] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "\"БУМБОТ\"",
},
[98021] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Тотем духовной связи",
},
[188046] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Обитатель Сна",
},
[333489] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[451099] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Суреки-ополченец",
},
[439778] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[320696] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сшитый боец авангарда",
},
[224125] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[473713] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Киза Скоропышец",
},
[445052] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[438749] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарабей-панцирекол",
},
[1218308] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[427176] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Извивающееся порождение Тьмы",
},
[224126] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[465012] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Громадный кровостраж",
},
[333492] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[442495] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[441295] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[315585] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[445570] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[322654] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[436867] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[424958] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[224127] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[444702] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[274991] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[423051] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[324387] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Костяное чудовище",
},
[321725] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Иллюзорный клон",
},
[450055] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Прожорливый скарабей",
},
[455831] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Укрепленная сеть",
},
[444034] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[448640] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Отважный страж проклятой кузни",
},
[428682] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[320703] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сшитый боец авангарда",
},
[461460] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гигантская свеча",
},
[454782] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[443954] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[449734] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[439795] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[430013] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[198030] = {
["school"] = 124,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[270042] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рикса Огневерт",
},
[210824] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[458388] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[473719] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Киза Скоропышец",
},
[334321] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хирург Трупошов",
},
[448847] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Генерал Умбрисс",
},
[272662] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[271579] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Геомант Торговой компании",
},
[257650] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[267997] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сумеречная гончая",
},
[449687] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[5143] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[3600] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем оков земли",
},
[468604] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Гизл Гигабжик",
},
[1224494] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Перегруженный пилон",
},
[434829] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[435341] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[424903] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "ЗАЗУ",
},
[123996] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сюэнь",
},
[423200] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скарморак",
},
[1214326] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[423572] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[442507] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[424913] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
},
[444411] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[426145] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Свечной Король",
},
[443494] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Осколок кристалла",
},
[434832] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[431250] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[459210] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[431303] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный маг тени",
},
[453773] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Верховный лорд Дарион Могрейн",
},
[427157] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тьма",
},
[1220419] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Blastimus-Ragnaros",
},
[473220] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Большая МАМА",
},
[451278] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[455816] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[321226] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[424148] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[448660] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[274002] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[449169] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[456841] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[269029] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[425113] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[321006] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[262377] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ползучая мина",
},
[438931] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бочка с медом",
},
[320717] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[452237] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скованный кровью ужас",
},
[1214315] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[449167] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Дорлита",
},
[466055] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нитемот Таказдж",
},
[450191] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[440468] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[444546] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[463257] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Туманная защитница",
},
[383061] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[443081] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[320208] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Создание Трупошва",
},
[462859] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный снайпер",
},
[468616] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скачущая искра",
},
[473224] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Большая МАМА",
},
[48518] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[454438] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[448147] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Страж зала",
},
[447240] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[423121] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[426136] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[425011] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Вечный огонь",
},
[262383] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Боевая машина Торговой компании",
},
[443031] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скованный кровью ужас",
},
[458375] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[320200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[423062] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[428703] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Камнекрушитель",
},
[76151] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный обманщик",
},
[433821] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Крылатый переносчик",
},
[1214323] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[1214324] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кириосс",
},
[1214325] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[452245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[446086] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Суреки-неестественник",
},
[446794] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[423076] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[423588] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[454439] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Командир из корпорации Эшвейнов",
},
[429999] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[441298] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[341709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призывательница Туманов",
},
[456853] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[451224] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чернокнижник Сумеречного Молота",
},
[457877] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[425556] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[442525] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[44425] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[320729] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксав Несломленный",
},
[320376] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[442526] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[428709] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Камнекрушитель",
},
[392375] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[415404] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кругогриб",
},
[321754] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[441452] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[268752] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[322569] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Друст-душеруб",
},
[321755] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[428711] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[256639] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Метатель черной смолы",
},
[415406] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кругогриб",
},
[455287] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зараженное порождение",
},
[438947] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[444694] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[441425] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[442530] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[443042] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[256640] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Метатель черной смолы",
},
[276212] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Шеф Разданк",
},
[428202] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[438949] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[320358] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[321247] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[323250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Дроман Ульфарран",
},
[439789] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[449697] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Стражник королевы Ге'за",
},
[438343] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[445915] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призванный послушник",
},
[439817] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[457465] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[424421] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[465051] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ксал'атат",
},
[435403] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сикран",
},
[437417] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[336759] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[342232] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[322274] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Похитительница с \"Золрамуса\"",
},
[473576] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кул'тарок",
},
[437093] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[426160] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[434860] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[439408] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[439686] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вторящая тень",
},
[465717] = {
["school"] = 28,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Предок",
},
[193473] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Щупальце Бездны",
},
[449702] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[321253] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
},
[270590] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Крушащий ужас",
},
[438956] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[322450] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[442277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[447175] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[1216443] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[392388] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[1226680] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Воздушное судно R-21/X",
},
[1216446] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[447146] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[439784] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[454311] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[428212] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[451241] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[455847] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[444414] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чумной роевик",
},
[460965] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бронт",
},
[438960] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[461989] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[321258] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
},
[446349] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[440413] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[445021] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призванный послушник",
},
[424414] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[322576] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Друст-душеруб",
},
[461487] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[322795] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кроворуб",
},
[433845] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кровавый надсмотрщик",
},
[321772] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[451324] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[453458] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Яростный снайпер",
},
[269456] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вик'Гот",
},
[437343] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[213405] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[464876] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай машины",
},
[458411] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[426171] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[1216475] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кул'тарок",
},
[461994] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тикающая часовая бомба",
},
[454318] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[434786] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Окровавленный маг паутины",
},
[438966] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[444502] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[454319] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[444833] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[443061] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[450129] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нитемот Таказдж",
},
[462508] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Посланница Бездны",
},
[452127] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'иккадж",
},
[285443] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[425052] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[439992] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[323825] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Затягивающий разлом",
},
[443063] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'араш",
},
[439481] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[462510] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Посланница Бездны",
},
[431637] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный странник теней",
},
[428735] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[445623] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[276234] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "\"БУМБОТ\"",
},
[269984] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[438971] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хищная золопчела",
},
[257270] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мастер клинков прилива",
},
[435789] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[331618] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ксав Несломленный",
},
[428737] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[436934] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[326018] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Личинка иглобрюха",
},
[443906] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[342135] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Нектара Изувер",
},
[423109] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[427001] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[324424] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мордрета, Вечная императрица",
},
[443068] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'араш",
},
[474285] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Quiekel-Frostwolf",
},
[432967] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Оленепанцирник-дозорный",
},
[448064] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[438975] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хищная золопчела",
},
[225119] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[461880] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[456762] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[438976] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королева Ансурек",
},
[273681] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[444094] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[441362] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исказитель яиц Ови'накс",
},
[431493] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный проклятый клинок",
},
[320763] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем прилива маны",
},
[331510] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Непреклонный соперник",
},
[447270] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[424805] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[323177] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[1215636] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пакиран Заразный",
},
[444608] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[451261] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный заклинатель земли",
},
[324859] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Туманный острожал",
},
[437956] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[456891] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Укротитель пчел",
},
[426736] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[323110] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сочащиеся ошметки",
},
[440134] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бенк Жужжикс",
},
[52042] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[461498] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[427378] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[333242] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Яростный кроворог",
},
[452806] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[447170] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[455870] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Желчное порождение",
},
[339550] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
},
[438471] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[462372] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[435401] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[78674] = {
["school"] = 72,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[454848] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[443435] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Глашатай Ансурек",
},
[258627] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Земляной яростень",
},
[450087] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Щупальце Бездны",
},
[257170] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налетчик из братства Стальных Волн",
},
[450419] = {
["school"] = 72,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[320771] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[339706] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эхо наездника на быке",
},
[440521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[291922] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "КУ-ДЖ0",
},
[320772] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[211881] = {
["school"] = 124,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[470039] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Торфоморд",
},
[455363] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нитемот Таказдж",
},
[474298] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кул'тарок",
},
[470038] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Торфоморд",
},
[438476] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[443434] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Ансурек",
},
[81281] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[394108] = {
["school"] = 72,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[428242] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[423682] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[441242] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Дегустатор",
},
[258622] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Азерокк",
},
[270624] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сжимающий ужас",
},
[461507] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[439502] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Улгракс Пожиратель",
},
[257597] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Азерокк",
},
[442573] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[393957] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Mudita-Draenor",
},
[257596] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Азерокк",
},
[1217821] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сторожевой бот модели \"ПЕС\"",
},
[439325] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "И'па",
},
[445180] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[435410] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сикран",
},
[447419] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Предок",
},
[438481] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Королева Ансурек",
},
[283421] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[257069] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Метатель черной смолы",
},
[452299] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скованный кровью ужас",
},
[391215] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[283422] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[439506] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[433877] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[291878] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Воздушное судно R-21/X",
},
[451277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'араш",
},
[469478] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Торфоморд",
},
[441872] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королевские оковы",
},
[291874] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Летающий кран",
},
[443090] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[294855] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Непримечательное растение",
},
[260813] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Шеф Разданк",
},
[5277] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Brisè-Frostwolf",
},
[451279] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сурекийская оружейная стойка",
},
[435415] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[432565] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призванная тень",
},
[443401] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Суреки-ядошип",
},
[443092] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[320784] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[1215787] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кул'тарок",
},
[323146] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[443397] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Суреки-ядошип",
},
[1220706] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[285152] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "\"Гномогедд-0Н\"",
},
[473287] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Большая МАМА",
},
[269099] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Боевая машина Торговой компании",
},
[291915] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[1217286] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
},
[257582] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Земляной яростень",
},
[449236] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Едкий быстролап",
},
[472452] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мехадрон картеля Мрачных Минеров",
},
[448213] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[327952] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[473070] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Торфоморд",
},
[320788] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[323347] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хранитель врат с \"Золрамуса\"",
},
[443763] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[383783] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[320789] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ксав Несломленный",
},
[448215] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[153626] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[324372] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Костяное чудовище",
},
[437469] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Принцесса Нексуса Ки'веза",
},
[471894] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Азерокк",
},
[91776] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший вурдалак",
},
[466190] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гизл Гигабжик",
},
[453846] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Plebskillz-Kazzak",
},
[444123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[432353] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сикран",
},
[451288] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Потерянный дозорный",
},
[443612] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[473836] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Большая МАМА",
},
[448730] = {
["school"] = 6,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[449242] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Расхититель гробниц из племени Сухоусов",
},
[260318] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф Разданк",
},
[452313] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скованный кровью ужас",
},
[321575] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некромант с \"Золрамуса\"",
},
[291865] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Воздушное судно R-21/X",
},
[331288] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Хивин Ломатель",
},
[433067] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[473046] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Торфоморд",
},
[432868] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Громадный кровостраж",
},
[431333] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[466188] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Гизл Гигабжик",
},
[434404] = {
["school"] = 127,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Властитель преисподней",
},
[291626] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Воздушное судно R-21/X",
},
[439522] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[164812] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Mudita-Draenor",
},
[365362] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Tsunamí-Azshara",
},
[445152] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Королева Ансурек",
},
[462771] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Геодезист Торговой компании",
},
[323057] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[321821] = {
["school"] = 40,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Чумной мешок",
},
[440238] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[439524] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бенк Жужжикс",
},
[472338] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Геодезист Торговой компании",
},
[422125] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[324381] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Костяное чудовище",
},
[273718] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[1217055] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[434408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[185123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[210152] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[443835] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[393055] = {
["school"] = 127,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Albedo-Khaz'goroth",
},
[421282] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Свечной Король",
},
[273720] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[473436] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Танк-паук",
},
[428269] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгусток Бездны",
},
[426734] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[273721] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[424223] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пламекон",
},
},
["emotes"] = {
{
["boss"] = "Тред'ова",
},
{
["boss"] = "Призывательница Туманов",
},
{
["boss"] = "Ингра Малох",
},
},
}
