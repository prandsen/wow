
SavedInstancesDB = {
["QuestDB"] = {
["Daily"] = {
[54137] = -1,
[61075] = -1,
[60762] = -1,
[61079] = -1,
[60646] = -1,
[11924] = 84,
[61103] = -1,
[77165] = 2112,
[53701] = -1,
[51982] = -1,
[77303] = 2112,
[53939] = -1,
[54132] = -1,
[54134] = -1,
[58168] = -1,
[54138] = -1,
[61765] = -1,
[62214] = -1,
[53711] = -1,
[61088] = -1,
[60775] = -1,
[53885] = -1,
[63206] = -1,
[62234] = -1,
[54136] = -1,
[61104] = -1,
[58156] = -1,
[84222] = 2369,
[58151] = -1,
[84286] = 2292,
[58155] = -1,
[82080] = 84,
[53883] = -1,
[84680] = 2369,
[84432] = 2369,
[60622] = -1,
[58167] = -1,
[54135] = -1,
},
["Darkmoon"] = {
["expires"] = 1754863140,
[47767] = -1,
},
["AccountDaily"] = {
[40753] = -1,
[34774] = -1,
[56042] = -1,
[31752] = -1,
[86486] = 2369,
},
["Weekly"] = {
[66937] = -1,
[62452] = -1,
[72175] = -1,
[82491] = -1,
[59019] = -1,
[80671] = -1,
[52951] = -1,
[48911] = -1,
[89039] = 2339,
[72719] = -1,
[78915] = -1,
[60249] = -1,
[66364] = -1,
[76169] = -1,
[72720] = -1,
[75307] = -1,
[82493] = 2339,
[57008] = -1,
[66940] = -1,
[56050] = -1,
[70613] = -1,
[78821] = -1,
[75308] = -1,
[82494] = -1,
[76394] = -1,
[60250] = -1,
[81632] = -1,
[83229] = -1,
[79173] = -1,
[66941] = -1,
[70582] = -1,
[70614] = -1,
[72722] = -1,
[70199] = -1,
[82495] = -1,
[80004] = -1,
[66942] = -1,
[81793] = -1,
[83358] = 2339,
[70615] = -1,
[72723] = -1,
[70200] = -1,
[82496] = -1,
[60251] = -1,
[57728] = -1,
[70935] = -1,
[66943] = -1,
[81794] = -1,
[83359] = -1,
[70616] = -1,
[72724] = -1,
[70201] = -1,
[70233] = -1,
["expires"] = 1754452799,
[66944] = -1,
[81795] = -1,
[83360] = 2339,
[70617] = -1,
[72725] = -1,
[70202] = -1,
[70234] = -1,
[56148] = -1,
[60252] = -1,
[84127] = -1,
[72438] = -1,
[66945] = -1,
[81796] = -1,
[56308] = -1,
[70618] = -1,
[82946] = 2214,
[55350] = -1,
[82499] = -1,
[82531] = -1,
[84128] = -1,
[72407] = -1,
[82659] = -1,
[82787] = -1,
[75665] = -1,
[70587] = -1,
[70619] = -1,
[72727] = -1,
[40787] = -1,
[82500] = -1,
[78444] = -1,
[60253] = -1,
[81574] = -1,
[87419] = -1,
[62441] = -1,
[70620] = -1,
[72728] = -1,
[82501] = -1,
[84130] = -1,
[66884] = -1,
[52956] = -1,
[70557] = -1,
[70589] = -1,
[82502] = -1,
[60254] = -1,
[84131] = -1,
[72410] = -1,
[66949] = -1,
[83333] = 2214,
[83365] = -1,
[72155] = -1,
[78319] = -1,
[82503] = -1,
[84132] = -1,
[53436] = -1,
[66950] = -1,
[70559] = -1,
[83366] = 2339,
[72156] = -1,
[75286] = -1,
[57157] = -1,
[60255] = -1,
[84133] = -1,
[66951] = -1,
[70560] = -1,
[70592] = -1,
[72157] = -1,
[52782] = -1,
[70752] = -1,
[83240] = 2328,
[87417] = -1,
[52958] = -1,
[70561] = -1,
[70593] = -1,
[72158] = -1,
[75288] = -1,
[82506] = -1,
[62284] = -1,
[60256] = -1,
[60244] = -1,
[66363] = -1,
[66953] = -1,
[70562] = -1,
[70594] = -1,
[72159] = -1,
[48912] = -1,
[75289] = -1,
[70211] = -1,
[70754] = -1,
[72423] = -1,
[66890] = -1,
[40168] = 111,
[70531] = -1,
[70563] = -1,
[89502] = -1,
[82510] = -1,
[79346] = -1,
[66891] = -1,
[70723] = -1,
[56648] = -1,
[62285] = -1,
[60257] = -1,
[52957] = -1,
[76600] = -1,
[75309] = -1,
[70532] = -1,
[70564] = -1,
[62445] = -1,
[33334] = -1,
[82509] = -1,
[60242] = -1,
[56650] = -1,
[55499] = -1,
[70533] = -1,
[70565] = -1,
[82414] = -1,
[78933] = -1,
[62286] = -1,
[80562] = -1,
[72427] = -1,
[47148] = -1,
[82511] = -1,
[56969] = -1,
[81649] = -1,
[79158] = -1,
[70567] = -1,
[82512] = -1,
[62287] = -1,
[70568] = -1,
[82449] = -1,
[82492] = -1,
[47523] = 111,
[82508] = -1,
[82852] = -1,
[70595] = -1,
[87424] = -1,
[70569] = -1,
[76733] = -1,
[66938] = -1,
[32640] = -1,
[82458] = -1,
[82482] = -1,
[70750] = -1,
[62288] = -1,
[82498] = -1,
[48910] = -1,
[84129] = -1,
[66952] = -1,
[82706] = 2339,
[66897] = -1,
[72726] = -1,
[82507] = -1,
[83345] = -1,
[82355] = -1,
[60243] = -1,
[64710] = 627,
[82483] = -1,
[78427] = -1,
[76122] = -1,
[70753] = -1,
[86731] = -1,
[82707] = -1,
[80184] = -1,
[40786] = -1,
[79226] = -1,
[70571] = -1,
[70235] = -1,
[75351] = -1,
[83532] = -1,
[82452] = 2339,
[45563] = 554,
[82516] = -1,
[60245] = -1,
[89223] = 1165,
[56649] = -1,
[78428] = -1,
[78656] = -1,
[82708] = -1,
[80185] = -1,
[83530] = -1,
[70540] = -1,
[70572] = -1,
[62449] = -1,
[33338] = -1,
[85487] = -1,
[64541] = -1,
[82485] = -1,
[82504] = -1,
[78972] = -1,
[62289] = -1,
[84776] = -1,
[59016] = -1,
[64522] = -1,
[82709] = -1,
[80186] = 2339,
[52948] = -1,
[87422] = -1,
[66517] = -1,
[53435] = -1,
[85488] = -1,
[66900] = -1,
[82486] = -1,
[91205] = 2339,
[60246] = -1,
[83347] = 2339,
[70530] = -1,
[82678] = 2367,
[82710] = -1,
[80187] = -1,
[83285] = 85,
[52944] = -1,
[62450] = -1,
[83531] = -1,
[80672] = -1,
[75301] = -1,
[82487] = -1,
[72810] = -1,
[87423] = -1,
[55498] = 622,
[59017] = -1,
[82679] = 2367,
[82711] = -1,
[80188] = -1,
[52949] = -1,
[82497] = 2339,
[89514] = -1,
[72172] = -1,
[40173] = -1,
[82488] = -1,
[55121] = -1,
[60247] = -1,
[82453] = -1,
[66516] = -1,
[72428] = -1,
[82505] = -1,
[82712] = -1,
[80189] = -1,
[66935] = -1,
[72686] = -1,
[83529] = -1,
[83364] = 2339,
[72173] = -1,
[32641] = -1,
[82778] = -1,
[82489] = -1,
[70586] = -1,
[79216] = -1,
[52954] = -1,
[59018] = -1,
[70591] = -1,
[81691] = -1,
[70203] = -1,
[52950] = -1,
[70545] = -1,
[52953] = -1,
[56064] = -1,
[52952] = -1,
[85947] = 85,
[75304] = -1,
[82490] = -1,
[60248] = -1,
[76997] = -1,
[70558] = -1,
[83363] = 2339,
[80670] = 2255,
[82746] = -1,
[83362] = 2339,
},
["AccountWeekly"] = {
[80592] = 2255,
[72721] = -1,
[83357] = -1,
[46292] = -1,
[58458] = -1,
[45539] = -1,
[77236] = -1,
[56492] = -1,
["expires"] = 1754452799,
[84370] = 2339,
[54186] = -1,
[72528] = -1,
},
},
["Progress"] = {
["Enable"] = {
["tww-free-chett-list"] = false,
["tww-anniversary-restored-coffer-key"] = false,
["tww-spreading-the-light"] = false,
["df-shipment-of-goods"] = false,
["df-fighting-is-its-own-reward"] = false,
["df-aiding-the-accord"] = false,
["the-world-awaits"] = false,
["timewalking"] = false,
["df-primal-storms-elementals"] = false,
["tww-biergoth-dungeon-quest"] = false,
["great-vault-raid"] = false,
["df-grand-hunt"] = false,
["tww-algari-treatise"] = false,
["df-blooming-dreamseeds"] = false,
["call-to-battle"] = false,
["df-a-worthy-ally-loamm-niffen"] = false,
["bfa-horrific-vision"] = false,
["tww-gearing-up-for-trouble"] = false,
["call-to-delves"] = false,
["tww-siren-isle-weekly"] = false,
["tww-the-theater-trope"] = false,
["tww-special-assignments"] = false,
["tww-pvp-world"] = false,
["tww-radiant-echoes"] = true,
["sl-patterns-within-patterns"] = false,
["df-trial-of-flood"] = false,
["tww-chett-list"] = false,
["tww-nightfall-scenario"] = false,
["df-time-rift"] = false,
["tww-nightfall-daily"] = false,
["tww-the-key-to-success"] = false,
["emissary-of-war"] = false,
["bfa-lesser-vision"] = false,
["df-siege-on-dragonbane-keep"] = false,
["tww-weekly-cache"] = false,
["df-a-worthy-ally-dream-wardens"] = false,
["tww-rollin-down-in-the-deeps"] = false,
["sl-replenish-the-reservoir"] = false,
["df-researchers-under-fire"] = false,
["tww-services-requested"] = false,
["tww-archives"] = false,
["tww-brawl-weekly"] = false,
["df-trial-of-elements"] = false,
["tww-delvers-bounty"] = false,
["df-the-superbloom"] = false,
["bfa-nzoth-assault"] = false,
["df-the-big-dig-traitors-rest"] = false,
["df-services-requested"] = false,
["df-community-feast"] = false,
["df-dreamsurge"] = false,
["great-vault-pvp"] = false,
["great-vault-world"] = false,
["df-disciple-of-fyrakk"] = false,
["df-secured-shipment"] = false,
["sl-return-lost-souls"] = false,
["tww-delves"] = false,
["bfa-island"] = false,
["tww-lesser-keyflame"] = false,
["sl-shaping-fate"] = false,
["df-primal-storms-core"] = false,
["tww-pvp-weekly"] = false,
["sl-covenant-assault"] = false,
["df-sparks-of-life"] = false,
["tww-the-call-of-the-worldsoul"] = false,
["The Severed Threads"] = false,
},
["Order"] = {
["tww-free-chett-list"] = 50,
["tww-anniversary-restored-coffer-key"] = 50,
["tww-spreading-the-light"] = 50,
["df-shipment-of-goods"] = 50,
["df-fighting-is-its-own-reward"] = 50,
["df-aiding-the-accord"] = 50,
["the-world-awaits"] = 50,
["timewalking"] = 50,
["df-primal-storms-elementals"] = 50,
["tww-biergoth-dungeon-quest"] = 50,
["great-vault-raid"] = 50,
["df-grand-hunt"] = 50,
["tww-algari-treatise"] = 50,
["df-blooming-dreamseeds"] = 50,
["call-to-battle"] = 50,
["df-a-worthy-ally-loamm-niffen"] = 50,
["bfa-horrific-vision"] = 50,
["tww-gearing-up-for-trouble"] = 50,
["call-to-delves"] = 50,
["tww-siren-isle-weekly"] = 50,
["tww-the-theater-trope"] = 50,
["tww-special-assignments"] = 50,
["tww-pvp-world"] = 50,
["tww-radiant-echoes"] = 50,
["sl-patterns-within-patterns"] = 50,
["df-trial-of-flood"] = 50,
["tww-chett-list"] = 50,
["tww-nightfall-scenario"] = 50,
["df-time-rift"] = 50,
["tww-nightfall-daily"] = 50,
["tww-the-key-to-success"] = 50,
["emissary-of-war"] = 50,
["bfa-lesser-vision"] = 50,
["df-siege-on-dragonbane-keep"] = 50,
["tww-weekly-cache"] = 50,
["df-a-worthy-ally-dream-wardens"] = 50,
["tww-rollin-down-in-the-deeps"] = 50,
["sl-replenish-the-reservoir"] = 50,
["df-researchers-under-fire"] = 50,
["tww-services-requested"] = 50,
["tww-archives"] = 50,
["tww-brawl-weekly"] = 50,
["df-trial-of-elements"] = 50,
["tww-delvers-bounty"] = 50,
["df-the-superbloom"] = 50,
["bfa-nzoth-assault"] = 50,
["df-the-big-dig-traitors-rest"] = 50,
["df-services-requested"] = 50,
["df-community-feast"] = 50,
["df-dreamsurge"] = 50,
["great-vault-pvp"] = 50,
["great-vault-world"] = 50,
["df-disciple-of-fyrakk"] = 50,
["df-secured-shipment"] = 50,
["sl-return-lost-souls"] = 50,
["tww-delves"] = 50,
["bfa-island"] = 50,
["tww-lesser-keyflame"] = 50,
["sl-shaping-fate"] = 50,
["df-primal-storms-core"] = 50,
["tww-pvp-weekly"] = 50,
["sl-covenant-assault"] = 50,
["df-sparks-of-life"] = 50,
["tww-the-call-of-the-worldsoul"] = 50,
["The Severed Threads"] = 50,
},
["User"] = {
},
},
["spelltip"] = {
[71041] = {
"Покинувший подземелье",
"Вы покинули подземелье. Должно пройти некоторое время, прежде чем вы снова сможете воспользоваться поиском подземелья или рейда.",
"Осталось: 29 |4минута:минуты:минут;",
},
},
["Instances"] = {
["Трон Четырех Ветров"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 318,
},
["Случайное подземелье, путеш. во времени (Battle for Azeroth)"] = {
["Expansion"] = 7,
["Прециза - Свежеватель Душ"] = {
},
["Спленда - Свежеватель Душ"] = {
},
["Виандисто - Свежеватель Душ"] = {
},
["LFDID"] = 2874,
["Random"] = true,
["RecLevel"] = 10,
["Сорчистино - Свежеватель Душ"] = {
{
["Locked"] = false,
["Expires"] = 1754366399,
["ID"] = -1,
},
},
["Топмэн - Свежеватель Душ"] = {
},
["Raid"] = false,
["Holiday"] = true,
["Show"] = "saved",
},
["Квартал Звезд"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2280,
},
["Малификус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1884,
["RecLevel"] = 45,
["Raid"] = true,
},
["Огненные Просторы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 362,
},
["Театр Боли"] = {
["Show"] = "saved",
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["LFDID"] = 2815,
},
["Депо Мрачных Путей"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2319,
},
["Ара-Кара, Город Отголосков"] = {
["LFDID"] = 2726,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Некрополь Призрачной Луны"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1976,
},
["Сотанатор"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2014,
["RecLevel"] = 45,
["Raid"] = true,
},
["Змеиное святилище"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 194,
},
["Стратхольм – черный ход"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 2641,
},
["Битва за Дазар'алор"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["LFDID"] = 1944,
},
["Базуал"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2517,
["RecLevel"] = 70,
["Raid"] = true,
},
["Т'зейн"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2139,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное героическое подземелье (2-й сезон The War Within)"] = {
["LFDID"] = 2807,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Крепость Черной Ладьи"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2275,
},
["Аркатрац"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1011,
},
["Город Нитей"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2722,
},
["Инквизитор Мето"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2012,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 462,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Вольная Гавань"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2875,
},
["Непроглядная Пучина"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 10,
},
["Случайное героическое подземелье (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2537,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Коварные Дуо"] = {
["Show"] = "saved",
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = false,
["LFDID"] = 2803,
},
["Тазавеш: гамбит Со'леи"] = {
["Show"] = "saved",
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["LFDID"] = 2330,
},
["Нексус"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1019,
},
["Испытание крестоносца"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 248,
},
["Твердыня Крыла Тьмы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 314,
},
["Случайное подземелье (Dragonflight)"] = {
["Show"] = "saved",
["Expansion"] = 9,
["LFDID"] = 2350,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Кузня Душ"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2322,
},
["Тайный рынок Тазавеш"] = {
["Show"] = "saved",
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["LFDID"] = 2225,
},
["Случайное подземелье (Mists of Pandaria, героич.)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2539,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Каламир"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1774,
["RecLevel"] = 45,
["Raid"] = true,
},
["Престол Гроз"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 634,
},
["Аметистовая крепость"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["LFDID"] = 221,
},
["Темный лабиринт"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["LFDID"] = 181,
},
["Операция \"Мехагон\" – свалка"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["LFDID"] = 2027,
},
["Натанос Гнилостень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 9005,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Lich King (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 262,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Анторус, Пылающий Трон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["LFDID"] = 1642,
},
["Апокрон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1956,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ботаника"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2325,
},
["Огненная Пропасть"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 4,
},
["Логово Магтеридона"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 176,
},
["Вечный дворец"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["LFDID"] = 2016,
},
["Ауростор"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2562,
["RecLevel"] = 70,
["Raid"] = true,
},
["Азжол-Неруб"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2324,
},
["Горнило Штормов"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["LFDID"] = 1954,
},
["Шуррай"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2636,
["RecLevel"] = 80,
["Raid"] = true,
},
["Забытый город - квартал Криводревов"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["LFDID"] = 34,
},
["Случайное подземелье Shadowlands (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2087,
["RecLevel"] = 60,
["Random"] = true,
["Raid"] = false,
},
["Рубиновые Омуты Жизни"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2436,
},
["Принц Сарсарун"] = {
["LFDID"] = 310,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Legion)"] = {
["LFDID"] = 2274,
["Expansion"] = 6,
["Show"] = "saved",
["Random"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Raid"] = false,
},
["Госпожа Аллюрадель"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2011,
["RecLevel"] = 45,
["Raid"] = true,
},
["Казематы Стражей"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2278,
},
["Штурм Аметистовой крепости"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1209,
},
["Око Азшары"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2276,
},
["Лисканот"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2518,
["RecLevel"] = 70,
["Raid"] = true,
},
["На'зак Одержимый"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1783,
["RecLevel"] = 45,
["Raid"] = true,
},
["Крепость Темного Клыка"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 327,
},
["Великий посол Огнехлыст"] = {
["LFDID"] = 308,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["Show"] = "saved",
},
["Островные экспедиции"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 1762,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Хмелеварня Буйных Портеров"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2543,
},
["Кузня Крови"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2326,
},
["Око Вечности"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 237,
},
["Случайный сценарий Mists of Pandaria (героич.)"] = {
["LFDID"] = 641,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Глубины Черной горы - Верхний город"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["LFDID"] = 276,
},
["Корен Худовар"] = {
["LFDID"] = 287,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Holiday"] = true,
["Show"] = "saved",
},
["Гномреган"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 14,
},
["Расселина Темного Пламени"] = {
["LFDID"] = 2809,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Собор Вечной Ночи"] = {
["Show"] = "saved",
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["LFDID"] = 1488,
},
["Операция: шлюз"] = {
["Show"] = "saved",
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 1,
["LFDID"] = 2812,
},
["Зул'Гуруб"] = {
["Show"] = "saved",
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["LFDID"] = 334,
},
["Лазурное хранилище"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2498,
},
["Храм Нефритовой Змеи"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2541,
},
["Ашран"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 40,
["LFDID"] = 1127,
},
["Забытый город – квартал Криводревов"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 2635,
},
["Сердце Страха"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 534,
},
["Черный храм"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 196,
},
["Случайное подземелье классической игры"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 258,
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = false,
},
["Грим Батол"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2730,
},
["Каменный Свод"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2724,
},
["Случайное подземелье, путеш. во времени (Warlords of Draenor)"] = {
["LFDID"] = 1971,
["Expansion"] = 5,
["Show"] = "saved",
["Random"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Raid"] = false,
},
["Нижняя часть пика Черной горы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["LFDID"] = 32,
},
["Окулярус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2013,
["RecLevel"] = 45,
["Raid"] = true,
},
["Терраса Вечной Весны"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 536,
},
["Случайный сценарий путешествия во времени (Mists of Pandaria)"] = {
["LFDID"] = 2558,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Каражан"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 175,
},
["Аукиндон"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1975,
},
["Случайное подземелье Shadowlands"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2086,
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Иссохший Дж'им"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1796,
["RecLevel"] = 45,
["Raid"] = true,
},
["Крепость Бурь"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 193,
},
["Стратхольм – главные врата"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 2639,
},
["Островные экспедиции – индивидуальный тур"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2251,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Храм Ан'Киража"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 161,
},
["Антрос"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9013,
["RecLevel"] = 60,
["Raid"] = true,
},
["Ульдир"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["LFDID"] = 1889,
},
["Терраса Магистров"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1154,
},
["Прошлое Хиджала"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 195,
},
["Подземелья Могу'шан"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 532,
},
["Некроситет"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2557,
},
["Забытый город - палаты Гордока"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["LFDID"] = 38,
},
["Тол Дагор"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1714,
},
["Случайное подземелье (The War Within, героический режим)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2517,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Легиона"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 1045,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайный сценарий (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2559,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Си'ваш"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1885,
["RecLevel"] = 45,
["Raid"] = true,
},
["Кронпринцесса Терадрас"] = {
["LFDID"] = 309,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["Show"] = "saved",
},
["Ульдаман"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["LFDID"] = 22,
},
["Операция \"Мехагон\" – мастерская"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["LFDID"] = 2813,
},
["Зул'Аман"] = {
["Show"] = "saved",
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["LFDID"] = 340,
},
["Путешествие во времени, рейд: Ульдуар"] = {
["LFDID"] = 1677,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Show"] = "saved",
},
["Охотники за душами"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1756,
["RecLevel"] = 45,
["Raid"] = true,
},
["Гоблионе"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2683,
["RecLevel"] = 80,
["Raid"] = true,
},
["Кодекс Хроми"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 2714,
},
["Лабиринты Иглошкурых"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 16,
},
["Источник Вечности"] = {
["Show"] = "saved",
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["LFDID"] = 437,
},
["\"Сияющий Рассвет\""] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2725,
},
["Замок Нафрия"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["LFDID"] = 2095,
},
["Утроба Душ"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1192,
},
["Открытие Темного портала"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1012,
},
["Чертоги Камня"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["LFDID"] = 213,
},
["Случайный сценарий Mists of Pandaria"] = {
["LFDID"] = 493,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Нижетопь"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2327,
},
["Престол Триумвирата"] = {
["Show"] = "saved",
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["LFDID"] = 1535,
},
["Атал'Дазар"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2876,
},
["Очищение Стратхольма"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["LFDID"] = 2992,
},
["Глубины Черной горы - Тюремный блок"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["LFDID"] = 30,
},
["Кордак"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2637,
["RecLevel"] = 80,
["Raid"] = true,
},
["Неруб'арский дворец"] = {
["LFDID"] = 2645,
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["Show"] = "saved",
},
["Хранилище Воплощений"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["LFDID"] = 2390,
},
["Искроварня"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2811,
},
["Паровое подземелье"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["LFDID"] = 185,
},
["Ан'кахет: Старое Королевство"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1016,
},
["Верховный Молот"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["LFDID"] = 897,
},
["Курганы Иглошкурых"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["LFDID"] = 20,
},
["Случайное подземелье, путеш. во времени (The Burning Crusade)"] = {
["LFDID"] = 744,
["Expansion"] = 1,
["Show"] = "saved",
["Random"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Raid"] = false,
},
["Затонувший храм"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["LFDID"] = 28,
},
["Осада Оргриммара"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 766,
},
["Забытый город - центральный сад"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["LFDID"] = 36,
},
["Случайное подземелье Легиона (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 1046,
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Трон Приливов"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1150,
},
["Путешествие во времени, рейд: Черный храм"] = {
["LFDID"] = 1533,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Show"] = "saved",
},
["Гарнизон босс"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 9001,
["RecLevel"] = 40,
["Raid"] = true,
},
["Окулус"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["LFDID"] = 211,
},
["10.2.5 - VS Mode - LFG Dungeon (OJF)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2484,
},
["Улмат"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2362,
["RecLevel"] = 50,
["Raid"] = true,
},
["Усадьба Уэйкрестов"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2878,
},
["Чертоги Покаяния"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2119,
},
["Пещеры Времени: годовщина"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 1911,
},
["Лордеронский гарнизон"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2804,
},
["Вечное Цветение"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1972,
},
["Мародон - Зловонная пещера"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 26,
},
["Крепость Утгард"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2323,
},
["Хранилище Аркавона"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 240,
},
["Возвращение в Каражан"] = {
["Show"] = "saved",
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 110,
["LFDID"] = 1347,
},
["Сумеречный бастион"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 316,
},
["Верхняя часть пика Черной горы"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1004,
},
["Испытание доблести"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["LFDID"] = 1439,
},
["Пещеры Стенаний"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 1,
},
["Наксрамас"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 227,
},
["Логово Ониксии"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 257,
},
["Вакан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2531,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ни'алота, Пробуждающийся Город"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["LFDID"] = 2035,
},
["Наступление клана Нокхуд"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2442,
},
["Затерянный город Тол'вир"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1151,
},
["Гробницы маны"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1013,
},
["Рассвет Бесконечности: подъем Дорнозму"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["LFDID"] = 2530,
},
["Смертельная тризна"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2728,
},
["Испытание великого крестоносца"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 250,
},
["Мучители из Торгаста"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9007,
["RecLevel"] = 60,
["Raid"] = true,
},
["Возвращение в Каражан (верхняя часть)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["LFDID"] = 1474,
},
["Бастионы Адского Пламени"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 188,
},
["Хумонгрис"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1770,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Warlords of Draenor (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 789,
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["Кай'жу Газ'рилла"] = {
["LFDID"] = 306,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["Show"] = "saved",
},
["\"Валинор\""] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2430,
["RecLevel"] = 60,
["Raid"] = true,
},
["Солнечный Колодец"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 199,
},
["Конец Времен"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1152,
},
["Случайное подземелье, путешествие во времени (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2538,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Мор'гет Мучитель проклятых"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9012,
["RecLevel"] = 60,
["Raid"] = true,
},
["Орта"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2625,
["RecLevel"] = 80,
["Raid"] = true,
},
["Воспоминания Азерот: Wrath of the Lich King"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 2017,
},
["Катакомбы Сурамара"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["LFDID"] = 1190,
},
["Гнездовье (версия из задания)"] = {
["Show"] = "never",
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 70,
["LFDID"] = 2657,
},
["Хромовый король"] = {
["Show"] = "saved",
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["LFDID"] = 2798,
},
["Освобождение Нижней Шахты"] = {
["LFDID"] = 2893,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = true,
["Бимладен - Ревущий фьорд"] = {
[16] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2769:16:63|h[Освобождение Нижней Шахты]|h|r",
["ID"] = 362526543,
["Locked"] = false,
},
[15] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2769:15:192|h[Освобождение Нижней Шахты]|h|r",
["ID"] = 374846025,
["Locked"] = false,
},
},
["RecLevel"] = 80,
},
["Тихая Сень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["LFDID"] = 2025,
},
["Случайное подземелье, путеш. во времени (Wrath of the Lich King)"] = {
["LFDID"] = 995,
["Expansion"] = 2,
["Show"] = "saved",
["Random"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Raid"] = false,
},
["Тюрьма Штормграда"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 12,
},
["Случайное подземелье Battle For Azeroth (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 7,
["LFDID"] = 1671,
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Повелитель Холода Ахун"] = {
["LFDID"] = 286,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 1,
["Holiday"] = true,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 788,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Скопище кошмаров"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2635,
["RecLevel"] = 80,
["Raid"] = true,
},
["Забытый город – центральный сад"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 2646,
},
["Монастырь Шадо-Пан"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2545,
},
["Залы Отражений"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["LFDID"] = 256,
},
["Побег из Дарнхольда"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["LFDID"] = 183,
},
["Цитадель Ледяной Короны"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 280,
},
["Мародон - Поющие водопады"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 273,
},
["Душа Дракона"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 448,
},
["Налак"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 814,
["RecLevel"] = 35,
["Raid"] = true,
},
["Левантия"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1769,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ордос"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 861,
["RecLevel"] = 35,
["Raid"] = true,
},
["Лощина Бурошкуров"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2439,
},
["\"Валинор\", Светоч Эпох"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9008,
["RecLevel"] = 60,
["Raid"] = true,
},
["Ундаста"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 826,
["RecLevel"] = 35,
["Raid"] = true,
},
["Случайное подземелье Battle For Azeroth"] = {
["Show"] = "saved",
["Expansion"] = 7,
["LFDID"] = 1670,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Операция \"Мехагон\""] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["LFDID"] = 2006,
},
["Залы Алого ордена"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2553,
},
["Яма Сарона"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1153,
},
["Обломок"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1795,
["RecLevel"] = 45,
["Raid"] = true,
},
["Верховный владыка Каззак"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1452,
["RecLevel"] = 40,
["Raid"] = true,
},
["Случайное героическое подземелье (1-й сезон The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2723,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Храм Сетралисс"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2879,
},
["Чертоги Созидания"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["LFDID"] = 321,
},
["Ша Злости"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 691,
["RecLevel"] = 35,
["Raid"] = true,
},
["Мортанис"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2431,
["RecLevel"] = 60,
["Raid"] = true,
},
["Обсидиановое святилище"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 238,
},
["Воспоминания Азерот: Burning Crusade"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 2004,
},
["Случайное подземелье (The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2516,
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Врата Заходящего Солнца"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2549,
},
["Чертоги Насыщения"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2444,
},
["Крепость Барадин"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["LFDID"] = 329,
},
["Случайное подземелье, путеш. во времени (Mists of Pandaria)"] = {
["LFDID"] = 1453,
["Expansion"] = 4,
["Show"] = "saved",
["Random"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Raid"] = false,
},
["Подгнилье"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1712,
},
["Логово Груула"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 177,
},
["Королева Ансурек"] = {
["Show"] = "saved",
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["LFDID"] = 2715,
},
["Случайное подземелье, путеш. во времени (Classic)"] = {
["LFDID"] = 2634,
["Expansion"] = 0,
["Show"] = "saved",
["Random"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Raid"] = false,
},
["Дюнный пожиратель Краулок"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2210,
["RecLevel"] = 50,
["Raid"] = true,
},
["Туманы Тирна Скитта"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2727,
},
["Стратхольм - Черный ход"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["LFDID"] = 274,
},
["Вершина Смерча"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1147,
},
["Пещеры Черной горы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2321,
},
["Гнездовье"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2808,
},
["Ораномонос Вечноветвящаяся"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9010,
["RecLevel"] = 60,
["Raid"] = true,
},
["Рухмар"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1262,
["RecLevel"] = 40,
["Raid"] = true,
},
["Гробница королей"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 2880,
},
["Логово Крыла Тьмы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 50,
},
["Крепость Драк'Тарон"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["LFDID"] = 215,
},
["Академия Алгет'ар"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2464,
},
["Чертоги Доблести"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1194,
},
["Случайное подземелье Cataclysm"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 300,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Драгон Зиморожденный"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1789,
["RecLevel"] = 45,
["Raid"] = true,
},
["Лазуретос"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2199,
["RecLevel"] = 50,
["Raid"] = true,
},
["Мертвые копи"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2636,
},
["Шпили Перерождения"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2122,
},
["Путешествие во времени, рейд: Огненные Просторы"] = {
["LFDID"] = 2026,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Show"] = "saved",
},
["Цитадель Ночи"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["LFDID"] = 1353,
},
["Нургаш Жижерожденный"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2433,
["RecLevel"] = 60,
["Raid"] = true,
},
["Рассвет Бесконечности: падение Галакронда"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["LFDID"] = 2529,
},
["Сетеккские залы"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["LFDID"] = 180,
},
["Осада Боралуса"] = {
["LFDID"] = 2729,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "never",
},
["Руины Ан'Киража"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 160,
},
["Вук'лаз Землелом"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2381,
["RecLevel"] = 50,
["Raid"] = true,
},
["Шлаковые шахты Кровавого Молота"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1973,
},
["Цитадель Темного Молота"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 7,
["LFDID"] = 2043,
},
["Разрушенные залы"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1014,
},
["Испытание чемпиона"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["LFDID"] = 249,
},
["Гробница Саргераса"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["LFDID"] = 1527,
},
["Шар'тос"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1763,
["RecLevel"] = 45,
["Raid"] = true,
},
["Изумрудный Кошмар"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["LFDID"] = 1350,
},
["Дворец Могу'шан"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2551,
},
["Каменные Недра"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1148,
},
["Вершина Утгард"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1020,
},
["Литейная клана Черной горы"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["LFDID"] = 900,
},
["Чаща Темного Сердца"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2277,
},
["Случайное подземелье \"Времени Сумерек\" (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 434,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Рубиновое святилище"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 294,
},
["Воспоминания Азерот: Cataclysm"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 2018,
},
["Всадник без головы"] = {
["LFDID"] = 285,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Holiday"] = true,
["Show"] = "saved",
},
["Королевская химическая компания"] = {
["LFDID"] = 288,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 1,
["Holiday"] = true,
["Show"] = "saved",
},
["Та Сторона"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2118,
},
["Кровавые катакомбы"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2117,
},
["Тазавеш: улицы чудес"] = {
["Show"] = "saved",
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["LFDID"] = 2329,
},
["Случайное подземелье Burning Crusade"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 259,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Экспедиции на остров Кишащий"] = {
["LFDID"] = 2054,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = true,
},
["Мор'гет"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2456,
["RecLevel"] = 60,
["Raid"] = true,
},
["Базрикрон"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2506,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ана-Муз"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1790,
["RecLevel"] = 45,
["Raid"] = true,
},
["Рассвет Бесконечности"] = {
["Show"] = "saved",
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 70,
["LFDID"] = 2430,
},
["Возвращение в Каражан (нижняя часть)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["LFDID"] = 1475,
},
["Чертоги Молний"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1018,
},
["Йорундалль"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["LFDID"] = 2041,
},
["Градовый голем"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2197,
["RecLevel"] = 50,
["Raid"] = true,
},
["Нитхегг"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1749,
["RecLevel"] = 45,
["Raid"] = true,
},
["Джи'арак"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2141,
["RecLevel"] = 50,
["Raid"] = true,
},
["Мародон - Оскверненный грот"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["LFDID"] = 272,
},
["Святилище Господства"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["LFDID"] = 2228,
},
["Случайные островные экспедиции – эпохальный режим"] = {
["LFDID"] = 1891,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Четыре небожителя"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 857,
["RecLevel"] = 35,
["Raid"] = true,
},
["Госпожа Фолнуна"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2010,
["RecLevel"] = 45,
["Raid"] = true,
},
["Галеон"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 725,
["RecLevel"] = 35,
["Raid"] = true,
},
["Властитель преисподней Веролом"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2015,
["RecLevel"] = 45,
["Raid"] = true,
},
["Монастырь Алого ордена"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2555,
},
["Глубины Черной горы"] = {
["LFDID"] = 2754,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 80,
["Holiday"] = true,
["Show"] = "saved",
},
["Бруталл"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1883,
["RecLevel"] = 45,
["Raid"] = true,
},
["Механар"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["LFDID"] = 192,
},
["Случайное подземелье, путеш. во времени (Cataclysm)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 1146,
["Holiday"] = true,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Случайное подземелье Cataclysm (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 301,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Mists of Pandaria"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 463,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Приорат Священного Пламени"] = {
["Show"] = "never",
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 1,
["LFDID"] = 2810,
},
["Струнраан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2515,
["RecLevel"] = 70,
["Raid"] = true,
},
["Цитадель Адского Пламени"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["LFDID"] = 989,
},
["Железные доки"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1974,
},
["Святилище Штормов"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2877,
},
["Стратхольм - Главные врата"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["LFDID"] = 40,
},
["Гнев Тюремщика"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9006,
["RecLevel"] = 60,
["Raid"] = true,
},
["Время Сумерек"] = {
["Show"] = "saved",
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["LFDID"] = 439,
},
["Вестник войны Йенаж"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2198,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Burning Crusade (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 260,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Зул'Фаррак"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2640,
},
["Узилище"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1015,
},
["Чумные каскады"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2121,
},
["Случайное подземелье Lich King"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 261,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
["Show"] = "saved",
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2814,
},
["Ульдаман: наследие Тира"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2465,
},
["Амирдрассил, Надежда Сна"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["LFDID"] = 2504,
},
["Гробница Предвечных"] = {
["Show"] = "saved",
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["LFDID"] = 2290,
},
["Аукенайские гробницы"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["LFDID"] = 178,
},
["Случайное подземелье в героическом режиме (Dragonflight)"] = {
["Show"] = "saved",
["Expansion"] = 9,
["LFDID"] = 2351,
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Осада храма Нюцзао"] = {
["Show"] = "saved",
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2547,
},
["Логово Нелтариона"] = {
["Show"] = "saved",
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2279,
},
["Векемара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2363,
["RecLevel"] = 50,
["Raid"] = true,
},
["Великая императрица Шек'зара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2378,
["RecLevel"] = 50,
["Raid"] = true,
},
["Огненные Недра"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["LFDID"] = 48,
},
["Дров / Тарлна"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1211,
["RecLevel"] = 40,
["Raid"] = true,
},
["Гундрак"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1017,
},
["Ульдуар"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["LFDID"] = 244,
},
["Небесный Путь"] = {
["Show"] = "saved",
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 1977,
},
["Аберрий, Затененное Горнило"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["LFDID"] = 2405,
},
["Нелтарий"] = {
["Show"] = "saved",
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["LFDID"] = 2440,
},
},
["histGeneration"] = 4684,
["Warfront"] = {
{
["contributing"] = false,
["restTime"] = 1754446242,
["captureSide"] = "Alliance",
},
{
["contributing"] = false,
["restTime"] = 1754792982,
["captureSide"] = "Horde",
},
},
["DBVersion"] = 12,
["Tooltip"] = {
["CurrencySortName"] = false,
["Emissary6"] = false,
["TrackBonus"] = true,
["TrackParagon"] = false,
["Currency3220"] = false,
["Currency3008"] = true,
["CombineWorldBosses"] = false,
["HistoryText"] = false,
["CategorySpaces"] = false,
["Currency2807"] = false,
["Currency3090"] = false,
["Currency2806"] = false,
["ShowRandom"] = false,
["Currency3010"] = false,
["Currency2917"] = false,
["TimewornMythicKey"] = true,
["Currency3110"] = true,
["TrackDeserter"] = true,
["Currency2812"] = false,
["Currency2915"] = false,
["Currency2003"] = false,
["Currency2778"] = false,
["Currency3116"] = true,
["MythicKey"] = true,
["Warfront2"] = false,
["Currency3132"] = true,
["ReverseInstances"] = false,
["Currency3218"] = false,
["CurrencyMax"] = false,
["Currency2914"] = false,
["Currency2800"] = false,
["ReportResets"] = false,
["NewFirst"] = true,
["Currency2809"] = false,
["CategorySort"] = "EXPANSION",
["SelfAlways"] = false,
["ShowServer"] = false,
["Currency3056"] = false,
["Warfront1"] = false,
["ShowExpired"] = false,
["RaidsFirst"] = true,
["posy"] = 423.1907348632813,
["AugmentBonus"] = true,
["CombineCalling"] = false,
["Currency3226"] = false,
["EmissaryFullName"] = true,
["Scale"] = 1,
["CurrencyEarned"] = true,
["Currency3109"] = false,
["Currency2813"] = false,
["CurrencyValueColor"] = true,
["ShowCategories"] = false,
["Currency3028"] = false,
["posx"] = 716.1676635742188,
["TrackWeeklyQuests"] = true,
["ShowHints"] = true,
["LimitWarn"] = true,
["Calling"] = false,
["ServerOnly"] = false,
["RowHighlight"] = 0.1,
["ShowSoloCategory"] = false,
["TrackDailyQuests"] = true,
["AbbreviateKeystone"] = false,
["MythicKeyBest"] = true,
["Currency3023"] = false,
["Currency3108"] = false,
["TrackLFG"] = true,
["KeystoneReportTarget"] = "EXPORT",
["CallingShowCompleted"] = false,
["Currency2815"] = false,
["NumberFormat"] = true,
["EmissaryShowCompleted"] = true,
["CombineEmissary"] = false,
["CombineLFR"] = true,
["ServerSort"] = true,
["SelfFirst"] = true,
["Currency3089"] = false,
["Currency2916"] = false,
["Currency3100"] = false,
["Currency3216"] = false,
["Emissary7"] = false,
["Currency2245"] = false,
["Currency3107"] = false,
["TrackPlayed"] = true,
["ConnectedRealms"] = "group",
["TrackSkills"] = false,
["FitToScreen"] = true,
["ShowHoliday"] = false,
["Currency2803"] = false,
},
["RealmMap"] = {
{
"Aegwynn",
"Bonechewer",
"Daggerspine",
"Garrosh",
"Gurubashi",
"Hakkar",
},
["Daggerspine"] = 1,
["Hakkar"] = 1,
["Garrosh"] = 1,
["Gurubashi"] = 1,
["Aegwynn"] = 1,
["Bonechewer"] = 1,
},
["History"] = {
},
["MinimapIcon"] = {
["hide"] = false,
["showInCompartment"] = true,
},
["Toons"] = {
["Мальдика - Свежеватель Душ"] = {
["lastbossyell"] = "Голди Барондон: Эпохальный ключ",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сейф Фарондиса",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Жрица",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["lastbosstime"] = 1754143291,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 655.5,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 655.5,
["Zone"] = "Дорногал",
["Order"] = 50,
["Class"] = "PRIEST",
["oRace"] = "BloodElf",
["ILPvp"] = 655.5,
["LastSeen"] = 1754143386,
["currency"] = {
[2917] = {
["amount"] = 0,
},
[2815] = {
["amount"] = 1355,
},
[1904] = {
["totalEarned"] = 1779,
["totalMax"] = 3510,
["amount"] = 109,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 3,
},
[1979] = {
["amount"] = 522,
},
[1810] = {
["covenant"] = {
[3] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 2290,
},
[3108] = {
["totalEarned"] = 15,
["amount"] = 10,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 5,
},
[1767] = {
["amount"] = 2,
},
[3132] = {
["totalMax"] = 22,
["amount"] = 7,
},
[1716] = {
["amount"] = 100,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3109] = {
["totalEarned"] = 48,
["amount"] = 8,
},
[1191] = {
["amount"] = 0,
},
[1719] = {
["amount"] = 2469,
},
[1813] = {
["covenant"] = {
[3] = 33190,
},
["totalMax"] = 200000,
["amount"] = 33190,
},
[3023] = {
["totalEarned"] = 19,
["totalMax"] = 28,
["amount"] = 19,
},
[2000] = {
["amount"] = 44,
},
[2706] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3110] = {
["totalEarned"] = 302,
["amount"] = 192,
},
[2803] = {
["amount"] = 1875,
},
[1885] = {
["amount"] = 1,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 897,
},
[2707] = {
["amount"] = 0,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 27,
},
[1977] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 4870,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[2915] = {
["amount"] = 0,
},
[1560] = {
["amount"] = 5617,
},
[1718] = {
["amount"] = 0,
},
[2009] = {
["amount"] = 47052,
},
[2708] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 59010,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1710] = {
["amount"] = 250,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2774] = {
["amount"] = 17,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[2916] = {
["amount"] = 0,
},
[3056] = {
["amount"] = 3375,
},
[2914] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 8970,
},
[1822] = {
["covenant"] = {
[3] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1602] = {
["amount"] = 0,
},
[3090] = {
["amount"] = 6172,
},
[3100] = {
["amount"] = 0,
},
[3107] = {
["totalEarned"] = 24,
["amount"] = 39,
},
},
["DailyResetTime"] = 1754366399,
["Warmode"] = false,
["BGBRating"] = {
0,
},
["Level"] = 80,
["Covenant"] = 3,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
["level"] = 11,
["mapID"] = 370,
["ResetTime"] = 1754452799,
["link"] = "|cnIQ4:|Hkeystone:180653:370:11:148:10:9:0:0|h[Ключ: Операция \"Мехагон\" – мастерская (11)]|h|r",
},
["PlayedTotal"] = 5278020,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1754143292,
["MaxXP"] = 100000000,
["MythicKeyBest"] = {
12,
12,
12,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 370,
["runScore"] = 373,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 370,
["runScore"] = 373,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 371,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 373,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 504,
["runScore"] = 379,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 504,
["runScore"] = 368,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Искроварня",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 506,
["runScore"] = 379,
["rewardLevel"] = 662,
},
{
["completed"] = false,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 525,
["runScore"] = 317,
["rewardLevel"] = 662,
},
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["Progress"] = {
["the-world-awaits"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = true,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 2584,
["lastboss"] = "Голди Барондон: Эпохальный ключ",
["SpecializationIDs"] = {
256,
257,
258,
},
["PlayedLevel"] = 1381103,
["Money"] = 36129472,
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Испытания Малдраксуса",
["questID"] = 60436,
["expiredTime"] = 1754366399,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754452799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754539199,
},
["unlocked"] = true,
},
["Skills"] = {
},
["WeeklyResetTime"] = 1754452799,
["Arena3v3rating"] = 0,
},
["Прециза - Свежеватель Душ"] = {
["lastbossyell"] = "Око Наксрамаса: Путешествие во времени",
["isResting"] = true,
["Emissary"] = {
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Охотница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
},
["lastbosstime"] = 1753735383,
["Covenant"] = 3,
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 445.3125,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 625.1875,
["Zone"] = "Дорногал",
["SpecializationIDs"] = {
253,
254,
255,
},
["Class"] = "HUNTER",
["Arena3v3rating"] = 0,
["ILPvp"] = 625.1875,
["LastSeen"] = 1753735658,
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 16,
},
[1822] = {
["covenant"] = {
[3] = 4,
},
["totalMax"] = 80,
["amount"] = 4,
},
[1885] = {
["amount"] = 2,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1767] = {
["amount"] = 2812,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 18,
},
[1220] = {
["amount"] = 2083,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 30,
},
[1813] = {
["covenant"] = {
[3] = 342,
},
["totalMax"] = 200000,
["amount"] = 342,
},
[1721] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 20,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 198,
},
[1166] = {
["amount"] = 1470,
},
[1716] = {
["amount"] = 16,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
},
["Skills"] = {
},
["Warmode"] = false,
["Show"] = "saved",
["Level"] = 78,
["Order"] = 50,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 675443,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1753735548,
["Money"] = 123885219,
["MaxXP"] = 100000000,
["Progress"] = {
["the-world-awaits"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["lastboss"] = "Лорд Аурий Ривендер: Путешествие во времени",
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1754452799,
},
["PlayedLevel"] = 5437,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754366399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754452799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754539199,
},
["unlocked"] = true,
},
["WeeklyResetTime"] = 1754452799,
["DailyResetTime"] = 1754366399,
["oRace"] = "BloodElf",
["BGBRating"] = {
0,
0,
},
},
["Спленда - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сейф Фарондиса",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["currencyID"] = 1553,
["quantity"] = 3600,
},
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["BGBRating"] = {
0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["lastbosstime"] = 1754248651,
["Covenant"] = 2,
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 450.5625,
["Quests"] = {
[89223] = {
["Expires"] = 1754452799,
["Title"] = "Осколок Азерот",
["Link"] = "|cffffff00|Hquest:89223:840|h[Осколок Азерот]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 1165,
["name"] = "Дазар'алор",
["parentMapID"] = 862,
["flags"] = 4,
},
["isDaily"] = false,
},
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1754248696,
["Progress"] = {
["df-services-requested"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
["show"] = true,
[88945] = {
["show"] = false,
},
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
["show"] = true,
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
},
["Class"] = "DEATHKNIGHT",
["LClass"] = "Рыцарь смерти",
["ILPvp"] = 630.3125,
["Order"] = 50,
["currency"] = {
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 84,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 3,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1220] = {
["amount"] = 2368,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 20,
},
[1560] = {
["amount"] = 26,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 1590,
},
[1710] = {
["amount"] = 9,
},
[1533] = {
["amount"] = 5,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3107] = {
["totalEarned"] = 5,
["amount"] = 5,
},
},
["DailyResetTime"] = 1754366399,
["Warmode"] = true,
["SpecializationIDs"] = {
250,
251,
252,
},
["Level"] = 74,
["IL"] = 630.3125,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
"H",
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["level"] = "H",
["name"] = "Героический режим",
["rewardLevel"] = 632,
},
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 1,
},
["PlayedTotal"] = 330703,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1754248651,
["Money"] = 117410488,
["MythicKey"] = {
},
["MaxXP"] = 100000000,
["MythicPlusScore"] = 0,
["lastboss"] = "Язма: Путешествие во времени",
["WeeklyResetTime"] = 1754452799,
["PlayedLevel"] = 13685,
["Calling"] = {
},
["Zone"] = "Дорногал",
["Skills"] = {
},
["lastbossyell"] = "Язма: Путешествие во времени",
["Show"] = "saved",
},
["Вольтчара - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сейф Фарондиса",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
},
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Тауренка",
["LClass"] = "Шаманка",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
[3] = 0,
},
["lastbosstime"] = 1754250390,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 665.9375,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1754452799,
["LastSeen"] = 1754250492,
["Progress"] = {
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["the-world-awaits"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-archives"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
},
["Class"] = "SHAMAN",
["oRace"] = "Tauren",
["ILPvp"] = 665.9375,
["SpecializationIDs"] = {
262,
263,
264,
},
["currency"] = {
[1191] = {
["amount"] = 0,
},
[2815] = {
["amount"] = 5701,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 3,
},
[1979] = {
["amount"] = 807,
},
[1810] = {
["covenant"] = {
7,
},
["totalMax"] = 100,
["amount"] = 7,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3108] = {
["totalEarned"] = 15,
["amount"] = 30,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 4,
},
[1767] = {
["amount"] = 28146,
},
[3132] = {
["totalMax"] = 22,
["amount"] = 17,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[3023] = {
["totalEarned"] = 16,
["totalMax"] = 28,
["amount"] = 16,
},
[3110] = {
["totalEarned"] = 602,
["amount"] = 167,
},
[2803] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1288,
},
[1906] = {
["amount"] = 7480,
},
[2914] = {
["amount"] = 0,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1166] = {
["amount"] = 2775,
},
[2917] = {
["amount"] = 0,
},
[1560] = {
["amount"] = 3,
},
[3107] = {
["totalEarned"] = 32,
["amount"] = 47,
},
[2009] = {
["amount"] = 38086,
},
[1822] = {
["covenant"] = {
80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1828] = {
["amount"] = 96655,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3056] = {
["amount"] = 6715,
},
[1885] = {
["amount"] = 21,
},
[1533] = {
["amount"] = 1092,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[2916] = {
["amount"] = 0,
},
[1977] = {
["amount"] = 16,
},
[3109] = {
["totalEarned"] = 48,
["amount"] = 38,
},
[2000] = {
["amount"] = 37,
},
[1931] = {
["amount"] = 1579,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1813] = {
["covenant"] = {
140482,
},
["totalMax"] = 200000,
["amount"] = 140482,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[2915] = {
["amount"] = 0,
},
},
["DailyResetTime"] = 1754366399,
["Warmode"] = false,
["BGBRating"] = {
[3] = 0,
},
["Level"] = 80,
["Covenant"] = 1,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
["mapID"] = 525,
["level"] = 14,
["ResetTime"] = 1754452799,
["link"] = "|cnIQ4:|Hkeystone:180653:525:14:10:9:147:0:12|h[Ключ: Операция: шлюз (14)]|h|r",
},
["PlayedTotal"] = 5369508,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1754250390,
["Money"] = 1921367065,
["Order"] = 50,
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Испытания Малдраксуса",
["questID"] = 60447,
["expiredTime"] = 1754366399,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Помощь Арденвельду",
["questID"] = 60391,
["expiredTime"] = 1754452799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754539199,
},
["unlocked"] = true,
},
["MythicPlusScore"] = 3002,
["lastboss"] = "Скардинское чудовище: Эпохальный ключ",
["Zone"] = "Дорногал",
["PlayedLevel"] = 1232338,
["MaxXP"] = 100000000,
["MythicKeyBest"] = {
12,
12,
12,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "ЗОЛОТАЯ ЖИЛА!!!",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 247,
["runScore"] = 374,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 370,
["runScore"] = 374,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Приорат Священного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 499,
["runScore"] = 375,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 374,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 372,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 379,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 504,
["runScore"] = 378,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Искроварня",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 506,
["runScore"] = 373,
["rewardLevel"] = 662,
},
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["Skills"] = {
},
["lastbossyell"] = "Чудище камня Бездны: Эпохальный ключ",
["IL"] = 665.9375,
},
["Джуставар - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["BGBRating"] = {
[3] = 0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 383.4375,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 630.0625,
["LastSeen"] = 1754045679,
["Order"] = 50,
["Class"] = "WARRIOR",
["ILPvp"] = 630.0625,
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 1,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1710] = {
["amount"] = 20,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 14,
},
[1716] = {
["amount"] = 21,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 7,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 20,
},
[1166] = {
["amount"] = 1400,
},
[3107] = {
["totalEarned"] = 5,
["amount"] = 5,
},
[1602] = {
["amount"] = 0,
},
},
["Warmode"] = true,
["Zone"] = "Дорногал",
["Level"] = 80,
["oRace"] = "BloodElf",
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 486368,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1754366399,
["Money"] = 123558526,
["Covenant"] = 1,
["WeeklyResetTime"] = 1754452799,
["Progress"] = {
["the-world-awaits"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["SpecializationIDs"] = {
71,
72,
73,
},
["PlayedLevel"] = 619,
["LClass"] = "Воин",
["MaxXP"] = 100000000,
["Skills"] = {
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
},
["Calling"] = {
},
},
["Топмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["BGBRating"] = {
[3] = 0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["lastbosstime"] = 1753646417,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 498.3125,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1754452799,
["LastSeen"] = 1753646481,
["Order"] = 50,
["Class"] = "MAGE",
["LClass"] = "Маг",
["ILPvp"] = 609.625,
["oRace"] = "BloodElf",
["currency"] = {
[824] = {
["totalMax"] = 10000,
["amount"] = 304,
},
[1719] = {
["amount"] = 725,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
[2003] = {
["amount"] = 647,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 9553,
},
[1822] = {
["covenant"] = {
[3] = 6,
},
["totalMax"] = 80,
["amount"] = 6,
},
[1889] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 3502,
},
[2707] = {
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 208,
},
[1220] = {
["amount"] = 7992,
},
[1803] = {
["amount"] = 4344,
},
[2706] = {
["amount"] = 0,
},
[2409] = {
["totalEarned"] = 83,
["amount"] = 83,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 302,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[2118] = {
["amount"] = 50,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 170,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 112,
},
[2410] = {
["totalEarned"] = 124,
["amount"] = 124,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 4255,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1275] = {
["amount"] = 190,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 1410,
},
[2774] = {
["amount"] = 3,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 11,
},
[1155] = {
["totalMax"] = 900,
["amount"] = 204,
},
[1828] = {
["amount"] = 30,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 2,
},
[1710] = {
["amount"] = 7,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 6,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 1223,
},
[2412] = {
["totalEarned"] = 36,
["amount"] = 36,
},
[1226] = {
["amount"] = 23153,
},
[2411] = {
["totalEarned"] = 196,
["amount"] = 196,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1885] = {
["amount"] = 2,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1813] = {
["covenant"] = {
[3] = 124,
},
["totalMax"] = 200000,
["amount"] = 124,
},
[2650] = {
["amount"] = 50,
},
[2413] = {
["amount"] = 27,
},
},
["DailyResetTime"] = 1754366399,
["Warmode"] = false,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754366399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754452799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754539199,
},
["unlocked"] = true,
},
["Level"] = 77,
["Money"] = 128002592,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1754452799,
},
["PlayedTotal"] = 4173219,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1753646070,
["MaxXP"] = 100000000,
["MythicKey"] = {
},
["Progress"] = {
["emissary-of-war"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
["show"] = true,
[87306] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["lastboss"] = "Принц Тортелдрин: Путешествие во времени",
["IL"] = 609.625,
["PlayedLevel"] = 4929,
["SpecializationIDs"] = {
62,
63,
64,
},
["Covenant"] = 3,
["Skills"] = {
},
["Zone"] = "Дорногал",
["lastbossyell"] = "Вождь Укорз Песчаный Череп: Путешествие во времени",
},
["Виандисто - Свежеватель Душ"] = {
["lastbossyell"] = "Горак Тул: Путешествие во времени",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сейф Фарондиса",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
},
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Разбойник",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[2] = 0,
},
["lastbosstime"] = 1754220377,
["Covenant"] = 1,
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 425.4375,
["Quests"] = {
[89223] = {
["Expires"] = 1754452799,
["Title"] = "Осколок Азерот",
["Link"] = "|cffffff00|Hquest:89223:840|h[Осколок Азерот]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 1165,
["name"] = "Дазар'алор",
["parentMapID"] = 862,
["flags"] = 4,
},
["isDaily"] = false,
},
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1754452799,
["Zone"] = "Дорногал",
["Order"] = 50,
["Class"] = "ROGUE",
["BGBRating"] = {
[2] = 0,
},
["ILPvp"] = 622.75,
["oRace"] = "BloodElf",
["currency"] = {
[1822] = {
["covenant"] = {
2,
},
["totalMax"] = 80,
["amount"] = 2,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1710] = {
["amount"] = 8,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 2,
},
[1716] = {
["amount"] = 36,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 20,
},
[1166] = {
["amount"] = 2250,
},
[3107] = {
["totalEarned"] = 5,
["amount"] = 5,
},
[1602] = {
["amount"] = 0,
},
},
["Skills"] = {
},
["Warmode"] = true,
["IL"] = 622.75,
["Level"] = 76,
["Calling"] = {
},
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 811108,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1754220377,
["Money"] = 112480220,
["MaxXP"] = 100000000,
["MythicKeyBest"] = {
"H",
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["level"] = "H",
["name"] = "Героический режим",
["rewardLevel"] = 632,
},
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 1,
},
["MythicPlusScore"] = 0,
["lastboss"] = "Горак Тул: Путешествие во времени",
["SpecializationIDs"] = {
259,
260,
261,
},
["PlayedLevel"] = 9922,
["Progress"] = {
["df-services-requested"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
["show"] = true,
[88945] = {
["show"] = false,
},
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
["show"] = true,
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
},
["Show"] = "saved",
["DailyResetTime"] = 1754366399,
["LastSeen"] = 1754220637,
["Arena3v3rating"] = 0,
},
["Бимладен - Ревущий фьорд"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Ночная эльфийка",
["LClass"] = "Друид",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
1867,
},
["lastbosstime"] = 1754086194,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Alliance",
["ILe"] = 683.125,
["Quests"] = {
},
["Paragon"] = {
2413,
},
["oRace"] = "NightElf",
["LastSeen"] = 1754086343,
["Progress"] = {
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = true,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
},
["Class"] = "DRUID",
["lastbossyell"] = "Король Мехагон: Эпохальный ключ",
["ILPvp"] = 684.875,
["SpecializationIDs"] = {
102,
103,
104,
105,
},
["currency"] = {
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[2650] = {
["amount"] = 659,
},
[2809] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 47,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 10,
},
[1810] = {
["covenant"] = {
[4] = 4,
},
["totalMax"] = 100,
["amount"] = 4,
},
[1191] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 740,
},
[2812] = {
["amount"] = 0,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3100] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 45801,
},
[1717] = {
["amount"] = 604,
},
[2815] = {
["amount"] = 20840,
},
[2003] = {
["amount"] = 24710,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 1,
},
[1813] = {
["covenant"] = {
[4] = 34350,
},
["totalMax"] = 200000,
["amount"] = 34350,
},
[2118] = {
["amount"] = 34197,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 2000,
},
[1560] = {
["amount"] = 16480,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 2645,
},
[2915] = {
["amount"] = 0,
},
[2122] = {
["amount"] = 19,
},
[2916] = {
["amount"] = 0,
},
[3107] = {
["totalEarned"] = 272,
["amount"] = 202,
},
[2123] = {
["amount"] = 0,
},
[515] = {
["amount"] = 10,
},
[3108] = {
["totalEarned"] = 381,
["amount"] = 471,
},
[1721] = {
["amount"] = 28,
},
[3109] = {
["totalEarned"] = 634,
["amount"] = 394,
},
[2411] = {
["totalEarned"] = 1498,
["amount"] = 1498,
},
[1166] = {
["amount"] = 4770,
},
[3110] = {
["totalEarned"] = 4168,
["amount"] = 2613,
},
[738] = {
["amount"] = 4,
},
[2413] = {
["amount"] = 28,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1977] = {
["amount"] = 22,
},
[2009] = {
["amount"] = 41885,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 6102,
},
[3132] = {
["totalMax"] = 22,
["amount"] = 21,
},
[1767] = {
["amount"] = 13155,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 6794,
},
[2807] = {
["amount"] = 0,
},
[1931] = {
["amount"] = 9542,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 2,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 25,
},
[1979] = {
["amount"] = 558,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1533] = {
["amount"] = 3588,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 15000,
},
[2800] = {
["totalEarned"] = 12,
["totalMax"] = 30,
["amount"] = 12,
},
[2774] = {
["amount"] = 23,
},
[1275] = {
["amount"] = 5,
},
[1710] = {
["amount"] = 945,
},
[2594] = {
["amount"] = 3431,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 13,
},
[3023] = {
["totalEarned"] = 19,
["totalMax"] = 28,
["amount"] = 19,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 35,
},
[2707] = {
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[2410] = {
["totalEarned"] = 1364,
["amount"] = 1364,
},
[2803] = {
["amount"] = 11763,
},
[2708] = {
["amount"] = 0,
},
[2412] = {
["totalEarned"] = 3984,
["amount"] = 3984,
},
[2709] = {
["amount"] = 0,
},
[3056] = {
["amount"] = 13276,
},
[3090] = {
["amount"] = 3207,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1889] = {
["amount"] = 18,
},
[1220] = {
["amount"] = 3293,
},
[3218] = {
["amount"] = 1,
},
[2917] = {
["amount"] = 0,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 3,
},
[2806] = {
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[2409] = {
["totalEarned"] = 807,
["amount"] = 807,
},
[2777] = {
["amount"] = 2,
},
[1602] = {
["totalEarned"] = 12972,
["amount"] = 4747,
},
[2914] = {
["amount"] = 0,
},
[3010] = {
["totalEarned"] = 11,
["totalMax"] = 18,
["amount"] = 11,
},
[1719] = {
["amount"] = 7096,
},
},
["Skills"] = {
},
["Warmode"] = false,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754366399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754452799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1754539199,
},
["unlocked"] = true,
},
["Level"] = 80,
["MaxXP"] = 100000000,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
14,
12,
10,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["mapChallengeModeID"] = 370,
["level"] = 14,
["runScore"] = 399,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["mapChallengeModeID"] = 370,
["level"] = 12,
["runScore"] = 371,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Театр Боли",
["thisWeek"] = true,
["mapChallengeModeID"] = 382,
["level"] = 12,
["runScore"] = 372,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Приорат Священного Пламени",
["thisWeek"] = true,
["mapChallengeModeID"] = 499,
["level"] = 12,
["runScore"] = 378,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["mapChallengeModeID"] = 500,
["level"] = 12,
["runScore"] = 372,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["mapChallengeModeID"] = 504,
["level"] = 12,
["runScore"] = 378,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["mapChallengeModeID"] = 504,
["level"] = 12,
["runScore"] = 377,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Приорат Священного Пламени",
["thisWeek"] = true,
["mapChallengeModeID"] = 499,
["level"] = 10,
["runScore"] = 325,
["rewardLevel"] = 662,
},
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["PlayedTotal"] = 30570533,
["Arena2v2rating"] = 1839,
["lastbossyelltime"] = 1754086194,
["Money"] = 2038308234,
["MythicKey"] = {
["mapID"] = 499,
["level"] = 18,
["ResetTime"] = 1754452799,
["link"] = "|cnIQ4:|Hkeystone:180653:499:18:10:9:147:0:18|h[Ключ: Приорат Священного Пламени (18)]|h|r",
},
["Order"] = 50,
["lastboss"] = "Король Мехагон: Эпохальный ключ",
["MythicPlusScore"] = 3664,
["WeeklyResetTime"] = 1754452799,
["PlayedLevel"] = 2941387,
["Covenant"] = 4,
["BGBRating"] = {
0,
0,
0,
0,
},
["DailyResetTime"] = 1754366399,
["Zone"] = "Дорногал",
["IL"] = 683.3125,
},
["Сорчистино - Свежеватель Душ"] = {
["lastbossyell"] = "Гюрзис: Путешествие во времени",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = true,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сейф Фарондиса",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["isComplete"] = true,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["isComplete"] = true,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Подношение Крутогорья",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = true,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
},
{
["isComplete"] = true,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
},
{
["isComplete"] = true,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Чернокнижница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["lastbosstime"] = 1754322203,
["oRace"] = "BloodElf",
["lastboss"] = "Гальваззт: Путешествие во времени",
["Covenant"] = 3,
["TimewornMythicKey"] = {
},
["Calling"] = {
},
["ILe"] = 466.25,
["Quests"] = {
[89223] = {
["Expires"] = 1754452799,
["Title"] = "Осколок Азерот",
["Link"] = "|cffffff00|Hquest:89223:840|h[Осколок Азерот]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 1165,
["name"] = "Дазар'алор",
["parentMapID"] = 862,
["flags"] = 4,
},
["isDaily"] = false,
},
},
["DailyResetTime"] = 1754366399,
["Paragon"] = {
},
["LFG1"] = 1754322604.19,
["WeeklyResetTime"] = 1754452799,
["LastSeen"] = 1754322335,
["Progress"] = {
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
["show"] = true,
[88945] = {
["show"] = false,
},
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
["show"] = true,
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["tww-services-requested"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
},
["Class"] = "WARLOCK",
["BGBRating"] = {
0,
},
["ILPvp"] = 613.6875,
["IL"] = 613.6875,
["currency"] = {
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 4,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 40,
},
[1719] = {
["amount"] = 122,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 442,
},
[1710] = {
["amount"] = 4,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 195,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 45,
},
[1560] = {
["amount"] = 1181,
},
[1220] = {
["amount"] = 5255,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 5728,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 1265,
},
[1226] = {
["amount"] = 11010,
},
[1275] = {
["amount"] = 150,
},
[1166] = {
["amount"] = 3530,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 46,
},
[1755] = {
["amount"] = 12450,
["relatedItemCount"] = 0,
},
},
["Money"] = 119628666,
["Warmode"] = false,
["Faction"] = "Horde",
["Level"] = 68,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1754452799,
["rewardWaiting"] = false,
},
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1754321801,
["MaxXP"] = 100000000,
["MythicKey"] = {
},
["LFG2"] = 1754324011.793,
["SpecializationIDs"] = {
265,
266,
267,
},
["MythicPlusScore"] = 0,
["PlayedTotal"] = 3096887,
["PlayedLevel"] = 9005,
["Zone"] = "Дорногал",
["Show"] = "saved",
["Skills"] = {
},
["Order"] = 50,
["Arena3v3rating"] = 0,
},
},
["Emissary"] = {
["Cache"] = {
[43179] = "Маги Кирин-Тора в Даларане",
[42170] = "Ткачи Снов",
[56120] = "Освобожденные",
[42420] = "Двор Фарондиса",
[48639] = "Армия Света",
[50562] = "Защитники Азерот",
[48641] = "Армия погибели Легиона",
[48642] = "Защитники Аргуса",
[50606] = "Военная кампания Орды",
[50605] = "Военная кампания Альянса",
[50598] = "Империя Зандалари",
[50599] = "Адмиралтейство Праудмуров",
[50600] = "Орден Пылающих Углей",
[56119] = "Клинки Волн",
[50602] = "Экспедиция Таланджи",
[42233] = "Племена Крутогорья",
[42234] = "Валарьяры",
[42421] = "Помраченные",
[42422] = "Стражи",
[50604] = "Тортолланские искатели",
[50603] = "Жители Вол'дуна",
[50601] = "Возрождение Шторма",
},
["Expansion"] = {
[6] = {
{
["questID"] = {
["Horde"] = 42420,
["Alliance"] = 42420,
},
["questNeed"] = 4,
["expiredTime"] = 1754366483,
},
{
["questID"] = {
["Horde"] = 42422,
["Alliance"] = 42422,
},
["questNeed"] = 4,
["expiredTime"] = 1754452883,
},
{
["questID"] = {
["Horde"] = 42233,
["Alliance"] = 42233,
},
["questNeed"] = 4,
["expiredTime"] = 1754539283,
},
},
[7] = {
{
["questID"] = {
["Horde"] = 50562,
["Alliance"] = 50562,
},
["questNeed"] = 4,
["expiredTime"] = 1754366483,
},
{
["questID"] = {
["Horde"] = 50603,
["Alliance"] = 50600,
},
["questNeed"] = 4,
["expiredTime"] = 1754452883,
},
{
["questID"] = {
["Horde"] = 56120,
["Alliance"] = 56119,
},
["questNeed"] = 4,
["expiredTime"] = 1754539283,
},
},
},
},
["DailyResetTime"] = 1754366399,
["Quests"] = {
},
["Indicators"] = {
["R2ClassColor"] = true,
["D2Indicator"] = "BLANK",
["R7Color"] = {
1,
1,
0,
},
["R5Color"] = {
0,
0,
1,
},
["R1Text"] = "KILLED/TOTAL",
["R4Indicator"] = "BLANK",
["R1Color"] = {
0.6,
0.6,
0,
},
["R0Indicator"] = "BLANK",
["R8ClassColor"] = true,
["D2ClassColor"] = true,
["R4ClassColor"] = true,
["R6ClassColor"] = true,
["D2Color"] = {
0,
1,
0,
},
["D1Text"] = "KILLED/TOTAL",
["R0ClassColor"] = true,
["R1ClassColor"] = true,
["D1Indicator"] = "BLANK",
["R2Indicator"] = "BLANK",
["R8Color"] = {
1,
0,
0,
},
["D3ClassColor"] = true,
["D2Text"] = "KILLED/TOTALH",
["R6Color"] = {
0,
1,
0,
},
["D3Text"] = "KILLED/TOTALM",
["R4Color"] = {
1,
0,
0,
},
["R8Text"] = "KILLED/TOTALM",
["R7Indicator"] = "BLANK",
["D3Color"] = {
1,
0,
0,
},
["R0Text"] = "KILLED/TOTAL",
["R0Color"] = {
0.6,
0.6,
0,
},
["R6Text"] = "KILLED/TOTAL",
["R1Indicator"] = "BLANK",
["R3Indicator"] = "BLANK",
["R7ClassColor"] = true,
["R3Text"] = "KILLED/TOTALH",
["D1ClassColor"] = true,
["R4Text"] = "KILLED/TOTALH",
["R3Color"] = {
1,
1,
0,
},
["R3ClassColor"] = true,
["R5Indicator"] = "BLANK",
["R5ClassColor"] = true,
["R2Color"] = {
0.6,
0,
0,
},
["R8Indicator"] = "BLANK",
["R2Text"] = "KILLED/TOTAL",
["D1Color"] = {
0,
0.6,
0,
},
["R6Indicator"] = "BLANK",
["D3Indicator"] = "BLANK",
["R7Text"] = "KILLED/TOTALH",
["R5Text"] = "KILLED/TOTALL",
},
}
