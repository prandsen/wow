
g_professionsSpecsSelectedTabs = {
[2871] = 960,
[2883] = 987,
}
g_professionsSpecsSelectedPaths = {
[999] = 100938,
[987] = 100306,
[998] = 100906,
[1007] = 101801,
[960] = 98953,
}
