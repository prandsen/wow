
NewSettingsSeen = {
["panelItemQualityColorOverrides"] = true,
["cooldownViewerEnabled"] = true,
["assistedCombatHighlight"] = true,
["ASSISTED_COMBAT_ROTATION"] = true,
}
