
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
["dungeon6"] = false,
["dps"] = {
["max"] = "2",
["min"] = "",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
["act"] = true,
["val"] = 4,
},
["dungeon1"] = true,
["tanks"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dungeon2"] = false,
["dungeon8"] = false,
["dungeon3"] = true,
["dungeon5"] = true,
["dungeon4"] = false,
},
},
["c3f6"] = {
["enabled"] = false,
["raid"] = {
["difficulty"] = {
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["min"] = "",
["max"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["version"] = 6,
["c114f5"] = {
["enabled"] = true,
},
["c114f6"] = {
["enabled"] = true,
},
["c6f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["act"] = true,
["val"] = 3,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c9f8"] = {
["enabled"] = true,
},
}
