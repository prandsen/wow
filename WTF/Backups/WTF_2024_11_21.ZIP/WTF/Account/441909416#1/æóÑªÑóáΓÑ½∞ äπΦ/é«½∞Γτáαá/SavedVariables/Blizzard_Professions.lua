
g_professionsSpecsSelectedTabs = {
[2871] = 960,
}
g_professionsSpecsSelectedPaths = {
[960] = 98953,
}
