
ElvCharacterDB = {
["ConvertKeybindings"] = true,
["ChatEditHistory"] = {
},
["ChatHistoryLog"] = {
},
}
