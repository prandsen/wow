
EncounterDetailsDB = {
["chartData"] = {
},
["encounter_spells"] = {
},
["emotes"] = {
},
}
