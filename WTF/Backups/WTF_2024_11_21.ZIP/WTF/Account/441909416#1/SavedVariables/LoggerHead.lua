
LoggerHeadDB = {
["profileKeys"] = {
["Beamladen - Twisting Nether"] = "Default",
["Пва - Свежеватель Душ"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Дракобес - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["log"] = {
["raid"] = {
["Неруб'арский дворец"] = {
[14] = false,
[16] = false,
[15] = false,
[17] = false,
},
},
["party"] = {
["Каменный Свод"] = {
false,
false,
[8] = true,
[23] = false,
},
["Туманы Тирна Скитта"] = {
false,
false,
[23] = false,
[8] = true,
},
["\"Сияющий Рассвет\""] = {
false,
false,
[8] = true,
[23] = false,
},
["Город Нитей"] = {
false,
false,
[8] = true,
[23] = false,
},
["Смертельная тризна"] = {
false,
false,
[23] = false,
[8] = true,
},
["Ара-Кара, Город Отголосков"] = {
false,
[8] = true,
[23] = false,
},
["Гнездовье"] = {
false,
},
["Осада Боралуса"] = {
false,
[8] = true,
[23] = false,
},
["Грим Батол"] = {
false,
false,
[23] = false,
[8] = true,
},
},
},
["version"] = 3,
["minimap"] = {
["hide"] = true,
},
},
},
}
