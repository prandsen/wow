
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["VERSION"] = 114,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[66419] = true,
[75257] = true,
[81624] = true,
[64531] = true,
[76586] = true,
[64273] = true,
},
["Filter"] = 63,
},
["Сорчистино-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Мальдика-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
[82523] = true,
[81624] = true,
[64531] = true,
[81656] = true,
[76586] = true,
[83538] = true,
},
["VERSION"] = 114,
},
["Вольтчара-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["Filter"] = 63,
["Quests"] = {
[82332] = true,
[82468] = true,
[61815] = true,
[83536] = true,
[83718] = true,
[59600] = true,
[81828] = true,
[76586] = true,
[60337] = true,
},
["VERSION"] = 114,
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Sort"] = 5,
["VERSION"] = 114,
["Алианкано-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Сэйвмэн-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 114,
["Quests"] = {
[76586] = true,
[59600] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["Дракобес-СвежевательДуш"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
[71164] = true,
},
["Filter"] = 63,
},
["Топмэн-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["SortPrio"] = {
},
["Ignore"] = {
},
["Вантачмэн-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[74835] = true,
[52196] = true,
[49345] = true,
[73146] = true,
[54896] = true,
[82295] = true,
[51612] = true,
[66551] = true,
[82456] = true,
[82586] = true,
[71180] = true,
[70068] = true,
[55466] = true,
[52756] = true,
[72029] = true,
[82292] = true,
[50497] = true,
[69927] = true,
[58743] = true,
[71140] = true,
[51297] = true,
[75280] = true,
[58747] = true,
},
["VERSION"] = 113,
},
["Пва-СвежевательДуш"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Beamladen-TwistingNether"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 114,
},
["AzeriteFormat"] = 20,
["Прециза-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["HideLegion"] = true,
}
