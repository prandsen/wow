
BugSackDB = {
["auto"] = false,
["fontSize"] = "GameFontHighlight",
["useMaster"] = false,
["altwipe"] = true,
["mute"] = false,
["soundMedia"] = "BugSack: Fatality",
["chatframe"] = false,
}
BugSackLDBIconDB = {
}
