
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 300,
["messageHistory"] = {
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Completed challenge mode mapID 658, level 15, time 1874937",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"Got new connection 2",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 18:21",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 13h 0m 43s",
0,
},
{
"Level: 4d 10h 23m 41s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 18:43",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 13h 6m 30s",
0,
},
{
"Level: 4d 10h 29m 28s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 18:47",
0,
},
{
"Time set to 3/30/2026 (Mon) 18:47",
0,
},
{
"Time set to 3/30/2026 (Mon) 18:47",
0,
},
{
"Time set to 3/30/2026 (Mon) 18:47",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 10, time 1141144",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:24",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:24",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:25",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:25",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:25",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:25",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:27",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:27",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:28",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:28",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:28",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:28",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:29",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:29",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:30",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:30",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:30",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:30",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:45",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:45",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:58",
0,
},
{
"Time set to 3/30/2026 (Mon) 19:58",
0,
},
{
"Time set to 3/30/2026 (Mon) 20:00",
0,
},
{
"Time set to 3/30/2026 (Mon) 20:00",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Completed challenge mode mapID 2805, level 15, time 1712009",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:12",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:12",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2811, level 13, time 1522947",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:46",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:46",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:47",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:47",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:59",
0,
},
{
"Time set to 3/30/2026 (Mon) 21:59",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 10, time 1687878",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 11, time 1766675",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:13",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 17h 56m 4s",
0,
},
{
"Level: 4d 15h 19m 2s",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:14",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:14",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:14",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:14",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:21",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:21",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:35",
0,
},
{
"Time set to 3/31/2026 (Tue) 11:35",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 13:27",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 18h 19m 3s",
0,
},
{
"Level: 4d 15h 42m 1s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 13:35",
0,
},
{
"Time set to 3/31/2026 (Tue) 13:35",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 10, time 1130379",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 1",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 27 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 15:10",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 18h 49m 50s",
0,
},
{
"Level: 4d 16h 12m 48s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 11, time 1624104",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 10, time 1172234",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:20",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:20",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:20",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:20",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:20",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:20",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 10, time 1394893",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:57",
0,
},
{
"Time set to 3/31/2026 (Tue) 16:57",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:00",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:00",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 11, time 1566085",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:41",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:41",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 21h 22m 44s",
0,
},
{
"Level: 4d 18h 45m 42s",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:44",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:44",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:51",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:51",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:51",
0,
},
{
"Time set to 3/31/2026 (Tue) 17:51",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 14, time 1486719",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Completed challenge mode mapID 658, level 14, time 1356376",
0,
},
{
"Weather changed to 2, intensity 0.280000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 19:04",
0,
},
{
"Time set to 3/31/2026 (Tue) 19:04",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2915, level 15, time 1861719",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 20:00",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 385d 23h 13m 11s",
0,
},
{
"Level: 4d 20h 36m 9s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 1209, level 14, time 1356474",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 1753, level 15, time 1689845",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:0 to new lightning ID: 131.",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.750000\n",
0,
},
{
"Only one lightning storm at a time is supported (including storms from weather).",
0,
},
{
"Changing lightning storm from previous lightning ID:131 to new lightning ID: 132.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2874, level 15, time 1814317",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:02",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 386d 1h 15m 1s",
0,
},
{
"Level: 4d 22h 37m 59s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2811, level 14, time 1968738",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:45",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 386d 1h 58m 17s",
0,
},
{
"Level: 4d 23h 21m 15s",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:47",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:47",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:50",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:50",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:51",
0,
},
{
"Time set to 3/31/2026 (Tue) 22:51",
0,
},
{
"Time set to 3/31/2026 (Tue) 23:04",
0,
},
{
"Time set to 3/31/2026 (Tue) 23:04",
0,
},
{
"Time set to 3/31/2026 (Tue) 23:11",
0,
},
{
"Time set to 3/31/2026 (Tue) 23:11",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 3/31/2026 (Tue) 23:58",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 386d 2h 46m 57s",
0,
},
{
"Level: 5d 0h 9m 55s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time set to 4/1/2026 (Wed) 0:28",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.6 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.6 (default 0.750000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 0, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 386d 3h 16m 54s",
0,
},
{
"Level: 5d 0h 39m 52s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
