
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = false,
},
["dungeon6"] = false,
["dungeon1"] = false,
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
["val"] = 3,
["act"] = false,
},
["dungeon4"] = false,
["dungeon2"] = true,
["dungeon3"] = false,
["dungeon8"] = false,
["dungeon7"] = false,
["dungeon5"] = false,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
},
},
["c121f4"] = {
["enabled"] = true,
},
["version"] = 8,
["c9f8"] = {
["enabled"] = true,
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c3f6"] = {
["enabled"] = true,
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["act"] = true,
["val"] = 1,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
}
