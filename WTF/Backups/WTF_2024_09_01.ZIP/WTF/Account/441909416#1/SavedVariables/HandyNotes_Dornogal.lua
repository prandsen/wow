
HandyNotes_DornogalDB = {
["profileKeys"] = {
["Бимладен - Ревущий фьорд"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
