
MRT_NL_DB = {
["autoload"] = {
},
["postAction"] = "",
["showSendButton"] = false,
["scale"] = 1,
["clearMismatched"] = false,
}
