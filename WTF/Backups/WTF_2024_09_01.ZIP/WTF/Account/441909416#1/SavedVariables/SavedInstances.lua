
SavedInstancesDB = {
["DBVersion"] = 12,
["Toons"] = {
["Вантачмэн - Ревущий фьорд"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Монахиня",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 485.4375,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1724710109,
["Order"] = 50,
["Class"] = "MONK",
["ILPvp"] = 486.9375,
["currency"] = {
[2413] = {
["amount"] = 27,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[2650] = {
["amount"] = 9,
},
[2706] = {
["amount"] = 0,
},
[2777] = {
["amount"] = 1,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 18769,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1767] = {
["amount"] = 15729,
},
[738] = {
["amount"] = 2,
},
[1275] = {
["amount"] = 69,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 93,
},
[1220] = {
["amount"] = 20273,
},
[1602] = {
["amount"] = 0,
},
[1810] = {
["covenant"] = {
[4] = 9,
},
["totalMax"] = 100,
["amount"] = 9,
},
[1803] = {
["amount"] = 2173,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[2708] = {
["amount"] = 0,
},
[2003] = {
["amount"] = 2139,
},
[2409] = {
["totalEarned"] = 160,
["amount"] = 160,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 330,
},
[1716] = {
["amount"] = 342,
},
[1191] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1977] = {
["amount"] = 51,
},
[1906] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 1,
},
[2410] = {
["totalEarned"] = 103,
["amount"] = 103,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1166] = {
["amount"] = 5830,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[2707] = {
["amount"] = 0,
},
[2411] = {
["totalEarned"] = 186,
["amount"] = 186,
},
[1560] = {
["amount"] = 39597,
},
[1533] = {
["amount"] = 915,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 14,
},
[1718] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 21950,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 632,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 2,
},
[2774] = {
["amount"] = 20,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 252,
},
[2412] = {
["totalEarned"] = 580,
["amount"] = 580,
},
[1226] = {
["amount"] = 12160,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2709] = {
["amount"] = 0,
},
[1931] = {
["amount"] = 7485,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1813] = {
["covenant"] = {
[4] = 42597,
},
["totalMax"] = 200000,
["amount"] = 42597,
},
[1719] = {
["amount"] = 9929,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 68,
},
},
["Warmode"] = false,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725163199,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
["unlocked"] = true,
},
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["PlayedTotal"] = 8893096,
["Arena2v2rating"] = 0,
["Zone"] = "Вальдраккен",
["Money"] = 6130217354,
["DailyResetTime"] = 1725163199,
["IL"] = 486.9375,
["Covenant"] = 4,
["MythicPlusScore"] = 0,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["numFulfilled"] = 0,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["isComplete"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"1/1 Продолжите кампанию \"Хранители Сна\", чтобы открыть Изумрудный Сон",
"Посадите семена Сна: 0/3",
"3000/3000 Повысьте репутацию среди фракций Драконьих островов",
["show"] = true,
["numFulfilled"] = 1,
["numRequired"] = 1,
["isComplete"] = false,
["leaderboardCount"] = 3,
["text"] = "1/1 0/3 3000/3000",
["objectiveType"] = "object",
["isFinish"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
"Посадите семена Сна: 0/3",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 3,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/3",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["PlayedLevel"] = 1251078,
["SpecializationIDs"] = {
268,
270,
269,
},
["MaxXP"] = 225105,
["Skills"] = {
},
["MythicKey"] = {
},
["WeeklyResetTime"] = 1725422399,
},
["Мальдика - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Жрица",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 485.625,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1724710169,
["SpecializationIDs"] = {
256,
257,
258,
},
["Class"] = "PRIEST",
["ILPvp"] = 486,
["currency"] = {
[1191] = {
["amount"] = 0,
},
[1904] = {
["totalEarned"] = 1779,
["totalMax"] = 3510,
["amount"] = 109,
},
[1719] = {
["amount"] = 2469,
},
[1979] = {
["amount"] = 522,
},
[1810] = {
["covenant"] = {
[3] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 2290,
},
[1822] = {
["covenant"] = {
[3] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1767] = {
["amount"] = 2,
},
[2707] = {
["amount"] = 0,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 44,
},
[1906] = {
["amount"] = 8970,
},
[1721] = {
["amount"] = 27,
},
[1977] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 1630,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1560] = {
["amount"] = 5617,
},
[2009] = {
["amount"] = 47052,
},
[1828] = {
["amount"] = 59010,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 250,
},
[1718] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[2774] = {
["amount"] = 17,
},
[2708] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 1,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1716] = {
["amount"] = 100,
},
[2709] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[3] = 33190,
},
["totalMax"] = 200000,
["amount"] = 33190,
},
[2706] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
},
["Zone"] = "Вальдраккен",
["Warmode"] = false,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725163199,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
["unlocked"] = true,
},
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["RestXP"] = 14,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1725163199,
["MaxXP"] = 225105,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["numFulfilled"] = 0,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["isComplete"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Covenant"] = 3,
["WeeklyResetTime"] = 1725422399,
["MythicPlusScore"] = 0,
["IL"] = 486,
["PlayedLevel"] = 285467,
["Order"] = 50,
["Money"] = 346986915,
["Skills"] = {
},
["PlayedTotal"] = 3879764,
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
},
["Топмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Маг",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 453.8125,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1724710196,
["SpecializationIDs"] = {
62,
63,
64,
},
["Class"] = "MAGE",
["ILPvp"] = 454.1875,
["currency"] = {
[2413] = {
["amount"] = 27,
},
[2650] = {
["amount"] = 50,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
[2003] = {
["amount"] = 647,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 9553,
},
[1885] = {
["amount"] = 2,
},
[1889] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 3502,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 170,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 208,
},
[1220] = {
["amount"] = 7992,
},
[1803] = {
["amount"] = 4344,
},
[2409] = {
["totalEarned"] = 83,
["amount"] = 83,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 302,
},
[2118] = {
["amount"] = 50,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 304,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 112,
},
[2410] = {
["totalEarned"] = 124,
["amount"] = 124,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 3175,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[2707] = {
["amount"] = 0,
},
[2706] = {
["amount"] = 0,
},
[1560] = {
["amount"] = 1410,
},
[2411] = {
["totalEarned"] = 196,
["amount"] = 196,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 11,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1828] = {
["amount"] = 30,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 2,
},
[1710] = {
["amount"] = 7,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 6,
},
[2774] = {
["amount"] = 3,
},
[1155] = {
["totalMax"] = 900,
["amount"] = 204,
},
[2412] = {
["totalEarned"] = 36,
["amount"] = 36,
},
[1226] = {
["amount"] = 23153,
},
[1822] = {
["covenant"] = {
[3] = 6,
},
["totalMax"] = 80,
["amount"] = 6,
},
[1533] = {
["amount"] = 1223,
},
[1718] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1813] = {
["covenant"] = {
[3] = 124,
},
["totalMax"] = 200000,
["amount"] = 124,
},
[1275] = {
["amount"] = 190,
},
[1719] = {
["amount"] = 725,
},
},
["Warmode"] = false,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725163199,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
["unlocked"] = true,
},
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["PlayedTotal"] = 4161106,
["Arena2v2rating"] = 0,
["Zone"] = "Вальдраккен",
["Money"] = 61551664,
["DailyResetTime"] = 1725163199,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["numFulfilled"] = 0,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["isComplete"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"1/1 Продолжите кампанию \"Хранители Сна\", чтобы открыть Изумрудный Сон",
"Получите цветок во время Цветочного бума: 0/50",
"Завершите Цветочный бум: 0/1",
"0/3000 Повысьте репутацию среди фракций Драконьих островов",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 1,
["leaderboardCount"] = 4,
["text"] = "1/1 0/50 0/1 0/3000",
["objectiveType"] = "object",
["numFulfilled"] = 1,
},
["df-secured-shipment"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["IL"] = 454.1875,
["PlayedLevel"] = 159867,
["WeeklyResetTime"] = 1725422399,
["MythicKey"] = {
},
["Skills"] = {
},
["MaxXP"] = 225105,
["Order"] = 50,
},
["Дракобес - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
},
["Race"] = "Драктир",
["LClass"] = "Пробудитель",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[2] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 417.0625,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "Dracthyr",
["LastSeen"] = 1724710226,
["SpecializationIDs"] = {
1467,
1468,
1473,
},
["Class"] = "EVOKER",
["ILPvp"] = 417.0625,
["currency"] = {
[2003] = {
["amount"] = 3880,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1191] = {
["amount"] = 0,
},
},
["PlayedTotal"] = 897304,
["Warmode"] = false,
["Money"] = 65027,
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["RestXP"] = 2,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["MaxXP"] = 225105,
["MythicKey"] = {
},
["WeeklyResetTime"] = 1725422399,
["Covenant"] = 0,
["MythicPlusScore"] = 0,
["IL"] = 417.0625,
["PlayedLevel"] = 835922,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"Отправьтесь на штурм Драконьей Погибели: 0/1",
"3000/3000 Репутация среди фракций Драконьих островов",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 1,
["isComplete"] = false,
["leaderboardCount"] = 2,
["text"] = "0/1 3000/3000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["numFulfilled"] = 0,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["isComplete"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
},
["Order"] = 50,
["DailyResetTime"] = 1725163199,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725163199,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
["unlocked"] = true,
},
["Zone"] = "Вальдраккен",
},
["Бимладен - Ревущий фьорд"] = {
["lastbossyell"] = "Вестник Бездны Эйрих: Соратник",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сокровища валарьяров",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["money"] = 2000000,
},
},
{
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сундук со снаряжением ордена Пылающих Углей",
["itemLvl"] = 99,
["quality"] = 4,
},
},
},
},
},
["Race"] = "Ночная эльфийка",
["LClass"] = "Друид",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
1702,
0,
0,
2192,
},
["lastbosstime"] = 1725143202,
["Covenant"] = 4,
["TimewornMythicKey"] = {
},
["Faction"] = "Alliance",
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Обучение в Ревендрете",
["questID"] = 60411,
["expiredTime"] = 1725163199,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Призыв Арденвельда",
["questID"] = 60423,
["expiredTime"] = 1725249599,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Буря в Утробе",
["questID"] = 60455,
["expiredTime"] = 1725335999,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["ILe"] = 570.25,
["oRace"] = "NightElf",
["Quests"] = {
[83240] = {
["Expires"] = 1725422399,
["Title"] = "Театральная труппа",
["Link"] = "|cffffff00|Hquest:83240:2462|h[Театральная труппа]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2328,
["name"] = "Авансцена",
["parentMapID"] = 2248,
["flags"] = 524292,
},
["isDaily"] = false,
},
[83333] = {
["Expires"] = 1725422399,
["Link"] = "|cffffff00|Hquest:83333:90|h[Шестеренки неприятностей]|h|r",
["Title"] = "Шестеренки неприятностей",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2214,
["name"] = "Гулкие глубины",
["parentMapID"] = 2274,
["flags"] = 6,
},
},
[80670] = {
["Expires"] = 1725422399,
["Title"] = "Глаза Прядильщицы",
["Link"] = "|cffffff00|Hquest:80670:2861|h[Глаза Прядильщицы]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2255,
["name"] = "Аз-Кахет",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
[82452] = {
["Expires"] = 1725422399,
["Title"] = "Воспоминание души мира: локальные задания",
["Link"] = "|cffffff00|Hquest:82452:2838|h[Воспоминание души мира: локальные задания]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["isDaily"] = false,
},
[82946] = {
["Expires"] = 1725422399,
["Title"] = "Вниз в глубины",
["Link"] = "|cffffff00|Hquest:82946:2869|h[Вниз в глубины]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2214,
["name"] = "Гулкие глубины",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
},
["Paragon"] = {
2413,
},
["IL"] = 573.0625,
["LastSeen"] = 1725143821,
["SpecializationIDs"] = {
102,
103,
104,
105,
},
["Class"] = "DRUID",
["ILPvp"] = 573.0625,
["Zone"] = "Дорногал",
["currency"] = {
[1904] = {
["totalEarned"] = 3510,
["amount"] = 0,
["totalMax"] = 3510,
},
[2650] = {
["amount"] = 659,
},
[2809] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 47,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 10,
},
[1810] = {
["covenant"] = {
[4] = 4,
},
["amount"] = 4,
["totalMax"] = 100,
},
[1191] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 740,
},
[2812] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 45801,
},
[1717] = {
["amount"] = 604,
},
[2815] = {
["amount"] = 3681,
},
[2003] = {
["amount"] = 24710,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 1,
},
[2594] = {
["amount"] = 3431,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1954,
},
[1560] = {
["amount"] = 16480,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 2645,
},
[1275] = {
["amount"] = 5,
},
[2122] = {
["amount"] = 19,
},
[2123] = {
["totalMax"] = 200000,
["amount"] = 0,
},
[2409] = {
["totalEarned"] = 807,
["amount"] = 807,
},
[2410] = {
["totalEarned"] = 1364,
["amount"] = 1364,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[2411] = {
["totalEarned"] = 1498,
["amount"] = 1498,
},
[1166] = {
["amount"] = 7400,
},
[1533] = {
["amount"] = 3588,
},
[2412] = {
["totalEarned"] = 3984,
["amount"] = 3984,
},
[1767] = {
["amount"] = 13155,
},
[2413] = {
["amount"] = 28,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1977] = {
["amount"] = 22,
},
[1755] = {
["amount"] = 6794,
["relatedItemCount"] = 0,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 6102,
},
[2807] = {
["amount"] = 0,
},
[1931] = {
["amount"] = 9542,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[3023] = {
["totalEarned"] = 1,
["amount"] = 1,
["totalMax"] = 1,
},
[1979] = {
["amount"] = 558,
},
[1719] = {
["amount"] = 7096,
},
[2800] = {
["totalEarned"] = 12,
["amount"] = 12,
["totalMax"] = 20,
},
[1813] = {
["covenant"] = {
[4] = 34350,
},
["amount"] = 34350,
["totalMax"] = 200000,
},
[2915] = {
["totalEarned"] = 10,
["amount"] = 110,
["totalMax"] = 180,
},
[1710] = {
["amount"] = 945,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 13,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3056] = {
["amount"] = 4066,
},
[2707] = {
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["amount"] = 80,
["totalMax"] = 80,
},
[1889] = {
["amount"] = 18,
},
[2708] = {
["amount"] = 0,
},
[2774] = {
["amount"] = 23,
},
[2709] = {
["amount"] = 0,
},
[2914] = {
["totalEarned"] = 148,
["amount"] = 103,
["totalMax"] = 180,
},
[2777] = {
["amount"] = 2,
},
[1220] = {
["amount"] = 3293,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 27,
},
[3010] = {
["totalEarned"] = 11,
["amount"] = 11,
["totalMax"] = 18,
},
[3028] = {
["amount"] = 4,
},
[2806] = {
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 25,
},
[515] = {
["amount"] = 10,
},
[1602] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 28,
},
[2118] = {
["amount"] = 34197,
},
[2009] = {
["amount"] = 41885,
},
},
["Arena3v3rating"] = 1776,
["Warmode"] = false,
["Skills"] = {
},
["Level"] = 80,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
["rewardWaiting"] = false,
},
["PlayedTotal"] = 27733538,
["Arena2v2rating"] = 1750,
["lastbossyelltime"] = 1725143594,
["MaxXP"] = 100000000,
["MythicKey"] = {
},
["Order"] = 50,
["MythicPlusScore"] = 3751,
["lastboss"] = "Главные механики: Соратник",
["PlayedLevel"] = 104392,
["Show"] = "saved",
["Money"] = 5209015207,
["DailyResetTime"] = 1725163199,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["numFulfilled"] = 0,
["maxUnlocks"] = 0,
["rewardWaiting"] = false,
["isComplete"] = true,
["numRequired"] = 0,
["unlocked"] = true,
["unlocksCompleted"] = 0,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["WeeklyResetTime"] = 1725422399,
},
["Вольтчара - Свежеватель Душ"] = {
["lastbossyell"] = "Ки'катал Жница: Обычный",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Тауренка",
["LClass"] = "Шаманка",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["lastbosstime"] = 1725066048,
["Covenant"] = 1,
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 470.6875,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 503.75,
["Zone"] = "Дорногал",
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["unlocked"] = false,
["isComplete"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
},
["Class"] = "SHAMAN",
["ILPvp"] = 503.75,
["Show"] = "saved",
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1977] = {
["amount"] = 16,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1979] = {
["amount"] = 807,
},
[1828] = {
["amount"] = 96655,
},
[1767] = {
["amount"] = 28146,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1822] = {
["covenant"] = {
80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1885] = {
["amount"] = 21,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[1931] = {
["amount"] = 1579,
},
[1560] = {
["amount"] = 3,
},
[1813] = {
["covenant"] = {
140482,
},
["totalMax"] = 200000,
["amount"] = 140482,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1191] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 1092,
},
[1906] = {
["amount"] = 7480,
},
[2000] = {
["amount"] = 37,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 15,
},
[1810] = {
["covenant"] = {
7,
},
["totalMax"] = 100,
["amount"] = 7,
},
[1166] = {
["amount"] = 2775,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[1602] = {
["amount"] = 0,
},
[2009] = {
["amount"] = 38086,
},
},
["Order"] = 50,
["Warmode"] = false,
["DailyResetTime"] = 1725163199,
["Level"] = 77,
["MythicKey"] = {
},
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
["rewardWaiting"] = false,
},
["PlayedTotal"] = 4137438,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1725066048,
["MaxXP"] = 100000000,
["Money"] = 176223568,
["oRace"] = "Tauren",
["lastboss"] = "Ки'катал Жница: Обычный",
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1725422399,
["PlayedLevel"] = 3086,
["LastSeen"] = 1725066270,
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Обучение в Ревендрете",
["questID"] = 60412,
["expiredTime"] = 1725163199,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Призыв Арденвельда",
["questID"] = 60424,
["expiredTime"] = 1725249599,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
["unlocked"] = true,
},
["Skills"] = {
},
["Arena3v3rating"] = 0,
["SpecializationIDs"] = {
262,
263,
264,
},
},
},
["MinimapIcon"] = {
["hide"] = false,
["showInCompartment"] = true,
},
["Emissary"] = {
["Cache"] = {
[43179] = "Маги Кирин-Тора в Даларане",
[48639] = "Армия Света",
[50562] = "Защитники Азерот",
[48641] = "Армия погибели Легиона",
[48642] = "Защитники Аргуса",
[42170] = "Ткачи Снов",
[56120] = "Освобожденные",
[50598] = "Империя Зандалари",
[50599] = "Адмиралтейство Праудмуров",
[50600] = "Орден Пылающих Углей",
[56119] = "Клинки Волн",
[50602] = "Экспедиция Таланджи",
[50603] = "Жители Вол'дуна",
[42234] = "Валарьяры",
[42421] = "Помраченные",
[50606] = "Военная кампания Орды",
[42420] = "Двор Фарондиса",
[50605] = "Военная кампания Альянса",
[50601] = "Возрождение Шторма",
},
["Expansion"] = {
[6] = {
{
["questID"] = {
["Horde"] = 42170,
["Alliance"] = 42170,
},
["questNeed"] = 4,
["expiredTime"] = 1725163298,
},
{
["questID"] = {
["Horde"] = 48642,
["Alliance"] = 48642,
},
["questNeed"] = 4,
["expiredTime"] = 1725249698,
},
{
["questID"] = {
["Horde"] = 42234,
["Alliance"] = 42234,
},
["questNeed"] = 4,
["expiredTime"] = 1725336098,
},
},
[7] = {
{
["questID"] = {
["Horde"] = 50602,
["Alliance"] = 50601,
},
["questNeed"] = 4,
["expiredTime"] = 1725163238,
},
{
["questID"] = {
["Horde"] = 50562,
["Alliance"] = 50562,
},
["questNeed"] = 4,
["expiredTime"] = 1725249638,
},
{
["questID"] = {
["Horde"] = 50603,
["Alliance"] = 50600,
},
["questNeed"] = 4,
["expiredTime"] = 1725336038,
},
},
},
},
["Tooltip"] = {
["CurrencySortName"] = false,
["Emissary6"] = false,
["Scale"] = 1,
["TrackParagon"] = false,
["Currency3008"] = true,
["CombineWorldBosses"] = false,
["HistoryText"] = false,
["CategorySpaces"] = false,
["Currency2807"] = false,
["posx"] = 895.2146606445312,
["Currency2806"] = false,
["ShowRandom"] = true,
["Currency3010"] = false,
["Currency2917"] = true,
["TimewornMythicKey"] = true,
["ServerOnly"] = false,
["Currency2812"] = false,
["TrackDailyQuests"] = true,
["Currency2003"] = false,
["Currency2778"] = true,
["TrackBonus"] = false,
["Currency2914"] = true,
["ConnectedRealms"] = "group",
["Warfront2"] = false,
["ReverseInstances"] = false,
["CurrencyMax"] = false,
["AbbreviateKeystone"] = true,
["Currency2800"] = false,
["ShowExpired"] = false,
["ReportResets"] = true,
["Currency2809"] = false,
["CategorySort"] = "EXPANSION",
["ShowSoloCategory"] = false,
["ShowServer"] = false,
["NumberFormat"] = true,
["Warfront1"] = false,
["EmissaryShowCompleted"] = true,
["RaidsFirst"] = true,
["posy"] = 394.23828125,
["CombineCalling"] = true,
["CombineEmissary"] = false,
["CombineLFR"] = true,
["Currency2815"] = false,
["Emissary7"] = false,
["CurrencyValueColor"] = true,
["Currency3028"] = true,
["EmissaryFullName"] = true,
["Currency3089"] = true,
["LimitWarn"] = true,
["Calling"] = false,
["RowHighlight"] = 0.1,
["ShowHoliday"] = true,
["AugmentBonus"] = true,
["ShowCategories"] = false,
["TrackLFG"] = true,
["KeystoneReportTarget"] = "EXPORT",
["CallingShowCompleted"] = true,
["MythicKey"] = true,
["NewFirst"] = true,
["TrackDeserter"] = true,
["Currency2915"] = true,
["MythicKeyBest"] = true,
["Currency3023"] = true,
["SelfFirst"] = true,
["ServerSort"] = true,
["Currency2916"] = true,
["FitToScreen"] = true,
["SelfAlways"] = false,
["Currency3056"] = false,
["CurrencyEarned"] = true,
["TrackPlayed"] = true,
["TrackWeeklyQuests"] = true,
["TrackSkills"] = true,
["Currency2245"] = false,
["ShowHints"] = true,
["Currency2803"] = true,
},
["Progress"] = {
["Enable"] = {
["df-shipment-of-goods"] = false,
["df-fighting-is-its-own-reward"] = false,
["df-aiding-the-accord"] = false,
["great-vault-pvp"] = false,
["timewalking"] = true,
["bfa-lesser-vision"] = false,
["df-the-superbloom"] = false,
["df-disciple-of-fyrakk"] = false,
["df-grand-hunt"] = false,
["df-a-worthy-ally-dream-wardens"] = false,
["df-blooming-dreamseeds"] = false,
["df-a-worthy-ally-loamm-niffen"] = false,
["df-researchers-under-fire"] = false,
["sl-covenant-assault"] = false,
["df-trial-of-elements"] = false,
["bfa-nzoth-assault"] = false,
["df-community-feast"] = false,
["df-dreamsurge"] = false,
["df-time-rift"] = false,
["df-secured-shipment"] = false,
["df-the-big-dig-traitors-rest"] = false,
["great-vault-raid"] = true,
["df-primal-storms-core"] = false,
["tww-radiant-echoes"] = true,
["sl-patterns-within-patterns"] = false,
["df-siege-on-dragonbane-keep"] = false,
["df-sparks-of-life"] = false,
["df-primal-storms-elementals"] = false,
["bfa-island"] = false,
["emissary-of-war"] = true,
["df-trial-of-flood"] = false,
["bfa-horrific-vision"] = false,
["the-world-awaits"] = true,
},
["Order"] = {
["df-shipment-of-goods"] = 50,
["df-fighting-is-its-own-reward"] = 50,
["df-aiding-the-accord"] = 50,
["great-vault-pvp"] = 50,
["timewalking"] = 50,
["bfa-lesser-vision"] = 50,
["df-the-superbloom"] = 50,
["df-disciple-of-fyrakk"] = 50,
["df-grand-hunt"] = 50,
["df-a-worthy-ally-dream-wardens"] = 50,
["df-blooming-dreamseeds"] = 50,
["df-a-worthy-ally-loamm-niffen"] = 50,
["df-researchers-under-fire"] = 50,
["sl-covenant-assault"] = 50,
["df-trial-of-elements"] = 50,
["bfa-nzoth-assault"] = 50,
["df-community-feast"] = 50,
["df-dreamsurge"] = 50,
["df-time-rift"] = 50,
["df-secured-shipment"] = 50,
["df-the-big-dig-traitors-rest"] = 50,
["great-vault-raid"] = 50,
["df-primal-storms-core"] = 50,
["tww-radiant-echoes"] = 50,
["sl-patterns-within-patterns"] = 50,
["df-siege-on-dragonbane-keep"] = 50,
["df-sparks-of-life"] = 50,
["df-primal-storms-elementals"] = 50,
["bfa-island"] = 50,
["emissary-of-war"] = 50,
["df-trial-of-flood"] = 50,
["bfa-horrific-vision"] = 50,
["the-world-awaits"] = 50,
},
["User"] = {
},
},
["Instances"] = {
["СПР (LFR): Тень Нелтариона"] = {
["LFDID"] = 2401,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["СПР (LFR): Залы Искажения Плоти"] = {
["LFDID"] = 837,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Квартал Звезд"] = {
["LFDID"] = 2280,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 45,
},
["СПР (LFR): Авангард Тюремщика"] = {
["LFDID"] = 2221,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Малификус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1884,
["RecLevel"] = 45,
["Raid"] = true,
},
["Огненные Просторы"] = {
["LFDID"] = 362,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Стражи Могу'шан"] = {
["LFDID"] = 2598,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 25,
["Raid"] = true,
},
["Залы Искажения Плоти"] = {
["LFDID"] = 2592,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Ара-Кара, Город Отголосков"] = {
["LFDID"] = 2726,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["СПР (LFR): Сердце Порчи"] = {
["LFDID"] = 1733,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Сотанатор"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2014,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Warlords of Draenor"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 788,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Битва за Дазар'алор"] = {
["LFDID"] = 1944,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 50,
},
["Базуал"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2517,
["RecLevel"] = 70,
["Raid"] = true,
},
["Т'зейн"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2139,
["RecLevel"] = 50,
["Raid"] = true,
},
["Крепость Черной Ладьи"] = {
["LFDID"] = 2275,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Сила Альянса"] = {
["LFDID"] = 1947,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Аркатрац"] = {
["LFDID"] = 1011,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["СПР (LFR): Сон наяву"] = {
["LFDID"] = 2039,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Город Нитей"] = {
["LFDID"] = 2722,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["Инквизитор Мето"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2012,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 462,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Изначальный бастион"] = {
["LFDID"] = 2703,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Случайное подземелье Cataclysm (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 301,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Непроглядная Пучина"] = {
["LFDID"] = 10,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Случайное героическое подземелье (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2537,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Победа или смерть"] = {
["LFDID"] = 1950,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Тазавеш: гамбит Со'леи"] = {
["LFDID"] = 2330,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = false,
},
["Раскаленное вторжение"] = {
["LFDID"] = 2711,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Реликварий роскоши"] = {
["LFDID"] = 2412,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Испытание крестоносца"] = {
["LFDID"] = 248,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Твердыня Крыла Тьмы"] = {
["LFDID"] = 314,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Случайное подземелье (Dragonflight)"] = {
["LFDID"] = 2350,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Кузня Душ"] = {
["LFDID"] = 2322,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Тайный рынок Тазавеш"] = {
["LFDID"] = 2225,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = false,
},
["Случайное подземелье (Mists of Pandaria, героич.)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2539,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Кошмар Шек'зир"] = {
["LFDID"] = 2595,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 35,
["Raid"] = true,
},
["Расплата"] = {
["LFDID"] = 2418,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Престол Гроз"] = {
["LFDID"] = 634,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Аметистовая крепость"] = {
["LFDID"] = 221,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Темный лабиринт"] = {
["LFDID"] = 181,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Операция \"Мехагон\" – свалка"] = {
["LFDID"] = 2027,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = false,
},
["Натанос Гнилостень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 9005,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Lich King (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 262,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Анторус, Пылающий Трон"] = {
["LFDID"] = 1642,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Апокрон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1956,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ботаника"] = {
["LFDID"] = 2325,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Огненная Пропасть"] = {
["LFDID"] = 4,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Логово Магтеридона"] = {
["LFDID"] = 176,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["СПР (LFR): Подъем Императора"] = {
["LFDID"] = 1365,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Вечный дворец"] = {
["LFDID"] = 2016,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 50,
},
["Ауростор"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2562,
["RecLevel"] = 70,
["Raid"] = true,
},
["Азжол-Неруб"] = {
["LFDID"] = 2324,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["СПР (LFR): Раскаленное вторжение"] = {
["LFDID"] = 2468,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Шуррай"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2636,
["RecLevel"] = 80,
["Raid"] = true,
},
["Граница Бездны"] = {
["LFDID"] = 2709,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Mists of Pandaria)"] = {
["LFDID"] = 1453,
["Expansion"] = 4,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Shadowlands (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2087,
["RecLevel"] = 60,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Последний оплот зандаларов"] = {
["LFDID"] = 835,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Черные врата"] = {
["LFDID"] = 1370,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Векемара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2363,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Сделка со Смертью"] = {
["LFDID"] = 1949,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Госпожа Аллюрадель"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2011,
["RecLevel"] = 45,
["Raid"] = true,
},
["Казематы Стражей"] = {
["LFDID"] = 2278,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Штурм Аметистовой крепости"] = {
["LFDID"] = 1209,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Око Азшары"] = {
["LFDID"] = 2276,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Лисканот"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2518,
["RecLevel"] = 70,
["Raid"] = true,
},
["На'зак Одержимый"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1783,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Эфемеровые равнины"] = {
["LFDID"] = 2292,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Мор'гет Мучитель проклятых"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9012,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Надвигающийся ужас"] = {
["LFDID"] = 832,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Королевская библиотека"] = {
["LFDID"] = 1924,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Крепость Темного Клыка"] = {
["LFDID"] = 327,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Залы Крови"] = {
["LFDID"] = 1367,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Островные экспедиции"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 1762,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Хмелеварня Буйных Портеров"] = {
["LFDID"] = 2543,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Кузня Крови"] = {
["LFDID"] = 2326,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Рассвет Бесконечности"] = {
["LFDID"] = 2430,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = false,
},
["Око Вечности"] = {
["LFDID"] = 237,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Изумрудный Кошмар"] = {
["LFDID"] = 1350,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["СПР (LFR): Дар Плоти"] = {
["LFDID"] = 2038,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Оплот Тьмы"] = {
["LFDID"] = 1368,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Цитадель Ледяной Короны"] = {
["LFDID"] = 280,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Гномреган"] = {
["LFDID"] = 14,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Логово Нелтариона"] = {
["LFDID"] = 2279,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Трон Четырех Ветров"] = {
["LFDID"] = 318,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Собор Вечной Ночи"] = {
["LFDID"] = 1488,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Raid"] = false,
},
["\"Валинор\""] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2430,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Чертоги Преданности"] = {
["LFDID"] = 2037,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Авангард Тюремщика"] = {
["LFDID"] = 2415,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Зул'Гуруб"] = {
["LFDID"] = 334,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Raid"] = false,
},
["Лазурное хранилище"] = {
["LFDID"] = 2498,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Театр Боли"] = {
["LFDID"] = 2124,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["Гробница королей"] = {
["LFDID"] = 1785,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = false,
},
["Ашран"] = {
["LFDID"] = 1127,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 40,
["Raid"] = true,
},
["Великая императрица Шек'зара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2378,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Глубины преданных"] = {
["LFDID"] = 2010,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Логово Ониксии"] = {
["LFDID"] = 257,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Змеиное святилище"] = {
["LFDID"] = 194,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Случайное подземелье в героическом режиме (Dragonflight)"] = {
["Show"] = "saved",
["Expansion"] = 9,
["LFDID"] = 2351,
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Сердце Страха"] = {
["LFDID"] = 534,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Наксрамас"] = {
["LFDID"] = 227,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["СПР (LFR): Забытые глубины"] = {
["LFDID"] = 836,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Расплата"] = {
["LFDID"] = 2224,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Чертоги сдерживания"] = {
["LFDID"] = 1731,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Штурм Дазар'алора"] = {
["LFDID"] = 1945,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Каменный Свод"] = {
["LFDID"] = 2724,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["Случайное подземелье, путеш. во времени (Warlords of Draenor)"] = {
["LFDID"] = 1971,
["Expansion"] = 5,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Тайны Неруб'арского дворца"] = {
["LFDID"] = 2650,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "saved",
},
["Джи'арак"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2141,
["RecLevel"] = 50,
["Raid"] = true,
},
["Нижняя часть пика Черной горы"] = {
["LFDID"] = 32,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 21,
["Raid"] = false,
},
["Операция \"Мехагон\""] = {
["LFDID"] = 2006,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = false,
},
["СПР (LFR): Трон Пантеона"] = {
["LFDID"] = 1913,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Великий замысел"] = {
["LFDID"] = 2422,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Утроба Душ"] = {
["LFDID"] = 1192,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Вечноскорбящий дол"] = {
["LFDID"] = 839,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Случайный сценарий путешествия во времени (Mists of Pandaria)"] = {
["LFDID"] = 2558,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Случайный сценарий Mists of Pandaria (героич.)"] = {
["LFDID"] = 641,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Вольная Гавань"] = {
["LFDID"] = 2178,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Каражан"] = {
["LFDID"] = 175,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Случайное подземелье Легиона (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 1046,
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Аукиндон"] = {
["LFDID"] = 1975,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Случайное подземелье Shadowlands"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2086,
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Время Сумерек"] = {
["LFDID"] = 439,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Raid"] = false,
},
["СПР (LFR): Подземная крепость"] = {
["LFDID"] = 841,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Туманы Тирна Скитта"] = {
["LFDID"] = 2727,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["Обломок"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1795,
["RecLevel"] = 45,
["Raid"] = true,
},
["Нексус"] = {
["LFDID"] = 1019,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Падение империи"] = {
["LFDID"] = 1946,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Расплата у врат"] = {
["LFDID"] = 840,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Крепость Бурь"] = {
["LFDID"] = 193,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Храм Сетралисс"] = {
["LFDID"] = 1695,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Терраса Вечной Весны"] = {
["LFDID"] = 2599,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Каламир"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1774,
["RecLevel"] = 45,
["Raid"] = true,
},
["Тихая Сень"] = {
["LFDID"] = 2025,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 1,
["Raid"] = true,
},
["Монастырь Алого ордена"] = {
["LFDID"] = 2555,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Орта"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2625,
["RecLevel"] = 80,
["Raid"] = true,
},
["Эфемеровые равнины"] = {
["LFDID"] = 2420,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Островные экспедиции – индивидуальный тур"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2251,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Храм Ан'Киража"] = {
["LFDID"] = 161,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Антрос"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9013,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Оковы судьбы"] = {
["LFDID"] = 2223,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Иссохший Дж'им"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1796,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ульдир"] = {
["LFDID"] = 1889,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 50,
},
["Случайное подземелье (The War Within)"] = {
["LFDID"] = 2516,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = false,
["Random"] = true,
["Вольтчара - Свежеватель Душ"] = {
},
},
["Госпожа Фолнуна"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2010,
["RecLevel"] = 45,
["Raid"] = true,
},
["Подземелья Могу'шан"] = {
["LFDID"] = 532,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Случайное подземелье Warlords of Draenor (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 789,
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Врата ада"] = {
["LFDID"] = 1920,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Кровь из камня"] = {
["LFDID"] = 2413,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Случайное подземелье Burning Crusade (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 260,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Горнило Штормов"] = {
["LFDID"] = 1954,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 50,
},
["Некроситет"] = {
["LFDID"] = 2557,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Вершина Утгард"] = {
["LFDID"] = 1020,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Низвержение"] = {
["LFDID"] = 2587,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Забытый город - палаты Гордока"] = {
["LFDID"] = 38,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Королевская химическая компания"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 288,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 1,
},
["Тол Дагор"] = {
["LFDID"] = 1714,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Случайное подземелье (The War Within, героический режим)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2517,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Забытый город - квартал Криводревов"] = {
["LFDID"] = 34,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Случайное подземелье Легиона"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 1045,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайный сценарий (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2559,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Си'ваш"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1885,
["RecLevel"] = 45,
["Raid"] = true,
},
["Рубиновые Омуты Жизни"] = {
["LFDID"] = 2436,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Тень Нелтариона"] = {
["LFDID"] = 2708,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Ульдаман"] = {
["LFDID"] = 22,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Операция \"Мехагон\" – мастерская"] = {
["LFDID"] = 2028,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = false,
},
["СПР (LFR): Падение королевы"] = {
["LFDID"] = 2651,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Укрепления Снующих лап"] = {
["LFDID"] = 2649,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "saved",
},
["Зул'Аман"] = {
["LFDID"] = 340,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Raid"] = false,
},
["Путешествие во времени, рейд: Ульдуар"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 1677,
["Raid"] = true,
["Holiday"] = true,
["RecLevel"] = 30,
},
["Чумные каскады"] = {
["LFDID"] = 2121,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["Охотники за душами"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1756,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Погибель надежды"] = {
["LFDID"] = 1914,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Принц Сарсарун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 310,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 30,
},
["Стратхольм - Черный ход"] = {
["LFDID"] = 274,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 21,
["Raid"] = false,
},
["Возвращение в Каражан (верхняя часть)"] = {
["LFDID"] = 1474,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Raid"] = false,
},
["Забытый город - центральный сад"] = {
["LFDID"] = 36,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Гундрак"] = {
["LFDID"] = 1017,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Случайное героическое подземелье (1-й сезон The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2723,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Великий посол Огнехлыст"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 308,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 30,
},
["СПР (LFR): Великий замысел"] = {
["LFDID"] = 2294,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Обсидиановое святилище"] = {
["LFDID"] = 238,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Гнев Тюремщика"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9006,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Зал аватары"] = {
["LFDID"] = 1918,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Лабиринты Иглошкурых"] = {
["LFDID"] = 16,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Источник Вечности"] = {
["LFDID"] = 437,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Raid"] = false,
},
["Корен Худовар"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 287,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Расселина Темного Пламени"] = {
["LFDID"] = 2655,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["Усадьба Уэйкрестов"] = {
["LFDID"] = 1706,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Испытание доблести"] = {
["LFDID"] = 1921,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Крепость Драк'Тарон"] = {
["LFDID"] = 215,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Подгнилье"] = {
["LFDID"] = 1712,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Храм Нефритовой Змеи"] = {
["LFDID"] = 2541,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Мародон - Оскверненный грот"] = {
["LFDID"] = 272,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Открытие Темного портала"] = {
["LFDID"] = 1012,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Ульдуар"] = {
["LFDID"] = 244,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Повелитель Холода Ахун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 286,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 1,
},
["Чертоги Камня"] = {
["LFDID"] = 213,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Гробницы маны"] = {
["LFDID"] = 1013,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Случайный сценарий Mists of Pandaria"] = {
["LFDID"] = 493,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["СПР (LFR): Изумрудное плетение"] = {
["LFDID"] = 2467,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Цитадель Адского Пламени"] = {
["LFDID"] = 989,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Нижетопь"] = {
["LFDID"] = 2327,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Престол Триумвирата"] = {
["LFDID"] = 1535,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Raid"] = false,
},
["Атал'Дазар"] = {
["LFDID"] = 2177,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Черная Кузня"] = {
["LFDID"] = 1360,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Фундамент Созидания"] = {
["LFDID"] = 2419,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Очищение Стратхольма"] = {
["LFDID"] = 210,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Черный храм"] = {
["LFDID"] = 196,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Случайное подземелье Battle For Azeroth (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 7,
["LFDID"] = 1671,
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Кордак"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2637,
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): След Воплощения"] = {
["LFDID"] = 2466,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Гнев бури"] = {
["LFDID"] = 2706,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["СПР (LFR): Граница Бездны"] = {
["LFDID"] = 2402,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Залы Отражений"] = {
["LFDID"] = 256,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Вершина Бурь"] = {
["LFDID"] = 2591,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Воспоминания Азерот: Wrath of the Lich King"] = {
["LFDID"] = 2017,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Сумеречный бастион"] = {
["LFDID"] = 316,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Неруб'арский дворец"] = {
["LFDID"] = 2645,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Raid"] = true,
},
["Хранилище Воплощений"] = {
["LFDID"] = 2390,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 70,
},
["Искроварня"] = {
["LFDID"] = 2700,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["\"Валинор\", Светоч Эпох"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9008,
["RecLevel"] = 60,
["Raid"] = true,
},
["Окулярус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2013,
["RecLevel"] = 45,
["Raid"] = true,
},
["Шпили Перерождения"] = {
["LFDID"] = 2122,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["СПР (LFR): Темный острог"] = {
["LFDID"] = 2222,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Налак"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 814,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Осада Храма Драконьего Покоя"] = {
["LFDID"] = 843,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Градовый голем"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2197,
["RecLevel"] = 50,
["Raid"] = true,
},
["Верховный Молот"] = {
["LFDID"] = 897,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Курганы Иглошкурых"] = {
["LFDID"] = 20,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Встреча с тщеславием"] = {
["LFDID"] = 2414,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["СПР (LFR): Вершина Бурь"] = {
["LFDID"] = 838,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Низвержение"] = {
["LFDID"] = 842,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Глубины Черной горы - Верхний город"] = {
["LFDID"] = 276,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 21,
["Raid"] = false,
},
["Монастырь Шадо-Пан"] = {
["LFDID"] = 2545,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Затонувший храм"] = {
["LFDID"] = 28,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 21,
["Raid"] = false,
},
["Осада Оргриммара"] = {
["LFDID"] = 766,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Небесный Путь"] = {
["LFDID"] = 1977,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["Галеон"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 725,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Подъем Предателя"] = {
["LFDID"] = 1922,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Ульдаман: наследие Тира"] = {
["LFDID"] = 2465,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Отбракованные жизни"] = {
["LFDID"] = 2704,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Трон Приливов"] = {
["LFDID"] = 1150,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["СПР (LFR): Темная Ветвь"] = {
["LFDID"] = 1912,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Струнраан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2515,
["RecLevel"] = 70,
["Raid"] = true,
},
["СПР (LFR): Воспоминания Азерот: Burning Crusade"] = {
["LFDID"] = 2004,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Пещеры Стенаний"] = {
["LFDID"] = 1,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Улмат"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2362,
["RecLevel"] = 50,
["Raid"] = true,
},
["Ораномонос Вечноветвящаяся"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9010,
["RecLevel"] = 60,
["Raid"] = true,
},
["Стратхольм - Главные врата"] = {
["LFDID"] = 40,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Чертоги Покаяния"] = {
["LFDID"] = 2119,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["Пещеры Времени: годовщина"] = {
["LFDID"] = 1911,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Оковы судьбы"] = {
["LFDID"] = 2417,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Судьба Амирдрассила"] = {
["LFDID"] = 2713,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Святилище Штормов"] = {
["LFDID"] = 1774,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Предел Господства"] = {
["LFDID"] = 2293,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Вечное Цветение"] = {
["LFDID"] = 1972,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 36,
},
["Мародон - Зловонная пещера"] = {
["LFDID"] = 26,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["СПР (LFR): Залы Стенаний"] = {
["LFDID"] = 1919,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Крепость Утгард"] = {
["LFDID"] = 2323,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Хранилище Аркавона"] = {
["LFDID"] = 240,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Яма Сарона"] = {
["LFDID"] = 1153,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Возвращение в Каражан"] = {
["LFDID"] = 1347,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 110,
["Raid"] = false,
},
["Терраса Магистров"] = {
["LFDID"] = 1154,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Верхняя часть пика Черной горы"] = {
["LFDID"] = 1004,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Испытание доблести"] = {
["LFDID"] = 1439,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Прошлое Хиджала"] = {
["LFDID"] = 195,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Ша Злости"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 691,
["RecLevel"] = 35,
["Raid"] = true,
},
["Гробница Предвечных"] = {
["LFDID"] = 2290,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["СПР (LFR): Шлаковый цех"] = {
["LFDID"] = 1361,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Ни'алота, Пробуждающийся Город"] = {
["LFDID"] = 2035,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 50,
},
["Наступление клана Нокхуд"] = {
["LFDID"] = 2442,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Затерянный город Тол'вир"] = {
["LFDID"] = 1151,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["СПР (LFR): Стражи Могу'шан"] = {
["LFDID"] = 830,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Рассвет Бесконечности: подъем Дорнозму"] = {
["LFDID"] = 2530,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 70,
},
["Смертельная тризна"] = {
["LFDID"] = 2728,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["Испытание великого крестоносца"] = {
["LFDID"] = 250,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Мучители из Торгаста"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9007,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Ночной Шпиль"] = {
["LFDID"] = 1923,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Бастионы Адского Пламени"] = {
["LFDID"] = 188,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Хумонгрис"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1770,
["RecLevel"] = 45,
["Raid"] = true,
},
["Дюнный пожиратель Краулок"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2210,
["RecLevel"] = 50,
["Raid"] = true,
},
["Логово Груула"] = {
["LFDID"] = 177,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Кронпринцесса Терадрас"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 309,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 30,
},
["Солнечный Колодец"] = {
["LFDID"] = 199,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Конец Времен"] = {
["LFDID"] = 1152,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 35,
},
["Случайное подземелье, путешествие во времени (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2538,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Пещеры Насыщения"] = {
["LFDID"] = 2705,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["СПР (LFR): Кошмар Шек'зир"] = {
["LFDID"] = 833,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Крепость Барадин"] = {
["LFDID"] = 329,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Прорыв Света"] = {
["LFDID"] = 1916,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
["LFDID"] = 1708,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Депо Мрачных Путей"] = {
["LFDID"] = 2319,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 36,
},
["Кай'жу Газ'рилла"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 306,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 30,
},
["Мертвые копи"] = {
["LFDID"] = 326,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Вечноскорбящий дол"] = {
["LFDID"] = 2590,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Тюрьма Штормграда"] = {
["LFDID"] = 12,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Вакан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2531,
["RecLevel"] = 70,
["Raid"] = true,
},
["СПР (LFR): Встреча с тщеславием"] = {
["LFDID"] = 2096,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Ярость гигантов"] = {
["LFDID"] = 2400,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Скопище кошмаров"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2635,
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): Круг Звезд"] = {
["LFDID"] = 2011,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Руины Ан'Киража"] = {
["LFDID"] = 160,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["СПР (LFR): Горнило Штормов"] = {
["LFDID"] = 1951,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Побег из Дарнхольда"] = {
["LFDID"] = 183,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["\"Сияющий Рассвет\""] = {
["LFDID"] = 2725,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["Мародон - Поющие водопады"] = {
["LFDID"] = 273,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 10,
["Raid"] = false,
},
["Душа Дракона"] = {
["LFDID"] = 448,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Случайное подземелье классической игры"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 258,
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = false,
},
["Левантия"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1769,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Адский пролом"] = {
["LFDID"] = 1366,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Лощина Бурошкуров"] = {
["LFDID"] = 2439,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Падение Смертокрыла"] = {
["LFDID"] = 844,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Врата Заходящего Солнца"] = {
["LFDID"] = 2549,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Случайное подземелье Battle For Azeroth"] = {
["Show"] = "saved",
["Expansion"] = 7,
["LFDID"] = 1670,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Замок Нафрия"] = {
["LFDID"] = 2095,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Цитадель Ночи"] = {
["LFDID"] = 1353,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Вершина Смерча"] = {
["LFDID"] = 1147,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["Экспедиции на остров Кишащий"] = {
["LFDID"] = 2054,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = true,
},
["Литейная клана Черной горы"] = {
["LFDID"] = 900,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Глубины Черной горы - Тюремный блок"] = {
["LFDID"] = 30,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 21,
["Raid"] = false,
},
["СПР (LFR): Искрящий акведук"] = {
["LFDID"] = 1925,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Чертоги Созидания"] = {
["LFDID"] = 321,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["СПР (LFR): Одержимые хранители"] = {
["LFDID"] = 1927,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Мортанис"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2431,
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Cataclysm)"] = {
["LFDID"] = 1146,
["Expansion"] = 3,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье, путеш. во времени (Legion)"] = {
["LFDID"] = 2274,
["Expansion"] = 6,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Рубиновое святилище"] = {
["LFDID"] = 294,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Случайное подземелье \"Времени Сумерек\" (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 434,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Чертоги Насыщения"] = {
["LFDID"] = 2444,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Паровое подземелье"] = {
["LFDID"] = 185,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["СПР (LFR): Изначальный бастион"] = {
["LFDID"] = 2370,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (The Burning Crusade)"] = {
["LFDID"] = 744,
["Expansion"] = 1,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Воспоминания Азерот: Cataclysm"] = {
["LFDID"] = 2018,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Королева Ансурек"] = {
["LFDID"] = 2715,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Raid"] = true,
},
["Мор'гет"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2456,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Судьба Амирдрассила"] = {
["LFDID"] = 2469,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["СПР (LFR): Падение Искусителя"] = {
["LFDID"] = 1917,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Цитадель Темного Молота"] = {
["LFDID"] = 2043,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 7,
["Raid"] = false,
},
["СПР (LFR): Железный цех"] = {
["LFDID"] = 1362,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Пещеры Черной горы"] = {
["LFDID"] = 2321,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["Надвигающийся ужас"] = {
["LFDID"] = 2596,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 35,
["Raid"] = true,
},
["Путешествие во времени, рейд: Черный храм"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 1533,
["Raid"] = true,
["Holiday"] = true,
["RecLevel"] = 30,
},
["Чертоги Доблести"] = {
["LFDID"] = 1194,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Гарнизон босс"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 9001,
["RecLevel"] = 40,
["Raid"] = true,
},
["Логово Крыла Тьмы"] = {
["LFDID"] = 50,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Окулус"] = {
["LFDID"] = 211,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Путешествие во времени, рейд: Огненные Просторы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 2026,
["Raid"] = true,
["Holiday"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Почетный прием"] = {
["LFDID"] = 2009,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Темный острог"] = {
["LFDID"] = 2416,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Драгон Зиморожденный"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1789,
["RecLevel"] = 45,
["Raid"] = true,
},
["Лазуретос"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2199,
["RecLevel"] = 50,
["Raid"] = true,
},
["Гнездовье (версия из задания)"] = {
["LFDID"] = 2657,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = false,
},
["Шар'тос"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1763,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Отбракованные жизни"] = {
["LFDID"] = 2399,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Катакомбы Сурамара"] = {
["LFDID"] = 1190,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 45,
},
["Нургаш Жижерожденный"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2433,
["RecLevel"] = 60,
["Raid"] = true,
},
["Рассвет Бесконечности: падение Галакронда"] = {
["LFDID"] = 2529,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 70,
},
["Сетеккские залы"] = {
["LFDID"] = 180,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Осада Боралуса"] = {
["LFDID"] = 2729,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["СПР (LFR): Видение судьбы"] = {
["LFDID"] = 2036,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Вук'лаз Землелом"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2381,
["RecLevel"] = 50,
["Raid"] = true,
},
["Шлаковые шахты Кровавого Молота"] = {
["LFDID"] = 1973,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Некрополь Призрачной Луны"] = {
["LFDID"] = 1976,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Разрушенные залы"] = {
["LFDID"] = 1014,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Ан'кахет: Старое Королевство"] = {
["LFDID"] = 1016,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["СПР (LFR): Фундамент Созидания"] = {
["LFDID"] = 2291,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Испытание чемпиона"] = {
["LFDID"] = 249,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Случайные островные экспедиции – эпохальный режим"] = {
["LFDID"] = 1891,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Дворец Могу'шан"] = {
["LFDID"] = 2551,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["СПР (LFR): Оборона Дазар'алора"] = {
["LFDID"] = 1948,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Тазавеш: улицы чудес"] = {
["LFDID"] = 2329,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = false,
},
["СПР (LFR): Запретный спуск"] = {
["LFDID"] = 1915,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Чаща Темного Сердца"] = {
["LFDID"] = 2277,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Подземная крепость"] = {
["LFDID"] = 2588,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Волшебное святилище"] = {
["LFDID"] = 1364,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Чертоги Молний"] = {
["LFDID"] = 1018,
["Expansion"] = 2,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Всадник без головы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 285,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["СПР (LFR): Алый спуск"] = {
["LFDID"] = 1732,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Та Сторона"] = {
["LFDID"] = 2118,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["Кровавые катакомбы"] = {
["LFDID"] = 2117,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 50,
},
["СПР (LFR): Кровь из камня"] = {
["LFDID"] = 2092,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье Burning Crusade"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 259,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Гробница Саргераса"] = {
["LFDID"] = 1527,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Случайное подземелье Cataclysm"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 300,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Базрикрон"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2506,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ана-Муз"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1790,
["RecLevel"] = 45,
["Raid"] = true,
},
["Академия Алгет'ар"] = {
["LFDID"] = 2464,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Возвращение в Каражан (нижняя часть)"] = {
["LFDID"] = 1475,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Raid"] = false,
},
["СПР (LFR): Пещеры Насыщения"] = {
["LFDID"] = 2371,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Йорундалль"] = {
["LFDID"] = 2041,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 1,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Wrath of the Lich King)"] = {
["LFDID"] = 995,
["Expansion"] = 2,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Нитхегг"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1749,
["RecLevel"] = 45,
["Raid"] = true,
},
["Забытые глубины"] = {
["LFDID"] = 2593,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Рухмар"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1262,
["RecLevel"] = 40,
["Raid"] = true,
},
["Святилище Господства"] = {
["LFDID"] = 2228,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["СПР (LFR): Терраса Разрушителя"] = {
["LFDID"] = 1369,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Четыре небожителя"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 857,
["RecLevel"] = 35,
["Raid"] = true,
},
["Последний оплот зандаларов"] = {
["LFDID"] = 2594,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 50,
["Raid"] = true,
},
["Ундаста"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 826,
["RecLevel"] = 35,
["Raid"] = true,
},
["Властитель преисподней Веролом"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2015,
["RecLevel"] = 45,
["Raid"] = true,
},
["Хранилище тайн"] = {
["LFDID"] = 2597,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 25,
["Raid"] = true,
},
["Гнездовье"] = {
["LFDID"] = 2718,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["Бруталл"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1883,
["RecLevel"] = 45,
["Raid"] = true,
},
["Механар"] = {
["LFDID"] = 192,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 21,
},
["Расплата у врат"] = {
["LFDID"] = 2589,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Провал Альн"] = {
["LFDID"] = 1926,
["Expansion"] = 6,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 45,
},
["Случайное подземелье Mists of Pandaria"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 463,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Приорат Священного Пламени"] = {
["LFDID"] = 2699,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["СПР (LFR): Терраса Вечной Весны"] = {
["LFDID"] = 834,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["Изумрудное плетение"] = {
["LFDID"] = 2712,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Железные доки"] = {
["LFDID"] = 1974,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Залы Алого ордена"] = {
["LFDID"] = 2553,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["СПР (LFR): Истощающие хранилища"] = {
["LFDID"] = 2090,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Каменные Недра"] = {
["LFDID"] = 1148,
["Expansion"] = 3,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["След Воплощения"] = {
["LFDID"] = 2710,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Вестник войны Йенаж"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2198,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Город за стеной"] = {
["LFDID"] = 1363,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["Зул'Фаррак"] = {
["LFDID"] = 24,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 16,
["Raid"] = false,
},
["Узилище"] = {
["LFDID"] = 1015,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
["Случайное подземелье Lich King"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 261,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Хранилище тайн"] = {
["LFDID"] = 831,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 35,
},
["СПР (LFR): Реликварий роскоши"] = {
["LFDID"] = 2091,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Raid"] = true,
},
["Амирдрассил, Надежда Сна"] = {
["LFDID"] = 2504,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 70,
},
["Грим Батол"] = {
["LFDID"] = 2730,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 31,
},
["СПР (LFR): Тигель Чернорука"] = {
["LFDID"] = 1359,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 40,
},
["СПР (LFR): Гнев бури"] = {
["LFDID"] = 2372,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Осада храма Нюцзао"] = {
["LFDID"] = 2547,
["Expansion"] = 4,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 26,
},
["Ордос"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 861,
["RecLevel"] = 35,
["Raid"] = true,
},
["Ярость гигантов"] = {
["LFDID"] = 2707,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Raid"] = true,
},
["Аукенайские гробницы"] = {
["LFDID"] = 178,
["Expansion"] = 1,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 16,
},
["Огненные Недра"] = {
["LFDID"] = 48,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 30,
["Raid"] = true,
},
["Дров / Тарлна"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1211,
["RecLevel"] = 40,
["Raid"] = true,
},
["Верховный владыка Каззак"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1452,
["RecLevel"] = 40,
["Raid"] = true,
},
["Предел Господства"] = {
["LFDID"] = 2421,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Истощающие хранилища"] = {
["LFDID"] = 2411,
["Expansion"] = 8,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 60,
},
["Аберрий, Затененное Горнило"] = {
["LFDID"] = 2405,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 70,
},
["Нелтарий"] = {
["LFDID"] = 2440,
["Expansion"] = 9,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 10,
},
},
["DailyResetTime"] = 1725163199,
["History"] = {
},
["QuestDB"] = {
["Daily"] = {
[60622] = -1,
[61088] = -1,
[53711] = -1,
[58167] = -1,
[62234] = -1,
[51982] = -1,
[53701] = -1,
[58151] = -1,
[58155] = -1,
[63206] = -1,
[61075] = -1,
[53939] = -1,
[58156] = -1,
[62214] = -1,
[61103] = -1,
[61104] = -1,
[60762] = -1,
[53883] = -1,
[54132] = -1,
[53885] = -1,
[54134] = -1,
[61079] = -1,
[60646] = -1,
[54137] = -1,
[54138] = -1,
[61765] = -1,
[54135] = -1,
[60775] = -1,
[54136] = -1,
[58168] = -1,
},
["Darkmoon"] = {
["expires"] = 1725832740,
[47767] = -1,
},
["AccountDaily"] = {
[40753] = -1,
[34774] = -1,
[56042] = -1,
[31752] = -1,
},
["Weekly"] = {
[70617] = -1,
[32640] = -1,
[57008] = -1,
[52944] = -1,
[52952] = -1,
[83240] = 2328,
[75351] = -1,
[66952] = -1,
[48912] = -1,
[70586] = -1,
[70618] = -1,
[72722] = -1,
[66363] = -1,
[75304] = -1,
[56148] = -1,
[62284] = -1,
[66953] = -1,
[78444] = -1,
[70571] = -1,
[56969] = -1,
[59017] = -1,
[70619] = -1,
[72723] = -1,
[75289] = -1,
[66890] = -1,
[33334] = -1,
[66938] = -1,
[70540] = -1,
[79226] = -1,
[70572] = -1,
[62452] = -1,
[70620] = -1,
[72724] = -1,
[66891] = -1,
[62288] = -1,
[60245] = -1,
[60253] = -1,
[70557] = -1,
[72175] = -1,
[70589] = -1,
[59018] = -1,
[32641] = -1,
[72438] = -1,
[78319] = -1,
[72725] = -1,
[52954] = -1,
[56650] = -1,
[76122] = -1,
[66940] = -1,
[75307] = -1,
[55499] = -1,
[70558] = -1,
[62445] = -1,
[72726] = -1,
[40786] = -1,
[72407] = -1,
[72423] = -1,
[64541] = -1,
[75308] = -1,
[70750] = -1,
[62286] = -1,
[60254] = -1,
[70203] = -1,
[70559] = -1,
[57728] = -1,
[70591] = -1,
[59019] = -1,
[40173] = -1,
[72727] = -1,
[72155] = -1,
[75309] = -1,
["expires"] = 1725422399,
[66942] = -1,
[66945] = -1,
[70560] = -1,
[56064] = -1,
[70592] = -1,
[40787] = -1,
[66943] = -1,
[52957] = -1,
[72728] = -1,
[70752] = -1,
[60247] = -1,
[60255] = -1,
[70545] = -1,
[70561] = -1,
[70593] = -1,
[72410] = -1,
[55498] = -1,
[52956] = -1,
[70211] = -1,
[70753] = -1,
[64710] = -1,
[70530] = -1,
[70562] = -1,
[70235] = -1,
[70594] = -1,
[78427] = -1,
[72156] = -1,
[72427] = -1,
[56050] = -1,
[56648] = -1,
[82946] = 2214,
[66897] = -1,
[70754] = -1,
[60248] = -1,
[60256] = -1,
[75288] = -1,
[70563] = -1,
[70595] = -1,
[66937] = -1,
[72157] = -1,
[72428] = -1,
[53435] = -1,
[60252] = -1,
[66951] = -1,
[52949] = -1,
[70723] = -1,
[70587] = -1,
[33338] = -1,
[66364] = -1,
[70532] = -1,
[52953] = -1,
[70564] = -1,
[66516] = -1,
[56308] = -1,
[52782] = -1,
[60246] = -1,
[55121] = -1,
[62285] = -1,
[66900] = -1,
[57157] = -1,
[70199] = -1,
[66941] = -1,
[62289] = -1,
[70533] = -1,
[75665] = -1,
[66517] = -1,
[70613] = -1,
[72159] = -1,
[40168] = -1,
[53436] = -1,
[72810] = -1,
[52950] = -1,
[52958] = -1,
[52948] = -1,
[66944] = -1,
[48910] = -1,
[72172] = -1,
[62441] = -1,
[70582] = -1,
[66884] = -1,
[70614] = -1,
[78821] = -1,
[72686] = -1,
[82452] = 2339,
[60243] = -1,
[70200] = -1,
[70531] = -1,
[62287] = -1,
[60242] = -1,
[60250] = -1,
[70565] = -1,
[56649] = -1,
[70567] = -1,
[83333] = 2214,
[72173] = -1,
[70615] = -1,
[70935] = -1,
[60257] = -1,
[72719] = -1,
[72158] = -1,
[70201] = -1,
[75301] = -1,
[70233] = -1,
[52951] = -1,
[66950] = -1,
[48911] = -1,
[80670] = 2255,
[70568] = -1,
[62450] = -1,
[70616] = -1,
[60249] = -1,
[64522] = -1,
[55350] = -1,
[72720] = -1,
[75286] = -1,
[70202] = -1,
[45563] = -1,
[70234] = -1,
[66935] = -1,
[60251] = -1,
[62449] = -1,
[60244] = -1,
[70569] = -1,
[66949] = -1,
[59016] = -1,
[78428] = -1,
},
["AccountWeekly"] = {
[45539] = -1,
[72721] = -1,
[72528] = -1,
["expires"] = 1725422399,
[77236] = -1,
[56492] = -1,
[58458] = -1,
[54186] = -1,
[46292] = -1,
},
},
["Indicators"] = {
["R2ClassColor"] = true,
["D2Indicator"] = "BLANK",
["R7Color"] = {
1,
1,
0,
},
["R5Color"] = {
0,
0,
1,
},
["R1Text"] = "KILLED/TOTAL",
["R4Indicator"] = "BLANK",
["R1Color"] = {
0.6,
0.6,
0,
},
["R0Indicator"] = "BLANK",
["R8ClassColor"] = true,
["D2ClassColor"] = true,
["R4ClassColor"] = true,
["R6ClassColor"] = true,
["D2Color"] = {
0,
1,
0,
},
["D1Text"] = "KILLED/TOTAL",
["R0ClassColor"] = true,
["R1ClassColor"] = true,
["D1Indicator"] = "BLANK",
["R2Indicator"] = "BLANK",
["R8Color"] = {
1,
0,
0,
},
["D3ClassColor"] = true,
["D2Text"] = "KILLED/TOTALH",
["R6Color"] = {
0,
1,
0,
},
["D3Text"] = "KILLED/TOTALM",
["R4Color"] = {
1,
0,
0,
},
["R8Text"] = "KILLED/TOTALM",
["R7Indicator"] = "BLANK",
["D3Color"] = {
1,
0,
0,
},
["R0Text"] = "KILLED/TOTAL",
["R0Color"] = {
0.6,
0.6,
0,
},
["R6Text"] = "KILLED/TOTAL",
["R1Indicator"] = "BLANK",
["R3Indicator"] = "BLANK",
["R7ClassColor"] = true,
["R3Text"] = "KILLED/TOTALH",
["D1ClassColor"] = true,
["R4Text"] = "KILLED/TOTALH",
["R3Color"] = {
1,
1,
0,
},
["R3ClassColor"] = true,
["R5Indicator"] = "BLANK",
["R5ClassColor"] = true,
["R2Color"] = {
0.6,
0,
0,
},
["R8Indicator"] = "BLANK",
["R2Text"] = "KILLED/TOTAL",
["D1Color"] = {
0,
0.6,
0,
},
["R6Indicator"] = "BLANK",
["D3Indicator"] = "BLANK",
["R7Text"] = "KILLED/TOTALH",
["R5Text"] = "KILLED/TOTALL",
},
["RealmMap"] = {
},
["histGeneration"] = 105,
["Quests"] = {
},
["Warfront"] = {
{
["contributing"] = true,
["captureSide"] = "Alliance",
},
{
["contributing"] = false,
["restTime"] = 1725282197,
["captureSide"] = "Alliance",
},
},
}
