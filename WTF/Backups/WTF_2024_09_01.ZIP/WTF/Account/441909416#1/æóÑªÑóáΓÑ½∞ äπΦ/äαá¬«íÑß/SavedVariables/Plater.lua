
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[1467] = 25,
[1468] = 25,
[1473] = 25,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0F4AC394"] = true,
},
["resources_on_target"] = false,
["minimap"] = {
},
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[1467] = 25,
[1468] = 25,
[1473] = 25,
},
}
