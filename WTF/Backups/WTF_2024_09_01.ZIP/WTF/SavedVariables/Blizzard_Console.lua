
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 299.9999694824219,
["messageHistory"] = {
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303576.  Modifier not supported on client (type=174, asset=78620, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303579.  Modifier not supported on client (type=174, asset=78621, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 303581.  Modifier not supported on client (type=174, asset=78624, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"World transfer pending...",
0,
},
{
"World transfer aborted (reason: 8)",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 8/31/2024 (Sat) 13:19, newtime = 8/31/2024 (Sat) 13:21)",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2464.34, -2297.68, 1063.37)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2262.34, -2240.17, -553.144)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2394.93, -2222.8, -629.391)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2552 from previous map 2601 with translation: (-0.340088, -0.820068, -1131.33)\n    Location : (2460.27, -2353.38, -280.883)\n    Location in previous map : (2460.61, -2352.56, 850.45)",
0,
},
{
"[Airlock] Swapping to preloaded map 2552 and unloading map 2601. (Map Table Size 288 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2552",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2460.25, -2346.88, 852.217)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.800000\n",
0,
},
{
"Weather changed to 2, intensity 0.800000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 4, intensity 0.500000\n",
0,
},
{
"Weather changed to 4, intensity 0.500000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.800000\n",
0,
},
{
"Weather changed to 2, intensity 0.800000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.800000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 0.800000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2686, Current MapID:2601, PreviousTransitionID:-1, Position (-432.308, -177.896, 183.946)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2686, Current MapID:2601, PreviousTransitionID:2686, Position (-513.5, -110.267, 148.035)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2686 from previous map 2601 with translation: (-2841.71, -1653.08, 300.371)\n    Location : (-521.031, -101.149, 139.313)\n    Location in previous map : (2320.68, 1551.94, -161.058)",
0,
},
{
"[Airlock] Swapping to preloaded map 2686 but keeping old map 2601 RESIDENT.",
0,
},
{
"[Airlock] Freezing AOI updates for old map 2601",
0,
},
{
"[Airlock] Finished transition to new map 2686",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2686, PreviousTransitionID:2601, Position (2320.68, 1551.94, -161.058)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2686, PreviousTransitionID:2601, Position (2316.3, 1607.32, -162.836)",
0,
},
{
"[Airlock] Preload skipped - map is same as current map.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2686 with translation: (2841.71, 1653.08, -300.371)\n    Location : (2369.2, 1503.79, -146.008)\n    Location in previous map : (-472.514, -149.293, 154.363)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2686. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2686, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Skill 2876 increased from 0 to 1",
0,
},
{
"Skill 2876 increased from 1 to 2",
0,
},
{
"Skill 2876 increased from 2 to 3",
0,
},
{
"Skill 2876 increased from 3 to 4",
0,
},
{
"Skill 2876 increased from 4 to 5",
0,
},
{
"Skill 2876 increased from 5 to 6",
0,
},
{
"Skill 2876 increased from 6 to 7",
0,
},
{
"Skill 356 increased from 7 to 8",
0,
},
{
"Skill 2876 increased from 7 to 8",
0,
},
{
"Skill 356 increased from 8 to 9",
0,
},
{
"Skill 2876 increased from 8 to 9",
0,
},
{
"Skill 356 increased from 9 to 10",
0,
},
{
"Skill 2876 increased from 9 to 10",
0,
},
{
"Skill 356 increased from 10 to 11",
0,
},
{
"Skill 2876 increased from 10 to 11",
0,
},
{
"Skill 356 increased from 11 to 12",
0,
},
{
"Skill 2876 increased from 11 to 12",
0,
},
{
"Skill 356 increased from 12 to 13",
0,
},
{
"Skill 2876 increased from 12 to 13",
0,
},
{
"Skill 356 increased from 13 to 14",
0,
},
{
"Skill 2876 increased from 13 to 14",
0,
},
{
"Skill 356 increased from 14 to 15",
0,
},
{
"Skill 2876 increased from 14 to 15",
0,
},
{
"Skill 356 increased from 15 to 16",
0,
},
{
"Skill 2876 increased from 15 to 16",
0,
},
{
"Skill 356 increased from 16 to 17",
0,
},
{
"Skill 2876 increased from 16 to 17",
0,
},
{
"Skill 356 increased from 17 to 18",
0,
},
{
"Skill 2876 increased from 17 to 18",
0,
},
{
"Skill 356 increased from 18 to 19",
0,
},
{
"Skill 2876 increased from 18 to 19",
0,
},
{
"Skill 356 increased from 19 to 20",
0,
},
{
"Skill 2876 increased from 19 to 20",
0,
},
{
"Skill 356 increased from 20 to 21",
0,
},
{
"Skill 2876 increased from 20 to 21",
0,
},
{
"Skill 356 increased from 21 to 22",
0,
},
{
"Skill 2876 increased from 21 to 22",
0,
},
{
"Skill 356 increased from 22 to 23",
0,
},
{
"Skill 2876 increased from 22 to 23",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 1.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725125946\" expirationTime=\"1725140346\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"Got new connection 2",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 8/31/2024 (Sat) 19:46",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 18h 56m 20s",
0,
},
{
"Level: 1d 0h 10m 34s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 8/31/2024 (Sat) 19:54, newtime = 8/31/2024 (Sat) 19:56)",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 19h 6m 50s",
0,
},
{
"Level: 1d 0h 21m 4s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.189042\n",
0,
},
{
"Weather changed to 2, intensity 0.224475\n",
0,
},
{
"Weather changed to 1, intensity 0.149078\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"[GlueLogin] [F] Disconnected from WoW previouslyConnected=\"true\"",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Destroying isInitialized=\"true\"",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725129760\" expirationTime=\"1725144160\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"2\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"2\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 8/31/2024 (Sat) 20:42",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 19h 52m 6s",
0,
},
{
"Level: 1d 1h 6m 20s",
0,
},
{
"[GlueLogin] [F] Fatal error while logging in result=\"( code=\"\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 20h 3m 47s",
0,
},
{
"Level: 1d 1h 18m 1s",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"[GlueLogin] [F] Disconnected from WoW previouslyConnected=\"true\"",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Destroying isInitialized=\"true\"",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725132723\" expirationTime=\"1725147123\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"3\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"3\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"Got new connection 2",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 8/31/2024 (Sat) 21:31",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 20h 41m 27s",
0,
},
{
"Level: 1d 1h 55m 41s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2464.36, -2299.5, 1044.99)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2262.34, -2240.17, -553.144)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 23h 14m 46s",
0,
},
{
"Level: 1d 4h 29m 0s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 23h 16m 17s",
0,
},
{
"Level: 1d 4h 30m 31s",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/1/2024 (Sun) 0:34",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 23h 43m 28s",
0,
},
{
"Level: 1d 4h 57m 42s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/1/2024 (Sun) 0:34",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 320d 23h 44m 10s",
0,
},
{
"Level: 1d 4h 58m 24s",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
