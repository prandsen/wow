
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = false,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dungeon6"] = false,
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
["val"] = 4,
["act"] = true,
},
["dungeon1"] = false,
["dungeon4"] = true,
["dungeon5"] = false,
["dungeon8"] = false,
["dungeon3"] = false,
["dungeon2"] = false,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
},
},
["c3f6"] = {
["enabled"] = false,
["raid"] = {
["difficulty"] = {
},
["heals"] = {
},
["tanks"] = {
["min"] = "",
["act"] = false,
},
["members"] = {
},
["dps"] = {
},
["defeated"] = {
},
["expression"] = "",
},
},
["version"] = 6,
["c9f8"] = {
["enabled"] = true,
},
["c114f6"] = {
["enabled"] = true,
},
["c6f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["val"] = 3,
["act"] = true,
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c114f5"] = {
["enabled"] = true,
},
}
