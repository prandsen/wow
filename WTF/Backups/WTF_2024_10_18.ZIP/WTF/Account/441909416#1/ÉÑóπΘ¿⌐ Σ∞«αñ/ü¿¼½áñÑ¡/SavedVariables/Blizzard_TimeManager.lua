
BlizzardStopwatchOptions = {
["position"] = {
["y"] = 859.714111328125,
["x"] = 671.4281005859375,
},
}
