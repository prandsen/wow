
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[64] = 40,
[103] = 40,
[105] = 40,
[104] = 30,
[102] = 45,
[63] = 40,
[62] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-3674-0B7455E9"] = true,
["Player-3674-0B7455E0"] = true,
},
["spellRangeCheckRangeEnemy"] = {
[64] = 40,
[103] = 40,
[105] = 40,
[104] = 30,
[102] = 45,
[63] = 40,
[62] = 40,
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["minimap"] = {
},
}
