
_detalhes_database = {
["savedbuffs"] = {
},
["mythic_dungeon_id"] = 0,
["tabela_historico"] = {
["tabelas"] = {
{
{
["tipo"] = 2,
["combatId"] = 267,
["_ActorTable"] = {
{
["flag_original"] = 1297,
["totalabsorbed"] = 0.002523,
["pets"] = {
},
["classe"] = "EVOKER",
["total_without_pet"] = 872081.002523,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 872081.002523,
["spec"] = 1467,
["colocacao"] = 1,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1604-0F4AC394",
["damage_from"] = {
},
["targets"] = {
["Водоросляк"] = 872081,
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1727457089,
["aID"] = "1604-0F4AC394",
["nome"] = "Дракобес",
["spells"] = {
["_ActorTable"] = {
[356995] = {
["c_amt"] = 1,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 558229,
},
["n_total"] = 317290,
["n_min"] = 104771,
["g_dmg"] = 0,
["counter"] = 4,
["total"] = 558229,
["c_max"] = 240939,
["id"] = 356995,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 240939,
["successful_casted"] = 0,
["c_total"] = 240939,
["n_amt"] = 3,
["n_max"] = 106770,
["r_amt"] = 0,
},
[370898] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 0,
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 10,
["total"] = 0,
["c_max"] = 0,
["IMMUNE"] = 10,
["id"] = 370898,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[357212] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 121784,
},
["n_total"] = 121784,
["n_min"] = 121784,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 121784,
["c_max"] = 0,
["id"] = 357212,
["r_dmg"] = 0,
["spellschool"] = 4,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 1,
["n_max"] = 121784,
["r_amt"] = 0,
},
[359077] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 192068,
},
["n_total"] = 192068,
["n_min"] = 192068,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 192068,
["c_max"] = 0,
["id"] = 359077,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 1,
["n_max"] = 192068,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 1727457083,
["damage_taken"] = 0.002523,
["start_time"] = 1727457080,
["delay"] = 0,
["last_dps"] = 100737.091662594,
},
{
["flag_original"] = 68136,
["pets"] = {
},
["classe"] = "UNKNOW",
["total_without_pet"] = 0.008702,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 0.008702,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Creature-0-3774-2552-24390-225985-000076BCBE",
["damage_from"] = {
["Дракобес"] = true,
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["aID"] = "225985",
["fight_component"] = true,
["end_time"] = 1727457089,
["totalabsorbed"] = 0.008702,
["nome"] = "Водоросляк",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 872081.008702,
["start_time"] = 1727457089,
["delay"] = 0,
["last_dps"] = 0,
},
},
},
{
["tipo"] = 3,
["combatId"] = 267,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 267,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 267,
["_ActorTable"] = {
{
["flag_original"] = 1047,
["debuff_uptime_spells"] = {
["_ActorTable"] = {
[356995] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 0,
["uptime"] = 2,
["id"] = 356995,
["refreshamt"] = 0,
["actived"] = false,
["counter"] = 0,
},
},
["tipo"] = 9,
},
["buff_uptime"] = 39,
["classe"] = "EVOKER",
["buff_uptime_spells"] = {
["_ActorTable"] = {
[441248] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 1,
["uptime"] = 9,
["id"] = 441248,
["refreshamt"] = 8,
["actived"] = false,
["counter"] = 0,
},
[370454] = {
["appliedamt"] = 2,
["targets"] = {
},
["activedamt"] = 2,
["uptime"] = 2,
["id"] = 370454,
["refreshamt"] = 7,
["actived"] = false,
["counter"] = 0,
},
[395152] = {
["activedamt"] = 9,
["id"] = 395152,
["targets"] = {
},
["actived_at"] = 1727529302,
["uptime"] = 10,
["appliedamt"] = 9,
["refreshamt"] = 0,
["actived"] = true,
["counter"] = 0,
},
[186403] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 1,
["uptime"] = 9,
["id"] = 186403,
["refreshamt"] = 0,
["actived"] = false,
["counter"] = 0,
},
[375802] = {
["appliedamt"] = 2,
["targets"] = {
},
["activedamt"] = 2,
["uptime"] = 9,
["id"] = 375802,
["refreshamt"] = 0,
["actived"] = false,
["counter"] = 0,
},
},
["tipo"] = 9,
},
["debuff_uptime"] = 2,
["buff_uptime_targets"] = {
},
["pets"] = {
},
["nome"] = "Дракобес",
["spec"] = 1467,
["grupo"] = true,
["debuff_uptime_targets"] = {
},
["last_event"] = 1727529302,
["aID"] = "1604-0F4AC394",
["serial"] = "Player-1604-0F4AC394",
["tipo"] = 4,
},
},
},
{
["tipo"] = 2,
["combatId"] = 267,
["_ActorTable"] = {
},
},
["raid_roster"] = {
["Дракобес"] = "Player-1604-0F4AC394",
},
["CombatStartedAt"] = 21298.662,
["tempo_start"] = 1727457080,
["last_events_tables"] = {
},
["alternate_power"] = {
["Сменщикбрана"] = {
["total"] = 0,
["last"] = 0,
},
["Сиоксика"] = {
["total"] = 0,
["last"] = 0,
},
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playing_solo"] = true,
["totals"] = {
161646336,
1828481,
{
0,
[0] = 3787230,
["alternatepower"] = 0,
[3] = 809,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
["Дракобес"] = {
["Погребальный костер"] = 1,
},
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["bloodlust"] = {
8.656999999999243,
8.656999999999243,
8.656999999999243,
},
["data_fim"] = "21:11:29",
["pvp"] = true,
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Водоросляк",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 8.656999999999243,
["CombatEndedAt"] = 21307.319,
["aura_timeline"] = {
},
["is_world_trash_combat"] = true,
["data_inicio"] = "21:11:20",
["end_time"] = 21307.319,
["mapId"] = 2552,
["combat_id"] = 267,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["boss_hp"] = 1,
["combat_counter"] = 373,
["totals_grupo"] = {
872081,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Дракобес"] = 872081.002523,
},
},
},
["start_time"] = 21298.662,
["TimeData"] = {
},
["playerTalents"] = {
},
},
{
{
["tipo"] = 2,
["combatId"] = 266,
["_ActorTable"] = {
{
["flag_original"] = 1297,
["totalabsorbed"] = 0.001067,
["pets"] = {
},
["classe"] = "EVOKER",
["total_without_pet"] = 314938.001067,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 314938.001067,
["spec"] = 1467,
["colocacao"] = 1,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Player-1604-0F4AC394",
["damage_from"] = {
},
["targets"] = {
["Водоросляк"] = 314938,
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1727457058,
["aID"] = "1604-0F4AC394",
["nome"] = "Дракобес",
["spells"] = {
["_ActorTable"] = {
[356995] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 209528,
},
["n_total"] = 209528,
["n_min"] = 104757,
["g_dmg"] = 0,
["counter"] = 2,
["total"] = 209528,
["c_max"] = 0,
["id"] = 356995,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 2,
["n_max"] = 104771,
["r_amt"] = 0,
},
[370898] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 0,
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 4,
["total"] = 0,
["c_max"] = 0,
["IMMUNE"] = 4,
["id"] = 370898,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["n_max"] = 0,
["r_amt"] = 0,
},
[357212] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 105410,
},
["n_total"] = 105410,
["n_min"] = 105410,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 105410,
["c_max"] = 0,
["id"] = 357212,
["r_dmg"] = 0,
["spellschool"] = 4,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 1,
["n_max"] = 105410,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 1727457053,
["damage_taken"] = 0.001067,
["start_time"] = 1727457051,
["delay"] = 0,
["last_dps"] = 45236.71374131299,
},
{
["flag_original"] = 68136,
["pets"] = {
},
["classe"] = "UNKNOW",
["total_without_pet"] = 0.008609,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 0.008609,
["friendlyfire"] = {
},
["total_extra"] = 0,
["serial"] = "Creature-0-3774-2552-24390-225985-000076BCBE",
["damage_from"] = {
["Дракобес"] = true,
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["aID"] = "225985",
["fight_component"] = true,
["end_time"] = 1727457058,
["totalabsorbed"] = 0.008609,
["nome"] = "Водоросляк",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["on_hold"] = false,
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 314938.008609,
["start_time"] = 1727457058,
["delay"] = 0,
["last_dps"] = 0,
},
},
},
{
["tipo"] = 3,
["combatId"] = 266,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["combatId"] = 266,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["combatId"] = 266,
["_ActorTable"] = {
{
["flag_original"] = 1047,
["debuff_uptime_spells"] = {
["_ActorTable"] = {
[356995] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 0,
["uptime"] = 2,
["id"] = 356995,
["refreshamt"] = 0,
["actived"] = false,
["counter"] = 0,
},
},
["tipo"] = 9,
},
["buff_uptime"] = 23,
["classe"] = "EVOKER",
["buff_uptime_spells"] = {
["_ActorTable"] = {
[186403] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 1,
["uptime"] = 7,
["id"] = 186403,
["refreshamt"] = 0,
["actived"] = false,
["counter"] = 0,
},
[441248] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 1,
["uptime"] = 7,
["id"] = 441248,
["refreshamt"] = 6,
["actived"] = false,
["counter"] = 0,
},
[370454] = {
["appliedamt"] = 1,
["targets"] = {
},
["activedamt"] = 1,
["uptime"] = 2,
["id"] = 370454,
["refreshamt"] = 1,
["actived"] = false,
["counter"] = 0,
},
[375802] = {
["appliedamt"] = 2,
["targets"] = {
},
["activedamt"] = 2,
["uptime"] = 7,
["id"] = 375802,
["refreshamt"] = 0,
["actived"] = false,
["counter"] = 0,
},
},
["tipo"] = 9,
},
["debuff_uptime"] = 2,
["buff_uptime_targets"] = {
},
["pets"] = {
},
["nome"] = "Дракобес",
["spec"] = 1467,
["grupo"] = true,
["debuff_uptime_targets"] = {
},
["last_event"] = 1727457058,
["aID"] = "1604-0F4AC394",
["serial"] = "Player-1604-0F4AC394",
["tipo"] = 4,
},
},
},
{
["tipo"] = 2,
["combatId"] = 266,
["_ActorTable"] = {
},
},
["boss_hp"] = 1,
["tempo_start"] = 1727457051,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playing_solo"] = true,
["totals"] = {
6398379,
357646,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["amountCasts"] = {
["Дракобес"] = {
["Погребальный костер"] = 1,
},
},
["instance_type"] = "none",
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "21:10:58",
["pvp"] = true,
["bIsClosed"] = true,
["cleu_timeline"] = {
},
["enemy"] = "Водоросляк",
["trinketProcs"] = {
},
["TotalElapsedCombatTime"] = 21276.686,
["CombatEndedAt"] = 21276.686,
["aura_timeline"] = {
},
["is_world_trash_combat"] = true,
["data_inicio"] = "21:10:51",
["end_time"] = 21276.686,
["mapId"] = 2552,
["combat_id"] = 266,
["overall_added"] = true,
["frags"] = {
},
["is_challenge"] = false,
["spells_cast_timeline"] = {
},
["raid_roster"] = {
["Дракобес"] = "Player-1604-0F4AC394",
},
["combat_counter"] = 372,
["totals_grupo"] = {
314938,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
{
},
},
["damage"] = {
{
["Дракобес"] = 314938.001067,
},
},
},
["start_time"] = 21269.724,
["TimeData"] = {
},
["playerTalents"] = {
},
},
},
},
["ocd_tracker"] = {
["show_title"] = true,
["current_cooldowns"] = {
},
["lines_per_column"] = 12,
["group_frames"] = true,
["show_options"] = false,
["frames"] = {
["defensive-raid"] = {
},
["main"] = {
},
["ofensive"] = {
},
["defensive-target"] = {
},
["utility"] = {
},
["defensive-personal"] = {
},
},
["width"] = 120,
["ignored_cooldowns"] = {
},
["cooldowns"] = {
},
["height"] = 18,
["own_frame"] = {
["defensive-raid"] = false,
["ofensive"] = false,
["defensive-target"] = false,
["utility"] = false,
["defensive-personal"] = false,
},
["framme_locked"] = false,
["show_conditions"] = {
["only_inside_instance"] = true,
["only_in_group"] = true,
},
["enabled"] = false,
["filters"] = {
["itemutil"] = false,
["itempower"] = false,
["defensive-target"] = false,
["itemheal"] = false,
["defensive-personal"] = false,
["defensive-raid"] = false,
["ofensive"] = true,
["crowdcontrol"] = false,
["utility"] = false,
},
},
["last_version"] = "11.0.2 13072",
["player_stats"] = {
},
["force_font_outline"] = "",
["tabela_instancias"] = {
},
["coach"] = {
["enabled"] = false,
["welcome_panel_pos"] = {
},
["last_coach_name"] = false,
},
["local_instances_config"] = {
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 2,
["pos"] = {
["normal"] = {
["y"] = -257.0172424316406,
["x"] = 851.7876586914062,
["w"] = 244.8981781005859,
["h"] = 100.9114608764648,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
5,
1,
},
["snap"] = {
[2] = 3,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -376.4429016113281,
["x"] = 851.2880249023438,
["w"] = 245.8994140625,
["h"] = 100.9109649658203,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
[4] = 2,
},
["segment"] = -1,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -497.3539161682129,
["x"] = 851.2880249023438,
["w"] = 245.8991394042969,
["h"] = 100.9110717773438,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
},
["cached_talents"] = {
},
["last_instance_id"] = 2649,
["data_harvest_for_charsts"] = {
["players"] = {
{
["playerKey"] = "total",
["combatObjectContainer"] = 1,
["name"] = "Damage of Each Individual Player",
["playerOnly"] = true,
},
},
["totals"] = {
{
["combatObjectSubTableKey"] = 1,
["name"] = "Damage of All Player Combined",
["combatObjectSubTableName"] = "totals",
},
},
},
["announce_interrupts"] = {
["enabled"] = false,
["whisper"] = "",
["channel"] = "SAY",
["custom"] = "",
["next"] = "",
},
["announce_prepots"] = {
["enabled"] = false,
["channel"] = "SELF",
["reverse"] = false,
},
["active_profile"] = "beamladen",
["mythic_dungeon_currentsaved"] = {
["dungeon_name"] = "",
["started"] = false,
["segment_id"] = 0,
["ej_id"] = 0,
["started_at"] = 0,
["run_id"] = 0,
["level"] = 0,
["dungeon_zone_id"] = 0,
["previous_boss_killed_at"] = 0,
},
["benchmark_db"] = {
["frame"] = {
},
},
["combat_log"] = {
["inverse_deathlog_overalldata"] = false,
["merge_gemstones_1007"] = false,
["track_hunter_frenzy"] = false,
["merge_critical_heals"] = false,
["inverse_deathlog_raid"] = false,
["calc_evoker_damage"] = true,
["evoker_show_realtimedps"] = false,
["inverse_deathlog_mplus"] = false,
},
["ignore_nicktag"] = false,
["mythic_plus_log"] = {
},
["combat_counter"] = 373,
["announce_damagerecord"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["data_harvested_for_charts"] = {
},
["on_death_menu"] = false,
["announce_firsthit"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["last_realversion"] = 161,
["last_instance_time"] = 1725490413,
["combat_id"] = 267,
["savedStyles"] = {
},
["last_day"] = "28",
["character_data"] = {
["logons"] = 10,
},
["announce_deaths"] = {
["enabled"] = false,
["last_hits"] = 1,
["only_first"] = 5,
["where"] = 1,
},
["tabela_overall"] = {
{
["tipo"] = 2,
["_ActorTable"] = {
{
["flag_original"] = 1297,
["totalabsorbed"] = 0.019868,
["pets"] = {
},
["aID"] = "1604-0F4AC394",
["total_without_pet"] = 2400186.019868,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 2400186.019868,
["spec"] = 1467,
["colocacao"] = 1,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Player-1604-0F4AC394",
["damage_from"] = {
},
["targets"] = {
["Водоросляк"] = 2400186,
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["end_time"] = 1727456936,
["friendlyfire"] = {
},
["nome"] = "Дракобес",
["spells"] = {
["_ActorTable"] = {
[370898] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 0,
["targets"] = {
["Водоросляк"] = 0,
},
["n_total"] = 0,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 26,
["total"] = 0,
["c_max"] = 0,
["IMMUNE"] = 26,
["id"] = 370898,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 0,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[370452] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 130989,
["targets"] = {
["Водоросляк"] = 130989,
},
["n_total"] = 130989,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 130989,
["c_max"] = 0,
["id"] = 370452,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 1,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[357212] = {
["c_amt"] = 1,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 121784,
["targets"] = {
["Водоросляк"] = 638036,
},
["n_total"] = 336365,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 4,
["total"] = 638036,
["c_max"] = 301671,
["id"] = 357212,
["r_dmg"] = 0,
["spellschool"] = 4,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 301671,
["n_amt"] = 3,
["b_dmg"] = 0,
["r_amt"] = 0,
},
[359077] = {
["c_amt"] = 0,
["b_amt"] = 0,
["g_amt"] = 0,
["b_dmg"] = 0,
["targets"] = {
["Водоросляк"] = 192068,
},
["n_total"] = 192068,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 1,
["total"] = 192068,
["c_max"] = 0,
["id"] = 359077,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 0,
["n_amt"] = 1,
["n_max"] = 192068,
["r_amt"] = 0,
},
[356995] = {
["c_amt"] = 1,
["b_amt"] = 0,
["g_amt"] = 0,
["n_max"] = 154415,
["targets"] = {
["Водоросляк"] = 1439093,
},
["n_total"] = 1198154,
["n_min"] = 0,
["g_dmg"] = 0,
["counter"] = 11,
["total"] = 1439093,
["c_max"] = 240939,
["id"] = 356995,
["r_dmg"] = 0,
["spellschool"] = 80,
["extra"] = {
},
["a_dmg"] = 0,
["a_amt"] = 0,
["c_min"] = 0,
["successful_casted"] = 0,
["c_total"] = 240939,
["n_amt"] = 10,
["b_dmg"] = 0,
["r_amt"] = 0,
},
},
["tipo"] = 2,
},
["grupo"] = true,
["classe"] = "EVOKER",
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 0.019868,
["start_time"] = 1727456903,
["delay"] = 0,
["last_dps"] = 81351.20728945003,
},
{
["flag_original"] = 68136,
["pets"] = {
},
["aID"] = "225985",
["total_without_pet"] = 0.025573,
["last_dps_realtime"] = 0,
["dps_started"] = false,
["total"] = 0.025573,
["on_hold"] = false,
["total_extra"] = 0,
["serial"] = "Creature-0-3774-2552-24390-225985-000076BCBE",
["damage_from"] = {
["Дракобес"] = true,
},
["targets"] = {
},
["friendlyfire_total"] = 0,
["raid_targets"] = {
},
["classe"] = "UNKNOW",
["fight_component"] = true,
["end_time"] = 1727456936,
["totalabsorbed"] = 0.025573,
["nome"] = "Водоросляк",
["spells"] = {
["_ActorTable"] = {
},
["tipo"] = 2,
},
["friendlyfire"] = {
},
["tipo"] = 1,
["custom"] = 0,
["last_event"] = 0,
["damage_taken"] = 2400186.025573,
["start_time"] = 1727456933,
["delay"] = 0,
["last_dps"] = 0,
},
},
},
{
["tipo"] = 3,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["_ActorTable"] = {
{
["flag_original"] = 1047,
["debuff_uptime_spells"] = {
["_ActorTable"] = {
[356995] = {
["refreshamt"] = 0,
["activedamt"] = 0,
["appliedamt"] = 4,
["id"] = 356995,
["uptime"] = 7,
["targets"] = {
},
["counter"] = 0,
},
[370452] = {
["refreshamt"] = 0,
["activedamt"] = 0,
["appliedamt"] = 1,
["id"] = 370452,
["uptime"] = 4,
["targets"] = {
},
["counter"] = 0,
},
},
["tipo"] = 9,
},
["buff_uptime"] = 101,
["classe"] = "EVOKER",
["buff_uptime_spells"] = {
["_ActorTable"] = {
[441248] = {
["refreshamt"] = 27,
["activedamt"] = 3,
["appliedamt"] = 3,
["id"] = 441248,
["uptime"] = 30,
["targets"] = {
},
["counter"] = 0,
},
[359618] = {
["refreshamt"] = 0,
["activedamt"] = 2,
["appliedamt"] = 2,
["id"] = 359618,
["uptime"] = 3,
["targets"] = {
},
["counter"] = 0,
},
[186403] = {
["refreshamt"] = 0,
["activedamt"] = 3,
["appliedamt"] = 3,
["id"] = 186403,
["uptime"] = 30,
["targets"] = {
},
["counter"] = 0,
},
[375802] = {
["refreshamt"] = 0,
["activedamt"] = 6,
["appliedamt"] = 6,
["id"] = 375802,
["uptime"] = 30,
["targets"] = {
},
["counter"] = 0,
},
[370454] = {
["refreshamt"] = 14,
["activedamt"] = 6,
["appliedamt"] = 6,
["id"] = 370454,
["uptime"] = 8,
["targets"] = {
},
["counter"] = 0,
},
},
["tipo"] = 9,
},
["debuff_uptime"] = 11,
["nome"] = "Дракобес",
["debuff_uptime_targets"] = {
},
["buff_uptime_targets"] = {
},
["spec"] = 1467,
["grupo"] = true,
["pets"] = {
},
["tipo"] = 4,
["last_event"] = 0,
["serial"] = "Player-1604-0F4AC394",
["aID"] = "1604-0F4AC394",
},
},
},
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["tempo_start"] = 1727456921,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["playerTalents"] = {
},
["totals"] = {
6369591.063257,
0.010163,
{
0,
[0] = 0.003814,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["totals_grupo"] = {
2400186.011412,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["cooldowns_defensive"] = 0,
["dispell"] = 0,
["interrupt"] = 0,
["debuff_uptime"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["overall_refreshed"] = true,
["amountCasts"] = {
["Дракобес"] = {
["Дезинтеграция"] = 1,
["Сокрушающая звезда"] = 1,
["Погребальный костер"] = 4,
},
},
["zoneName"] = "Каз Алгар (поверхность)",
["data_fim"] = "21:11:29",
["cleu_timeline"] = {
},
["trinketProcs"] = {
},
["aura_timeline"] = {
},
["PhaseData"] = {
{
1,
1,
},
["damage_section"] = {
},
["heal_section"] = {
},
["heal"] = {
},
["damage"] = {
},
},
["end_time"] = 21307.319,
["mapId"] = 2552,
["boss_hp"] = 1,
["combat_counter"] = 370,
["is_challenge"] = false,
["frags"] = {
},
["player_last_events"] = {
},
["overall_enemy_name"] = "Водоросляк",
["segments_added"] = {
{
["elapsed"] = 8.656999999999243,
["type"] = 0,
["name"] = "Водоросляк",
["clock"] = "21:11:20",
},
{
["elapsed"] = 6.961999999999534,
["type"] = 0,
["name"] = "Водоросляк",
["clock"] = "21:10:51",
},
{
["elapsed"] = 13.8849999999984,
["type"] = 0,
["name"] = "Водоросляк",
["clock"] = "21:08:42",
},
},
["data_inicio"] = "21:08:42",
["start_time"] = 21277.815,
["TimeData"] = {
["Raid Damage Done"] = {
},
},
["spells_cast_timeline"] = {
},
},
["plugin_database"] = {
["DETAILS_PLUGIN_TINY_THREAT"] = {
["enabled"] = true,
["animate"] = false,
["hide_pull_bar"] = false,
["author"] = "Terciob",
["playercolor"] = {
1,
1,
1,
},
["usefocus"] = false,
["updatespeed"] = 1,
["useclasscolors"] = false,
["showamount"] = false,
["useplayercolor"] = false,
["absolute_mode"] = false,
["playSound"] = false,
["playSoundFile"] = "Details Threat Warning Volume 3",
["disable_gouge"] = false,
},
["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
["enabled"] = true,
["author"] = "Terciob",
["max_compares"] = 4,
["compare_type"] = 1,
},
["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
["enabled"] = true,
["last_boss"] = false,
["author"] = "Details! Team",
["captures"] = {
false,
true,
true,
true,
},
["timeline_cutoff_delete_time"] = 3,
["last_player"] = false,
["max_deaths_for_current"] = 20,
["max_deaths_for_timeline"] = 5,
["last_encounter_hash"] = false,
["endurance_threshold"] = 3,
["timeline_cutoff_time"] = 3,
["last_segment"] = false,
["show_icon"] = 1,
["InstalledAt"] = 1724710209,
["max_segments_for_current"] = 2,
["showing_type"] = 4,
},
["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
["enabled"] = true,
["encounter_timers_bw"] = {
},
["max_emote_segments"] = 3,
["last_section_selected"] = "main",
["author"] = "Terciob",
["window_scale"] = 1,
["encounter_timers_dbm"] = {
},
["show_icon"] = 5,
["opened"] = 0,
["hide_on_combat"] = false,
},
["DETAILS_PLUGIN_RAIDCHECK"] = {
["enabled"] = true,
["food_tier1"] = true,
["mythic_1_4"] = true,
["food_tier2"] = true,
["author"] = "Terciob",
["use_report_panel"] = true,
["pre_pot_healers"] = false,
["pre_pot_tanks"] = false,
["food_tier3"] = true,
},
["DETAILS_PLUGIN_VANGUARD"] = {
["tank_block_size_height"] = 50,
["show_power_bar"] = false,
["first_run"] = false,
["aura_timer_text_size"] = 14,
["tank_block_castbar_size_height"] = 16,
["show_health_bar"] = true,
["aura_offset_y"] = 0,
["enabled"] = true,
["show_cast_bar"] = false,
["author"] = "Terciob",
["tank_block_size"] = 150,
["bar_height"] = 24,
["tank_block_texture"] = "Details Serenity",
["show_inc_bars"] = true,
["tank_block_powerbar_size_height"] = 10,
["tank_block_height"] = 40,
["tank_block_color"] = {
0.074509,
0.035294,
0.035294,
0.832845,
},
},
["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
["use_square_mode"] = false,
["is_first_run"] = false,
["grow_direction"] = "right",
["arrow_color"] = {
1,
1,
1,
0.5,
},
["main_frame_size"] = {
306.8570556640625,
100.0000076293945,
},
["arrow_anchor_y"] = 0,
["minimap"] = {
["minimapPos"] = 160,
["radius"] = 160,
["hide"] = true,
},
["main_frame_locked"] = true,
["arrow_anchor_x"] = 0,
["author"] = "Terciob",
["row_texture"] = "Melli",
["square_grow_direction"] = "right",
["font_size"] = 11,
["row_color"] = {
0.1019607931375504,
0.1019607931375504,
0.1019607931375504,
0.4000000357627869,
},
["square_amount"] = 5,
["enabled"] = true,
["arrow_size"] = 14,
["use_spark"] = false,
["row_spacement"] = 20,
["main_frame_color"] = {
0,
0,
0,
0,
},
["main_frame_strata"] = "LOW",
["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
["per_second"] = {
["enabled"] = false,
["point"] = "CENTER",
["scale"] = 1,
["font_shadow"] = true,
["y"] = 0.00018310546875,
["x"] = -3.0517578125e-05,
["attribute_type"] = 2,
["update_speed"] = 0.05,
["size"] = 32,
},
["y"] = 0.7619104385375977,
["x"] = -248.4752197265625,
["font_face"] = "ITCAvantGardeGothicDemi",
["square_size"] = 32,
["point"] = "BOTTOMRIGHT",
["font_color"] = {
1,
1,
1,
1,
},
["row_height"] = 20,
["scale"] = 1,
},
},
["SoloTablesSaved"] = {
["Mode"] = 1,
},
["nick_tag_cache"] = {
["nextreset"] = 1728752539,
["last_version"] = 16,
},
["announce_cooldowns"] = {
["ignored_cooldowns"] = {
},
["enabled"] = false,
["custom"] = "",
["channel"] = "RAID",
},
["rank_window"] = {
["last_difficulty"] = 15,
["last_raid"] = "",
},
["cached_roles"] = {
},
["cached_specs"] = {
["Player-1604-0F4AC394"] = 1473,
["Player-1604-0F9C81A1"] = 62,
},
}
