
PremadeGroupsFilterSettings = {
["signupOnEnter"] = false,
["classNamesInTooltip"] = true,
["rioRatingColors"] = true,
["dialogMovable"] = true,
["ratingInfo"] = true,
["specIcon"] = false,
["oneClickSignUp"] = true,
["coloredGroupTexts"] = true,
["leaderCrown"] = true,
["missingRoles"] = false,
["version"] = 3,
["classBar"] = true,
["signUpDeclined"] = true,
["classCircle"] = false,
["skipSignUpDialog"] = false,
["persistSignUpNote"] = true,
}
