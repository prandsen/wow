
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["VERSION"] = 113,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[66419] = true,
[64531] = true,
[81767] = true,
[64273] = true,
[76586] = true,
[82448] = true,
[82254] = true,
[82225] = true,
[81806] = true,
[75257] = true,
},
["Filter"] = 63,
},
["Сорчистино-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Мальдика-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
[82292] = true,
[81804] = true,
[81639] = true,
[82455] = true,
[82291] = true,
[81675] = true,
},
["VERSION"] = 112,
},
["Вольтчара-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["Filter"] = 63,
["Quests"] = {
[81767] = true,
[78995] = true,
[81824] = true,
[82468] = true,
[82332] = true,
[61411] = true,
[83537] = true,
[61815] = true,
},
["VERSION"] = 113,
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Sort"] = 5,
["VERSION"] = 113,
["Алианкано-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Сэйвмэн-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 113,
["Quests"] = {
[76586] = true,
[59600] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["Дракобес-СвежевательДуш"] = {
["VERSION"] = 113,
["FilterType"] = {
},
["Quests"] = {
[74837] = true,
[70634] = true,
[70652] = true,
[71164] = true,
[70149] = true,
[70424] = true,
[70067] = true,
},
["Filter"] = 63,
},
["Топмэн-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["SortPrio"] = {
},
["Ignore"] = {
},
["Вантачмэн-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[74835] = true,
[52196] = true,
[49345] = true,
[73146] = true,
[54896] = true,
[82295] = true,
[51612] = true,
[66551] = true,
[82456] = true,
[82586] = true,
[71180] = true,
[70068] = true,
[55466] = true,
[52756] = true,
[72029] = true,
[82292] = true,
[50497] = true,
[69927] = true,
[58743] = true,
[71140] = true,
[51297] = true,
[75280] = true,
[58747] = true,
},
["VERSION"] = 113,
},
["Beamladen-TwistingNether"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 113,
},
["AzeriteFormat"] = 20,
["Прециза-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["HideLegion"] = true,
}
