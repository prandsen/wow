
SavedInstancesDB = {
["Toons"] = {
["Beamladen - Twisting Nether"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
},
["Race"] = "Nightborne",
["LClass"] = "Mage",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[5] = 0,
[2] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 8,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "Nightborne",
["LastSeen"] = 1728925718,
["Order"] = 50,
["Class"] = "MAGE",
["ILPvp"] = 8,
["currency"] = {
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 3,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
},
["Warmode"] = false,
["Progress"] = {
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["df-trial-of-elements"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["bfa-island"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-sparks-of-life"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
},
["Level"] = 10,
["XP"] = 0,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1729655999,
},
["MythicKey"] = {
},
["PlayedTotal"] = 792,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1729310399,
["Money"] = 10000,
["MaxXP"] = 8490,
["IL"] = 8,
["Covenant"] = 0,
["MythicPlusScore"] = 0,
["SpecializationIDs"] = {
62,
63,
64,
105,
},
["PlayedLevel"] = 792,
["Zone"] = "Orgrimmar",
["RestXP"] = 1000,
["Skills"] = {
},
["WeeklyResetTime"] = 1729655999,
["Calling"] = {
},
},
["Мальдика - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Жрица",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["lastbosstime"] = 1725540758,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 509.6875,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 514.75,
["Zone"] = "Дорногал",
["Order"] = 50,
["Class"] = "PRIEST",
["ILPvp"] = 514.75,
["Covenant"] = 3,
["currency"] = {
[1191] = {
["amount"] = 0,
},
[1904] = {
["totalEarned"] = 1779,
["totalMax"] = 3510,
["amount"] = 109,
},
[1719] = {
["amount"] = 2469,
},
[1979] = {
["amount"] = 522,
},
[2706] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1885] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 2,
},
[2707] = {
["amount"] = 0,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[2708] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 15,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 27,
},
[1977] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 1630,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1560] = {
["amount"] = 5617,
},
[2009] = {
["amount"] = 47052,
},
[1828] = {
["amount"] = 59010,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 250,
},
[1718] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[1822] = {
["covenant"] = {
[3] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1810] = {
["covenant"] = {
[3] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 2290,
},
[2000] = {
["amount"] = 44,
},
[1716] = {
["amount"] = 100,
},
[1813] = {
["covenant"] = {
[3] = 33190,
},
["totalMax"] = 200000,
["amount"] = 33190,
},
[1906] = {
["amount"] = 8970,
},
[2774] = {
["amount"] = 17,
},
},
["oRace"] = "BloodElf",
["Warmode"] = false,
["Skills"] = {
},
["Level"] = 80,
["MythicKey"] = {
},
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1729655999,
},
["PlayedTotal"] = 3896971,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1725540758,
["MaxXP"] = 100000000,
["Money"] = 391374500,
["WeeklyResetTime"] = 1729655999,
["MythicPlusScore"] = 0,
["lastboss"] = "Скардинское чудовище: Обычный",
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["PlayedLevel"] = 54,
["LastSeen"] = 1725797896,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729310399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729396799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729483199,
},
["unlocked"] = true,
},
["DailyResetTime"] = 1729310399,
["lastbossyell"] = "Чудище камня Бездны: Обычный",
["SpecializationIDs"] = {
256,
257,
258,
},
},
["Вантачмэн - Ревущий фьорд"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Монахиня",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["lastbosstime"] = 1725626435,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729310399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729396799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729483199,
},
["unlocked"] = true,
},
["ILe"] = 516.25,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 548.4375,
["Zone"] = "Дорногал",
["Order"] = 50,
["Class"] = "MONK",
["ILPvp"] = 548.4375,
["WeeklyResetTime"] = 1729655999,
["currency"] = {
[2413] = {
["amount"] = 27,
},
[2815] = {
["amount"] = 0,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[1719] = {
["amount"] = 9929,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 68,
},
[2650] = {
["amount"] = 9,
},
[2706] = {
["amount"] = 0,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1810] = {
["covenant"] = {
[4] = 9,
},
["totalMax"] = 100,
["amount"] = 9,
},
[2777] = {
["amount"] = 1,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 18769,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[2707] = {
["amount"] = 0,
},
[1767] = {
["amount"] = 15729,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[738] = {
["amount"] = 2,
},
[1275] = {
["amount"] = 69,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 93,
},
[1220] = {
["amount"] = 20273,
},
[1602] = {
["totalMax"] = 2800,
["amount"] = 0,
},
[2003] = {
["amount"] = 2139,
},
[1906] = {
["amount"] = 0,
},
[1803] = {
["amount"] = 2173,
},
[1977] = {
["amount"] = 51,
},
[2708] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 915,
},
[2409] = {
["totalEarned"] = 160,
["amount"] = 160,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 330,
},
[2774] = {
["amount"] = 20,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 693,
},
[1166] = {
["amount"] = 5830,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 1,
},
[2410] = {
["totalEarned"] = 103,
["amount"] = 103,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[3056] = {
["amount"] = 450,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1716] = {
["amount"] = 342,
},
[1560] = {
["amount"] = 39597,
},
[2915] = {
["totalEarned"] = 8,
["totalMax"] = 540,
["amount"] = 63,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 14,
},
[2411] = {
["totalEarned"] = 186,
["amount"] = 186,
},
[1828] = {
["amount"] = 21950,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 2,
},
[1710] = {
["amount"] = 632,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 2,
},
[1718] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 252,
},
[2412] = {
["totalEarned"] = 580,
["amount"] = 580,
},
[1226] = {
["amount"] = 12160,
},
[3023] = {
["totalEarned"] = 2,
["totalMax"] = 5,
["amount"] = 2,
},
[2914] = {
["totalEarned"] = 16,
["totalMax"] = 540,
["amount"] = 91,
},
[1931] = {
["amount"] = 7485,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1813] = {
["covenant"] = {
[4] = 42597,
},
["totalMax"] = 200000,
["amount"] = 42597,
},
[3028] = {
["relatedItemCount"] = 25,
["amount"] = 4,
},
[1191] = {
["amount"] = 0,
},
},
["LastSeen"] = 1727457015,
["Warmode"] = false,
["DailyResetTime"] = 1729310399,
["Level"] = 80,
["oRace"] = "BloodElf",
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1729655999,
},
["PlayedTotal"] = 8923575,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1725627381,
["Money"] = 6243639215,
["Covenant"] = 4,
["MythicKey"] = {
},
["Progress"] = {
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
"Соберите странные сгустки воска: 2/10",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 10,
["leaderboardCount"] = 1,
["text"] = "2/10",
["objectiveType"] = "monster",
["numFulfilled"] = 2,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["lastboss"] = "Вестник Бездны Эйрих: Обычный",
["PlayedLevel"] = 8884,
["MaxXP"] = 100000000,
["SpecializationIDs"] = {
268,
270,
269,
},
["Skills"] = {
},
["lastbossyell"] = "Глашатай Бреция",
["Faction"] = "Horde",
},
["Дракобес - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
},
["Race"] = "Драктир",
["LClass"] = "Пробудитель",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
},
["lastbosstime"] = 1725490972,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 503.5,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "Dracthyr",
["LastSeen"] = 1727529307,
["Order"] = 50,
["Class"] = "EVOKER",
["ILPvp"] = 544,
["lastbossyell"] = "Настоятельница Муррпрэй: Обычный",
["currency"] = {
[1191] = {
["amount"] = 0,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 2,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 15,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2003] = {
["amount"] = 3880,
},
},
["IL"] = 544,
["Warmode"] = false,
["DailyResetTime"] = 1729310399,
["Level"] = 80,
["MaxXP"] = 100000000,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 917367,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1725490972,
["Money"] = 78531078,
["WeeklyResetTime"] = 1729655999,
["Covenant"] = 0,
["MythicPlusScore"] = 0,
["lastboss"] = "Настоятельница Муррпрэй: Обычный",
["Progress"] = {
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-secured-shipment"] = {
["show"] = false,
},
},
["PlayedLevel"] = 963,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1729655999,
},
["SpecializationIDs"] = {
1467,
1468,
1473,
},
["Skills"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729310399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729396799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729483199,
},
["unlocked"] = true,
},
["Zone"] = "Дорногал",
},
["Вольтчара - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сундук Кирин-Тора",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["quantity"] = 600,
["currencyID"] = 1553,
},
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
},
},
},
},
["Race"] = "Тауренка",
["LClass"] = "Шаманка",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
[3] = 0,
},
["lastbosstime"] = 1729187138,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["lastbossyell"] = "Глашатай Бреция",
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Обучение в Малдраксусе",
["questID"] = 60407,
["expiredTime"] = 1729310399,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Призыв Малдраксуса",
["questID"] = 60430,
["expiredTime"] = 1729396799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Испытания Малдраксуса",
["questID"] = 60447,
["expiredTime"] = 1729483199,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["ILe"] = 625.75,
["Faction"] = "Horde",
["Quests"] = {
[82496] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Город Нитей",
["Link"] = "|cffffff00|Hquest:82496:90|h[Душа мира: Город Нитей]|h|r",
},
[82500] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Гнездовье",
["Link"] = "|cffffff00|Hquest:82500:90|h[Душа мира: Гнездовье]|h|r",
},
[82659] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Неруб'арский дворец",
["Link"] = "|cffffff00|Hquest:82659:90|h[Душа мира: Неруб'арский дворец]|h|r",
},
[82506] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: расселина Темного Пламени",
["Link"] = "|cffffff00|Hquest:82506:90|h[Душа мира: расселина Темного Пламени]|h|r",
},
[82512] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: босс вне подземелья",
["Link"] = "|cffffff00|Hquest:82512:90|h[Душа мира: босс вне подземелья]|h|r",
},
[82452] = {
["Expires"] = 1729655999,
["Link"] = "|cffffff00|Hquest:82452:90|h[Воспоминание души мира: локальные задания]|h|r",
["Title"] = "Воспоминание души мира: локальные задания",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82516] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: заключение пакта",
["Link"] = "|cffffff00|Hquest:82516:90|h[Душа мира: заключение пакта]|h|r",
},
[82491] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Ара-Кара, Город Отголосков",
["Link"] = "|cffffff00|Hquest:82491:90|h[Душа мира: Ара-Кара, Город Отголосков]|h|r",
},
[82493] = {
["Expires"] = 1729655999,
["Link"] = "|cffffff00|Hquest:82493:90|h[Душа мира: \"Сияющий Рассвет\"]|h|r",
["Title"] = "Душа мира: \"Сияющий Рассвет\"",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82495] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Искроварня",
["Link"] = "|cffffff00|Hquest:82495:90|h[Душа мира: Искроварня]|h|r",
},
[82499] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: приорат Священного Пламени",
["Link"] = "|cffffff00|Hquest:82499:90|h[Душа мира: приорат Священного Пламени]|h|r",
},
[82505] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Каменный Свод",
["Link"] = "|cffffff00|Hquest:82505:90|h[Душа мира: Каменный Свод]|h|r",
},
[82511] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Машина пробуждения",
["Link"] = "|cffffff00|Hquest:82511:90|h[Душа мира: Машина пробуждения]|h|r",
},
[82482] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: разнюхивание",
["Link"] = "|cffffff00|Hquest:82482:90|h[Душа мира: разнюхивание]|h|r",
},
[82453] = {
["Expires"] = 1729655999,
["Title"] = "Воспоминание души мира: на бис!",
["Link"] = "|cffffff00|Hquest:82453:90|h[Воспоминание души мира: на бис!]|h|r",
},
[82483] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: благодать Света",
["Link"] = "|cffffff00|Hquest:82483:90|h[Душа мира: благодать Света]|h|r",
},
[82449] = {
["Expires"] = 1729655999,
["Title"] = "Зов души мира",
["Link"] = "|cffffff00|Hquest:82449:90|h[Зов души мира]|h|r",
},
},
["Paragon"] = {
},
["IL"] = 626.375,
["Zone"] = "Дорногал",
["Order"] = 50,
["Class"] = "SHAMAN",
["ILPvp"] = 626.375,
["WeeklyResetTime"] = 1729655999,
["currency"] = {
[1191] = {
["amount"] = 0,
},
[2815] = {
["amount"] = 4589,
},
[1904] = {
["totalEarned"] = 3510,
["amount"] = 0,
["totalMax"] = 3510,
},
[3028] = {
["amount"] = 4,
["relatedItemCount"] = 0,
},
[2917] = {
["totalEarned"] = 482,
["amount"] = 32,
["totalMax"] = 540,
},
[1979] = {
["amount"] = 807,
},
[3023] = {
["totalEarned"] = 7,
["amount"] = 7,
["totalMax"] = 8,
},
[1810] = {
["covenant"] = {
7,
},
["amount"] = 7,
["totalMax"] = 100,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1885] = {
["amount"] = 21,
},
[1767] = {
["amount"] = 28146,
},
[2915] = {
["totalEarned"] = 720,
["amount"] = 375,
["totalMax"] = 810,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
["totalMax"] = 4600,
},
[2000] = {
["amount"] = 37,
},
[2803] = {
["amount"] = 3187,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1077,
},
[1906] = {
["amount"] = 7480,
},
[2914] = {
["totalEarned"] = 402,
["amount"] = 312,
["totalMax"] = 810,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1166] = {
["amount"] = 2775,
},
[1822] = {
["covenant"] = {
80,
},
["amount"] = 80,
["totalMax"] = 80,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1560] = {
["amount"] = 3,
},
[2009] = {
["amount"] = 38086,
},
[1828] = {
["amount"] = 96655,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 2,
},
[3056] = {
["amount"] = 4800,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[2916] = {
["totalEarned"] = 450,
["amount"] = 80,
["totalMax"] = 540,
},
[1977] = {
["amount"] = 16,
},
[1931] = {
["amount"] = 1579,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1813] = {
["covenant"] = {
140482,
},
["amount"] = 140482,
["totalMax"] = 200000,
},
[1533] = {
["amount"] = 1092,
},
},
["LastSeen"] = 1729274343,
["Warmode"] = false,
["Skills"] = {
},
["Level"] = 80,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
["mapID"] = 507,
["name"] = "Грим Батол",
["link"] = "|cffa335ee|Hkeystone:180653:507:12:9:152:10:147|h[Ключ: Грим Батол (12)]|h|r",
["color"] = "ffa335ee",
["level"] = 12,
["ResetTime"] = 1729655999,
},
["PlayedTotal"] = 4757073,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1729274197,
["Money"] = 2050693184,
["MaxXP"] = 100000000,
["lastboss"] = "Скованный кровью ужас: Эпохальный",
["MythicPlusScore"] = 2805,
["SpecializationIDs"] = {
262,
263,
264,
},
["PlayedLevel"] = 619903,
["MythicKeyBest"] = {
10,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Туманы Тирна Скитта",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 375,
["runScore"] = 326,
["rewardLevel"] = 623,
},
},
["ResetTime"] = 1729655999,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 1,
},
["Progress"] = {
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["great-vault-raid"] = {
16,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = true,
["isComplete"] = true,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["The Severed Threads"] = {
"Выполняйте задачи в Аз-Кахете (0%)",
"Осмотрите товары пактов у поставщицы Ямас: 0/1 (необязательно)",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 100,
["leaderboardCount"] = 2,
["text"] = "0% 0/1",
["objectiveType"] = "progressbar",
["numFulfilled"] = 0,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-time-rift"] = {
["show"] = false,
},
},
["DailyResetTime"] = 1729310399,
["oRace"] = "Tauren",
["Covenant"] = 1,
},
["Алианкано - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Охотник на демонов",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 327,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 327,
["LastSeen"] = 1725797846,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 18390/36000",
["show"] = true,
["numFulfilled"] = 18390,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "18390/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "DEMONHUNTER",
["ILPvp"] = 327,
["currency"] = {
[1602] = {
["amount"] = 0,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1719] = {
["amount"] = 2193,
},
[1710] = {
["amount"] = 92,
},
[1803] = {
["amount"] = 85,
},
[1716] = {
["amount"] = 159,
},
[1560] = {
["amount"] = 2,
},
[1166] = {
["amount"] = 495,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1721] = {
["amount"] = 93,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 5195,
},
[1533] = {
["amount"] = 5,
},
[1718] = {
["amount"] = 0,
},
[1220] = {
["amount"] = 4243,
},
},
["SpecializationIDs"] = {
577,
581,
},
["Warmode"] = true,
["MythicKey"] = {
},
["Level"] = 60,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1729655999,
},
["RestXP"] = 83498,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["Money"] = 21231,
["oRace"] = "BloodElf",
["MaxXP"] = 55665,
["Covenant"] = 1,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1729655999,
["PlayedLevel"] = 2244,
["PlayedTotal"] = 1296590,
["Order"] = 50,
["DailyResetTime"] = 1729310399,
["Calling"] = {
},
["Zone"] = "Оргриммар",
},
["Сорчистино - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Чернокнижница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 184.125,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 191.75,
["LastSeen"] = 1725797811,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "WARLOCK",
["ILPvp"] = 191.75,
["currency"] = {
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 40,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 442,
},
[1710] = {
["amount"] = 4,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 1265,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 195,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 45,
},
[1560] = {
["amount"] = 1041,
},
[1220] = {
["amount"] = 5255,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 5728,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 4,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 12450,
},
[1226] = {
["amount"] = 11010,
},
[1275] = {
["amount"] = 150,
},
[1166] = {
["amount"] = 2165,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 46,
},
[1719] = {
["amount"] = 122,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1729655999,
},
["Warmode"] = false,
["PlayedTotal"] = 3075591,
["Level"] = 60,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["RestXP"] = 83498,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["MaxXP"] = 55665,
["Money"] = 178639,
["oRace"] = "BloodElf",
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1729655999,
["PlayedLevel"] = 7184,
["SpecializationIDs"] = {
265,
266,
267,
},
["Calling"] = {
},
["DailyResetTime"] = 1729310399,
["Order"] = 50,
["Zone"] = "Орибос",
},
["Топмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Маг",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 453.8125,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1729655999,
["LastSeen"] = 1725797746,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"1/1 Продолжите кампанию \"Хранители Сна\", чтобы открыть Изумрудный Сон",
"Получите цветок во время Цветочного бума: 0/50",
"Завершите Цветочный бум: 0/1",
"0/3000 Повысьте репутацию среди фракций Драконьих островов",
["show"] = true,
["numFulfilled"] = 1,
["numRequired"] = 1,
["isComplete"] = false,
["leaderboardCount"] = 4,
["text"] = "1/1 0/50 0/1 0/3000",
["objectiveType"] = "object",
["isFinish"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["Class"] = "MAGE",
["ILPvp"] = 454.1875,
["currency"] = {
[824] = {
["totalMax"] = 10000,
["amount"] = 304,
},
[2650] = {
["amount"] = 50,
},
[2706] = {
["amount"] = 0,
},
[2003] = {
["amount"] = 647,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 9553,
},
[1822] = {
["covenant"] = {
[3] = 6,
},
["totalMax"] = 80,
["amount"] = 6,
},
[1889] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 3502,
},
[2707] = {
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 208,
},
[1220] = {
["amount"] = 7992,
},
[1803] = {
["amount"] = 4344,
},
[2409] = {
["totalEarned"] = 83,
["amount"] = 83,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 302,
},
[2118] = {
["amount"] = 50,
},
[2413] = {
["amount"] = 27,
},
[1719] = {
["amount"] = 725,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 112,
},
[2410] = {
["totalEarned"] = 124,
["amount"] = 124,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 3175,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 1410,
},
[1885] = {
["amount"] = 2,
},
[2411] = {
["totalEarned"] = 196,
["amount"] = 196,
},
[1275] = {
["amount"] = 190,
},
[1828] = {
["amount"] = 30,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 2,
},
[1710] = {
["amount"] = 7,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 6,
},
[1718] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 900,
["amount"] = 204,
},
[2412] = {
["totalEarned"] = 36,
["amount"] = 36,
},
[1226] = {
["amount"] = 23153,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1533] = {
["amount"] = 1223,
},
[2774] = {
["amount"] = 3,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 11,
},
[1813] = {
["covenant"] = {
[3] = 124,
},
["totalMax"] = 200000,
["amount"] = 124,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 170,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
},
["oRace"] = "BloodElf",
["Warmode"] = false,
["Order"] = 50,
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1729655999,
},
["RestXP"] = 236374,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["MaxXP"] = 225105,
["Money"] = 61551664,
["MythicKey"] = {
},
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["IL"] = 454.1875,
["PlayedLevel"] = 159918,
["PlayedTotal"] = 4161157,
["Zone"] = "Вальдраккен",
["DailyResetTime"] = 1729310399,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729310399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729396799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729483199,
},
["unlocked"] = true,
},
["SpecializationIDs"] = {
62,
63,
64,
},
},
["Бимладен - Ревущий фьорд"] = {
["lastbossyell"] = "Скарморак: Эпохальный ключ",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сундук Кирин-Тора",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["quantity"] = 600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["money"] = 2000000,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Ночная эльфийка",
["LClass"] = "Друид",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
0,
},
["lastbosstime"] = 1729270342,
["Covenant"] = 4,
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Обучение войск",
["questID"] = 60408,
["expiredTime"] = 1729310399,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Беды на родине",
["questID"] = 60429,
["expiredTime"] = 1729396799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Испытания Малдраксуса",
["questID"] = 60445,
["expiredTime"] = 1729483199,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["ILe"] = 626.125,
["Quests"] = {
[82496] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Город Нитей",
["Link"] = "|cffffff00|Hquest:82496:90|h[Душа мира: Город Нитей]|h|r",
},
[82500] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Гнездовье",
["Link"] = "|cffffff00|Hquest:82500:90|h[Душа мира: Гнездовье]|h|r",
},
[82659] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Неруб'арский дворец",
["Link"] = "|cffffff00|Hquest:82659:90|h[Душа мира: Неруб'арский дворец]|h|r",
},
[82506] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: расселина Темного Пламени",
["Link"] = "|cffffff00|Hquest:82506:90|h[Душа мира: расселина Темного Пламени]|h|r",
},
[83347] = {
["Expires"] = 1729655999,
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["Title"] = "Посланник войны",
["Link"] = "|cffffff00|Hquest:83347:2892|h[Посланник войны]|h|r",
},
[82512] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: босс вне подземелья",
["Link"] = "|cffffff00|Hquest:82512:90|h[Душа мира: босс вне подземелья]|h|r",
},
[82483] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: благодать Света",
["Link"] = "|cffffff00|Hquest:82483:90|h[Душа мира: благодать Света]|h|r",
},
[82516] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: заключение пакта",
["Link"] = "|cffffff00|Hquest:82516:90|h[Душа мира: заключение пакта]|h|r",
},
[82491] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Ара-Кара, Город Отголосков",
["Link"] = "|cffffff00|Hquest:82491:90|h[Душа мира: Ара-Кара, Город Отголосков]|h|r",
},
[82493] = {
["Expires"] = 1729655999,
["Link"] = "|cffffff00|Hquest:82493:90|h[Душа мира: \"Сияющий Рассвет\"]|h|r",
["Title"] = "Душа мира: \"Сияющий Рассвет\"",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82495] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Искроварня",
["Link"] = "|cffffff00|Hquest:82495:90|h[Душа мира: Искроварня]|h|r",
},
[82499] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: приорат Священного Пламени",
["Link"] = "|cffffff00|Hquest:82499:90|h[Душа мира: приорат Священного Пламени]|h|r",
},
[82505] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Каменный Свод",
["Link"] = "|cffffff00|Hquest:82505:90|h[Душа мира: Каменный Свод]|h|r",
},
[82511] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: Машина пробуждения",
["Link"] = "|cffffff00|Hquest:82511:90|h[Душа мира: Машина пробуждения]|h|r",
},
[82482] = {
["Expires"] = 1729655999,
["Title"] = "Душа мира: разнюхивание",
["Link"] = "|cffffff00|Hquest:82482:90|h[Душа мира: разнюхивание]|h|r",
},
[82453] = {
["Expires"] = 1729655999,
["Title"] = "Воспоминание души мира: на бис!",
["Link"] = "|cffffff00|Hquest:82453:90|h[Воспоминание души мира: на бис!]|h|r",
},
[82452] = {
["Expires"] = 1729655999,
["Link"] = "|cffffff00|Hquest:82452:90|h[Воспоминание души мира: локальные задания]|h|r",
["Title"] = "Воспоминание души мира: локальные задания",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82449] = {
["Expires"] = 1729655999,
["Title"] = "Зов души мира",
["Link"] = "|cffffff00|Hquest:82449:90|h[Зов души мира]|h|r",
},
},
["Paragon"] = {
2413,
},
["IL"] = 626.125,
["Zone"] = "Дорногал",
["Progress"] = {
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["great-vault-raid"] = {
16,
15,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = true,
["isComplete"] = true,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
"Победите Тьму",
["show"] = true,
["isComplete"] = false,
["leaderboardCount"] = 1,
["isFinish"] = false,
},
["emissary-of-war"] = {
["show"] = true,
["isComplete"] = true,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
},
["Class"] = "DRUID",
["ILPvp"] = 626.125,
["Faction"] = "Alliance",
["currency"] = {
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[2650] = {
["amount"] = 659,
},
[2809] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 47,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 10,
},
[1810] = {
["covenant"] = {
[4] = 4,
},
["totalMax"] = 100,
["amount"] = 4,
},
[1191] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 740,
},
[2812] = {
["amount"] = 0,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 1,
},
[1828] = {
["amount"] = 45801,
},
[1717] = {
["amount"] = 604,
},
[2815] = {
["amount"] = 20616,
},
[2003] = {
["amount"] = 24710,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 1,
},
[2594] = {
["amount"] = 3431,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1702,
},
[1560] = {
["amount"] = 16480,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 2645,
},
[1275] = {
["amount"] = 5,
},
[2122] = {
["amount"] = 19,
},
[2916] = {
["totalEarned"] = 540,
["totalMax"] = 540,
["amount"] = 120,
},
[2123] = {
["totalMax"] = 4100,
["amount"] = 0,
},
[2409] = {
["totalEarned"] = 807,
["amount"] = 807,
},
[2410] = {
["totalEarned"] = 1364,
["amount"] = 1364,
},
[2411] = {
["totalEarned"] = 1498,
["amount"] = 1498,
},
[1166] = {
["amount"] = 8050,
},
[2412] = {
["totalEarned"] = 3984,
["amount"] = 3984,
},
[2413] = {
["amount"] = 28,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 25,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 6794,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 6102,
},
[1931] = {
["amount"] = 9542,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1979] = {
["amount"] = 558,
},
[1813] = {
["covenant"] = {
[4] = 34350,
},
["totalMax"] = 200000,
["amount"] = 34350,
},
[1533] = {
["amount"] = 3588,
},
[1719] = {
["amount"] = 7096,
},
[2800] = {
["totalEarned"] = 12,
["totalMax"] = 27,
["amount"] = 12,
},
[1602] = {
["totalEarned"] = 550,
["totalMax"] = 4600,
["amount"] = 375,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3023] = {
["totalEarned"] = 7,
["totalMax"] = 8,
["amount"] = 7,
},
[2009] = {
["amount"] = 41885,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 13,
},
[2917] = {
["totalEarned"] = 540,
["totalMax"] = 540,
["amount"] = 90,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 27,
},
[2707] = {
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[2806] = {
["amount"] = 0,
},
[2803] = {
["amount"] = 6115,
},
[2708] = {
["amount"] = 0,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 2,
},
[1721] = {
["amount"] = 28,
},
[1710] = {
["amount"] = 945,
},
[2709] = {
["amount"] = 0,
},
[2777] = {
["amount"] = 2,
},
[2915] = {
["totalEarned"] = 754,
["totalMax"] = 810,
["amount"] = 429,
},
[1220] = {
["amount"] = 3293,
},
[2118] = {
["amount"] = 34197,
},
[1977] = {
["amount"] = 22,
},
[2774] = {
["amount"] = 23,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 859,
},
[3056] = {
["amount"] = 7836,
},
[1767] = {
["amount"] = 13155,
},
[1889] = {
["amount"] = 18,
},
[2807] = {
["amount"] = 0,
},
[3010] = {
["totalEarned"] = 11,
["totalMax"] = 18,
["amount"] = 11,
},
[2914] = {
["totalEarned"] = 641,
["totalMax"] = 810,
["amount"] = 446,
},
[515] = {
["amount"] = 10,
},
},
["WeeklyResetTime"] = 1729655999,
["Warmode"] = false,
["DailyResetTime"] = 1729310399,
["Level"] = 80,
["Show"] = "saved",
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
["mapID"] = 501,
["name"] = "Каменный Свод",
["link"] = "|cffa335ee|Hkeystone:180653:501:9:159:9:152:0|h[Ключ: Каменный Свод (9)]|h|r",
["color"] = "ff0070dd",
["level"] = 9,
["ResetTime"] = 1729655999,
},
["PlayedTotal"] = 28549712,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1729271108,
["MaxXP"] = 100000000,
["Order"] = 50,
["SpecializationIDs"] = {
102,
103,
104,
105,
},
["LastSeen"] = 1729273333,
["lastboss"] = "ЗАЗУ: Эпохальный ключ",
["MythicPlusScore"] = 2661,
["PlayedLevel"] = 920566,
["oRace"] = "NightElf",
["Arena3v3rating"] = 0,
["Skills"] = {
},
["Money"] = 4313198202,
["MythicKeyBest"] = {
10,
10,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Осада Боралуса",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 353,
["runScore"] = 329,
["rewardLevel"] = 623,
},
{
["completed"] = true,
["name"] = "Осада Боралуса",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 353,
["runScore"] = 330,
["rewardLevel"] = 623,
},
{
["completed"] = true,
["name"] = "Каменный Свод",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 501,
["runScore"] = 331,
["rewardLevel"] = 623,
},
{
["completed"] = true,
["name"] = "Город Нитей",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 502,
["runScore"] = 331,
["rewardLevel"] = 623,
},
{
["completed"] = true,
["name"] = "Ара-Кара, Город Отголосков",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 503,
["runScore"] = 332,
["rewardLevel"] = 623,
},
{
["completed"] = true,
["name"] = "\"Сияющий Рассвет\"",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 505,
["runScore"] = 332,
["rewardLevel"] = 623,
},
{
["completed"] = true,
["name"] = "Грим Батол",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 507,
["runScore"] = 329,
["rewardLevel"] = 623,
},
},
["ResetTime"] = 1729655999,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 2,
},
},
["Прециза - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Охотница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 179.5,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 190.1875,
["LastSeen"] = 1725797781,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "HUNTER",
["ILPvp"] = 190.1875,
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 16,
},
[1822] = {
["covenant"] = {
[3] = 4,
},
["totalMax"] = 80,
["amount"] = 4,
},
[1885] = {
["amount"] = 2,
},
[1828] = {
["amount"] = 20,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 18,
},
[1716] = {
["amount"] = 16,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 30,
},
[1813] = {
["covenant"] = {
[3] = 342,
},
["totalMax"] = 200000,
["amount"] = 342,
},
[1721] = {
["amount"] = 0,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 198,
},
[1166] = {
["amount"] = 95,
},
[1220] = {
["amount"] = 2083,
},
[1767] = {
["amount"] = 2812,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
},
["Order"] = 50,
["Warmode"] = false,
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1729655999,
},
["Level"] = 60,
["XP"] = 195,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["RestXP"] = 83498,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["Money"] = 19781,
["oRace"] = "BloodElf",
["MaxXP"] = 55665,
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1729655999,
["PlayedLevel"] = 124686,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729310399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729396799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1729483199,
},
["unlocked"] = true,
},
["PlayedTotal"] = 655604,
["DailyResetTime"] = 1729310399,
["SpecializationIDs"] = {
253,
254,
255,
},
["Zone"] = "Оргриммар",
},
},
["Emissary"] = {
["Expansion"] = {
[6] = {
{
["questID"] = {
["Horde"] = 43179,
["Alliance"] = 43179,
},
["questNeed"] = 3,
["expiredTime"] = 1729310493,
},
{
["questID"] = {
["Horde"] = 42170,
["Alliance"] = 42170,
},
["questNeed"] = 4,
["expiredTime"] = 1729396893,
},
{
["questID"] = {
["Horde"] = 48642,
["Alliance"] = 48642,
},
["questNeed"] = 4,
["expiredTime"] = 1729483293,
},
},
[7] = {
{
["questID"] = {
["Horde"] = 50598,
["Alliance"] = 50599,
},
["questNeed"] = 4,
["expiredTime"] = 1729310433,
},
{
["questID"] = {
["Horde"] = 50604,
["Alliance"] = 50604,
},
["questNeed"] = 3,
["expiredTime"] = 1729396833,
},
{
["questID"] = {
["Horde"] = 50606,
["Alliance"] = 50605,
},
["questNeed"] = 4,
["expiredTime"] = 1729483233,
},
},
},
["Cache"] = {
[43179] = "Маги Кирин-Тора в Даларане",
[56119] = "Клинки Волн",
[42233] = "Племена Крутогорья",
[42234] = "Валарьяры",
[48639] = "Армия Света",
[50562] = "Защитники Азерот",
[48641] = "Армия погибели Легиона",
[48642] = "Защитники Аргуса",
[42422] = "Стражи",
[42421] = "Помраченные",
[50598] = "Империя Зандалари",
[50599] = "Адмиралтейство Праудмуров",
[50600] = "Орден Пылающих Углей",
[50601] = "Возрождение Шторма",
[50602] = "Экспедиция Таланджи",
[50603] = "Жители Вол'дуна",
[50604] = "Тортолланские искатели",
[50605] = "Военная кампания Альянса",
[50606] = "Военная кампания Орды",
[42420] = "Двор Фарондиса",
[56120] = "Освобожденные",
[42170] = "Ткачи Снов",
},
},
["spelltip"] = {
[71041] = {
"Покинувший подземелье",
"Вы покинули подземелье. Должно пройти некоторое время, прежде чем вы снова сможете воспользоваться поиском подземелья или рейда.",
"Осталось: 27 |4минута:минуты:минут;",
},
},
["Instances"] = {
["Трон Четырех Ветров"] = {
["LFDID"] = 318,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["СПР (LFR): Залы Искажения Плоти"] = {
["LFDID"] = 837,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Квартал Звезд"] = {
["LFDID"] = 2280,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["СПР (LFR): Авангард Тюремщика"] = {
["LFDID"] = 2221,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Малификус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1884,
["RecLevel"] = 45,
["Raid"] = true,
},
["Огненные Просторы"] = {
["LFDID"] = 362,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Стражи Могу'шан"] = {
["LFDID"] = 2598,
["Expansion"] = 4,
["RecLevel"] = 25,
["Raid"] = true,
["Show"] = "saved",
},
["Залы Искажения Плоти"] = {
["LFDID"] = 2592,
["Expansion"] = 4,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Ара-Кара, Город Отголосков"] = {
["LFDID"] = 2726,
["Expansion"] = 10,
["Show"] = "never",
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2660:23:7|h[Ара-Кара, Город Отголосков]|h|r",
["ID"] = 583528009,
["Locked"] = false,
},
},
["Raid"] = false,
},
["Некрополь Призрачной Луны"] = {
["LFDID"] = 1976,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Сотанатор"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2014,
["RecLevel"] = 45,
["Raid"] = true,
},
["Змеиное святилище"] = {
["LFDID"] = 194,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Битва за Дазар'алор"] = {
["LFDID"] = 1944,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Базуал"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2517,
["RecLevel"] = 70,
["Raid"] = true,
},
["Т'зейн"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2139,
["RecLevel"] = 50,
["Raid"] = true,
},
["Крепость Черной Ладьи"] = {
["LFDID"] = 2275,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Сила Альянса"] = {
["LFDID"] = 1947,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Аркатрац"] = {
["LFDID"] = 1011,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["СПР (LFR): Сон наяву"] = {
["LFDID"] = 2039,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Город Нитей"] = {
["LFDID"] = 2722,
["Expansion"] = 10,
["Show"] = "never",
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2669:23:15|h[Город Нитей]|h|r",
["ID"] = 583529087,
["Locked"] = false,
},
},
["Raid"] = false,
},
["Инквизитор Мето"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2012,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria (героич.)"] = {
["LFDID"] = 462,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Изначальный бастион"] = {
["LFDID"] = 2703,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное героическое подземелье (1-й сезон The War Within)"] = {
["LFDID"] = 2723,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Непроглядная Пучина"] = {
["LFDID"] = 10,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное героическое подземелье (Mists of Pandaria)"] = {
["LFDID"] = 2537,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Победа или смерть"] = {
["LFDID"] = 1950,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Тазавеш: гамбит Со'леи"] = {
["LFDID"] = 2330,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = false,
["Show"] = "saved",
},
["Раскаленное вторжение"] = {
["LFDID"] = 2711,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Реликварий роскоши"] = {
["LFDID"] = 2412,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Испытание крестоносца"] = {
["LFDID"] = 248,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Твердыня Крыла Тьмы"] = {
["LFDID"] = 314,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Случайное подземелье (Dragonflight)"] = {
["LFDID"] = 2350,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Кузня Душ"] = {
["LFDID"] = 2322,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Тайный рынок Тазавеш"] = {
["LFDID"] = 2225,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2539,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Каламир"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1774,
["RecLevel"] = 45,
["Raid"] = true,
},
["Расплата"] = {
["LFDID"] = 2418,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Престол Гроз"] = {
["LFDID"] = 634,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Аметистовая крепость"] = {
["LFDID"] = 221,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Темный лабиринт"] = {
["LFDID"] = 181,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Орта"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2625,
["RecLevel"] = 80,
["Raid"] = true,
},
["Натанос Гнилостень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 9005,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Lich King (героич.)"] = {
["LFDID"] = 262,
["Expansion"] = 2,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Анторус, Пылающий Трон"] = {
["LFDID"] = 1642,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Апокрон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1956,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ботаника"] = {
["LFDID"] = 2325,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Огненная Пропасть"] = {
["LFDID"] = 4,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Магтеридона"] = {
["LFDID"] = 176,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Подъем Императора"] = {
["LFDID"] = 1365,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Истощающие хранилища"] = {
["LFDID"] = 2411,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Ауростор"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2562,
["RecLevel"] = 70,
["Raid"] = true,
},
["Небесный Путь"] = {
["LFDID"] = 1977,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["СПР (LFR): Раскаленное вторжение"] = {
["LFDID"] = 2468,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Шуррай"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2636,
["RecLevel"] = 80,
["Raid"] = true,
},
["Граница Бездны"] = {
["LFDID"] = 2709,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Забытый город - квартал Криводревов"] = {
["LFDID"] = 34,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Чумные каскады"] = {
["LFDID"] = 2121,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Последний оплот зандаларов"] = {
["LFDID"] = 835,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Рубиновые Омуты Жизни"] = {
["LFDID"] = 2436,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Векемара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2363,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Legion)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 2274,
["Random"] = true,
["RecLevel"] = 45,
["Holiday"] = true,
["Raid"] = false,
},
["Госпожа Аллюрадель"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2011,
["RecLevel"] = 45,
["Raid"] = true,
},
["Казематы Стражей"] = {
["LFDID"] = 2278,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Штурм Аметистовой крепости"] = {
["LFDID"] = 1209,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Око Азшары"] = {
["LFDID"] = 2276,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Лисканот"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2518,
["RecLevel"] = 70,
["Raid"] = true,
},
["На'зак Одержимый"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1783,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Эфемеровые равнины"] = {
["LFDID"] = 2292,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Вечноскорбящий дол"] = {
["LFDID"] = 2590,
["Expansion"] = 4,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Надвигающийся ужас"] = {
["LFDID"] = 832,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["СПР (LFR): Королевская библиотека"] = {
["LFDID"] = 1924,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Крепость Темного Клыка"] = {
["LFDID"] = 327,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Великий посол Огнехлыст"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["LFDID"] = 308,
},
["Островные экспедиции"] = {
["LFDID"] = 1762,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Хмелеварня Буйных Портеров"] = {
["LFDID"] = 2543,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Кузня Крови"] = {
["LFDID"] = 2326,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Гнездовье"] = {
["LFDID"] = 2718,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 1,
["Show"] = "never",
},
["СПР (LFR): Великий замысел"] = {
["LFDID"] = 2294,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Изумрудное плетение"] = {
["LFDID"] = 2712,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Дар Плоти"] = {
["LFDID"] = 2038,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Глубины Черной горы - Верхний город"] = {
["LFDID"] = 276,
["Expansion"] = 0,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Цитадель Ледяной Короны"] = {
["LFDID"] = 280,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Гномреган"] = {
["LFDID"] = 14,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Нелтариона"] = {
["LFDID"] = 2279,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Тень Нелтариона"] = {
["LFDID"] = 2401,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Собор Вечной Ночи"] = {
["LFDID"] = 1488,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["\"Валинор\""] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2430,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Чертоги Преданности"] = {
["LFDID"] = 2037,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Операция \"Мехагон\""] = {
["LFDID"] = 2006,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Усадьба Уэйкрестов"] = {
["LFDID"] = 1706,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Лазурное хранилище"] = {
["LFDID"] = 2498,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Театр Боли"] = {
["LFDID"] = 2124,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Гробница королей"] = {
["LFDID"] = 1785,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Ашран"] = {
["LFDID"] = 1127,
["Expansion"] = 0,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Мор'гет Мучитель проклятых"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9012,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Сердце Порчи"] = {
["LFDID"] = 1733,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Логово Ониксии"] = {
["LFDID"] = 257,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor"] = {
["LFDID"] = 788,
["Expansion"] = 5,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье в героическом режиме (Dragonflight)"] = {
["LFDID"] = 2351,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Изумрудный Кошмар"] = {
["LFDID"] = 1350,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Аберрий, Затененное Горнило"] = {
["LFDID"] = 2405,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["СПР (LFR): Забытые глубины"] = {
["LFDID"] = 836,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Черный храм"] = {
["LFDID"] = 196,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Бимладен - Ревущий фьорд"] = {
[33] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:564:33:511|h[Черный храм]|h|r",
["ID"] = 2295571782,
["Locked"] = false,
},
},
["Raid"] = true,
},
["Случайное подземелье классической игры"] = {
["LFDID"] = 258,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = false,
},
["Аукенайские гробницы"] = {
["LFDID"] = 178,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Каменный Свод"] = {
["LFDID"] = 2724,
["Expansion"] = 10,
["Show"] = "never",
["Raid"] = false,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2652:23:15|h[Каменный Свод]|h|r",
["ID"] = 583534467,
["Locked"] = false,
},
},
["RecLevel"] = 1,
},
["Случайное подземелье, путеш. во времени (Warlords of Draenor)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 1971,
["Random"] = true,
["RecLevel"] = 40,
["Holiday"] = true,
["Raid"] = false,
},
["СПР (LFR): Тайны Неруб'арского дворца"] = {
["LFDID"] = 2650,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "never",
},
["Авангард Тюремщика"] = {
["LFDID"] = 2415,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Нижняя часть пика Черной горы"] = {
["LFDID"] = 32,
["Expansion"] = 0,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Великая императрица Шек'зара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2378,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Трон Пантеона"] = {
["LFDID"] = 1913,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Окулярус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2013,
["RecLevel"] = 45,
["Raid"] = true,
},
["Цитадель Ночи"] = {
["LFDID"] = 1353,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Терраса Вечной Весны"] = {
["LFDID"] = 2599,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Случайный сценарий путешествия во времени (Mists of Pandaria)"] = {
["LFDID"] = 2558,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Burning Crusade (героич.)"] = {
["LFDID"] = 260,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Cataclysm (героич.)"] = {
["LFDID"] = 301,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Каражан"] = {
["LFDID"] = 175,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Катакомбы Сурамара"] = {
["LFDID"] = 1190,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Аукиндон"] = {
["LFDID"] = 1975,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Случайное подземелье Shadowlands"] = {
["LFDID"] = 2086,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Гнев Тюремщика"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9006,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Подземная крепость"] = {
["LFDID"] = 841,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Иссохший Дж'им"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1796,
["RecLevel"] = 45,
["Raid"] = true,
},
["Расселина Темного Пламени"] = {
["LFDID"] = 2655,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 1,
["Show"] = "never",
},
["Нексус"] = {
["LFDID"] = 1019,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Падение империи"] = {
["LFDID"] = 1946,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Расплата у врат"] = {
["LFDID"] = 840,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Крепость Бурь"] = {
["LFDID"] = 193,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Храм Сетралисс"] = {
["LFDID"] = 1695,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Градовый голем"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2197,
["RecLevel"] = 50,
["Raid"] = true,
},
["Кошмар Шек'зир"] = {
["LFDID"] = 2595,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайный сценарий (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2559,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье, путеш. во времени (Cataclysm)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 1146,
["Random"] = true,
["RecLevel"] = 35,
["Holiday"] = true,
["Raid"] = false,
},
["Операция \"Мехагон\" – свалка"] = {
["LFDID"] = 2027,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Предел Господства"] = {
["LFDID"] = 2293,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Островные экспедиции – индивидуальный тур"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2251,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Храм Ан'Киража"] = {
["LFDID"] = 161,
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Антрос"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9013,
["RecLevel"] = 60,
["Raid"] = true,
},
["Время Сумерек"] = {
["LFDID"] = 439,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor (героич.)"] = {
["LFDID"] = 789,
["Expansion"] = 5,
["Show"] = "saved",
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["Ульдир"] = {
["LFDID"] = 1889,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Терраса Магистров"] = {
["LFDID"] = 1154,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Госпожа Фолнуна"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2010,
["RecLevel"] = 45,
["Raid"] = true,
},
["Подземелья Могу'шан"] = {
["LFDID"] = 532,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Кровь из камня"] = {
["LFDID"] = 2413,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["СПР (LFR): Врата ада"] = {
["LFDID"] = 1920,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Азжол-Неруб"] = {
["LFDID"] = 2324,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Горнило Штормов"] = {
["LFDID"] = 1954,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Тазавеш: улицы чудес"] = {
["LFDID"] = 2329,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = false,
["Show"] = "saved",
},
["Некроситет"] = {
["LFDID"] = 2557,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Крепость Драк'Тарон"] = {
["LFDID"] = 215,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Низвержение"] = {
["LFDID"] = 2587,
["Expansion"] = 4,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Забытый город - палаты Гордока"] = {
["LFDID"] = 38,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 1453,
["Random"] = true,
["RecLevel"] = 35,
["Holiday"] = true,
["Raid"] = false,
},
["Тол Дагор"] = {
["LFDID"] = 1714,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное подземелье (The War Within, героический режим)"] = {
["LFDID"] = 2517,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Возвращение в Каражан (верхняя часть)"] = {
["LFDID"] = 1474,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Легиона"] = {
["LFDID"] = 1045,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Тихая Сень"] = {
["LFDID"] = 2025,
["Expansion"] = 7,
["RecLevel"] = 1,
["Raid"] = true,
["Show"] = "saved",
},
["Си'ваш"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1885,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Shadowlands (героич.)"] = {
["LFDID"] = 2087,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Random"] = true,
["Raid"] = false,
},
["Кронпринцесса Терадрас"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["LFDID"] = 309,
},
["СПР (LFR): Фундамент Созидания"] = {
["LFDID"] = 2291,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Операция \"Мехагон\" – мастерская"] = {
["LFDID"] = 2028,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Падение королевы"] = {
["Show"] = "never",
["Expansion"] = 10,
["LFDID"] = 2651,
["Raid"] = true,
["Бимладен - Ревущий фьорд"] = {
[2] = {
true,
false,
["Expires"] = 1729655999,
["ID"] = -2,
},
},
["RecLevel"] = 80,
},
["СПР (LFR): Укрепления Снующих лап"] = {
["LFDID"] = 2649,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "never",
},
["Зул'Аман"] = {
["LFDID"] = 340,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = false,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Ульдуар"] = {
["Show"] = "saved",
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Holiday"] = true,
["LFDID"] = 1677,
},
["СПР (LFR): Черные врата"] = {
["LFDID"] = 1370,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Охотники за душами"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1756,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Погибель надежды"] = {
["LFDID"] = 1914,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Принц Сарсарун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["LFDID"] = 310,
},
["СПР (LFR): Сделка со Смертью"] = {
["LFDID"] = 1949,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Ульдаман: наследие Тира"] = {
["LFDID"] = 2465,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Верховный владыка Каззак"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1452,
["RecLevel"] = 40,
["Raid"] = true,
},
["Корен Худовар"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Holiday"] = true,
["LFDID"] = 287,
},
["СПР (LFR): Залы Крови"] = {
["LFDID"] = 1367,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["СПР (LFR): Оплот Тьмы"] = {
["LFDID"] = 1368,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Вольная Гавань"] = {
["LFDID"] = 2178,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Око Вечности"] = {
["LFDID"] = 237,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Случайный сценарий Mists of Pandaria (героич.)"] = {
["LFDID"] = 641,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Сумеречный бастион"] = {
["LFDID"] = 316,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Лабиринты Иглошкурых"] = {
["LFDID"] = 16,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Источник Вечности"] = {
["LFDID"] = 437,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = false,
["Show"] = "saved",
},
["Гарнизон босс"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 9001,
["RecLevel"] = 40,
["Raid"] = true,
},
["СПР (LFR): Зал аватары"] = {
["LFDID"] = 1918,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["СПР (LFR): Оковы судьбы"] = {
["LFDID"] = 2223,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["\"Сияющий Рассвет\""] = {
["LFDID"] = 2725,
["Expansion"] = 10,
["Show"] = "never",
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2662:23:7|h[\"Сияющий Рассвет\"]|h|r",
["ID"] = 583525920,
["Locked"] = false,
},
},
["Raid"] = false,
},
["СПР (LFR): Глубины преданных"] = {
["LFDID"] = 2010,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Замок Нафрия"] = {
["LFDID"] = 2095,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Храм Нефритовой Змеи"] = {
["LFDID"] = 2541,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Утроба Душ"] = {
["LFDID"] = 1192,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Открытие Темного портала"] = {
["LFDID"] = 1012,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Вакан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2531,
["RecLevel"] = 70,
["Raid"] = true,
},
["Повелитель Холода Ахун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 1,
["Holiday"] = true,
["LFDID"] = 286,
},
["Чертоги Камня"] = {
["LFDID"] = 213,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Дров / Тарлна"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1211,
["RecLevel"] = 40,
["Raid"] = true,
},
["Случайный сценарий Mists of Pandaria"] = {
["LFDID"] = 493,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Изумрудное плетение"] = {
["LFDID"] = 2467,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Сердце Страха"] = {
["LFDID"] = 534,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Нижетопь"] = {
["LFDID"] = 2327,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Встреча с тщеславием"] = {
["LFDID"] = 2096,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Атал'Дазар"] = {
["LFDID"] = 2177,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Ордос"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 861,
["RecLevel"] = 35,
["Raid"] = true,
},
["Фундамент Созидания"] = {
["LFDID"] = 2419,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Очищение Стратхольма"] = {
["LFDID"] = 210,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["СПР (LFR): Расплата"] = {
["LFDID"] = 2224,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье Battle For Azeroth (героич.)"] = {
["LFDID"] = 1671,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Кордак"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2637,
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): След Воплощения"] = {
["LFDID"] = 2466,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Гнев бури"] = {
["LFDID"] = 2706,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Граница Бездны"] = {
["LFDID"] = 2402,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Залы Отражений"] = {
["LFDID"] = 256,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Вершина Бурь"] = {
["LFDID"] = 2591,
["Expansion"] = 4,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Воспоминания Азерот: Wrath of the Lich King"] = {
["LFDID"] = 2017,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Грим Батол"] = {
["LFDID"] = 2730,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "never",
},
["Неруб'арский дворец"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2645,
["Raid"] = true,
["RecLevel"] = 80,
["Бимладен - Ревущий фьорд"] = {
[14] = {
["Expires"] = 1729656001,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2657:14:64|h[Неруб'арский дворец]|h|r",
["ID"] = 1162406042,
["Locked"] = true,
},
[16] = {
["Expires"] = 1729656001,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2657:16:7|h[Неруб'арский дворец]|h|r",
["ID"] = 1162451784,
["Locked"] = true,
},
[17] = {
["Expires"] = 1729656001,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2657:17:64|h[Неруб'арский дворец]|h|r",
["ID"] = 2350390829,
["Locked"] = true,
},
[15] = {
["Expires"] = 1729656001,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2657:15:68|h[Неруб'арский дворец]|h|r",
["ID"] = 419688729,
["Locked"] = true,
},
},
["Вольтчара - Свежеватель Душ"] = {
[14] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:14:255|h[Неруб'арский дворец]|h|r",
["ID"] = 1159054082,
["Locked"] = false,
},
[16] = {
["Expires"] = 1729655999,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:16:6|h[Неруб'арский дворец]|h|r",
["ID"] = 1162545370,
["Locked"] = true,
},
[17] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:17:248|h[Неруб'арский дворец]|h|r",
["ID"] = 2310304222,
["Locked"] = false,
},
[15] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:15:127|h[Неруб'арский дворец]|h|r",
["ID"] = 449513319,
["Locked"] = false,
},
},
},
["Хранилище Воплощений"] = {
["LFDID"] = 2390,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Искроварня"] = {
["LFDID"] = 2700,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 1,
["Show"] = "never",
},
["Гнездовье (версия из задания)"] = {
["LFDID"] = 2657,
["Expansion"] = 10,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "never",
},
["Великий замысел"] = {
["LFDID"] = 2422,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["СПР (LFR): Вечноскорбящий дол"] = {
["LFDID"] = 839,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["СПР (LFR): Темный острог"] = {
["LFDID"] = 2222,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Налак"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 814,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Осада Храма Драконьего Покоя"] = {
["LFDID"] = 843,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Ан'кахет: Старое Королевство"] = {
["LFDID"] = 1016,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Верховный Молот"] = {
["LFDID"] = 897,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Курганы Иглошкурых"] = {
["LFDID"] = 20,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Предел Господства"] = {
["LFDID"] = 2421,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["СПР (LFR): Терраса Вечной Весны"] = {
["LFDID"] = 834,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Встреча с тщеславием"] = {
["LFDID"] = 2414,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["СПР (LFR): Низвержение"] = {
["LFDID"] = 842,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Туманы Тирна Скитта"] = {
["LFDID"] = 2727,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "never",
},
["Затонувший храм"] = {
["LFDID"] = 28,
["Expansion"] = 0,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Осада Оргриммара"] = {
["LFDID"] = 766,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Монастырь Шадо-Пан"] = {
["LFDID"] = 2545,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Галеон"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 725,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Падение Искусителя"] = {
["LFDID"] = 1917,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Случайное подземелье Легиона (героич.)"] = {
["LFDID"] = 1046,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Вечный дворец"] = {
["LFDID"] = 2016,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Железный цех"] = {
["LFDID"] = 1362,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["СПР (LFR): Темная Ветвь"] = {
["LFDID"] = 1912,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Струнраан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2515,
["RecLevel"] = 70,
["Raid"] = true,
},
["Окулус"] = {
["LFDID"] = 211,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Пещеры Стенаний"] = {
["LFDID"] = 1,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Улмат"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2362,
["RecLevel"] = 50,
["Raid"] = true,
},
["След Воплощения"] = {
["LFDID"] = 2710,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Расплата у врат"] = {
["LFDID"] = 2589,
["Expansion"] = 4,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Чертоги Покаяния"] = {
["LFDID"] = 2119,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Пещеры Времени: годовщина"] = {
["LFDID"] = 1911,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Оковы судьбы"] = {
["LFDID"] = 2417,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Судьба Амирдрассила"] = {
["LFDID"] = 2713,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Стратхольм - Главные врата"] = {
["LFDID"] = 40,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Святилище Штормов"] = {
["LFDID"] = 1774,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Вечное Цветение"] = {
["LFDID"] = 1972,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 36,
["Show"] = "saved",
},
["Мародон - Зловонная пещера"] = {
["LFDID"] = 26,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Залы Стенаний"] = {
["LFDID"] = 1919,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Крепость Утгард"] = {
["LFDID"] = 2323,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Хранилище Аркавона"] = {
["LFDID"] = 240,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Эфемеровые равнины"] = {
["LFDID"] = 2420,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Вершина Смерча"] = {
["LFDID"] = 1147,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["Железные доки"] = {
["LFDID"] = 1974,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Верхняя часть пика Черной горы"] = {
["LFDID"] = 1004,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Испытание доблести"] = {
["LFDID"] = 1439,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Случайное подземелье (The War Within)"] = {
["LFDID"] = 2516,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Прошлое Хиджала"] = {
["LFDID"] = 195,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Каменные Недра"] = {
["LFDID"] = 1148,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["Стратхольм - Черный ход"] = {
["LFDID"] = 274,
["Expansion"] = 0,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Ни'алота, Пробуждающийся Город"] = {
["LFDID"] = 2035,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Прорыв Света"] = {
["LFDID"] = 1916,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Затерянный город Тол'вир"] = {
["LFDID"] = 1151,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["СПР (LFR): Стражи Могу'шан"] = {
["LFDID"] = 830,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Рассвет Бесконечности: подъем Дорнозму"] = {
["LFDID"] = 2530,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Смертельная тризна"] = {
["LFDID"] = 2728,
["Expansion"] = 10,
["Show"] = "never",
["Raid"] = false,
["RecLevel"] = 50,
},
["Испытание великого крестоносца"] = {
["LFDID"] = 250,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Мучители из Торгаста"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9007,
["RecLevel"] = 60,
["Raid"] = true,
},
["Депо Мрачных Путей"] = {
["LFDID"] = 2319,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 36,
["Show"] = "saved",
},
["Бастионы Адского Пламени"] = {
["LFDID"] = 188,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
["LFDID"] = 1708,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Штурм Дазар'алора"] = {
["LFDID"] = 1945,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Кай'жу Газ'рилла"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 30,
["Holiday"] = true,
["LFDID"] = 306,
},
["СПР (LFR): Ночной Шпиль"] = {
["LFDID"] = 1923,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Солнечный Колодец"] = {
["LFDID"] = 199,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Конец Времен"] = {
["LFDID"] = 1152,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Случайное подземелье, путешествие во времени (Mists of Pandaria)"] = {
["LFDID"] = 2538,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Королевская химическая компания"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 1,
["Holiday"] = true,
["LFDID"] = 288,
},
["СПР (LFR): Кошмар Шек'зир"] = {
["LFDID"] = 833,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Крепость Барадин"] = {
["LFDID"] = 329,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Тень Нелтариона"] = {
["LFDID"] = 2708,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Ульдаман"] = {
["LFDID"] = 22,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Гробница Предвечных"] = {
["LFDID"] = 2290,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Зул'Гуруб"] = {
["LFDID"] = 334,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = false,
["Show"] = "saved",
},
["Ундаста"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 826,
["RecLevel"] = 35,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Wrath of the Lich King)"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 995,
["Random"] = true,
["RecLevel"] = 30,
["Holiday"] = true,
["Raid"] = false,
},
["Тюрьма Штормграда"] = {
["LFDID"] = 12,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Доблести"] = {
["LFDID"] = 1194,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Ша Злости"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 691,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Ярость гигантов"] = {
["LFDID"] = 2400,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Скопище кошмаров"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2635,
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): Круг Звезд"] = {
["LFDID"] = 2011,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Йорундалль"] = {
["LFDID"] = 2041,
["Expansion"] = 7,
["RecLevel"] = 1,
["Raid"] = true,
["Show"] = "saved",
},
["Забытые глубины"] = {
["LFDID"] = 2593,
["Expansion"] = 4,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Побег из Дарнхольда"] = {
["LFDID"] = 183,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["СПР (LFR): Шлаковый цех"] = {
["LFDID"] = 1361,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Мародон - Поющие водопады"] = {
["LFDID"] = 273,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Душа Дракона"] = {
["LFDID"] = 448,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["СПР (LFR): Тигель Чернорука"] = {
["LFDID"] = 1359,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Левантия"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1769,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Адский пролом"] = {
["LFDID"] = 1366,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Лощина Бурошкуров"] = {
["LFDID"] = 2439,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Падение Смертокрыла"] = {
["LFDID"] = 844,
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Врата Заходящего Солнца"] = {
["LFDID"] = 2549,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Случайное подземелье Battle For Azeroth"] = {
["LFDID"] = 1670,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Хранилище тайн"] = {
["LFDID"] = 831,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["СПР (LFR): Испытание доблести"] = {
["LFDID"] = 1921,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Подгнилье"] = {
["LFDID"] = 1712,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Цитадель Адского Пламени"] = {
["LFDID"] = 989,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Мародон - Оскверненный грот"] = {
["LFDID"] = 272,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Молний"] = {
["LFDID"] = 1018,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Экспедиции на остров Кишащий"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2054,
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = true,
},
["Чертоги Созидания"] = {
["LFDID"] = 321,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["СПР (LFR): Одержимые хранители"] = {
["LFDID"] = 1927,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Мортанис"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2431,
["RecLevel"] = 60,
["Raid"] = true,
},
["Обсидиановое святилище"] = {
["LFDID"] = 238,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Престол Триумвирата"] = {
["LFDID"] = 1535,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["Литейная клана Черной горы"] = {
["LFDID"] = 900,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["СПР (LFR): Вершина Бурь"] = {
["LFDID"] = 838,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Чертоги Насыщения"] = {
["LFDID"] = 2444,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Глубины Черной горы - Тюремный блок"] = {
["LFDID"] = 30,
["Expansion"] = 0,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Искрящий акведук"] = {
["LFDID"] = 1925,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["СПР (LFR): Волшебное святилище"] = {
["LFDID"] = 1364,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Случайное подземелье \"Времени Сумерек\" (героич.)"] = {
["LFDID"] = 434,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Королева Ансурек"] = {
["LFDID"] = 2715,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "saved",
},
["Мор'гет"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2456,
["RecLevel"] = 60,
["Raid"] = true,
},
["Паровое подземелье"] = {
["LFDID"] = 185,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["СПР (LFR): Изначальный бастион"] = {
["LFDID"] = 2370,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (The Burning Crusade)"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 744,
["Random"] = true,
["RecLevel"] = 30,
["Holiday"] = true,
["Raid"] = false,
},
["Случайные островные экспедиции – эпохальный режим"] = {
["LFDID"] = 1891,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Пещеры Черной горы"] = {
["LFDID"] = 2321,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["Надвигающийся ужас"] = {
["LFDID"] = 2596,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Испытание чемпиона"] = {
["LFDID"] = 249,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Джи'арак"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2141,
["RecLevel"] = 50,
["Raid"] = true,
},
["Забытый город - центральный сад"] = {
["LFDID"] = 36,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Крыла Тьмы"] = {
["LFDID"] = 50,
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Подъем Предателя"] = {
["LFDID"] = 1922,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Огненные Просторы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["Raid"] = true,
["RecLevel"] = 35,
["Holiday"] = true,
["LFDID"] = 2026,
},
["Логово Груула"] = {
["LFDID"] = 177,
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье Cataclysm"] = {
["LFDID"] = 300,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Драгон Зиморожденный"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1789,
["RecLevel"] = 45,
["Raid"] = true,
},
["Лазуретос"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2199,
["RecLevel"] = 50,
["Raid"] = true,
},
["Трон Приливов"] = {
["LFDID"] = 1150,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 31,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Черный храм"] = {
["Show"] = "saved",
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Holiday"] = true,
["LFDID"] = 1533,
},
["СПР (LFR): Оборона Дазар'алора"] = {
["LFDID"] = 1948,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Воспоминания Азерот: Burning Crusade"] = {
["LFDID"] = 2004,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Рассвет Бесконечности"] = {
["LFDID"] = 2430,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Рассвет Бесконечности: падение Галакронда"] = {
["LFDID"] = 2529,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Сетеккские залы"] = {
["LFDID"] = 180,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Осада Боралуса"] = {
["Show"] = "never",
["Expansion"] = 10,
["LFDID"] = 2729,
["Raid"] = false,
["RecLevel"] = 50,
},
["СПР (LFR): Видение судьбы"] = {
["LFDID"] = 2036,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Руины Ан'Киража"] = {
["LFDID"] = 160,
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Шлаковые шахты Кровавого Молота"] = {
["LFDID"] = 1973,
["Expansion"] = 5,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Почетный прием"] = {
["LFDID"] = 2009,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Разрушенные залы"] = {
["LFDID"] = 1014,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Хумонгрис"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1770,
["RecLevel"] = 45,
["Raid"] = true,
},
["Обломок"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1795,
["RecLevel"] = 45,
["Raid"] = true,
},
["Шар'тос"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1763,
["RecLevel"] = 45,
["Raid"] = true,
},
["Цитадель Темного Молота"] = {
["LFDID"] = 2043,
["Expansion"] = 0,
["RecLevel"] = 7,
["Raid"] = false,
["Show"] = "saved",
},
["Дворец Могу'шан"] = {
["LFDID"] = 2551,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["СПР (LFR): Судьба Амирдрассила"] = {
["LFDID"] = 2469,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Вершина Утгард"] = {
["LFDID"] = 1020,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["СПР (LFR): Воспоминания Азерот: Cataclysm"] = {
["LFDID"] = 2018,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Чаща Темного Сердца"] = {
["LFDID"] = 2277,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Подземная крепость"] = {
["LFDID"] = 2588,
["Expansion"] = 4,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Рубиновое святилище"] = {
["LFDID"] = 294,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Вук'лаз Землелом"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2381,
["RecLevel"] = 50,
["Raid"] = true,
},
["Всадник без головы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Holiday"] = true,
["LFDID"] = 285,
},
["СПР (LFR): Алый спуск"] = {
["LFDID"] = 1732,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Та Сторона"] = {
["LFDID"] = 2118,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Кровавые катакомбы"] = {
["LFDID"] = 2117,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Кровь из камня"] = {
["LFDID"] = 2092,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье Burning Crusade"] = {
["LFDID"] = 259,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Черная Кузня"] = {
["LFDID"] = 1360,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Возвращение в Каражан"] = {
["LFDID"] = 1347,
["Expansion"] = 6,
["RecLevel"] = 110,
["Raid"] = false,
["Show"] = "saved",
},
["Базрикрон"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2506,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ана-Муз"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1790,
["RecLevel"] = 45,
["Raid"] = true,
},
["Пещеры Насыщения"] = {
["LFDID"] = 2705,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Возвращение в Каражан (нижняя часть)"] = {
["LFDID"] = 1475,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Пещеры Насыщения"] = {
["LFDID"] = 2371,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Мертвые копи"] = {
["LFDID"] = 326,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Нургаш Жижерожденный"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2433,
["RecLevel"] = 60,
["Raid"] = true,
},
["Нитхегг"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1749,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Отбракованные жизни"] = {
["LFDID"] = 2399,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Запретный спуск"] = {
["LFDID"] = 1915,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Святилище Господства"] = {
["LFDID"] = 2228,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["СПР (LFR): Терраса Разрушителя"] = {
["LFDID"] = 1369,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Четыре небожителя"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 857,
["RecLevel"] = 35,
["Raid"] = true,
},
["Последний оплот зандаларов"] = {
["LFDID"] = 2594,
["Expansion"] = 4,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Горнило Штормов"] = {
["LFDID"] = 1951,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Властитель преисподней Веролом"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2015,
["RecLevel"] = 45,
["Raid"] = true,
},
["Хранилище тайн"] = {
["LFDID"] = 2597,
["Expansion"] = 4,
["RecLevel"] = 25,
["Raid"] = true,
["Show"] = "saved",
},
["Темный острог"] = {
["LFDID"] = 2416,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Бруталл"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1883,
["RecLevel"] = 45,
["Raid"] = true,
},
["Механар"] = {
["LFDID"] = 192,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Академия Алгет'ар"] = {
["LFDID"] = 2464,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Провал Альн"] = {
["LFDID"] = 1926,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Случайное подземелье Mists of Pandaria"] = {
["LFDID"] = 463,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Приорат Священного Пламени"] = {
["LFDID"] = 2699,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 1,
["Show"] = "never",
},
["Дюнный пожиратель Краулок"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2210,
["RecLevel"] = 50,
["Raid"] = true,
},
["Ораномонос Вечноветвящаяся"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9010,
["RecLevel"] = 60,
["Raid"] = true,
},
["Яма Сарона"] = {
["LFDID"] = 1153,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["Залы Алого ордена"] = {
["LFDID"] = 2553,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Истощающие хранилища"] = {
["LFDID"] = 2090,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Рухмар"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1262,
["RecLevel"] = 40,
["Raid"] = true,
},
["Отбракованные жизни"] = {
["LFDID"] = 2704,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Вестник войны Йенаж"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2198,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Город за стеной"] = {
["LFDID"] = 1363,
["Expansion"] = 5,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Зул'Фаррак"] = {
["LFDID"] = 24,
["Expansion"] = 0,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Узилище"] = {
["LFDID"] = 1015,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное подземелье Lich King"] = {
["LFDID"] = 261,
["Expansion"] = 2,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Монастырь Алого ордена"] = {
["LFDID"] = 2555,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Реликварий роскоши"] = {
["LFDID"] = 2091,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Амирдрассил, Надежда Сна"] = {
["LFDID"] = 2504,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Шпили Перерождения"] = {
["LFDID"] = 2122,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Гробница Саргераса"] = {
["LFDID"] = 1527,
["Expansion"] = 6,
["Raid"] = true,
["RecLevel"] = 45,
["Show"] = "saved",
},
["СПР (LFR): Гнев бури"] = {
["LFDID"] = 2372,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Осада храма Нюцзао"] = {
["LFDID"] = 2547,
["Expansion"] = 4,
["Raid"] = false,
["RecLevel"] = 26,
["Show"] = "saved",
},
["СПР (LFR): Чертоги сдерживания"] = {
["LFDID"] = 1731,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Ярость гигантов"] = {
["LFDID"] = 2707,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Наступление клана Нокхуд"] = {
["LFDID"] = 2442,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Огненные Недра"] = {
["LFDID"] = 48,
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Гробницы маны"] = {
["LFDID"] = 1013,
["Expansion"] = 1,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Гундрак"] = {
["LFDID"] = 1017,
["Expansion"] = 2,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["\"Валинор\", Светоч Эпох"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9008,
["RecLevel"] = 60,
["Raid"] = true,
},
["Ульдуар"] = {
["LFDID"] = 244,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Наксрамас"] = {
["LFDID"] = 227,
["Expansion"] = 2,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Нелтарий"] = {
["LFDID"] = 2440,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
},
["histGeneration"] = 1268,
["Warfront"] = {
{
["contributing"] = false,
["captureSide"] = "Alliance",
},
{
["contributing"] = true,
["captureSide"] = "Horde",
},
},
["MinimapIcon"] = {
["showInCompartment"] = true,
["hide"] = false,
},
["Tooltip"] = {
["CurrencySortName"] = false,
["Emissary6"] = false,
["TrackBonus"] = true,
["TrackParagon"] = false,
["Currency3008"] = true,
["CombineWorldBosses"] = false,
["HistoryText"] = false,
["CategorySpaces"] = false,
["Currency2807"] = false,
["posx"] = 876.1668701171875,
["Currency2806"] = false,
["ShowRandom"] = true,
["Currency3010"] = false,
["Currency2917"] = true,
["TimewornMythicKey"] = true,
["TrackDeserter"] = true,
["Currency2812"] = false,
["TrackDailyQuests"] = true,
["Currency2003"] = false,
["Currency3056"] = false,
["Currency2778"] = false,
["AbbreviateKeystone"] = false,
["MythicKeyBest"] = true,
["Warfront2"] = false,
["ReverseInstances"] = false,
["RowHighlight"] = 0.1,
["CurrencyMax"] = false,
["Currency2800"] = false,
["ConnectedRealms"] = "group",
["ReportResets"] = false,
["Currency2809"] = false,
["CategorySort"] = "EXPANSION",
["ShowSoloCategory"] = false,
["ShowServer"] = false,
["NumberFormat"] = true,
["Warfront1"] = false,
["ShowExpired"] = false,
["RaidsFirst"] = true,
["posy"] = 323.3809814453125,
["CombineCalling"] = false,
["Currency3089"] = false,
["ShowCategories"] = false,
["CurrencyEarned"] = true,
["CombineEmissary"] = false,
["CurrencyValueColor"] = true,
["Currency3028"] = false,
["EmissaryFullName"] = true,
["ShowHints"] = true,
["LimitWarn"] = true,
["Calling"] = false,
["Currency2914"] = false,
["Scale"] = 1,
["Currency2245"] = false,
["Currency2813"] = true,
["NewFirst"] = true,
["TrackLFG"] = true,
["KeystoneReportTarget"] = "EXPORT",
["CallingShowCompleted"] = false,
["ServerOnly"] = false,
["Currency2915"] = false,
["AugmentBonus"] = true,
["CombineLFR"] = true,
["MythicKey"] = true,
["Currency3023"] = true,
["Emissary7"] = false,
["ServerSort"] = true,
["Currency2916"] = false,
["FitToScreen"] = true,
["SelfAlways"] = false,
["EmissaryShowCompleted"] = true,
["Currency2815"] = false,
["TrackPlayed"] = true,
["TrackWeeklyQuests"] = true,
["TrackSkills"] = false,
["SelfFirst"] = true,
["ShowHoliday"] = true,
["Currency2803"] = false,
},
["QuestDB"] = {
["Daily"] = {
[53885] = -1,
[61075] = -1,
[60762] = -1,
[61079] = -1,
[60646] = -1,
[61103] = -1,
[77165] = 2112,
[51982] = -1,
[77303] = 2112,
[53939] = -1,
[54132] = -1,
[63206] = -1,
[54136] = -1,
[54138] = -1,
[53701] = -1,
[62214] = -1,
[53711] = -1,
[61088] = -1,
[60775] = -1,
[61765] = -1,
[62234] = -1,
[61104] = -1,
[54137] = -1,
[58151] = -1,
[58156] = -1,
[58155] = -1,
[54134] = -1,
[58168] = -1,
[54135] = -1,
[60622] = -1,
[53883] = -1,
[58167] = -1,
},
["Darkmoon"] = {
["expires"] = 1728856740,
[47767] = -1,
},
["AccountDaily"] = {
[31752] = -1,
[34774] = -1,
[56042] = -1,
[40753] = -1,
},
["Weekly"] = {
[66937] = -1,
[62452] = -1,
[72175] = -1,
[82491] = -1,
[59019] = -1,
[80671] = -1,
[52951] = -1,
[48911] = -1,
[72719] = -1,
[78915] = -1,
[60249] = -1,
[66364] = -1,
[76169] = -1,
[72720] = -1,
[75307] = -1,
[82493] = 2339,
[57008] = -1,
[66940] = -1,
[56050] = -1,
[70613] = -1,
[78821] = -1,
[75308] = -1,
[82494] = -1,
[76394] = -1,
[60250] = -1,
[81632] = -1,
[83229] = -1,
[79173] = -1,
[66941] = -1,
[70582] = -1,
[70614] = -1,
[72722] = -1,
[70199] = -1,
[82495] = -1,
[80004] = -1,
[66942] = -1,
[81793] = -1,
[83358] = -1,
[70615] = -1,
[72723] = -1,
[70200] = -1,
[82496] = -1,
[60251] = -1,
[57728] = -1,
[70935] = -1,
[66943] = -1,
[81794] = -1,
[83359] = -1,
[70616] = -1,
[72724] = -1,
[70201] = -1,
[70233] = -1,
["expires"] = 1729655999,
[66944] = -1,
[81795] = -1,
[83360] = -1,
[70617] = -1,
[72725] = -1,
[70202] = -1,
[70234] = -1,
[56148] = -1,
[60252] = -1,
[72438] = -1,
[66945] = -1,
[81796] = -1,
[56308] = -1,
[70618] = -1,
[82946] = 2214,
[55350] = -1,
[82499] = -1,
[82531] = -1,
[72407] = -1,
[82659] = -1,
[82787] = -1,
[75665] = -1,
[70587] = -1,
[70619] = -1,
[72727] = -1,
[40787] = -1,
[82500] = -1,
[78444] = -1,
[60253] = -1,
[81574] = -1,
[62441] = -1,
[70620] = -1,
[72728] = -1,
[82501] = -1,
[66884] = -1,
[52956] = -1,
[70557] = -1,
[70589] = -1,
[82502] = -1,
[60254] = -1,
[72410] = -1,
[66949] = -1,
[83333] = 2214,
[83365] = -1,
[72155] = -1,
[78319] = -1,
[82503] = -1,
[53436] = -1,
[66950] = -1,
[70559] = -1,
[83366] = 2339,
[72156] = -1,
[75286] = -1,
[57157] = -1,
[60255] = -1,
[66951] = -1,
[70560] = -1,
[70592] = -1,
[72157] = -1,
[52782] = -1,
[70752] = -1,
[83240] = 2328,
[52958] = -1,
[70561] = -1,
[70593] = -1,
[72158] = -1,
[75288] = -1,
[70753] = -1,
[62284] = -1,
[60256] = -1,
[70530] = -1,
[70562] = -1,
[70594] = -1,
[72159] = -1,
[75289] = -1,
[70211] = -1,
[70754] = -1,
[66890] = -1,
[40168] = -1,
[70531] = -1,
[70563] = -1,
[70595] = -1,
[79346] = -1,
[70723] = -1,
[56648] = -1,
[62285] = -1,
[60257] = -1,
[84776] = -1,
[70532] = -1,
[70564] = -1,
[62445] = -1,
[33334] = -1,
[82509] = -1,
[52957] = -1,
[55499] = -1,
[70533] = -1,
[70565] = -1,
[82497] = 2339,
[82414] = -1,
[56649] = -1,
[78933] = -1,
[60242] = -1,
[59017] = -1,
[80562] = -1,
[53435] = -1,
[52948] = -1,
[60243] = -1,
[70750] = -1,
[66952] = -1,
[47148] = -1,
[82511] = -1,
[56969] = -1,
[81649] = -1,
[79158] = -1,
[70558] = -1,
[70567] = -1,
[82512] = -1,
[62287] = -1,
[80672] = -1,
[70568] = -1,
[82449] = -1,
[70569] = -1,
[76733] = -1,
[82482] = -1,
[62288] = -1,
[82706] = -1,
[66897] = -1,
[83345] = -1,
[82355] = -1,
[82483] = -1,
[78427] = -1,
[70591] = -1,
[72423] = -1,
[82707] = -1,
[80184] = -1,
[62286] = -1,
[79226] = -1,
[70571] = -1,
[82498] = -1,
[66363] = -1,
[40786] = -1,
[82452] = 2339,
[66953] = -1,
[78428] = -1,
[62289] = -1,
[72726] = -1,
[75304] = -1,
[75309] = -1,
[47523] = 111,
[56064] = -1,
[80185] = -1,
[72686] = -1,
[70540] = -1,
[83347] = 2339,
[62449] = -1,
[33338] = -1,
[83364] = -1,
[64541] = -1,
[82485] = -1,
[52944] = -1,
[78972] = -1,
[82852] = -1,
[82507] = -1,
[59016] = -1,
[64710] = -1,
[82709] = -1,
[66900] = -1,
[40173] = -1,
[66516] = -1,
[66517] = -1,
[75351] = -1,
[55498] = -1,
[60244] = -1,
[82486] = -1,
[80186] = 2339,
[60246] = -1,
[82508] = -1,
[64522] = -1,
[82678] = 2367,
[45563] = -1,
[80187] = -1,
[80189] = -1,
[62450] = -1,
[52953] = -1,
[32640] = -1,
[75301] = -1,
[82487] = -1,
[72810] = -1,
[82505] = -1,
[70203] = -1,
[72427] = -1,
[82679] = 2367,
[82711] = -1,
[80188] = -1,
[52949] = -1,
[76122] = -1,
[70586] = -1,
[72172] = -1,
[83363] = 2339,
[82488] = -1,
[55121] = -1,
[60247] = -1,
[52954] = -1,
[79216] = -1,
[72428] = -1,
[82506] = -1,
[82712] = -1,
[78656] = -1,
[66935] = -1,
[82516] = -1,
[66891] = -1,
[66938] = -1,
[72173] = -1,
[70572] = -1,
[56650] = -1,
[82489] = -1,
[82492] = -1,
[82453] = -1,
[83362] = -1,
[59018] = -1,
[60245] = -1,
[81691] = -1,
[70235] = -1,
[52950] = -1,
[70545] = -1,
[76600] = -1,
[48910] = -1,
[82510] = -1,
[48912] = -1,
[82458] = -1,
[82490] = -1,
[60248] = -1,
[76997] = -1,
[52952] = -1,
[82504] = -1,
[80670] = 2255,
[82746] = -1,
[32641] = -1,
},
["AccountWeekly"] = {
[80592] = 2255,
[77236] = -1,
[83357] = -1,
[46292] = -1,
["expires"] = 1729655999,
[45539] = -1,
[72721] = -1,
[72528] = -1,
[58458] = -1,
[84370] = 2339,
[54186] = -1,
[56492] = -1,
},
},
["History"] = {
["Бимладен - Ревущий фьорд:Каменный Свод:party:23:1268"] = {
["last"] = 1729271761,
["create"] = 1729269934,
["desc"] = "Бимладен: Каменный Свод - Эпохальный",
},
},
["DBVersion"] = 12,
["Indicators"] = {
["R2ClassColor"] = true,
["D2Indicator"] = "BLANK",
["R7Color"] = {
1,
1,
0,
},
["R5Color"] = {
0,
0,
1,
},
["R1Text"] = "KILLED/TOTAL",
["R4Indicator"] = "BLANK",
["R1Color"] = {
0.6,
0.6,
0,
},
["R0Indicator"] = "BLANK",
["R8ClassColor"] = true,
["D2ClassColor"] = true,
["R4ClassColor"] = true,
["R6ClassColor"] = true,
["D2Color"] = {
0,
1,
0,
},
["D1Text"] = "KILLED/TOTAL",
["R5Text"] = "KILLED/TOTALL",
["R7Text"] = "KILLED/TOTALH",
["D1Indicator"] = "BLANK",
["R8Color"] = {
1,
0,
0,
},
["D3Indicator"] = "BLANK",
["D3ClassColor"] = true,
["R6Indicator"] = "BLANK",
["R6Color"] = {
0,
1,
0,
},
["D1Color"] = {
0,
0.6,
0,
},
["R4Color"] = {
1,
0,
0,
},
["R7Indicator"] = "BLANK",
["R2Text"] = "KILLED/TOTAL",
["R8Indicator"] = "BLANK",
["R0Text"] = "KILLED/TOTAL",
["R0Color"] = {
0.6,
0.6,
0,
},
["R1Indicator"] = "BLANK",
["R2Color"] = {
0.6,
0,
0,
},
["R3Indicator"] = "BLANK",
["R7ClassColor"] = true,
["R5Indicator"] = "BLANK",
["D1ClassColor"] = true,
["R4Text"] = "KILLED/TOTALH",
["R3Color"] = {
1,
1,
0,
},
["R3ClassColor"] = true,
["R3Text"] = "KILLED/TOTALH",
["R5ClassColor"] = true,
["R6Text"] = "KILLED/TOTAL",
["D3Color"] = {
1,
0,
0,
},
["R8Text"] = "KILLED/TOTALM",
["D3Text"] = "KILLED/TOTALM",
["D2Text"] = "KILLED/TOTALH",
["R2Indicator"] = "BLANK",
["R1ClassColor"] = true,
["R0ClassColor"] = true,
},
["Progress"] = {
["Enable"] = {
["tww-spreading-the-light"] = true,
["df-shipment-of-goods"] = false,
["df-fighting-is-its-own-reward"] = false,
["df-aiding-the-accord"] = false,
["df-services-requested"] = true,
["great-vault-pvp"] = false,
["timewalking"] = true,
["bfa-lesser-vision"] = false,
["df-the-superbloom"] = false,
["df-disciple-of-fyrakk"] = false,
["df-grand-hunt"] = false,
["df-a-worthy-ally-dream-wardens"] = false,
["df-blooming-dreamseeds"] = false,
["call-to-battle"] = true,
["the-world-awaits"] = true,
["emissary-of-war"] = true,
["tww-rollin-down-in-the-deeps"] = true,
["df-trial-of-flood"] = false,
["tww-biergoth-dungeon-quest"] = true,
["sl-replenish-the-reservoir"] = true,
["df-primal-storms-elementals"] = false,
["df-researchers-under-fire"] = false,
["df-a-worthy-ally-loamm-niffen"] = false,
["bfa-horrific-vision"] = false,
["tww-gearing-up-for-trouble"] = true,
["df-sparks-of-life"] = false,
["df-siege-on-dragonbane-keep"] = false,
["sl-patterns-within-patterns"] = false,
["tww-brawl-weekly"] = true,
["tww-radiant-echoes"] = true,
["df-trial-of-elements"] = false,
["df-time-rift"] = false,
["great-vault-raid"] = false,
["call-to-delves"] = true,
["bfa-nzoth-assault"] = false,
["The Severed Threads"] = true,
["tww-the-theater-trope"] = true,
["df-community-feast"] = false,
["df-dreamsurge"] = false,
["tww-the-call-of-the-worldsoul"] = true,
["tww-special-assignments"] = true,
["tww-pvp-world"] = true,
["bfa-island"] = false,
["sl-return-lost-souls"] = true,
["df-primal-storms-core"] = false,
["sl-shaping-fate"] = true,
["tww-lesser-keyflame"] = true,
["tww-the-key-to-success"] = true,
["sl-covenant-assault"] = false,
["tww-pvp-weekly"] = true,
["df-secured-shipment"] = false,
["df-the-big-dig-traitors-rest"] = false,
["great-vault-world"] = true,
["tww-weekly-cache"] = true,
},
["Order"] = {
["tww-spreading-the-light"] = 50,
["df-shipment-of-goods"] = 50,
["df-fighting-is-its-own-reward"] = 50,
["df-aiding-the-accord"] = 50,
["df-services-requested"] = 50,
["great-vault-pvp"] = 50,
["timewalking"] = 50,
["bfa-lesser-vision"] = 50,
["df-the-superbloom"] = 50,
["df-disciple-of-fyrakk"] = 50,
["df-grand-hunt"] = 50,
["df-a-worthy-ally-dream-wardens"] = 50,
["df-blooming-dreamseeds"] = 50,
["call-to-battle"] = 50,
["the-world-awaits"] = 50,
["emissary-of-war"] = 50,
["tww-rollin-down-in-the-deeps"] = 50,
["df-trial-of-flood"] = 50,
["tww-biergoth-dungeon-quest"] = 50,
["sl-replenish-the-reservoir"] = 50,
["df-primal-storms-elementals"] = 50,
["df-researchers-under-fire"] = 50,
["df-a-worthy-ally-loamm-niffen"] = 50,
["bfa-horrific-vision"] = 50,
["tww-gearing-up-for-trouble"] = 50,
["df-sparks-of-life"] = 50,
["df-siege-on-dragonbane-keep"] = 50,
["sl-patterns-within-patterns"] = 50,
["tww-brawl-weekly"] = 50,
["tww-radiant-echoes"] = 50,
["df-trial-of-elements"] = 50,
["df-time-rift"] = 50,
["great-vault-raid"] = 50,
["call-to-delves"] = 50,
["bfa-nzoth-assault"] = 50,
["The Severed Threads"] = 50,
["tww-the-theater-trope"] = 50,
["df-community-feast"] = 50,
["df-dreamsurge"] = 50,
["tww-the-call-of-the-worldsoul"] = 50,
["tww-special-assignments"] = 50,
["tww-pvp-world"] = 50,
["bfa-island"] = 50,
["sl-return-lost-souls"] = 50,
["df-primal-storms-core"] = 50,
["sl-shaping-fate"] = 50,
["tww-lesser-keyflame"] = 50,
["tww-the-key-to-success"] = 50,
["sl-covenant-assault"] = 50,
["tww-pvp-weekly"] = 50,
["df-secured-shipment"] = 50,
["df-the-big-dig-traitors-rest"] = 50,
["great-vault-world"] = 50,
["tww-weekly-cache"] = 50,
},
["User"] = {
},
},
["DailyResetTime"] = 1729310399,
["Quests"] = {
},
["RealmMap"] = {
},
}
