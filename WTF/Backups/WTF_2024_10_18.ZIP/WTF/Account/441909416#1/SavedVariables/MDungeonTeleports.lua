
MDungeonTeleports = {
["Season1Pos"] = {
["y"] = -521.8279612495558,
["x"] = 861.2559918902698,
},
["PortalLibraryPos"] = {
["y"] = -85.52383422851562,
["x"] = 1002,
},
["lastLoginMessageDate"] = "20241018",
["firstLaunch"] = false,
["showTooltips"] = false,
["selectedUIPack"] = "Interface/AddOns/MDungeonTeleports/media/ui/default_ui/",
["isSeason1PortalsShown"] = true,
["PortalLibraryRaidPos"] = {
["y"] = -195,
["x"] = 970,
},
["selectedFramePack"] = "Interface/Addons/MDungeonTeleports/media/frames/default_frames.blp",
["frameScale"] = 1.200000047683716,
["isPortalLibraryShown"] = false,
["isPortalLibraryRaidShown"] = false,
}
