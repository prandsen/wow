
HandyNotes_TheWarWithinDB = {
["profileKeys"] = {
["Сорчистино - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["icon_display_flat_earthen"] = false,
["icon_display_profession_treasures"] = false,
},
},
}
