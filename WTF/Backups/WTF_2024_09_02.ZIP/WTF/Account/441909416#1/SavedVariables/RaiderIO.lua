
RaiderIO_Config = {
["replayAlpha"] = 1,
["enableKeystoneTooltips"] = true,
["profilePoint"] = {
["y"] = 0,
["x"] = -16,
["point"] = "TOPLEFT",
},
["enableReplay"] = true,
["enableLFGDropdown"] = true,
["minimapIcon"] = {
["minimapPos"] = 180,
["showInCompartment"] = true,
["lock"] = false,
["hide"] = true,
},
["showMainsScore"] = true,
["showRaidEncountersInProfile"] = true,
["showAverageScore"] = true,
["enableWhoMessages"] = false,
["useEnglishAbbreviations"] = true,
["disableScoreColors"] = false,
["showMainBestScore"] = true,
["allowClientToControlCombatLog"] = false,
["replayBackground"] = {
["a"] = 0.5,
["r"] = 0,
["g"] = 0,
["b"] = 0,
},
["showRaiderIOProfile"] = true,
["showSimpleScoreColors"] = false,
["replaySelection"] = "user_best_replay",
["inverseProfileModifier"] = false,
["enableGuildTooltips"] = true,
["enableWhoTooltips"] = false,
["showScoreModifier"] = false,
["enableProfileModifier"] = true,
["showRoleIcons"] = true,
["enableUnitTooltips"] = true,
["enableFriendsTooltips"] = true,
["hidePersonalRaiderIOProfile"] = false,
["showDropDownCopyURL"] = true,
["positionProfileAuto"] = true,
["enableLFGTooltips"] = true,
["enableClientEnhancements"] = true,
["enableCombatLogTracking"] = false,
["lockProfile"] = false,
["showScoreInCombat"] = true,
["mplusHeadlineMode"] = 0,
["showClientGuildBest"] = true,
}
RaiderIO_LastCharacter = "eu-Вольтчара-soulflayer"
RaiderIO_MissingCharacters = {
["eu-Вольтчара-soulflayer"] = true,
["eu-Кельтекс-soulflayer"] = true,
["eu-Ргооху-soulflayer"] = true,
["eu-Жуня-soulflayer"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
