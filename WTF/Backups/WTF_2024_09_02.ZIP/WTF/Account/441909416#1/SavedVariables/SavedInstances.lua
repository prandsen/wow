
SavedInstancesDB = {
["DBVersion"] = 12,
["Toons"] = {
["Вантачмэн - Ревущий фьорд"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Монахиня",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 485.4375,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1724710109,
["Order"] = 50,
["Class"] = "MONK",
["ILPvp"] = 486.9375,
["currency"] = {
[2413] = {
["amount"] = 27,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[2650] = {
["amount"] = 9,
},
[2706] = {
["amount"] = 0,
},
[2777] = {
["amount"] = 1,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 18769,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1767] = {
["amount"] = 15729,
},
[738] = {
["amount"] = 2,
},
[1275] = {
["amount"] = 69,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 93,
},
[1220] = {
["amount"] = 20273,
},
[1602] = {
["amount"] = 0,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 68,
},
[1803] = {
["amount"] = 2173,
},
[1719] = {
["amount"] = 9929,
},
[2708] = {
["amount"] = 0,
},
[2003] = {
["amount"] = 2139,
},
[2409] = {
["totalEarned"] = 160,
["amount"] = 160,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 330,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1191] = {
["amount"] = 0,
},
[2709] = {
["amount"] = 0,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1906] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 1,
},
[1977] = {
["amount"] = 51,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1166] = {
["amount"] = 5830,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[2707] = {
["amount"] = 0,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 14,
},
[1560] = {
["amount"] = 39597,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 252,
},
[2411] = {
["totalEarned"] = 186,
["amount"] = 186,
},
[2774] = {
["amount"] = 20,
},
[1828] = {
["amount"] = 21950,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 632,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 2,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 915,
},
[2412] = {
["totalEarned"] = 580,
["amount"] = 580,
},
[1226] = {
["amount"] = 12160,
},
[2410] = {
["totalEarned"] = 103,
["amount"] = 103,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1931] = {
["amount"] = 7485,
},
[1716] = {
["amount"] = 342,
},
[1813] = {
["covenant"] = {
[4] = 42597,
},
["totalMax"] = 200000,
["amount"] = 42597,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1810] = {
["covenant"] = {
[4] = 9,
},
["totalMax"] = 100,
["amount"] = 9,
},
},
["Warmode"] = false,
["WeeklyResetTime"] = 1725422399,
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["PlayedTotal"] = 8893096,
["Arena2v2rating"] = 0,
["MythicKey"] = {
},
["Money"] = 6130217354,
["Skills"] = {
},
["MaxXP"] = 225105,
["SpecializationIDs"] = {
268,
270,
269,
},
["MythicPlusScore"] = 0,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"1/1 Продолжите кампанию \"Хранители Сна\", чтобы открыть Изумрудный Сон",
"Посадите семена Сна: 0/3",
"3000/3000 Повысьте репутацию среди фракций Драконьих островов",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 1,
["leaderboardCount"] = 3,
["text"] = "1/1 0/3 3000/3000",
["objectiveType"] = "object",
["numFulfilled"] = 1,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["great-vault-pvp"] = {
["isComplete"] = false,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["numFulfilled"] = 0,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
"Посадите семена Сна: 0/3",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 3,
["leaderboardCount"] = 1,
["text"] = "0/3",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["emissary-of-war"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["PlayedLevel"] = 1251078,
["Covenant"] = 4,
["IL"] = 486.9375,
["DailyResetTime"] = 1725249599,
["Zone"] = "Вальдраккен",
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725422399,
},
["unlocked"] = true,
},
},
["Топмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Маг",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 453.8125,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1724710196,
["SpecializationIDs"] = {
62,
63,
64,
},
["Class"] = "MAGE",
["ILPvp"] = 454.1875,
["currency"] = {
[2413] = {
["amount"] = 27,
},
[2650] = {
["amount"] = 50,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
[2003] = {
["amount"] = 647,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 9553,
},
[1885] = {
["amount"] = 2,
},
[1889] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 3502,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 170,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 208,
},
[1220] = {
["amount"] = 7992,
},
[1803] = {
["amount"] = 4344,
},
[2409] = {
["totalEarned"] = 83,
["amount"] = 83,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 302,
},
[2118] = {
["amount"] = 50,
},
[1719] = {
["amount"] = 725,
},
[1275] = {
["amount"] = 190,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 112,
},
[2410] = {
["totalEarned"] = 124,
["amount"] = 124,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 3175,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[2707] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 1410,
},
[1718] = {
["amount"] = 0,
},
[2411] = {
["totalEarned"] = 196,
["amount"] = 196,
},
[1533] = {
["amount"] = 1223,
},
[1828] = {
["amount"] = 30,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 2,
},
[1710] = {
["amount"] = 7,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 6,
},
[2774] = {
["amount"] = 3,
},
[1155] = {
["totalMax"] = 900,
["amount"] = 204,
},
[2412] = {
["totalEarned"] = 36,
["amount"] = 36,
},
[1226] = {
["amount"] = 23153,
},
[1822] = {
["covenant"] = {
[3] = 6,
},
["totalMax"] = 80,
["amount"] = 6,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 11,
},
[2706] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[3] = 124,
},
["totalMax"] = 200000,
["amount"] = 124,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 304,
},
},
["Warmode"] = false,
["Order"] = 50,
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["PlayedTotal"] = 4161106,
["Arena2v2rating"] = 0,
["MaxXP"] = 225105,
["Money"] = 61551664,
["Skills"] = {
},
["MythicKey"] = {
},
["WeeklyResetTime"] = 1725422399,
["MythicPlusScore"] = 0,
["IL"] = 454.1875,
["PlayedLevel"] = 159867,
["Covenant"] = 3,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"1/1 Продолжите кампанию \"Хранители Сна\", чтобы открыть Изумрудный Сон",
"Получите цветок во время Цветочного бума: 0/50",
"Завершите Цветочный бум: 0/1",
"0/3000 Повысьте репутацию среди фракций Драконьих островов",
["show"] = true,
["numFulfilled"] = 1,
["numRequired"] = 1,
["isComplete"] = false,
["leaderboardCount"] = 4,
["text"] = "1/1 0/50 0/1 0/3000",
["objectiveType"] = "object",
["isFinish"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["great-vault-pvp"] = {
["isComplete"] = false,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["numFulfilled"] = 0,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["DailyResetTime"] = 1725249599,
["Zone"] = "Вальдраккен",
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725422399,
},
["unlocked"] = true,
},
},
["Мальдика - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Жрица",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 485.625,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1724710169,
["SpecializationIDs"] = {
256,
257,
258,
},
["Class"] = "PRIEST",
["ILPvp"] = 486,
["currency"] = {
[1191] = {
["amount"] = 0,
},
[1904] = {
["totalEarned"] = 1779,
["totalMax"] = 3510,
["amount"] = 109,
},
[1719] = {
["amount"] = 2469,
},
[1979] = {
["amount"] = 522,
},
[1810] = {
["covenant"] = {
[3] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 2290,
},
[1822] = {
["covenant"] = {
[3] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1767] = {
["amount"] = 2,
},
[2707] = {
["amount"] = 0,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 44,
},
[1906] = {
["amount"] = 8970,
},
[1721] = {
["amount"] = 27,
},
[1977] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 1630,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1560] = {
["amount"] = 5617,
},
[2009] = {
["amount"] = 47052,
},
[1828] = {
["amount"] = 59010,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 250,
},
[1718] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 1,
},
[2709] = {
["amount"] = 0,
},
[1716] = {
["amount"] = 100,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1813] = {
["covenant"] = {
[3] = 33190,
},
["totalMax"] = 200000,
["amount"] = 33190,
},
[2708] = {
["amount"] = 0,
},
[2774] = {
["amount"] = 17,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["Warmode"] = false,
["PlayedTotal"] = 3879764,
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["RestXP"] = 14,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["MaxXP"] = 225105,
["Money"] = 346986915,
["Order"] = 50,
["WeeklyResetTime"] = 1725422399,
["MythicPlusScore"] = 0,
["IL"] = 486,
["PlayedLevel"] = 285467,
["Covenant"] = 3,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["great-vault-pvp"] = {
["isComplete"] = false,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["numFulfilled"] = 0,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["emissary-of-war"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["DailyResetTime"] = 1725249599,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725422399,
},
["unlocked"] = true,
},
["Zone"] = "Вальдраккен",
},
["Сорчистино - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сокровища валарьяров",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["currencyID"] = 1553,
["quantity"] = 3600,
},
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["currencyID"] = 1553,
["quantity"] = 600,
},
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Чернокнижница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 184.125,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 191.75,
["LastSeen"] = 1725204123,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-pvp"] = {
["unlocked"] = false,
["isComplete"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "WARLOCK",
["ILPvp"] = 191.75,
["currency"] = {
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 40,
},
[1275] = {
["amount"] = 150,
},
[1803] = {
["amount"] = 1265,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 442,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 195,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 45,
},
[1560] = {
["amount"] = 1041,
},
[1220] = {
["amount"] = 5255,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[1719] = {
["amount"] = 122,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 4,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 12450,
},
[1226] = {
["amount"] = 11010,
},
[1533] = {
["amount"] = 5728,
},
[1166] = {
["amount"] = 2165,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 46,
},
[1710] = {
["amount"] = 4,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
},
["MythicKey"] = {
},
["Warmode"] = false,
["RestXP"] = 83498,
["Level"] = 60,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
["rewardWaiting"] = false,
},
["PlayedTotal"] = 3075572,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["Money"] = 178639,
["oRace"] = "BloodElf",
["MaxXP"] = 55665,
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1725422399,
["PlayedLevel"] = 7165,
["SpecializationIDs"] = {
265,
266,
267,
},
["Calling"] = {
},
["DailyResetTime"] = 1725249599,
["Order"] = 50,
["Zone"] = "Орибос",
},
["Дракобес - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
},
["Race"] = "Драктир",
["LClass"] = "Пробудитель",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[2] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 417.0625,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "Dracthyr",
["LastSeen"] = 1724710226,
["SpecializationIDs"] = {
1467,
1468,
1473,
},
["Class"] = "EVOKER",
["ILPvp"] = 417.0625,
["currency"] = {
[2003] = {
["amount"] = 3880,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1191] = {
["amount"] = 0,
},
},
["Zone"] = "Вальдраккен",
["Warmode"] = false,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725249599,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725335999,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1725422399,
},
["unlocked"] = true,
},
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
},
["PlayedTotal"] = 897304,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1725249599,
["Money"] = 65027,
["Order"] = 50,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"Отправьтесь на штурм Драконьей Погибели: 0/1",
"3000/3000 Репутация среди фракций Драконьих островов",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 1,
["leaderboardCount"] = 2,
["text"] = "0/1 3000/3000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["great-vault-pvp"] = {
["isComplete"] = false,
["unlocksCompleted"] = 0,
["unlocked"] = false,
["numFulfilled"] = 0,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
},
["Covenant"] = 0,
["MythicPlusScore"] = 0,
["IL"] = 417.0625,
["PlayedLevel"] = 835922,
["WeeklyResetTime"] = 1725422399,
["MythicKey"] = {
},
["Skills"] = {
},
["MaxXP"] = 225105,
["RestXP"] = 2,
},
["Бимладен - Ревущий фьорд"] = {
["lastbossyell"] = "Глашатай Бреция",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Сокровища валарьяров",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["currencyID"] = 1553,
["quantity"] = 3600,
},
},
{
["questReward"] = {
["itemName"] = "Сундук со снаряжением ордена Пылающих Углей",
["itemLvl"] = 99,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["currencyID"] = 1553,
["quantity"] = 600,
},
},
},
},
},
["Race"] = "Ночная эльфийка",
["LClass"] = "Друид",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
1702,
0,
0,
2192,
},
["lastbosstime"] = 1725201386,
["Covenant"] = 4,
["TimewornMythicKey"] = {
},
["Faction"] = "Alliance",
["ILe"] = 570.25,
["Quests"] = {
[83240] = {
["Expires"] = 1725422399,
["Title"] = "Театральная труппа",
["Link"] = "|cffffff00|Hquest:83240:2462|h[Театральная труппа]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2328,
["name"] = "Авансцена",
["parentMapID"] = 2248,
["flags"] = 524292,
},
["isDaily"] = false,
},
[83333] = {
["Expires"] = 1725422399,
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2214,
["name"] = "Гулкие глубины",
["parentMapID"] = 2274,
["flags"] = 6,
},
["Title"] = "Шестеренки неприятностей",
["Link"] = "|cffffff00|Hquest:83333:90|h[Шестеренки неприятностей]|h|r",
},
[80670] = {
["Expires"] = 1725422399,
["Title"] = "Глаза Прядильщицы",
["Link"] = "|cffffff00|Hquest:80670:2861|h[Глаза Прядильщицы]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2255,
["name"] = "Аз-Кахет",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
[82452] = {
["Expires"] = 1725422399,
["Title"] = "Воспоминание души мира: локальные задания",
["Link"] = "|cffffff00|Hquest:82452:2838|h[Воспоминание души мира: локальные задания]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["isDaily"] = false,
},
[82946] = {
["Expires"] = 1725422399,
["Title"] = "Вниз в глубины",
["Link"] = "|cffffff00|Hquest:82946:2869|h[Вниз в глубины]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2214,
["name"] = "Гулкие глубины",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
},
["Paragon"] = {
2413,
},
["WeeklyResetTime"] = 1725422399,
["LastSeen"] = 1725219316,
["SpecializationIDs"] = {
102,
103,
104,
105,
},
["Class"] = "DRUID",
["ILPvp"] = 573.0625,
["oRace"] = "NightElf",
["currency"] = {
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[2650] = {
["amount"] = 659,
},
[2809] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 47,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 10,
},
[1810] = {
["covenant"] = {
[4] = 4,
},
["totalMax"] = 100,
["amount"] = 4,
},
[1191] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 740,
},
[2812] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 45801,
},
[1717] = {
["amount"] = 604,
},
[2815] = {
["amount"] = 4185,
},
[2003] = {
["amount"] = 24710,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 1,
},
[2594] = {
["amount"] = 3431,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 2000,
},
[1560] = {
["amount"] = 16480,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 2645,
},
[1275] = {
["amount"] = 5,
},
[2122] = {
["amount"] = 19,
},
[2123] = {
["totalMax"] = 200000,
["amount"] = 0,
},
[2409] = {
["totalEarned"] = 807,
["amount"] = 807,
},
[2410] = {
["totalEarned"] = 1364,
["amount"] = 1364,
},
[2411] = {
["totalEarned"] = 1498,
["amount"] = 1498,
},
[1166] = {
["amount"] = 7400,
},
[2412] = {
["totalEarned"] = 3984,
["amount"] = 3984,
},
[2413] = {
["amount"] = 28,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1977] = {
["amount"] = 22,
},
[2009] = {
["amount"] = 41885,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 6102,
},
[1931] = {
["amount"] = 9542,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1979] = {
["amount"] = 558,
},
[2118] = {
["amount"] = 34197,
},
[2800] = {
["totalEarned"] = 12,
["totalMax"] = 20,
["amount"] = 12,
},
[1533] = {
["amount"] = 3588,
},
[1889] = {
["amount"] = 18,
},
[1710] = {
["amount"] = 945,
},
[1602] = {
["amount"] = 0,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 13,
},
[515] = {
["amount"] = 10,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 27,
},
[2707] = {
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1719] = {
["amount"] = 7096,
},
[3023] = {
["totalEarned"] = 1,
["totalMax"] = 1,
["amount"] = 1,
},
[2708] = {
["amount"] = 0,
},
[2806] = {
["amount"] = 0,
},
[3028] = {
["amount"] = 4,
},
[3010] = {
["totalEarned"] = 11,
["totalMax"] = 18,
["amount"] = 11,
},
[2709] = {
["amount"] = 0,
},
[3056] = {
["amount"] = 4066,
},
[2777] = {
["amount"] = 2,
},
[1220] = {
["amount"] = 3293,
},
[1721] = {
["amount"] = 28,
},
[1767] = {
["amount"] = 13155,
},
[2774] = {
["amount"] = 23,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[4] = 34350,
},
["totalMax"] = 200000,
["amount"] = 34350,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 6794,
},
[2914] = {
["totalEarned"] = 162,
["totalMax"] = 180,
["amount"] = 117,
},
[2807] = {
["amount"] = 0,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 25,
},
[2915] = {
["totalEarned"] = 10,
["totalMax"] = 180,
["amount"] = 110,
},
},
["IL"] = 573.0625,
["Warmode"] = false,
["DailyResetTime"] = 1725249599,
["Level"] = 80,
["Order"] = 50,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 27772691,
["Arena2v2rating"] = 1750,
["lastbossyelltime"] = 1725206198,
["MaxXP"] = 100000000,
["Show"] = "saved",
["Money"] = 5227425702,
["Zone"] = "Дорногал",
["MythicPlusScore"] = 3751,
["lastboss"] = "Глашатай Гальвен: Вылазки",
["PlayedLevel"] = 143545,
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
["rewardWaiting"] = false,
},
["Arena3v3rating"] = 1776,
["Skills"] = {
},
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["great-vault-pvp"] = {
["unlocksCompleted"] = 0,
["maxUnlocks"] = 0,
["rewardWaiting"] = false,
["isComplete"] = true,
["numRequired"] = 0,
["unlocked"] = true,
["numFulfilled"] = 0,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
},
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Призыв Арденвельда",
["questID"] = 60423,
["expiredTime"] = 1725249599,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Буря в Утробе",
["questID"] = 60455,
["expiredTime"] = 1725335999,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Помощь Малдраксусу",
["questID"] = 60396,
["expiredTime"] = 1725422399,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
},
["Вольтчара - Свежеватель Душ"] = {
["lastbossyell"] = "Ки'катал Жница: Обычный",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questReward"] = {
["itemName"] = "Сокровища валарьяров",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["quantity"] = 3600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["quantity"] = 600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Тауренка",
["LClass"] = "Шаманка",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["lastbosstime"] = 1725066048,
["Covenant"] = 1,
["TimewornMythicKey"] = {
},
["Arena3v3rating"] = 0,
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Призыв Арденвельда",
["questID"] = 60424,
["expiredTime"] = 1725249599,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Буря в Утробе",
["questID"] = 60454,
["expiredTime"] = 1725335999,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Помощь Малдраксусу",
["questID"] = 60395,
["expiredTime"] = 1725422399,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["ILe"] = 470.6875,
["Money"] = 171012976,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "Tauren",
["LastSeen"] = 1725221756,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["great-vault-pvp"] = {
["unlocksCompleted"] = 0,
["maxUnlocks"] = 0,
["rewardWaiting"] = false,
["isComplete"] = true,
["numRequired"] = 0,
["unlocked"] = true,
["numFulfilled"] = 0,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
},
["Class"] = "SHAMAN",
["ILPvp"] = 496.25,
["Faction"] = "Horde",
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1822] = {
["covenant"] = {
80,
},
["amount"] = 80,
["totalMax"] = 80,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1979] = {
["amount"] = 807,
},
[1828] = {
["amount"] = 96655,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1810] = {
["covenant"] = {
7,
},
["amount"] = 7,
["totalMax"] = 100,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1977] = {
["amount"] = 16,
},
[1885] = {
["amount"] = 21,
},
[1767] = {
["amount"] = 28146,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[1931] = {
["amount"] = 1579,
},
[1560] = {
["amount"] = 3,
},
[2009] = {
["amount"] = 38086,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1191] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 1092,
},
[1906] = {
["amount"] = 7480,
},
[2000] = {
["amount"] = 37,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 15,
},
[1166] = {
["amount"] = 2775,
},
[1904] = {
["totalEarned"] = 3510,
["amount"] = 0,
["totalMax"] = 3510,
},
[1602] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
140482,
},
["amount"] = 140482,
["totalMax"] = 200000,
},
},
["IL"] = 496.25,
["Warmode"] = false,
["Skills"] = {
},
["Level"] = 80,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 4139776,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1725066048,
["MaxXP"] = 100000000,
["SpecializationIDs"] = {
262,
263,
264,
},
["WeeklyResetTime"] = 1725422399,
["lastboss"] = "Ки'катал Жница: Обычный",
["MythicPlusScore"] = 0,
["PlayedLevel"] = 2606,
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1725422399,
["rewardWaiting"] = false,
},
["Order"] = 50,
["DailyResetTime"] = 1725249599,
["Show"] = "saved",
["Zone"] = "Дорногал",
},
},
["MinimapIcon"] = {
["showInCompartment"] = true,
["hide"] = false,
},
["Emissary"] = {
["Expansion"] = {
[6] = {
{
["questID"] = {
["Horde"] = 48642,
["Alliance"] = 48642,
},
["questNeed"] = 4,
["expiredTime"] = 1725249691,
},
{
["questID"] = {
["Horde"] = 42234,
["Alliance"] = 42234,
},
["questNeed"] = 4,
["expiredTime"] = 1725336091,
},
{
["questID"] = {
["Horde"] = 42422,
["Alliance"] = 42422,
},
["questNeed"] = 4,
["expiredTime"] = 1725422491,
},
},
[7] = {
{
["questID"] = {
["Horde"] = 50562,
["Alliance"] = 50562,
},
["questNeed"] = 4,
["expiredTime"] = 1725249691,
},
{
["questID"] = {
["Horde"] = 50603,
["Alliance"] = 50600,
},
["questNeed"] = 4,
["expiredTime"] = 1725336091,
},
{
["questID"] = {
["Horde"] = 50606,
["Alliance"] = 50605,
},
["questNeed"] = 4,
["expiredTime"] = 1725422491,
},
},
},
["Cache"] = {
[43179] = "Маги Кирин-Тора в Даларане",
[50601] = "Возрождение Шторма",
[48639] = "Армия Света",
[50562] = "Защитники Азерот",
[48641] = "Армия погибели Легиона",
[48642] = "Защитники Аргуса",
[42234] = "Валарьяры",
[50605] = "Военная кампания Альянса",
[50598] = "Империя Зандалари",
[50599] = "Адмиралтейство Праудмуров",
[50600] = "Орден Пылающих Углей",
[56119] = "Клинки Волн",
[50602] = "Экспедиция Таланджи",
[50603] = "Жители Вол'дуна",
[42420] = "Двор Фарондиса",
[42421] = "Помраченные",
[50606] = "Военная кампания Орды",
[42422] = "Стражи",
[56120] = "Освобожденные",
[42170] = "Ткачи Снов",
},
},
["Tooltip"] = {
["CurrencySortName"] = false,
["Emissary6"] = false,
["TrackBonus"] = false,
["TrackParagon"] = false,
["Currency3008"] = true,
["CombineWorldBosses"] = false,
["HistoryText"] = false,
["ShowCategories"] = false,
["Currency2807"] = false,
["posx"] = 895.2146606445312,
["Currency2806"] = false,
["ShowRandom"] = true,
["Currency3010"] = false,
["Currency2917"] = true,
["TimewornMythicKey"] = true,
["TrackDeserter"] = true,
["Currency2812"] = false,
["TrackDailyQuests"] = true,
["Currency2003"] = false,
["Currency2778"] = true,
["Scale"] = 1,
["ShowHints"] = true,
["AugmentBonus"] = true,
["Currency3023"] = true,
["ReverseInstances"] = false,
["CurrencyMax"] = false,
["MythicKeyBest"] = true,
["Currency2800"] = false,
["NumberFormat"] = true,
["ReportResets"] = true,
["Currency2809"] = false,
["CategorySort"] = "EXPANSION",
["ShowSoloCategory"] = false,
["ShowServer"] = false,
["Currency3056"] = false,
["Warfront1"] = false,
["ShowExpired"] = false,
["RaidsFirst"] = true,
["posy"] = 394.23828125,
["CombineCalling"] = true,
["ShowHoliday"] = true,
["Currency2914"] = true,
["CurrencyEarned"] = true,
["SelfFirst"] = true,
["CurrencyValueColor"] = true,
["Currency3028"] = true,
["TrackWeeklyQuests"] = true,
["Currency3089"] = true,
["LimitWarn"] = true,
["Calling"] = false,
["RowHighlight"] = 0.1,
["AbbreviateKeystone"] = true,
["Currency2915"] = true,
["NewFirst"] = true,
["TrackLFG"] = true,
["KeystoneReportTarget"] = "EXPORT",
["CallingShowCompleted"] = true,
["EmissaryShowCompleted"] = true,
["CategorySpaces"] = false,
["ServerOnly"] = false,
["ConnectedRealms"] = "group",
["ServerSort"] = true,
["SelfAlways"] = false,
["Emissary7"] = false,
["CombineEmissary"] = false,
["Currency2916"] = true,
["FitToScreen"] = true,
["Currency2245"] = false,
["Currency2815"] = false,
["EmissaryFullName"] = true,
["TrackPlayed"] = true,
["CombineLFR"] = true,
["TrackSkills"] = true,
["Warfront2"] = false,
["MythicKey"] = true,
["Currency2803"] = true,
},
["Progress"] = {
["Enable"] = {
["df-shipment-of-goods"] = false,
["df-fighting-is-its-own-reward"] = false,
["df-aiding-the-accord"] = false,
["great-vault-pvp"] = false,
["timewalking"] = true,
["bfa-lesser-vision"] = false,
["df-the-superbloom"] = false,
["df-disciple-of-fyrakk"] = false,
["df-grand-hunt"] = false,
["df-a-worthy-ally-dream-wardens"] = false,
["df-blooming-dreamseeds"] = false,
["df-a-worthy-ally-loamm-niffen"] = false,
["df-researchers-under-fire"] = false,
["sl-covenant-assault"] = false,
["df-trial-of-elements"] = false,
["bfa-nzoth-assault"] = false,
["df-community-feast"] = false,
["df-dreamsurge"] = false,
["the-world-awaits"] = true,
["bfa-horrific-vision"] = false,
["df-trial-of-flood"] = false,
["emissary-of-war"] = true,
["bfa-island"] = false,
["df-primal-storms-core"] = false,
["sl-patterns-within-patterns"] = false,
["df-primal-storms-elementals"] = false,
["df-sparks-of-life"] = false,
["df-siege-on-dragonbane-keep"] = false,
["tww-radiant-echoes"] = true,
["great-vault-raid"] = true,
["df-the-big-dig-traitors-rest"] = false,
["df-secured-shipment"] = false,
["df-time-rift"] = false,
},
["Order"] = {
["df-shipment-of-goods"] = 50,
["df-fighting-is-its-own-reward"] = 50,
["df-aiding-the-accord"] = 50,
["great-vault-pvp"] = 50,
["timewalking"] = 50,
["bfa-lesser-vision"] = 50,
["df-the-superbloom"] = 50,
["df-disciple-of-fyrakk"] = 50,
["df-grand-hunt"] = 50,
["df-a-worthy-ally-dream-wardens"] = 50,
["df-blooming-dreamseeds"] = 50,
["df-a-worthy-ally-loamm-niffen"] = 50,
["df-researchers-under-fire"] = 50,
["sl-covenant-assault"] = 50,
["df-trial-of-elements"] = 50,
["bfa-nzoth-assault"] = 50,
["df-community-feast"] = 50,
["df-dreamsurge"] = 50,
["the-world-awaits"] = 50,
["bfa-horrific-vision"] = 50,
["df-trial-of-flood"] = 50,
["emissary-of-war"] = 50,
["bfa-island"] = 50,
["df-primal-storms-core"] = 50,
["sl-patterns-within-patterns"] = 50,
["df-primal-storms-elementals"] = 50,
["df-sparks-of-life"] = 50,
["df-siege-on-dragonbane-keep"] = 50,
["tww-radiant-echoes"] = 50,
["great-vault-raid"] = 50,
["df-the-big-dig-traitors-rest"] = 50,
["df-secured-shipment"] = 50,
["df-time-rift"] = 50,
},
["User"] = {
},
},
["Instances"] = {
["Трон Четырех Ветров"] = {
["LFDID"] = 318,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Залы Искажения Плоти"] = {
["LFDID"] = 837,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Квартал Звезд"] = {
["LFDID"] = 2280,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Авангард Тюремщика"] = {
["LFDID"] = 2221,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Малификус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1884,
["RecLevel"] = 45,
["Raid"] = true,
},
["Огненные Просторы"] = {
["LFDID"] = 362,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Театр Боли"] = {
["LFDID"] = 2124,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Залы Искажения Плоти"] = {
["LFDID"] = 2592,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Ара-Кара, Город Отголосков"] = {
["LFDID"] = 2726,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Глубины преданных"] = {
["LFDID"] = 2010,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Сотанатор"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2014,
["RecLevel"] = 45,
["Raid"] = true,
},
["Змеиное святилище"] = {
["LFDID"] = 194,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Битва за Дазар'алор"] = {
["LFDID"] = 1944,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Базуал"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2517,
["RecLevel"] = 70,
["Raid"] = true,
},
["Т'зейн"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2139,
["RecLevel"] = 50,
["Raid"] = true,
},
["Крепость Черной Ладьи"] = {
["LFDID"] = 2275,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Сила Альянса"] = {
["LFDID"] = 1947,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Аркатрац"] = {
["LFDID"] = 1011,
["Expansion"] = 1,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Сон наяву"] = {
["LFDID"] = 2039,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Город Нитей"] = {
["LFDID"] = 2722,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["Инквизитор Мето"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2012,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria (героич.)"] = {
["LFDID"] = 462,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Изначальный бастион"] = {
["LFDID"] = 2703,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Случайное подземелье Cataclysm (героич.)"] = {
["LFDID"] = 301,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Непроглядная Пучина"] = {
["LFDID"] = 10,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное героическое подземелье (Mists of Pandaria)"] = {
["LFDID"] = 2537,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Победа или смерть"] = {
["LFDID"] = 1950,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Подземная крепость"] = {
["LFDID"] = 841,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Нексус"] = {
["LFDID"] = 1019,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Падение империи"] = {
["LFDID"] = 1946,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Расплата у врат"] = {
["LFDID"] = 840,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Твердыня Крыла Тьмы"] = {
["LFDID"] = 314,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Храм Сетралисс"] = {
["LFDID"] = 1695,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Кузня Душ"] = {
["LFDID"] = 2322,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Тайный рынок Тазавеш"] = {
["LFDID"] = 2225,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Случайное подземелье (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2539,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Каламир"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1774,
["RecLevel"] = 45,
["Raid"] = true,
},
["Расплата"] = {
["LFDID"] = 2418,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Престол Гроз"] = {
["LFDID"] = 634,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Аметистовая крепость"] = {
["LFDID"] = 221,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Темный лабиринт"] = {
["LFDID"] = 181,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Орта"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2625,
["RecLevel"] = 80,
["Raid"] = true,
},
["Натанос Гнилостень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 9005,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Lich King (героич.)"] = {
["LFDID"] = 262,
["Expansion"] = 2,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Анторус, Пылающий Трон"] = {
["LFDID"] = 1642,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Апокрон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1956,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ботаника"] = {
["LFDID"] = 2325,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor (героич.)"] = {
["LFDID"] = 789,
["Expansion"] = 5,
["Show"] = "saved",
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["Логово Магтеридона"] = {
["LFDID"] = 176,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["СПР (LFR): Подъем Императора"] = {
["LFDID"] = 1365,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Истощающие хранилища"] = {
["LFDID"] = 2411,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Ауростор"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2562,
["RecLevel"] = 70,
["Raid"] = true,
},
["Азжол-Неруб"] = {
["LFDID"] = 2324,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Горнило Штормов"] = {
["LFDID"] = 1954,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Шуррай"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2636,
["RecLevel"] = 80,
["Raid"] = true,
},
["Граница Бездны"] = {
["LFDID"] = 2709,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Забытый город - квартал Криводревов"] = {
["LFDID"] = 34,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Чумные каскады"] = {
["LFDID"] = 2121,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Последний оплот зандаларов"] = {
["LFDID"] = 835,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Рубиновые Омуты Жизни"] = {
["LFDID"] = 2436,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Векемара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2363,
["RecLevel"] = 50,
["Raid"] = true,
},
["Стратхольм - Черный ход"] = {
["LFDID"] = 274,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Госпожа Аллюрадель"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2011,
["RecLevel"] = 45,
["Raid"] = true,
},
["Казематы Стражей"] = {
["LFDID"] = 2278,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Возвращение в Каражан (верхняя часть)"] = {
["LFDID"] = 1474,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Око Азшары"] = {
["LFDID"] = 2276,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Лисканот"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2518,
["RecLevel"] = 70,
["Raid"] = true,
},
["На'зак Одержимый"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1783,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Эфемеровые равнины"] = {
["LFDID"] = 2292,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Ан'кахет: Старое Королевство"] = {
["LFDID"] = 1016,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Надвигающийся ужас"] = {
["LFDID"] = 832,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Королевская библиотека"] = {
["LFDID"] = 1924,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Крепость Темного Клыка"] = {
["LFDID"] = 327,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Великий посол Огнехлыст"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 308,
},
["Островные экспедиции"] = {
["LFDID"] = 1762,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Хмелеварня Буйных Портеров"] = {
["LFDID"] = 2543,
["Expansion"] = 4,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Кузня Крови"] = {
["LFDID"] = 2326,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Йорундалль"] = {
["LFDID"] = 2041,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["Show"] = "saved",
},
["СПР (LFR): Великий замысел"] = {
["LFDID"] = 2294,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Шпили Перерождения"] = {
["LFDID"] = 2122,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Случайный сценарий Mists of Pandaria (героич.)"] = {
["LFDID"] = 641,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Оплот Тьмы"] = {
["LFDID"] = 1368,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Цитадель Ледяной Короны"] = {
["LFDID"] = 280,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Гномреган"] = {
["LFDID"] = 14,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Логово Нелтариона"] = {
["LFDID"] = 2279,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Тень Нелтариона"] = {
["LFDID"] = 2401,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Собор Вечной Ночи"] = {
["LFDID"] = 1488,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["\"Валинор\""] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2430,
["RecLevel"] = 60,
["Raid"] = true,
},
["СПР (LFR): Чертоги Преданности"] = {
["LFDID"] = 2037,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Операция \"Мехагон\""] = {
["LFDID"] = 2006,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Зул'Гуруб"] = {
["LFDID"] = 334,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Лазурное хранилище"] = {
["LFDID"] = 2498,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Стражи Могу'шан"] = {
["LFDID"] = 2598,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 25,
["Show"] = "saved",
},
["Храм Нефритовой Змеи"] = {
["LFDID"] = 2541,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ашран"] = {
["LFDID"] = 1127,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Великая императрица Шек'зара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2378,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Сердце Порчи"] = {
["LFDID"] = 1733,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Повелитель Холода Ахун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 1,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 286,
},
["Случайное подземелье Warlords of Draenor"] = {
["LFDID"] = 788,
["Expansion"] = 5,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Гнев бури"] = {
["LFDID"] = 2372,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Сердце Страха"] = {
["LFDID"] = 534,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Аберрий, Затененное Горнило"] = {
["LFDID"] = 2405,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Забытые глубины"] = {
["LFDID"] = 836,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Черный храм"] = {
["LFDID"] = 196,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["СПР (LFR): Чертоги сдерживания"] = {
["LFDID"] = 1731,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Штурм Дазар'алора"] = {
["LFDID"] = 1945,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Каменный Свод"] = {
["LFDID"] = 2724,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Warlords of Draenor)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 1971,
["Random"] = true,
["RecLevel"] = 40,
["Holiday"] = true,
["Raid"] = false,
},
["СПР (LFR): Тайны Неруб'арского дворца"] = {
["LFDID"] = 2650,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Raid"] = true,
},
["Авангард Тюремщика"] = {
["LFDID"] = 2415,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Нижняя часть пика Черной горы"] = {
["LFDID"] = 32,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Королевская химическая компания"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 1,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 288,
},
["СПР (LFR): Трон Пантеона"] = {
["LFDID"] = 1913,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Окулярус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2013,
["RecLevel"] = 45,
["Raid"] = true,
},
["Подгнилье"] = {
["LFDID"] = 1712,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Терраса Вечной Весны"] = {
["LFDID"] = 2599,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайный сценарий путешествия во времени (Mists of Pandaria)"] = {
["LFDID"] = 2558,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Зал аватары"] = {
["LFDID"] = 1918,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Вольная Гавань"] = {
["LFDID"] = 2178,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Каражан"] = {
["LFDID"] = 175,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["СПР (LFR): Залы Стенаний"] = {
["LFDID"] = 1919,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Аукиндон"] = {
["LFDID"] = 1975,
["Expansion"] = 5,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Shadowlands"] = {
["LFDID"] = 2086,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Гробница Саргераса"] = {
["LFDID"] = 1527,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Тазавеш: гамбит Со'леи"] = {
["LFDID"] = 2330,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Туманы Тирна Скитта"] = {
["LFDID"] = 2727,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Дар Плоти"] = {
["LFDID"] = 2038,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Раскаленное вторжение"] = {
["LFDID"] = 2711,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Реликварий роскоши"] = {
["LFDID"] = 2412,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Испытание крестоносца"] = {
["LFDID"] = 248,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Крепость Бурь"] = {
["LFDID"] = 193,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Случайное подземелье (Dragonflight)"] = {
["Show"] = "saved",
["Expansion"] = 9,
["LFDID"] = 2350,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Великий замысел"] = {
["LFDID"] = 2422,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Кошмар Шек'зир"] = {
["LFDID"] = 2595,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Случайное героическое подземелье (1-й сезон The War Within)"] = {
["LFDID"] = 2723,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Сделка со Смертью"] = {
["LFDID"] = 1949,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Операция \"Мехагон\" – свалка"] = {
["LFDID"] = 2027,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Эфемеровые равнины"] = {
["LFDID"] = 2420,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Островные экспедиции – индивидуальный тур"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2251,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Храм Ан'Киража"] = {
["LFDID"] = 161,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Антрос"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9013,
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 1453,
["Random"] = true,
["RecLevel"] = 35,
["Holiday"] = true,
["Raid"] = false,
},
["Обломок"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1795,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ульдир"] = {
["LFDID"] = 1889,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Терраса Магистров"] = {
["LFDID"] = 1154,
["Expansion"] = 1,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Прошлое Хиджала"] = {
["LFDID"] = 195,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Подземелья Могу'шан"] = {
["LFDID"] = 532,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Огненная Пропасть"] = {
["LFDID"] = 4,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Врата ада"] = {
["LFDID"] = 1920,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Вечный дворец"] = {
["LFDID"] = 2016,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Небесный Путь"] = {
["LFDID"] = 1977,
["Expansion"] = 5,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Раскаленное вторжение"] = {
["LFDID"] = 2468,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Некроситет"] = {
["LFDID"] = 2557,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Тазавеш: улицы чудес"] = {
["LFDID"] = 2329,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Низвержение"] = {
["LFDID"] = 2587,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Забытый город - палаты Гордока"] = {
["LFDID"] = 38,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Депо Мрачных Путей"] = {
["LFDID"] = 2319,
["Expansion"] = 5,
["RecLevel"] = 36,
["Raid"] = false,
["Show"] = "saved",
},
["Тол Дагор"] = {
["LFDID"] = 1714,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье (The War Within, героический режим)"] = {
["LFDID"] = 2517,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Гнездовье (версия из задания)"] = {
["LFDID"] = 2657,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Случайное подземелье Легиона"] = {
["LFDID"] = 1045,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Ночной Шпиль"] = {
["LFDID"] = 1923,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Си'ваш"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1885,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Shadowlands (героич.)"] = {
["LFDID"] = 2087,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Random"] = true,
["Raid"] = false,
},
["Кронпринцесса Терадрас"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 309,
},
["Ульдаман"] = {
["LFDID"] = 22,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Операция \"Мехагон\" – мастерская"] = {
["LFDID"] = 2028,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Падение королевы"] = {
["LFDID"] = 2651,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): Укрепления Снующих лап"] = {
["LFDID"] = 2649,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Raid"] = true,
},
["Зул'Аман"] = {
["LFDID"] = 340,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Ульдуар"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 1677,
},
["СПР (LFR): Черные врата"] = {
["LFDID"] = 1370,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Охотники за душами"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1756,
["RecLevel"] = 45,
["Raid"] = true,
},
["СПР (LFR): Прорыв Света"] = {
["LFDID"] = 1916,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Принц Сарсарун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 310,
},
["Случайное подземелье, путеш. во времени (Legion)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 2274,
["Random"] = true,
["RecLevel"] = 45,
["Holiday"] = true,
["Raid"] = false,
},
["Штурм Аметистовой крепости"] = {
["LFDID"] = 1209,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Шлаковый цех"] = {
["LFDID"] = 1361,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Наступление клана Нокхуд"] = {
["LFDID"] = 2442,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Залы Крови"] = {
["LFDID"] = 1367,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Око Вечности"] = {
["LFDID"] = 237,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Мор'гет Мучитель проклятых"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9012,
["RecLevel"] = 60,
["Raid"] = true,
},
["Верховный владыка Каззак"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1452,
["RecLevel"] = 40,
["Raid"] = true,
},
["Гнев Тюремщика"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9006,
["RecLevel"] = 60,
["Raid"] = true,
},
["Глубины Черной горы - Верхний город"] = {
["LFDID"] = 276,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Лабиринты Иглошкурых"] = {
["LFDID"] = 16,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Источник Вечности"] = {
["LFDID"] = 437,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Корен Худовар"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 287,
},
["Расселина Темного Пламени"] = {
["LFDID"] = 2655,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Оковы судьбы"] = {
["LFDID"] = 2223,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["\"Сияющий Рассвет\""] = {
["LFDID"] = 2725,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["След Воплощения"] = {
["LFDID"] = 2710,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Замок Нафрия"] = {
["LFDID"] = 2095,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Гробница королей"] = {
["LFDID"] = 1785,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Утроба Душ"] = {
["LFDID"] = 1192,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Открытие Темного портала"] = {
["LFDID"] = 1012,
["Expansion"] = 1,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Предел Господства"] = {
["LFDID"] = 2421,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Логово Ониксии"] = {
["LFDID"] = 257,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Чертоги Камня"] = {
["LFDID"] = 213,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Дров / Тарлна"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1211,
["RecLevel"] = 40,
["Raid"] = true,
},
["Случайный сценарий Mists of Pandaria"] = {
["LFDID"] = 493,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Изумрудное плетение"] = {
["LFDID"] = 2467,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Расплата у врат"] = {
["LFDID"] = 2589,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Нижетопь"] = {
["LFDID"] = 2327,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Встреча с тщеславием"] = {
["LFDID"] = 2096,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Атал'Дазар"] = {
["LFDID"] = 2177,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Изумрудный Кошмар"] = {
["LFDID"] = 1350,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Фундамент Созидания"] = {
["LFDID"] = 2419,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Очищение Стратхольма"] = {
["LFDID"] = 210,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Тигель Чернорука"] = {
["LFDID"] = 1359,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Глубины Черной горы - Тюремный блок"] = {
["LFDID"] = 30,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Кордак"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2637,
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): След Воплощения"] = {
["LFDID"] = 2466,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Гнев бури"] = {
["LFDID"] = 2706,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["СПР (LFR): Граница Бездны"] = {
["LFDID"] = 2402,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Случайное подземелье классической игры"] = {
["LFDID"] = 258,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = false,
},
["Вершина Бурь"] = {
["LFDID"] = 2591,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Воспоминания Азерот: Wrath of the Lich King"] = {
["LFDID"] = 2017,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Сумеречный бастион"] = {
["LFDID"] = 316,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Неруб'арский дворец"] = {
["LFDID"] = 2645,
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["Show"] = "saved",
},
["Хранилище Воплощений"] = {
["LFDID"] = 2390,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Искроварня"] = {
["LFDID"] = 2700,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["Залы Отражений"] = {
["LFDID"] = 256,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Вечноскорбящий дол"] = {
["LFDID"] = 839,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Изумрудное плетение"] = {
["LFDID"] = 2712,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["СПР (LFR): Темный острог"] = {
["LFDID"] = 2222,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Паровое подземелье"] = {
["LFDID"] = 185,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Осада Храма Драконьего Покоя"] = {
["LFDID"] = 843,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Изначальный бастион"] = {
["LFDID"] = 2370,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Верховный Молот"] = {
["LFDID"] = 897,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Курганы Иглошкурых"] = {
["LFDID"] = 20,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Встреча с тщеславием"] = {
["LFDID"] = 2414,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Терраса Вечной Весны"] = {
["LFDID"] = 834,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Низвержение"] = {
["LFDID"] = 842,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Иссохший Дж'им"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1796,
["RecLevel"] = 45,
["Raid"] = true,
},
["Узилище"] = {
["LFDID"] = 1015,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Затонувший храм"] = {
["LFDID"] = 28,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Осада Оргриммара"] = {
["LFDID"] = 766,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Время Сумерек"] = {
["LFDID"] = 439,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Забытый город - центральный сад"] = {
["LFDID"] = 36,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["СПР (LFR): Падение Искусителя"] = {
["LFDID"] = 1917,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье Легиона (героич.)"] = {
["LFDID"] = 1046,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Монастырь Алого ордена"] = {
["LFDID"] = 2555,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Железный цех"] = {
["LFDID"] = 1362,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Черный храм"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 30,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 1533,
},
["Гарнизон босс"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 9001,
["RecLevel"] = 40,
["Raid"] = true,
},
["Окулус"] = {
["LFDID"] = 211,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Пещеры Стенаний"] = {
["LFDID"] = 1,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Улмат"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2362,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Истощающие хранилища"] = {
["LFDID"] = 2090,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Залы Алого ордена"] = {
["LFDID"] = 2553,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Покаяния"] = {
["LFDID"] = 2119,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Пещеры Времени: годовщина"] = {
["LFDID"] = 1911,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Оковы судьбы"] = {
["LFDID"] = 2417,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Судьба Амирдрассила"] = {
["LFDID"] = 2713,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["СПР (LFR): Предел Господства"] = {
["LFDID"] = 2293,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Железные доки"] = {
["LFDID"] = 1974,
["Expansion"] = 5,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Вечное Цветение"] = {
["LFDID"] = 1972,
["Expansion"] = 5,
["RecLevel"] = 36,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Судьба Амирдрассила"] = {
["LFDID"] = 2469,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["СПР (LFR): Воспоминания Азерот: Cataclysm"] = {
["LFDID"] = 2018,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Крепость Утгард"] = {
["LFDID"] = 2323,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Хранилище Аркавона"] = {
["LFDID"] = 240,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье (The War Within)"] = {
["LFDID"] = 2516,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 70,
},
["Вершина Смерча"] = {
["LFDID"] = 1147,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Госпожа Фолнуна"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2010,
["RecLevel"] = 45,
["Raid"] = true,
},
["Верхняя часть пика Черной горы"] = {
["LFDID"] = 1004,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Испытание доблести"] = {
["LFDID"] = 1439,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Фундамент Созидания"] = {
["LFDID"] = 2291,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["СПР (LFR): Погибель надежды"] = {
["LFDID"] = 1914,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Джи'арак"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2141,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайный сценарий (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2559,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Ни'алота, Пробуждающийся Город"] = {
["LFDID"] = 2035,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Левантия"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1769,
["RecLevel"] = 45,
["Raid"] = true,
},
["Затерянный город Тол'вир"] = {
["LFDID"] = 1151,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Стражи Могу'шан"] = {
["LFDID"] = 830,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Рассвет Бесконечности: подъем Дорнозму"] = {
["LFDID"] = 2530,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Смертельная тризна"] = {
["LFDID"] = 2728,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Испытание великого крестоносца"] = {
["LFDID"] = 250,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Мучители из Торгаста"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9007,
["RecLevel"] = 60,
["Raid"] = true,
},
["Тень Нелтариона"] = {
["LFDID"] = 2708,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Бастионы Адского Пламени"] = {
["LFDID"] = 188,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
["LFDID"] = 1708,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Пещеры Насыщения"] = {
["LFDID"] = 2705,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Кай'жу Газ'рилла"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 306,
},
["Гробница Предвечных"] = {
["LFDID"] = 2290,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Солнечный Колодец"] = {
["LFDID"] = 199,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Конец Времен"] = {
["LFDID"] = 1152,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путешествие во времени (Mists of Pandaria)"] = {
["LFDID"] = 2538,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Путешествие во времени, рейд: Огненные Просторы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 2026,
},
["СПР (LFR): Кошмар Шек'зир"] = {
["LFDID"] = 833,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Крепость Барадин"] = {
["LFDID"] = 329,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Темный острог"] = {
["LFDID"] = 2416,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Чертоги Молний"] = {
["LFDID"] = 1018,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Запретный спуск"] = {
["LFDID"] = 1915,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Цитадель Адского Пламени"] = {
["LFDID"] = 989,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Оборона Дазар'алора"] = {
["LFDID"] = 1948,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Wrath of the Lich King)"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 995,
["Random"] = true,
["RecLevel"] = 30,
["Holiday"] = true,
["Raid"] = false,
},
["Тюрьма Штормграда"] = {
["LFDID"] = 12,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Испытание доблести"] = {
["LFDID"] = 1921,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Цитадель Ночи"] = {
["LFDID"] = 1353,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Ярость гигантов"] = {
["LFDID"] = 2400,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Скопище кошмаров"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2635,
["RecLevel"] = 80,
["Raid"] = true,
},
["СПР (LFR): Круг Звезд"] = {
["LFDID"] = 2011,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["СПР (LFR): Расплата"] = {
["LFDID"] = 2224,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Забытые глубины"] = {
["LFDID"] = 2593,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Побег из Дарнхольда"] = {
["LFDID"] = 183,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Мародон - Оскверненный грот"] = {
["LFDID"] = 272,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Мародон - Поющие водопады"] = {
["LFDID"] = 273,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Душа Дракона"] = {
["LFDID"] = 448,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Экспедиции на остров Кишащий"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2054,
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = true,
},
["Ша Злости"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 691,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Адский пролом"] = {
["LFDID"] = 1366,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Лощина Бурошкуров"] = {
["LFDID"] = 2439,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Падение Смертокрыла"] = {
["LFDID"] = 844,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Врата Заходящего Солнца"] = {
["LFDID"] = 2549,
["Expansion"] = 4,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Battle For Azeroth"] = {
["LFDID"] = 1670,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Грим Батол"] = {
["LFDID"] = 2730,
["Expansion"] = 10,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Престол Триумвирата"] = {
["LFDID"] = 1535,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Кровавые катакомбы"] = {
["LFDID"] = 2117,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Battle For Azeroth (героич.)"] = {
["LFDID"] = 1671,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Искрящий акведук"] = {
["LFDID"] = 1925,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Дюнный пожиратель Краулок"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2210,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Волшебное святилище"] = {
["LFDID"] = 1364,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Чертоги Созидания"] = {
["LFDID"] = 321,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Одержимые хранители"] = {
["LFDID"] = 1927,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Мортанис"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2431,
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье, путеш. во времени (Cataclysm)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 1146,
["Random"] = true,
["RecLevel"] = 35,
["Holiday"] = true,
["Raid"] = false,
},
["Подземная крепость"] = {
["LFDID"] = 2588,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Налак"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 814,
["RecLevel"] = 35,
["Raid"] = true,
},
["Градовый голем"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2197,
["RecLevel"] = 50,
["Raid"] = true,
},
["Чертоги Насыщения"] = {
["LFDID"] = 2444,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Вершина Бурь"] = {
["LFDID"] = 838,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Хумонгрис"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1770,
["RecLevel"] = 45,
["Raid"] = true,
},
["Руины Ан'Киража"] = {
["LFDID"] = 160,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (The Burning Crusade)"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 744,
["Random"] = true,
["RecLevel"] = 30,
["Holiday"] = true,
["Raid"] = false,
},
["Королева Ансурек"] = {
["LFDID"] = 2715,
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["Show"] = "saved",
},
["Мор'гет"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2456,
["RecLevel"] = 60,
["Raid"] = true,
},
["Галеон"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 725,
["RecLevel"] = 35,
["Raid"] = true,
},
["СПР (LFR): Подъем Предателя"] = {
["LFDID"] = 1922,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Ульдаман: наследие Тира"] = {
["LFDID"] = 2465,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Почетный прием"] = {
["LFDID"] = 2009,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Пещеры Черной горы"] = {
["LFDID"] = 2321,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Надвигающийся ужас"] = {
["LFDID"] = 2596,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Трон Приливов"] = {
["LFDID"] = 1150,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Доблести"] = {
["LFDID"] = 1194,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Темная Ветвь"] = {
["LFDID"] = 1912,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Логово Крыла Тьмы"] = {
["LFDID"] = 50,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Струнраан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2515,
["RecLevel"] = 70,
["Raid"] = true,
},
["Академия Алгет'ар"] = {
["LFDID"] = 2464,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Воспоминания Азерот: Burning Crusade"] = {
["LFDID"] = 2004,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["СПР (LFR): Хранилище тайн"] = {
["LFDID"] = 831,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Драгон Зиморожденный"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1789,
["RecLevel"] = 45,
["Raid"] = true,
},
["Лазуретос"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2199,
["RecLevel"] = 50,
["Raid"] = true,
},
["Испытание чемпиона"] = {
["LFDID"] = 249,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Мародон - Зловонная пещера"] = {
["LFDID"] = 26,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["СПР (LFR): Отбракованные жизни"] = {
["LFDID"] = 2399,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Разрушенные залы"] = {
["LFDID"] = 1014,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Рассвет Бесконечности"] = {
["LFDID"] = 2430,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Рассвет Бесконечности: падение Галакронда"] = {
["LFDID"] = 2529,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Сетеккские залы"] = {
["LFDID"] = 180,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Осада Боралуса"] = {
["LFDID"] = 2729,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Видение судьбы"] = {
["LFDID"] = 2036,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Вук'лаз Землелом"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2381,
["RecLevel"] = 50,
["Raid"] = true,
},
["Шлаковые шахты Кровавого Молота"] = {
["LFDID"] = 1973,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Катакомбы Сурамара"] = {
["LFDID"] = 1190,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["Цитадель Темного Молота"] = {
["LFDID"] = 2043,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 7,
["Show"] = "saved",
},
["Возвращение в Каражан"] = {
["LFDID"] = 1347,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 110,
["Show"] = "saved",
},
["Рухмар"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1262,
["RecLevel"] = 40,
["Raid"] = true,
},
["Шар'тос"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1763,
["RecLevel"] = 45,
["Raid"] = true,
},
["Тихая Сень"] = {
["LFDID"] = 2025,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["Show"] = "saved",
},
["Дворец Могу'шан"] = {
["LFDID"] = 2551,
["Expansion"] = 4,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Нургаш Жижерожденный"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2433,
["RecLevel"] = 60,
["Raid"] = true,
},
["Вершина Утгард"] = {
["LFDID"] = 1020,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Груула"] = {
["LFDID"] = 177,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Чаща Темного Сердца"] = {
["LFDID"] = 2277,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье \"Времени Сумерек\" (героич.)"] = {
["LFDID"] = 434,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Рубиновое святилище"] = {
["LFDID"] = 294,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Случайные островные экспедиции – эпохальный режим"] = {
["LFDID"] = 1891,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Всадник без головы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 285,
},
["СПР (LFR): Алый спуск"] = {
["LFDID"] = 1732,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Та Сторона"] = {
["LFDID"] = 2118,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Литейная клана Черной горы"] = {
["LFDID"] = 900,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Кровь из камня"] = {
["LFDID"] = 2092,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Случайное подземелье Burning Crusade"] = {
["LFDID"] = 259,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["СПР (LFR): Черная Кузня"] = {
["LFDID"] = 1360,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Горнило Штормов"] = {
["LFDID"] = 1951,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Базрикрон"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2506,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ана-Муз"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1790,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Cataclysm"] = {
["LFDID"] = 300,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Возвращение в Каражан (нижняя часть)"] = {
["LFDID"] = 1475,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["СПР (LFR): Пещеры Насыщения"] = {
["LFDID"] = 2371,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Мертвые копи"] = {
["LFDID"] = 326,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ундаста"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 826,
["RecLevel"] = 35,
["Raid"] = true,
},
["Нитхегг"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1749,
["RecLevel"] = 45,
["Raid"] = true,
},
["Вечноскорбящий дол"] = {
["LFDID"] = 2590,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Крепость Драк'Тарон"] = {
["LFDID"] = 215,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Святилище Господства"] = {
["LFDID"] = 2228,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["СПР (LFR): Терраса Разрушителя"] = {
["LFDID"] = 1369,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Четыре небожителя"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 857,
["RecLevel"] = 35,
["Raid"] = true,
},
["Последний оплот зандаларов"] = {
["LFDID"] = 2594,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Ораномонос Вечноветвящаяся"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9010,
["RecLevel"] = 60,
["Raid"] = true,
},
["Властитель преисподней Веролом"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2015,
["RecLevel"] = 45,
["Raid"] = true,
},
["Хранилище тайн"] = {
["LFDID"] = 2597,
["Expansion"] = 4,
["Raid"] = true,
["RecLevel"] = 25,
["Show"] = "saved",
},
["Гнездовье"] = {
["LFDID"] = 2718,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["Бруталл"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1883,
["RecLevel"] = 45,
["Raid"] = true,
},
["Механар"] = {
["LFDID"] = 192,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Аукенайские гробницы"] = {
["LFDID"] = 178,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Провал Альн"] = {
["LFDID"] = 1926,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье Mists of Pandaria"] = {
["LFDID"] = 463,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Приорат Священного Пламени"] = {
["LFDID"] = 2699,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["Обсидиановое святилище"] = {
["LFDID"] = 238,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Каменные Недра"] = {
["LFDID"] = 1148,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Яма Сарона"] = {
["LFDID"] = 1153,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Святилище Штормов"] = {
["LFDID"] = 1774,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Стратхольм - Главные врата"] = {
["LFDID"] = 40,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Кровь из камня"] = {
["LFDID"] = 2413,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Ордос"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 861,
["RecLevel"] = 35,
["Raid"] = true,
},
["Вестник войны Йенаж"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2198,
["RecLevel"] = 50,
["Raid"] = true,
},
["СПР (LFR): Город за стеной"] = {
["LFDID"] = 1363,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Зул'Фаррак"] = {
["LFDID"] = 24,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Монастырь Шадо-Пан"] = {
["LFDID"] = 2545,
["Expansion"] = 4,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Lich King"] = {
["LFDID"] = 261,
["Expansion"] = 2,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Некрополь Призрачной Луны"] = {
["LFDID"] = 1976,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["СПР (LFR): Реликварий роскоши"] = {
["LFDID"] = 2091,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Амирдрассил, Надежда Сна"] = {
["LFDID"] = 2504,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Усадьба Уэйкрестов"] = {
["LFDID"] = 1706,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Burning Crusade (героич.)"] = {
["LFDID"] = 260,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье в героическом режиме (Dragonflight)"] = {
["LFDID"] = 2351,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Осада храма Нюцзао"] = {
["LFDID"] = 2547,
["Expansion"] = 4,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Отбракованные жизни"] = {
["LFDID"] = 2704,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Ярость гигантов"] = {
["LFDID"] = 2707,
["Expansion"] = 9,
["Raid"] = true,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Вакан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2531,
["RecLevel"] = 70,
["Raid"] = true,
},
["Огненные Недра"] = {
["LFDID"] = 48,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Гробницы маны"] = {
["LFDID"] = 1013,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Гундрак"] = {
["LFDID"] = 1017,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["\"Валинор\", Светоч Эпох"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9008,
["RecLevel"] = 60,
["Raid"] = true,
},
["Ульдуар"] = {
["LFDID"] = 244,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Наксрамас"] = {
["LFDID"] = 227,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Нелтарий"] = {
["LFDID"] = 2440,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
},
["histGeneration"] = 116,
["History"] = {
},
["RealmMap"] = {
},
["Indicators"] = {
["R2ClassColor"] = true,
["D2Indicator"] = "BLANK",
["R7Color"] = {
1,
1,
0,
},
["R5Color"] = {
0,
0,
1,
},
["R1Text"] = "KILLED/TOTAL",
["R4Indicator"] = "BLANK",
["R1Color"] = {
0.6,
0.6,
0,
},
["R0Indicator"] = "BLANK",
["R8ClassColor"] = true,
["D2ClassColor"] = true,
["R4ClassColor"] = true,
["R6ClassColor"] = true,
["D2Color"] = {
0,
1,
0,
},
["D1Text"] = "KILLED/TOTAL",
["R5Text"] = "KILLED/TOTALL",
["R7Text"] = "KILLED/TOTALH",
["R1ClassColor"] = true,
["D3Indicator"] = "BLANK",
["R8Color"] = {
1,
0,
0,
},
["D3ClassColor"] = true,
["R6Indicator"] = "BLANK",
["R6Color"] = {
0,
1,
0,
},
["D1Color"] = {
0,
0.6,
0,
},
["R4Color"] = {
1,
0,
0,
},
["R7Indicator"] = "BLANK",
["R2Text"] = "KILLED/TOTAL",
["R8Indicator"] = "BLANK",
["R0Text"] = "KILLED/TOTAL",
["R0Color"] = {
0.6,
0.6,
0,
},
["R1Indicator"] = "BLANK",
["R2Color"] = {
0.6,
0,
0,
},
["R3Indicator"] = "BLANK",
["R7ClassColor"] = true,
["R5Indicator"] = "BLANK",
["D1ClassColor"] = true,
["R4Text"] = "KILLED/TOTALH",
["R3Color"] = {
1,
1,
0,
},
["R3ClassColor"] = true,
["R3Text"] = "KILLED/TOTALH",
["R5ClassColor"] = true,
["R6Text"] = "KILLED/TOTAL",
["D3Color"] = {
1,
0,
0,
},
["R8Text"] = "KILLED/TOTALM",
["D2Text"] = "KILLED/TOTALH",
["D3Text"] = "KILLED/TOTALM",
["R2Indicator"] = "BLANK",
["D1Indicator"] = "BLANK",
["R0ClassColor"] = true,
},
["QuestDB"] = {
["Daily"] = {
[62234] = -1,
[61088] = -1,
[53711] = -1,
[58167] = -1,
[60622] = -1,
[58151] = -1,
[53701] = -1,
[51982] = -1,
[58155] = -1,
[62214] = -1,
[61075] = -1,
[53939] = -1,
[58156] = -1,
[63206] = -1,
[61103] = -1,
[61104] = -1,
[60762] = -1,
[53883] = -1,
[54132] = -1,
[53885] = -1,
[54134] = -1,
[61079] = -1,
[54136] = -1,
[54137] = -1,
[54138] = -1,
[61765] = -1,
[54135] = -1,
[60775] = -1,
[60646] = -1,
[58168] = -1,
},
["Darkmoon"] = {
["expires"] = 1725832740,
[47767] = -1,
},
["AccountDaily"] = {
[31752] = -1,
[34774] = -1,
[56042] = -1,
[40753] = -1,
},
["Weekly"] = {
[70617] = -1,
[32640] = -1,
[57008] = -1,
[52944] = -1,
[70203] = -1,
[70235] = -1,
[75351] = -1,
[78427] = -1,
[48912] = -1,
[70586] = -1,
[70618] = -1,
[72722] = -1,
[66363] = -1,
[56650] = -1,
[56148] = -1,
[62284] = -1,
[66953] = -1,
[78444] = -1,
[70571] = -1,
[70587] = -1,
[59017] = -1,
[70619] = -1,
[72723] = -1,
[66364] = -1,
[52953] = -1,
[33334] = -1,
[66938] = -1,
[56308] = -1,
[79226] = -1,
[70572] = -1,
[62452] = -1,
[70620] = -1,
[72724] = -1,
[55121] = -1,
[62288] = -1,
[62285] = -1,
[60253] = -1,
[70557] = -1,
[70565] = -1,
[70589] = -1,
[59018] = -1,
[32641] = -1,
[72438] = -1,
[78319] = -1,
[72725] = -1,
[52954] = -1,
[75304] = -1,
[66942] = -1,
[66940] = -1,
[66891] = -1,
[60252] = -1,
[70558] = -1,
[62445] = -1,
[64541] = -1,
[40786] = -1,
[72407] = -1,
[72423] = -1,
[72726] = -1,
[75308] = -1,
[70750] = -1,
[62286] = -1,
[60254] = -1,
[52952] = -1,
[70559] = -1,
[57728] = -1,
[70591] = -1,
[59019] = -1,
[40173] = -1,
[72727] = -1,
[66945] = -1,
[75309] = -1,
["expires"] = 1725422399,
[76122] = -1,
[60248] = -1,
[70560] = -1,
[70562] = -1,
[70592] = -1,
[40787] = -1,
[60247] = -1,
[66884] = -1,
[72728] = -1,
[70752] = -1,
[62287] = -1,
[60255] = -1,
[70545] = -1,
[70561] = -1,
[70593] = -1,
[72410] = -1,
[55498] = -1,
[70211] = -1,
[72428] = -1,
[70753] = -1,
[66944] = -1,
[70530] = -1,
[56064] = -1,
[83240] = 2328,
[70594] = -1,
[66952] = -1,
[72156] = -1,
[72427] = -1,
[48910] = -1,
[66949] = -1,
[82946] = 2214,
[66897] = -1,
[70754] = -1,
[72810] = -1,
[70531] = -1,
[75288] = -1,
[70563] = -1,
[70595] = -1,
[66937] = -1,
[72157] = -1,
[72173] = -1,
[53435] = -1,
[78428] = -1,
[60251] = -1,
[55499] = -1,
[70723] = -1,
[56969] = -1,
[33338] = -1,
[75289] = -1,
[70532] = -1,
[66890] = -1,
[70564] = -1,
[66516] = -1,
[70540] = -1,
[72158] = -1,
[66943] = -1,
[60245] = -1,
[75307] = -1,
[64710] = -1,
[57157] = -1,
[52957] = -1,
[60246] = -1,
[62289] = -1,
[60257] = -1,
[75665] = -1,
[66517] = -1,
[70613] = -1,
[72159] = -1,
[72175] = -1,
[78821] = -1,
[72155] = -1,
[70199] = -1,
[80670] = 2255,
[52948] = -1,
[52956] = -1,
[56050] = -1,
[72172] = -1,
[62441] = -1,
[62449] = -1,
[45563] = -1,
[70614] = -1,
[52958] = -1,
[72686] = -1,
[82452] = 2339,
[66935] = -1,
[56648] = -1,
[60256] = -1,
[75301] = -1,
[60242] = -1,
[60250] = -1,
[70202] = -1,
[72720] = -1,
[70567] = -1,
[83333] = 2214,
[52949] = -1,
[70615] = -1,
[53436] = -1,
[52782] = -1,
[72719] = -1,
[70533] = -1,
[52951] = -1,
[60249] = -1,
[70233] = -1,
[40168] = -1,
[66950] = -1,
[48911] = -1,
[70201] = -1,
[70568] = -1,
[62450] = -1,
[70616] = -1,
[52950] = -1,
[64522] = -1,
[55350] = -1,
[70935] = -1,
[75286] = -1,
[56649] = -1,
[66900] = -1,
[70234] = -1,
[60243] = -1,
[66951] = -1,
[60244] = -1,
[70582] = -1,
[70569] = -1,
[70200] = -1,
[59016] = -1,
[66941] = -1,
},
["AccountWeekly"] = {
[45539] = -1,
[77236] = -1,
[46292] = -1,
["expires"] = 1725422399,
[72721] = -1,
[56492] = -1,
[58458] = -1,
[54186] = -1,
[72528] = -1,
},
},
["DailyResetTime"] = 1725249599,
["Quests"] = {
},
["Warfront"] = {
{
["contributing"] = true,
["captureSide"] = "Alliance",
},
{
["contributing"] = false,
["restTime"] = 1725282197,
["captureSide"] = "Alliance",
},
},
}
