
PremadeGroupsFilterSettings = {
["signupOnEnter"] = false,
["dialogMovable"] = true,
["ratingInfo"] = true,
["specIcon"] = false,
["oneClickSignUp"] = true,
["coloredGroupTexts"] = true,
["leaderCrown"] = false,
["missingRoles"] = false,
["version"] = 3,
["classBar"] = false,
["persistSignUpNote"] = true,
["classCircle"] = false,
["skipSignUpDialog"] = false,
["classNamesInTooltip"] = true,
}
