
MythicDungeonToolsDB = {
["profileKeys"] = {
["Вантачмэн - Ревущий фьорд"] = "Вантачмэн - Ревущий фьорд",
["Топмэн - Свежеватель Душ"] = "Топмэн - Свежеватель Душ",
["Мальдика - Свежеватель Душ"] = "Мальдика - Свежеватель Душ",
["Сорчистино - Свежеватель Душ"] = "Сорчистино - Свежеватель Душ",
["Дракобес - Свежеватель Душ"] = "Дракобес - Свежеватель Душ",
["Бимладен - Ревущий фьорд"] = "Бимладен - Ревущий фьорд",
["Вольтчара - Свежеватель Душ"] = "Вольтчара - Свежеватель Душ",
},
["global"] = {
["currentDungeonIdx"] = 31,
["minimap"] = {
["showInCompartment"] = true,
},
["selectedDungeonList"] = 9,
["scale"] = 1.4,
["maximized"] = false,
["presets"] = {
[19] = {
{
["difficulty"] = 10,
["week"] = 1,
["faction"] = 2,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["riftOffsets"] = {
{
},
},
["currentDungeonIdx"] = 19,
["teeming"] = false,
["selection"] = {
1,
},
["pulls"] = {
{
["color"] = "ff3eff",
},
},
},
},
},
[31] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["riftOffsets"] = {
{
},
},
["currentDungeonIdx"] = 31,
["teeming"] = false,
["selection"] = {
1,
},
["pulls"] = {
{
["color"] = "ff3eff",
},
},
},
},
},
[35] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["riftOffsets"] = {
{
},
},
["currentDungeonIdx"] = 35,
["teeming"] = false,
["selection"] = {
1,
},
["pulls"] = {
{
["color"] = "ff3eff",
},
},
},
},
},
[42] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["pulls"] = {
{
["color"] = "ff3eff",
},
},
["currentDungeonIdx"] = 42,
["teeming"] = false,
["selection"] = {
1,
},
["riftOffsets"] = {
{
},
},
},
},
},
[110] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["pulls"] = {
{
["color"] = "ff3eff",
},
},
["currentDungeonIdx"] = 110,
["teeming"] = false,
["selection"] = {
1,
},
["riftOffsets"] = {
{
},
},
},
},
},
[111] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["pulls"] = {
{
["color"] = "ff3eff",
},
},
["currentDungeonIdx"] = 111,
["teeming"] = false,
["selection"] = {
1,
},
["riftOffsets"] = {
{
},
},
},
},
},
[112] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["riftOffsets"] = {
{
},
},
["currentDungeonIdx"] = 112,
["teeming"] = false,
["selection"] = {
1,
},
["pulls"] = {
{
["color"] = "ff3eff",
},
},
},
},
},
[113] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["pulls"] = {
{
["color"] = "ff3eff",
},
},
["currentDungeonIdx"] = 113,
["teeming"] = false,
["selection"] = {
1,
},
["riftOffsets"] = {
{
},
},
},
},
},
[114] = {
{
["difficulty"] = 10,
["week"] = 1,
["value"] = {
["currentPull"] = 1,
["currentSublevel"] = 1,
["pulls"] = {
{
["color"] = "ff3eff",
},
},
["currentDungeonIdx"] = 114,
["teeming"] = false,
["selection"] = {
1,
},
["riftOffsets"] = {
{
},
},
},
},
},
},
["version"] = 507,
["latestSeenDungeonList"] = 8,
},
}
