
ElvCharacterDB = {
["ConvertKeybindings"] = true,
["ChatEditHistory"] = {
},
["ChatHistoryLog"] = {
{
"%s заслужила достижение |cffffff00|Hachievement:855:Player-1604-0AA7EF3A:1:8:27:24:4294967295:4294967295:4294967295:4294967295|h[Лунная поляна]|h|r!",
"Мальдика-СвежевательДуш",
"",
"",
"Мальдика-СвежевательДуш",
"",
0,
0,
"",
0,
32,
"Player-1604-0AA7EF3A",
0,
false,
false,
false,
false,
[52] = "|cffffffffМальдика|r",
[51] = 1724702933,
[50] = "CHAT_MSG_GUILD_ACHIEVEMENT",
},
},
}
