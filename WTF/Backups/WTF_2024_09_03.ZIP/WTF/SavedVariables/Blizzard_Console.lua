
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 299.9999694824219,
["messageHistory"] = {
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x000000c423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/1/2024 (Sun) 22:17",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 47d 21h 56m 22s",
0,
},
{
"Level: 0d 0h 43m 32s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000008001",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c001",
0,
},
{
"Proficiency in item class 2 set to 0x000000c003",
0,
},
{
"Proficiency in item class 2 set to 0x000000c403",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x000000c423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/1/2024 (Sun) 22:59",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 47d 22h 37m 53s",
0,
},
{
"Level: 0d 1h 25m 3s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 47d 22h 40m 55s",
0,
},
{
"Level: 0d 1h 28m 5s",
0,
},
{
"Set pending. Call UpdateWindow to finalize",
0,
},
{
"Set pending. Call UpdateWindow to finalize",
0,
},
{
"Set pending GxRestart",
0,
},
{
"Set pending GxRestart",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 47d 23h 6m 20s",
0,
},
{
"Level: 0d 1h 53m 30s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 1.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725279366\" expirationTime=\"1725293766\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"Got new connection 2",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000008001",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c001",
0,
},
{
"Proficiency in item class 2 set to 0x000000c003",
0,
},
{
"Proficiency in item class 2 set to 0x000000c403",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x000000c423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/2/2024 (Mon) 14:17",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 47d 23h 6m 31s",
0,
},
{
"Level: 0d 1h 53m 41s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/2/2024 (Mon) 14:23",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 321d 10h 38m 17s",
0,
},
{
"Level: 1d 15h 52m 31s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2460.4, -2271.84, 1061.25)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2552 with translation: (0.340088, 0.820068, 1131.33)\n    Location : (2256.58, -2275.26, 566.552)\n    Location in previous map : (2256.24, -2276.08, -564.781)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2552. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2256.95, -2270.06, -566.952)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 1.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725284250\" expirationTime=\"1725298650\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/2/2024 (Mon) 15:38",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 321d 11h 32m 52s",
0,
},
{
"Level: 1d 16h 47m 6s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"Got new connection 2",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/2/2024 (Mon) 16:03",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 4h 14m 45s",
0,
},
{
"Level: 12d 13h 58m 31s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 4h 17m 6s",
0,
},
{
"Level: 12d 14h 0m 52s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 4h 19m 9s",
0,
},
{
"Level: 12d 14h 2m 55s",
0,
},
{
"Player-1604-09765C91 TRAIT_VALIDATION: Failure: Config 2937249. 20 pending (including duplicates) after adding all open nodes.",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 300 to 305",
0,
},
{
"Skill 756 increased from 300 to 305",
0,
},
{
"Skill 800 increased from 300 to 305",
0,
},
{
"Skill 2733 increased from 300 to 305",
0,
},
{
"Skill 183 increased from 305 to 310",
0,
},
{
"Skill 756 increased from 305 to 310",
0,
},
{
"Skill 800 increased from 305 to 310",
0,
},
{
"Skill 2733 increased from 305 to 310",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Skill 183 increased from 310 to 315",
0,
},
{
"Skill 756 increased from 310 to 315",
0,
},
{
"Skill 800 increased from 310 to 315",
0,
},
{
"Skill 2733 increased from 310 to 315",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 315 to 320",
0,
},
{
"Skill 756 increased from 315 to 320",
0,
},
{
"Skill 800 increased from 315 to 320",
0,
},
{
"Skill 2733 increased from 315 to 320",
0,
},
{
"Skill 183 increased from 320 to 325",
0,
},
{
"Skill 756 increased from 320 to 325",
0,
},
{
"Skill 800 increased from 320 to 325",
0,
},
{
"Skill 2733 increased from 320 to 325",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Skill 183 increased from 325 to 330",
0,
},
{
"Skill 756 increased from 325 to 330",
0,
},
{
"Skill 800 increased from 325 to 330",
0,
},
{
"Skill 2733 increased from 325 to 330",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 330 to 335",
0,
},
{
"Skill 756 increased from 330 to 335",
0,
},
{
"Skill 800 increased from 330 to 335",
0,
},
{
"Skill 2733 increased from 330 to 335",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Skill 183 increased from 335 to 340",
0,
},
{
"Skill 756 increased from 335 to 340",
0,
},
{
"Skill 800 increased from 335 to 340",
0,
},
{
"Skill 2733 increased from 335 to 340",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 340 to 345",
0,
},
{
"Skill 756 increased from 340 to 345",
0,
},
{
"Skill 800 increased from 340 to 345",
0,
},
{
"Skill 2733 increased from 340 to 345",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 345 to 350",
0,
},
{
"Skill 756 increased from 345 to 350",
0,
},
{
"Skill 800 increased from 345 to 350",
0,
},
{
"Skill 2733 increased from 345 to 350",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 1.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA disabled",
0,
},
{
"MSAA for alpha-test enabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725294965\" expirationTime=\"1725309365\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"Got new connection 2",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/2/2024 (Mon) 18:35",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 6h 38m 33s",
0,
},
{
"Level: 0d 0h 14m 45s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 350 to 355",
0,
},
{
"Skill 756 increased from 350 to 355",
0,
},
{
"Skill 800 increased from 350 to 355",
0,
},
{
"Skill 2733 increased from 350 to 355",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 355 to 360",
0,
},
{
"Skill 756 increased from 355 to 360",
0,
},
{
"Skill 800 increased from 355 to 360",
0,
},
{
"Skill 2733 increased from 355 to 360",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 2, intensity 0.218028\n",
0,
},
{
"Weather changed to 2, intensity 0.218028\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 360 to 365",
0,
},
{
"Skill 756 increased from 360 to 365",
0,
},
{
"Skill 800 increased from 360 to 365",
0,
},
{
"Skill 2733 increased from 360 to 365",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.115136\n",
0,
},
{
"Weather changed to 1, intensity 0.115136\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 365 to 370",
0,
},
{
"Skill 756 increased from 365 to 370",
0,
},
{
"Skill 800 increased from 365 to 370",
0,
},
{
"Skill 2733 increased from 365 to 370",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/2/2024 (Mon) 20:38",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 8h 24m 15s",
0,
},
{
"Level: 0d 0h 18m 20s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 370 to 375",
0,
},
{
"Skill 756 increased from 370 to 375",
0,
},
{
"Skill 800 increased from 370 to 375",
0,
},
{
"Skill 2733 increased from 370 to 375",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 375 to 380",
0,
},
{
"Skill 756 increased from 375 to 380",
0,
},
{
"Skill 800 increased from 375 to 380",
0,
},
{
"Skill 2733 increased from 375 to 380",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 380 to 385",
0,
},
{
"Skill 756 increased from 380 to 385",
0,
},
{
"Skill 800 increased from 380 to 385",
0,
},
{
"Skill 2733 increased from 380 to 385",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 385 to 390",
0,
},
{
"Skill 756 increased from 385 to 390",
0,
},
{
"Skill 800 increased from 385 to 390",
0,
},
{
"Skill 2733 increased from 385 to 390",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 390 to 395",
0,
},
{
"Skill 756 increased from 390 to 395",
0,
},
{
"Skill 800 increased from 390 to 395",
0,
},
{
"Skill 2733 increased from 390 to 395",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Skill 183 increased from 395 to 400",
0,
},
{
"Skill 756 increased from 395 to 400",
0,
},
{
"Skill 800 increased from 395 to 400",
0,
},
{
"Skill 2733 increased from 395 to 400",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
