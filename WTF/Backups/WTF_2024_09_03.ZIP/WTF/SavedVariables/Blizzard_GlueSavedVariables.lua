
g_collapsedServerAlert = nil
g_characterSelectToolTrayCollapsed = nil
