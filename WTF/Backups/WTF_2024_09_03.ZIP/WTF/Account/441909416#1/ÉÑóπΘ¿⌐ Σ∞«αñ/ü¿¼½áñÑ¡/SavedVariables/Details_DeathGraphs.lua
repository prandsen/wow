
AdvancedDeathLogsDB = {
["__version"] = 1,
["deathsPerSegment"] = {
},
["spellIdCache"] = {
},
["enemySpellCasts"] = {
},
["deathsOccurrences"] = {
},
["encounterInfo"] = {
},
}
DeathGraphsDBEndurance = {
}
