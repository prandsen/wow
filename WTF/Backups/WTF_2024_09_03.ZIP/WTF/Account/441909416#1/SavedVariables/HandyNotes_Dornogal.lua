
HandyNotes_DornogalDB = {
["profileKeys"] = {
["Сорчистино - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
