
PremadeGroupsFilterSettings = {
["signupOnEnter"] = false,
["coloredGroupTexts"] = true,
["ratingInfo"] = true,
["classNamesInTooltip"] = true,
["oneClickSignUp"] = true,
["dialogMovable"] = true,
["leaderCrown"] = false,
["missingRoles"] = false,
["version"] = 3,
["classBar"] = false,
["persistSignUpNote"] = true,
["classCircle"] = false,
["skipSignUpDialog"] = false,
["specIcon"] = false,
}
