
VWQL = {
["Дракобес-СвежевательДуш"] = {
["VERSION"] = 111,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Бимладен-Ревущийфьорд"] = {
["VERSION"] = 112,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[70659] = true,
[70549] = true,
[42819] = true,
[59642] = true,
[72022] = true,
[66419] = true,
[43079] = true,
[58705] = true,
[71156] = true,
[71164] = true,
[70160] = true,
[43599] = true,
[70625] = true,
[61814] = true,
[70066] = true,
[70011] = true,
[64531] = true,
[70653] = true,
[70224] = true,
[51502] = true,
[70421] = true,
[70110] = true,
[70429] = true,
[69929] = true,
[48866] = true,
[43769] = true,
[64273] = true,
[75257] = true,
[70654] = true,
[74501] = true,
[66896] = true,
[67012] = true,
[42780] = true,
[52166] = true,
[64768] = true,
[48957] = true,
[73080] = true,
[70602] = true,
[44805] = true,
[44114] = true,
[52873] = true,
[70984] = true,
[70412] = true,
},
["Filter"] = 63,
},
["Сорчистино-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Мальдика-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 111,
},
["Вольтчара-СвежевательДуш"] = {
["FilterType"] = {
},
["Filter"] = 63,
["Quests"] = {
[82225] = true,
[82292] = true,
[81806] = true,
[81710] = true,
[81512] = true,
},
["VERSION"] = 112,
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Ignore"] = {
},
["AzeriteFormat"] = 20,
["Топмэн-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 111,
},
["Вантачмэн-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 111,
},
["VERSION"] = 112,
["SortPrio"] = {
},
["Sort"] = 5,
["Сэйвмэн-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 112,
["Quests"] = {
[70602] = true,
[70110] = true,
[70066] = true,
[70654] = true,
[70160] = true,
[71166] = true,
[70224] = true,
[71156] = true,
[71164] = true,
},
["FilterType"] = {
},
},
["HideLegion"] = true,
}
