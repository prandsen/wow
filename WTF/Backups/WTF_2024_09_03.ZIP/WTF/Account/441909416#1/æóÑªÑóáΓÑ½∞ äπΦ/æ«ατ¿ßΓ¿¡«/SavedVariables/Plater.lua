
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[266] = 40,
[267] = 40,
[265] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0A5B10F4"] = true,
},
["resources_on_target"] = false,
["minimap"] = {
},
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[266] = 40,
[267] = 40,
[265] = 40,
},
}
