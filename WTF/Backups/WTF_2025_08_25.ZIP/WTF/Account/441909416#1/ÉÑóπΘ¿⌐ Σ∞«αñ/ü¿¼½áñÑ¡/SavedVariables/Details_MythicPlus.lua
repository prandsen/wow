
Details_MythicPlus_CharacterDB = nil
