
NewSettingsSeen = {
["ASSISTED_COMBAT_ROTATION"] = true,
["cooldownViewerEnabled"] = true,
["PROXY_SPELL_DENSITY"] = true,
["PROXY_RAID_SPELL_DENSITY"] = true,
["panelItemQualityColorOverrides"] = true,
["assistedCombatHighlight"] = true,
["PROXY_ACCESSIBILITY_FONT_SIZE"] = true,
}
