
MinimapButtonButtonOptions = {
["direction"] = "leftdown",
["scale"] = 1,
["blacklist"] = {
},
["buttonScale"] = 1,
["buttonsShown"] = false,
["version"] = 5,
["position"] = {
"TOPRIGHT",
nil,
"TOPRIGHT",
-0.8350069522857666,
-200.3335723876953,
},
["buttonsPerRow"] = 6,
["hidecompartment"] = false,
["whitelist"] = {
["ZygorGuidesViewerMapIcon"] = true,
["CodexBrowserIcon"] = true,
["TrinketMenu_IconFrame"] = true,
},
["autohide"] = 0,
}
