
BigWigs3DB = {
["profileKeys"] = {
["Singa - EU Mythic Dungeons"] = "All classes",
["Мальдика - Свежеватель Душ"] = "All classes",
["Вантачмэн - Ревущий фьорд"] = "All classes",
["Сингардэма - Свежеватель Душ"] = "All classes",
["Сэйвмэн - Свежеватель Душ"] = "All classes",
["Garrettino - Aegwynn"] = "Default",
["Алианкано - Свежеватель Душ"] = "All classes",
["Сорчистино - Свежеватель Душ"] = "All classes",
["Healmachine - Nobundo"] = "Default",
["Иридесцента - Свежеватель Душ"] = "All classes",
["Прециза - Свежеватель Душ"] = "All classes",
["Спленда - Свежеватель Душ"] = "All classes",
["Вольтчара - Свежеватель Душ"] = "All classes",
["Дракобес - Свежеватель Душ"] = "All classes",
["Виандисто - Свежеватель Душ"] = "All classes",
["Мурдисто - Свежеватель Душ"] = "All classes",
["Джуставар - Свежеватель Душ"] = "All classes",
["Топмэн - Свежеватель Душ"] = "All classes",
["Джуста - Свежеватель Душ"] = "All classes",
["Бимладен - Ревущий фьорд"] = "All classes",
["Бимладен - Свежеватель Душ"] = "All classes",
},
["global"] = {
["watchedMovies"] = {
[-2002] = true,
[952] = true,
[956] = true,
[294] = true,
[295] = true,
[964] = true,
[-1152] = true,
[-1597] = true,
[-2170] = true,
[-2234] = true,
[549] = true,
[992] = true,
[-437] = true,
[-1153] = true,
[876] = true,
[-1358] = true,
[-1004] = true,
[886] = true,
[-2004] = true,
[-2409] = true,
[-573] = true,
[-575] = true,
[656] = true,
[-593] = {
true,
true,
},
[-2292] = true,
[-323] = true,
[-1345] = true,
[-2000] = true,
[-607] = true,
[688] = true,
[-2238] = {
true,
true,
},
[991] = true,
[875] = true,
[1003] = true,
[682] = true,
[-1151] = true,
[686] = true,
[-1352] = {
[2] = true,
},
[-609] = true,
[927] = true,
[958] = true,
[-2233] = true,
[-2296] = true,
},
},
["namespaces"] = {
["BigWigs_Bosses_Avanoxx"] = {
["profiles"] = {
["All classes"] = {
[438476] = 3129591,
},
},
},
["BigWigs_Bosses_Rocketspark and Borka"] = {
["profiles"] = {
["All classes"] = {
[162617] = 3129591,
},
},
},
["BigWigs_Bosses_Mana Devourer"] = {
["profiles"] = {
["All classes"] = {
[227457] = 3129591,
},
},
},
["BigWigs_Bosses_Tyr, the Infinite Keeper"] = {
["profiles"] = {
["All classes"] = {
[400642] = 3129591,
},
},
},
["BigWigs_Bosses_Viq'Goth"] = {
["profiles"] = {
["All classes"] = {
[275014] = 966887,
["custom_off_275014"] = true,
[269366] = 966887,
["demolishing"] = 966887,
[270185] = 1032439,
},
},
},
["BigWigs_Bosses_Black Rook Hold Trash"] = {
["profiles"] = {
["All classes"] = {
[203163] = 3129847,
},
},
},
["BigWigs_Bosses_Blight of Galakrond"] = {
["profiles"] = {
["All classes"] = {
[407159] = 3129591,
},
},
},
["BigWigs_Bosses_Executor Tarvold"] = {
["profiles"] = {
["All classes"] = {
[322573] = 3129591,
},
},
},
["BigWigs_Bosses_Mogul Razzdunk"] = {
["profiles"] = {
["All classes"] = {
[271456] = 966887,
[260829] = 1032439,
[260280] = 966887,
},
},
},
["BigWigs_Bosses_The Infinite Dragonflight"] = {
["profiles"] = {
["All classes"] = {
[410904] = 3129591,
[410908] = 3064055,
},
},
},
["BigWigs_Bosses_Hungering Destroyer"] = {
["profiles"] = {
["All classes"] = {
[334266] = 3129591,
},
},
},
["BigWigs_Bosses_Opera Hall: Wikket"] = {
["profiles"] = {
["All classes"] = {
[227776] = 3129591,
},
},
},
["BigWigs_Bosses_Voidstone Monstrosity"] = {
["profiles"] = {
["All classes"] = {
[423305] = 3129591,
},
},
},
["BigWigs_Bosses_Ring of Booty"] = {
["profiles"] = {
["All classes"] = {
[256489] = 966887,
[257904] = 966887,
[256358] = 1032439,
[257829] = 966887,
[256405] = 966887,
},
},
},
["BigWigs_Bosses_General Umbriss"] = {
["profiles"] = {
["All classes"] = {
[447261] = 3133687,
},
},
},
["BigWigs_Bosses_Uldaman: Legacy of Tyr Trash"] = {
["profiles"] = {
["All classes"] = {
[369335] = 3129591,
},
},
},
["BigWigs_Bosses_Ruby Life Pools Trash"] = {
["profiles"] = {
["All classes"] = {
[392486] = 3129591,
},
},
},
["BigWigs_Bosses_Yalnu"] = {
["profiles"] = {
["All classes"] = {
[169179] = 3129591,
},
},
},
["BigWigs_Bosses_Freehold Trash"] = {
["profiles"] = {
["All classes"] = {
[274400] = 966887,
[257736] = 966887,
[257775] = 966887,
[272402] = 966887,
[257272] = 966903,
[257908] = 966887,
[258199] = 966887,
[258672] = 966887,
[257870] = 966887,
[257756] = 966887,
[257739] = 967143,
[274555] = 966887,
[258181] = 966887,
[257732] = 966887,
[274383] = 966887,
[274507] = 966887,
[258323] = 966887,
},
},
},
["BigWigs_Bosses_Sylvanas Windrunner"] = {
["profiles"] = {
["All classes"] = {
[354068] = 3129591,
},
},
},
["BigWigs_Bosses_Ozumat"] = {
["profiles"] = {
["All classes"] = {
[428868] = 3129591,
},
},
},
["BigWigs_Bosses_Melidrussa Chillworn"] = {
["profiles"] = {
["All classes"] = {
[372851] = 3129591,
[373680] = 3129591,
},
},
},
["BigWigs_Bosses_Tazavesh Trash"] = {
["profiles"] = {
["All classes"] = {
[355473] = 966903,
[355915] = 975095,
[1240821] = 966903,
[347716] = 967927,
[356001] = 966903,
[355234] = 966903,
[357226] = 966903,
[356537] = 966903,
[355584] = 966903,
[355577] = 966903,
[357197] = 966903,
[355888] = 975095,
[1244650] = 966903,
[357229] = 967927,
[355900] = 966903,
[356548] = 3129591,
[357238] = 3129591,
[357029] = 966903,
[355429] = 3129591,
[355464] = 966903,
[357512] = 966903,
[356404] = 966903,
[352796] = 967927,
[355048] = 967927,
},
},
},
["BigWigs_Bosses_Cragmaw the Infested"] = {
["profiles"] = {
["All classes"] = {
[260333] = 3129591,
},
},
},
["BigWigs_Bosses_Mchimba the Embalmer"] = {
["profiles"] = {
["All classes"] = {
[267702] = 966887,
[267639] = 1032439,
[267618] = 966887,
},
},
},
["BigWigs_Bosses_Mists of Tirna Scithe Trash"] = {
["profiles"] = {
["All classes"] = {
[326046] = 966903,
[324923] = 966903,
[324776] = 966903,
[340160] = 966903,
[340300] = 970999,
[460092] = 966903,
[322569] = 967927,
[463248] = 967159,
[325418] = 967159,
[324914] = 975095,
[463217] = 970999,
[340279] = 975095,
[463256] = 966903,
[325021] = 967159,
[321968] = 966903,
[322486] = 966903,
[326090] = 975095,
[340544] = 966903,
[340304] = 966903,
[326021] = 966903,
[340289] = 970999,
[322557] = 1040631,
[340305] = 966903,
[340189] = 966903,
[325224] = 966903,
[322938] = 966903,
[340208] = 970999,
},
["Default"] = {
[326046] = 975095,
[324923] = 966903,
[324776] = 966903,
[322569] = 967927,
[463217] = 970999,
[463256] = 966903,
[322486] = 966903,
[340544] = 966903,
[325021] = 967159,
[326021] = 966903,
[322557] = 975095,
[321968] = 966903,
[325418] = 967159,
[324914] = 975095,
[325224] = 966903,
[322938] = 966903,
[463248] = 967159,
},
},
},
["BigWigs_Bosses_Emberon"] = {
["profiles"] = {
["All classes"] = {
[369110] = 3129591,
},
},
},
["BigWigs_Bosses_Shadowcrown"] = {
["profiles"] = {
["All classes"] = {
[428086] = 3064055,
[451026] = 3064055,
[426735] = 3137783,
},
},
},
["BigWigs_Bosses_Ki'katal the Harvester"] = {
["profiles"] = {
["All classes"] = {
[461487] = 3137783,
},
},
},
["BigWigs_Bosses_Lord and Lady Waycrest"] = {
["profiles"] = {
["All classes"] = {
[261438] = 1036535,
[261447] = 966887,
[261440] = 966887,
[268306] = 966887,
[268278] = 3064039,
},
},
},
["BigWigs_Bosses_The Nokhud Offensive Trash"] = {
["profiles"] = {
["All classes"] = {
[395035] = 3129591,
[386024] = 3129591,
},
},
},
["BigWigs_Bosses_Margrave Stradama"] = {
["profiles"] = {
["All classes"] = {
[322232] = 3129591,
},
},
},
["BigWigs_Bosses_Blazikon"] = {
["profiles"] = {
["All classes"] = {
[425394] = 3129591,
},
},
},
["BigWigs_Bosses_Oshir"] = {
["profiles"] = {
["All classes"] = {
[162415] = 3129591,
},
},
},
["BigWigs_Bosses_Throne of the Tides Trash"] = {
["profiles"] = {
["All classes"] = {
[428542] = 3129591,
[426645] = 3129591,
},
},
},
["BigWigs_Bosses_Shade of Medivh"] = {
["profiles"] = {
["All classes"] = {
["focused_power"] = 3129591,
},
},
},
["BigWigs_Bosses_Council of Dreams"] = {
["profiles"] = {
["All classes"] = {
[420525] = 3129591,
},
},
},
["BigWigs_Bosses_Oakheart"] = {
["profiles"] = {
["All classes"] = {
[204666] = 3129591,
},
},
},
["BigWigs_Bosses_Neltharions Lair Trash"] = {
["profiles"] = {
["All classes"] = {
[188587] = 3129591,
[226296] = 3129591,
},
},
},
["BigWigs_Bosses_The Necrotic Wake Trash"] = {
["profiles"] = {
["All classes"] = {
[338353] = 1032439,
[327240] = 966903,
[333479] = 966903,
[327396] = 966903,
[343470] = 966903,
[338456] = 970999,
[321780] = 966903,
[322756] = 966903,
[338357] = 1032439,
[335141] = 966903,
[324372] = 966903,
[323471] = 966903,
[338606] = 1032439,
[334748] = 966903,
[324293] = 966903,
[320464] = 966903,
[333477] = 966903,
[335143] = 966903,
[324394] = 1033463,
[327130] = 966903,
[323347] = 966903,
[324387] = 966903,
[345623] = 966903,
[328667] = 966903,
},
["Default"] = {
[327130] = 966903,
[338456] = 970999,
[334748] = 966903,
[323347] = 966903,
[323471] = 966903,
[343470] = 966903,
[338357] = 966903,
[324293] = 966903,
[335143] = 966903,
[322756] = 966903,
[321780] = 966903,
[338606] = 966903,
[338353] = 966903,
[328667] = 966903,
[327396] = 966903,
[327240] = 966903,
},
},
},
["BigWigs_Bosses_Tol Dagor Trash"] = {
["profiles"] = {
["All classes"] = {
[258079] = 966887,
[258864] = 966887,
[258634] = 966887,
[258313] = 966887,
[258153] = 966887,
[258917] = 966887,
[258128] = 966887,
},
},
},
["BigWigs_Bosses_Dargrul"] = {
["profiles"] = {
["All classes"] = {
[200637] = 3129591,
},
},
},
["BigWigs_Bosses_King Mechagon"] = {
["profiles"] = {
["All classes"] = {
[283551] = 3129591,
},
},
},
["BigWigs_Bosses_Sporecaller Zancha"] = {
["profiles"] = {
["All classes"] = {
[259732] = 1032439,
[259830] = 966887,
[273285] = 966887,
[259718] = 966887,
},
},
},
["BigWigs_Bosses_Timecap'n Hooktail"] = {
["profiles"] = {
["All classes"] = {
[352345] = 3129847,
},
},
},
["BigWigs_Bosses_Ularogg Cragshaper"] = {
["profiles"] = {
["All classes"] = {
[198496] = 3133687,
},
},
},
["BigWigs_Bosses_Atal'Dazar Trash"] = {
["profiles"] = {
["All classes"] = {
[256882] = 3129591,
[253544] = 966903,
[256849] = 966887,
[252687] = 966887,
[252781] = 966887,
},
},
},
["BigWigs_Bosses_Amarth, The Harvester"] = {
["profiles"] = {
["All classes"] = {
[328667] = 966903,
[333488] = 3129591,
},
},
},
["BigWigs_Bosses_Umbrelskul"] = {
["profiles"] = {
["All classes"] = {
[385331] = 3064055,
[384978] = 3133687,
},
},
},
["BigWigs_Plugins_Nameplates"] = {
["profiles"] = {
["All classes"] = {
["iconWidthTarget"] = 27,
["iconHeightOthers"] = 27,
["iconFontName"] = "ITCAvantGardeGothicDemi",
["iconGlowFrequency"] = 0.2000000000000002,
["textFontSize"] = 12,
["iconWidthOthers"] = 27,
["iconFontSize"] = 15,
["textFontName"] = "ITCAvantGardeGothicDemi",
["migratePosition"] = true,
["iconExpireGlowType"] = "proc",
["iconGlowPixelLength"] = 2,
["iconCooldownEdge"] = false,
["iconGlowColor"] = {
1,
1,
1,
},
["iconOffsetXTarget"] = 10,
["iconGlowPixelThickness"] = 2,
["iconOffsetX"] = 10,
["iconHeightTarget"] = 27,
},
["Default"] = {
["updated"] = true,
["iconOffsetY"] = -4,
},
},
},
["BigWigs_Bosses_Asaad"] = {
["profiles"] = {
["All classes"] = {
[413264] = 3129591,
[-2434] = 3129591,
},
},
},
["BigWigs_Bosses_The Raging Tempest"] = {
["profiles"] = {
["All classes"] = {
[384620] = 3129591,
},
},
},
["BigWigs_Plugins_Bars"] = {
["profiles"] = {
["Default"] = {
["fontSize"] = 12,
},
["All classes"] = {
["normalWidth"] = 223,
["visibleBarLimit"] = 3,
["expWidth"] = 251,
["fontName"] = "ITCAvantGardeGothicDemi",
["texture"] = "PlaterTexture",
["barStyle"] = "MonoUI",
["emphasize"] = false,
["fontSizeEmph"] = 11,
["normalHeight"] = 20,
["expPosition"] = {
"RIGHT",
"RIGHT",
-247,
-217,
},
["emphasizeTime"] = 10,
["normalPosition"] = {
"BOTTOM",
"BOTTOM",
307,
181,
},
},
},
},
["BigWigs_Bosses_Echo of Doragosa"] = {
["profiles"] = {
["All classes"] = {
[374361] = 3129591,
},
},
},
["BigWigs_Bosses_Council o' Captains"] = {
["profiles"] = {
["All classes"] = {
[258381] = 1032423,
[258338] = 966903,
[256589] = 966903,
},
},
},
["BigWigs_Bosses_Baron Braunpyke"] = {
["profiles"] = {
["All classes"] = {
[423051] = 3129591,
},
},
},
["BigWigs_Bosses_Forgemaster Throngus"] = {
["profiles"] = {
["All classes"] = {
[449444] = 3129591,
[447395] = 3129591,
},
},
},
["BigWigs_Plugins_Colors"] = {
["profiles"] = {
["All classes"] = {
["barColor"] = {
["BigWigs_Plugins_Colors"] = {
["default"] = {
1,
0,
0,
},
},
},
["flash"] = {
["BigWigs_Plugins_Colors"] = {
["default"] = {
0.929411764705882,
0.462745098039216,
nil,
1,
},
},
},
},
},
},
["BigWigs_Bosses_Dread Captain Lockwood"] = {
["profiles"] = {
["All classes"] = {
[272471] = 966887,
[269029] = 966887,
[268963] = 966887,
[268230] = 966887,
[268260] = 1032439,
[268752] = 966887,
[463182] = 3129591,
},
},
},
["BigWigs_Bosses_Geezle Gigazap"] = {
["profiles"] = {
["All classes"] = {
[465463] = 3129591,
},
},
},
["BigWigs_Bosses_Archdruid Glaidalis"] = {
["profiles"] = {
["All classes"] = {
[198379] = 3129591,
},
},
},
["BigWigs_Bosses_Waycrest Manor Trash"] = {
["profiles"] = {
["All classes"] = {
[263891] = 966887,
[263961] = 966887,
[265876] = 966887,
[264396] = 966887,
[264390] = 966887,
[264150] = 966887,
[265759] = 966887,
[265352] = 966887,
[264050] = 966903,
[265407] = 966903,
[265368] = 966887,
[264105] = 966887,
[265880] = 966887,
[265346] = 966887,
[263943] = 966887,
[271174] = 966903,
[265881] = 966887,
[263905] = 966887,
[264525] = 966887,
[263959] = 966903,
[264456] = 966887,
[265741] = 966887,
[264038] = 966887,
[265760] = 966887,
},
},
},
["BigWigs_Bosses_Big M.O.M.M.A."] = {
["profiles"] = {
["All classes"] = {
[473351] = 3133687,
},
},
},
["BigWigs_Bosses_Anub'zekt"] = {
["profiles"] = {
["All classes"] = {
[439506] = 3129591,
},
},
},
["BigWigs_Bosses_Primal Tsunami"] = {
["profiles"] = {
["All classes"] = {
[388424] = 3129591,
},
},
},
["BigWigs_Bosses_Heartsbane Triad"] = {
["profiles"] = {
["All classes"] = {
[260703] = 966887,
[268086] = 966887,
[260741] = 3129591,
},
},
},
["BigWigs_Bosses_The Council of Blood"] = {
["profiles"] = {
["All classes"] = {
[347350] = 3129591,
},
},
},
["BigWigs_Bosses_Rezan"] = {
["profiles"] = {
["All classes"] = {
[255371] = 966887,
[255434] = 1037559,
},
},
},
["BigWigs_Bosses_The Everbloom Trash"] = {
["profiles"] = {
["All classes"] = {
[427223] = 3131639,
},
},
},
["BigWigs_Bosses_Trixie & Naeno"] = {
["profiles"] = {
["All classes"] = {
[302682] = 4112887,
},
},
},
["BigWigs_Bosses_So'leah"] = {
["profiles"] = {
["All classes"] = {
[353635] = 3129591,
},
},
},
["BigWigs_Bosses_Globgrog"] = {
["profiles"] = {
["All classes"] = {
[324527] = 3129591,
},
},
},
["BigWigs_Plugins_Messages"] = {
["profiles"] = {
["All classes"] = {
["outline"] = "OUTLINE",
["disabled"] = true,
["emphFontName"] = "ITCAvantGardeGothicDemi",
["emphFontSize"] = 30,
["emphPosition"] = {
"TOP",
"TOP",
-15,
},
["emphDisabled"] = true,
["fontName"] = "ITCAvantGardeGothicDemi",
},
},
},
["BigWigs_Bosses_Chronikar"] = {
["profiles"] = {
["All classes"] = {
[413013] = 3133687,
},
},
},
["BigWigs_Bosses_Archmage Sol"] = {
["profiles"] = {
["All classes"] = {
[427899] = 3129591,
},
},
},
["BigWigs_Bosses_De Other Side Trash"] = {
["profiles"] = {
["All classes"] = {
[334051] = 3129591,
},
},
},
["BigWigs_Bosses_Mistcaller"] = {
["profiles"] = {
["All classes"] = {
[321828] = 4178167,
},
},
},
["BigWigs_Bosses_Rixxa Fluxflame"] = {
["profiles"] = {
["All classes"] = {
[270042] = 966887,
},
},
},
["BigWigs_Bosses_Bromach"] = {
["profiles"] = {
["All classes"] = {
[369700] = 3129591,
},
},
},
["BigWigs_Bosses_Skarmorak"] = {
["profiles"] = {
["All classes"] = {
[423538] = 3129591,
},
},
},
["BigWigs_Bosses_Mordretha, the Endless Empress"] = {
["profiles"] = {
["All classes"] = {
[324079] = 3133687,
},
},
},
["BigWigs_Bosses_Darkflame Cleft Trash"] = {
["profiles"] = {
["All classes"] = {
[426295] = 966903,
[1218131] = 966903,
[428066] = 3129591,
[426619] = 966903,
[440652] = 966903,
[425536] = 966903,
[428019] = 975095,
[426883] = 966903,
[423501] = 966903,
[1218117] = 3129591,
},
},
},
["BigWigs_Bosses_Forgemaster Gorek"] = {
["profiles"] = {
["All classes"] = {
[374635] = 3129591,
},
},
},
["BigWigs_Bosses_Forgeweaver Araz"] = {
["profiles"] = {
["All classes"] = {
[1228216] = 3129591,
[1232590] = 3129591,
},
},
},
["BigWigs_Bosses_Priestess Alun'za"] = {
["profiles"] = {
["All classes"] = {
[255577] = 1032439,
[255579] = 1033463,
[255582] = 966887,
[255558] = 966887,
},
},
},
["BigWigs_Bosses_Azhiccar"] = {
["profiles"] = {
["All classes"] = {
[1217232] = 3129591,
},
},
},
["BigWigs_Bosses_Tik'ali"] = {
["profiles"] = {
["All classes"] = {
[257593] = 966887,
[271698] = 966887,
[257582] = 966887,
[258622] = 1032439,
},
},
},
["BigWigs_Bosses_Yazma"] = {
["profiles"] = {
["All classes"] = {
[250036] = 966887,
[259187] = 1032439,
[250096] = 262163,
[249919] = 1425,
[250050] = 966887,
},
},
},
["BigWigs_Bosses_Gorak Tul"] = {
["profiles"] = {
["All classes"] = {
[266266] = 966887,
[266198] = 966887,
[266181] = 1032439,
[266225] = 966887,
},
},
},
["BigWigs_Bosses_Rokmora"] = {
["profiles"] = {
["All classes"] = {
[188114] = 3129591,
},
},
},
["BigWigs_Bosses_Ol' Waxbeard"] = {
["profiles"] = {
["All classes"] = {
[429093] = 3129591,
},
},
},
["BigWigs_Bosses_Skulloc"] = {
["profiles"] = {
["All classes"] = {
[168227] = 3129591,
},
},
},
["BigWigs_Bosses_Stormguard Gorren"] = {
["profiles"] = {
["All classes"] = {
[424958] = 3129591,
},
},
},
["BigWigs_Bosses_Knight Captain Valyri"] = {
["profiles"] = {
["All classes"] = {
[257028] = 966887,
[256970] = 966887,
},
},
},
["BigWigs_Bosses_Fyrakk the Blazing"] = {
["profiles"] = {
["All classes"] = {
[422837] = 3129591,
},
},
},
["BigWigs_Bosses_Grimrail Enforcers"] = {
["profiles"] = {
["All classes"] = {
[165152] = 3129591,
},
},
},
["BigWigs_Plugins_InfoBox"] = {
["profiles"] = {
["All classes"] = {
["position"] = {
"BOTTOM",
"BOTTOM",
-226.651123046875,
69.24858093261719,
},
},
},
},
["BigWigs_Bosses_Lady Jaina Proudmoore"] = {
["profiles"] = {
["All classes"] = {
[285177] = 0,
},
},
},
["BigWigs_Bosses_Maiden of Virtue"] = {
["profiles"] = {
["All classes"] = {
[227508] = 3129591,
},
},
},
["BigWigs_Bosses_Operation: Mechagon Trash"] = {
["profiles"] = {
["All classes"] = {
[295169] = 966903,
[294195] = 975095,
[293854] = 966903,
[300207] = 3129591,
[293986] = 966903,
[1215409] = 3129591,
[294103] = 966903,
[1215411] = 970999,
[293683] = 966903,
},
},
},
["BigWigs_Bosses_Zek'voz, Herald of N'zoth"] = {
["profiles"] = {
["All classes"] = {
[-18390] = 1032439,
},
},
},
["BigWigs_Plugins_Raid Icons"] = {
["profiles"] = {
["All classes"] = {
["secondIcon"] = 1,
},
},
},
["BigWigs_Bosses_Coin-Operated Crowd Pummeler"] = {
["profiles"] = {
["All classes"] = {
[262347] = 966887,
[269493] = 966887,
[256493] = 966887,
},
},
},
["BigWigs_Bosses_Kyrakka and Erkhart Stormvein"] = {
["profiles"] = {
["All classes"] = {
[381517] = 3129591,
},
},
},
["BigWigs_Bosses_City of Threads Trash"] = {
["profiles"] = {
["Default"] = {
[443500] = 966903,
[443437] = 966903,
[443430] = 966903,
[447271] = 966903,
[446086] = 966903,
[434137] = 966903,
[445813] = 966903,
[446717] = 966903,
[452162] = 966903,
[451543] = 966903,
},
},
},
["BigWigs_Bosses_Rasha'nan Dawnbreaker"] = {
["profiles"] = {
["All classes"] = {
[448888] = 3129591,
},
},
},
["BigWigs_Bosses_Chargath, Bane of Scales"] = {
["profiles"] = {
["All classes"] = {
[373424] = 3129591,
},
},
},
["BigWigs_Bosses_The Darkness"] = {
["profiles"] = {
["All classes"] = {
[428266] = 3129591,
},
},
},
["BigWigs_Bosses_King Rastakhan"] = {
["profiles"] = {
["All classes"] = {
[284831] = 966887,
},
},
},
["BigWigs_Bosses_E.D.N.A."] = {
["profiles"] = {
["All classes"] = {
[424888] = 3133687,
},
},
},
["BigWigs_Bosses_Myza's Oasis"] = {
["profiles"] = {
["All classes"] = {
[350919] = 3129591,
},
},
},
["BigWigs_Bosses_Adderis and Aspix"] = {
["profiles"] = {
["All classes"] = {
[263371] = 966887,
[263309] = 1032439,
[263246] = 966887,
},
},
},
["BigWigs_Bosses_Shade of Xavius"] = {
["profiles"] = {
["All classes"] = {
[200050] = 3129591,
[200238] = 4178167,
[200185] = 4112887,
},
},
},
["BigWigs_Bosses_Magmatusk"] = {
["profiles"] = {
["All classes"] = {
[375890] = 3129591,
},
},
},
["BigWigs_Bosses_Vol'kaal"] = {
["profiles"] = {
["All classes"] = {
[250585] = 966887,
[259572] = 1032439,
[250241] = 966887,
[250258] = 966887,
},
},
},
["BigWigs_Bosses_Hadal Darkfathom"] = {
["profiles"] = {
["All classes"] = {
[276068] = 1032439,
[257882] = 966887,
[261563] = 966887,
},
},
},
["BigWigs_Bosses_Vectis"] = {
["profiles"] = {
["All classes"] = {
[267242] = 1032439,
},
},
},
["BigWigs_Bosses_Merektha"] = {
["profiles"] = {
["All classes"] = {
[264239] = 966887,
[263912] = 966887,
[263958] = 1032439,
[263927] = 966887,
[264206] = 966887,
},
},
},
["BigWigs_Bosses_Elder Leaxa"] = {
["profiles"] = {
["All classes"] = {
[264757] = 966887,
[260894] = 966887,
[260879] = 966887,
[264603] = 966887,
},
},
},
["BigWigs_Bosses_Gulping Goliath"] = {
["profiles"] = {
["All classes"] = {
[385187] = 3129591,
[385442] = 3129591,
},
},
},
["BigWigs_Bosses_Vol'zith the Whisperer"] = {
["profiles"] = {
["All classes"] = {
[267037] = 966887,
[269399] = 966887,
[267360] = 966887,
[267385] = 966887,
},
},
},
["BigWigs_Bosses_Viz'aduum the Watcher"] = {
["profiles"] = {
["All classes"] = {
[230066] = 3129591,
},
},
},
["BigWigs_Bosses_King's Rest Trash"] = {
["profiles"] = {
["All classes"] = {
[270928] = 966887,
[271564] = 966887,
[270084] = 1032439,
[269976] = 1032439,
[270891] = 966887,
[270016] = 966887,
[269931] = 966887,
[270931] = 966887,
[270482] = 966887,
[270514] = 966887,
[270499] = 966887,
[270507] = 1032439,
[270503] = 966887,
[270492] = 966887,
[270872] = 966887,
[270487] = 1036535,
[271555] = 966887,
[270865] = 966887,
[270284] = 966887,
["healing_tide_totem"] = 1032439,
[270920] = 966887,
[269972] = 1032439,
},
},
},
["BigWigs_Bosses_Dawn of the Infinite Trash"] = {
["profiles"] = {
["All classes"] = {
[415769] = 3129591,
[413622] = 3129591,
},
},
},
["BigWigs_Plugins_AltPower"] = {
["profiles"] = {
["All classes"] = {
["fontName"] = "ITCAvantGardeGothicDemi",
["lock"] = true,
["position"] = {
"BOTTOM",
"BOTTOM",
1.298717021942139,
17.02692985534668,
},
},
},
},
["BigWigs_Bosses_Overseer Korgus"] = {
["profiles"] = {
["All classes"] = {
[256105] = 966887,
[256083] = 966887,
[256198] = 966887,
[263345] = 966887,
},
},
},
["BigWigs_Bosses_Raszageth the Storm-Eater"] = {
["profiles"] = {
["All classes"] = {
[387261] = 3129591,
[385574] = 3129591,
},
},
},
["BigWigs_Bosses_Unbound Abomination"] = {
["profiles"] = {
["All classes"] = {
[269843] = 966887,
[269310] = 966887,
[269301] = 966887,
},
},
},
["BigWigs_Bosses_Izo, the Grand Splicer"] = {
["profiles"] = {
["All classes"] = {
[439341] = 3131639,
[437700] = 3129591,
},
},
},
["MythicPlus"] = {
["profiles"] = {
["All classes"] = {
["instanceKeysPosition"] = {
"CENTER",
"CENTER",
10,
200,
},
["instanceKeysFontSize"] = 20,
["instanceKeysFontName"] = "ITCAvantGardeGothicDemi",
["viewerPosition"] = {
nil,
nil,
13,
-41,
},
},
},
},
["BigWigs_Bosses_Morchie"] = {
["profiles"] = {
["All classes"] = {
[405279] = 3129591,
},
},
},
["BigWigs_Bosses_Stormwall Blockade"] = {
["profiles"] = {
["All classes"] = {
[285118] = 1032439,
},
},
},
["BigWigs_Bosses_The Sand Queen"] = {
["profiles"] = {
["All classes"] = {
[257092] = 966887,
[257608] = 966887,
[257609] = 966887,
[257495] = 966887,
},
},
},
["BigWigs_Bosses_Fractillus"] = {
["profiles"] = {
["All classes"] = {
[1227373] = 4178167,
},
},
},
["BigWigs_Bosses_Jes Howlis"] = {
["profiles"] = {
["All classes"] = {
[257827] = 966887,
[257793] = 966887,
[257777] = 966887,
},
},
},
["BigWigs_Bosses_Aqu'sirr"] = {
["profiles"] = {
["All classes"] = {
[264166] = 966887,
[264101] = 1032439,
[264560] = 966887,
},
},
},
["BigWigs_Bosses_Ara-Kara, City of Echoes Trash"] = {
["profiles"] = {
["Default"] = {
[448248] = 966903,
[434252] = 966903,
[434793] = 966903,
[433845] = 966903,
[433841] = 966903,
[453161] = 966903,
},
["All classes"] = {
[438826] = 966903,
[1241693] = 3129591,
[453161] = 966903,
[434802] = 3129591,
[433845] = 966903,
[434824] = 966903,
},
},
},
["BigWigs_Bosses_Mindbender Ghur'sha"] = {
["profiles"] = {
["All classes"] = {
[429048] = 3072247,
[429037] = 3129591,
},
},
},
["BigWigs_Bosses_The Golden Serpent"] = {
["profiles"] = {
["All classes"] = {
[265773] = 966887,
[265781] = 966887,
[265923] = 966887,
[265910] = 1036535,
},
},
},
["BigWigs_Bosses_Nalthor the Rimebinder"] = {
["profiles"] = {
["All classes"] = {
[321368] = 3129591,
},
},
},
["BigWigs_Bosses_An Affront of Challengers"] = {
["profiles"] = {
["All classes"] = {
[333231] = 3129591,
},
},
},
["BigWigs_Bosses_The Council of Tribes"] = {
["profiles"] = {
["All classes"] = {
[266206] = 966887,
[266237] = 1033463,
[267060] = 966887,
[266951] = 966887,
},
},
},
["BigWigs_Bosses_Sennarth, The Cold Breath"] = {
["profiles"] = {
["All classes"] = {
[371983] = 3129591,
[373405] = 3129591,
},
},
},
["BigWigs_Bosses_Erudax"] = {
["profiles"] = {
["All classes"] = {
[449939] = 3129591,
[450100] = 3133687,
},
},
},
["BigWigs_Bosses_Surgeon Stitchflesh"] = {
["profiles"] = {
["All classes"] = {
[322681] = 2015479,
[343556] = 3129591,
[320376] = 3130615,
[334488] = 3130615,
},
},
},
["BigWigs_Bosses_Abyssal Commander Sivara"] = {
["profiles"] = {
["All classes"] = {
[296551] = 1032439,
},
},
},
["BigWigs_Bosses_Priory of the Sacred Flame Trash"] = {
["profiles"] = {
["All classes"] = {
[427484] = 966903,
[427950] = 966903,
[427342] = 966903,
[444728] = 975095,
[448515] = 975095,
[424429] = 966903,
[453458] = 975095,
[427609] = 3129591,
[424621] = 966903,
[435165] = 967927,
[424462] = 966903,
[424423] = 3129591,
[448485] = 970999,
[448791] = 3064055,
[448492] = 3129591,
},
},
},
["BigWigs_Bosses_Dimensius, the All-Devouring"] = {
["profiles"] = {
["All classes"] = {
[1238765] = 3129591,
[1233539] = 3129591,
},
},
},
["BigWigs_Bosses_The Coaglamation"] = {
["profiles"] = {
["All classes"] = {
[461842] = 3133687,
},
},
},
["BigWigs_Bosses_Igira the Cruel"] = {
["profiles"] = {
["All classes"] = {
[426056] = 3129591,
},
},
},
["BigWigs_Bosses_Theater Of Pain Trash"] = {
["profiles"] = {
["All classes"] = {
[331316] = 970999,
[330565] = 967927,
[330697] = 975095,
[333294] = 966903,
[334023] = 966903,
[333845] = 970999,
[331288] = 967927,
[330716] = 3129591,
[331223] = 3129591,
[342675] = 3064055,
[1215850] = 3129591,
[330725] = 975095,
[336995] = 966903,
[331237] = 966903,
[317605] = 966903,
[333299] = 975095,
[333827] = 3129591,
[330532] = 967159,
[333241] = 3129591,
[342135] = 3129591,
},
},
},
["BigWigs_Bosses_Chrono-Lord Deios"] = {
["profiles"] = {
["All classes"] = {
[376049] = 3129591,
},
},
},
["BigWigs_Bosses_Decatriarch Wratheye"] = {
["profiles"] = {
["All classes"] = {
[373944] = 3129591,
[373960] = 3129591,
},
},
},
["BigWigs_Bosses_Tidesage Coucil"] = {
["profiles"] = {
["All classes"] = {
[267818] = 966887,
[267899] = 1033463,
[267891] = 966887,
[267905] = 966887,
},
},
},
["BigWigs_Bosses_Amalgam of Souls"] = {
["profiles"] = {
["All classes"] = {
[196587] = 3129591,
},
},
},
["BigWigs_Bosses_Void Speaker Eirich"] = {
["profiles"] = {
["All classes"] = {
[427461] = 3129591,
},
},
},
["BigWigs_Bosses_Skycap'n Kragg"] = {
["profiles"] = {
["All classes"] = {
[255952] = 1032439,
[256106] = 3129575,
[256016] = 966887,
},
},
},
["BigWigs_Bosses_Machinist's Garden"] = {
["profiles"] = {
["All classes"] = {
[294855] = 3129847,
[285440] = 3129591,
},
},
},
["BigWigs_Bosses_Dresaron"] = {
["profiles"] = {
["All classes"] = {
[199460] = 3129591,
},
},
},
["BigWigs_Bosses_Grim Batol Trash"] = {
["profiles"] = {
["All classes"] = {
[451391] = 966903,
[456696] = 966903,
[451612] = 966903,
[451241] = 970999,
[451395] = 966903,
[451939] = 966903,
[451613] = 966903,
[76711] = 966903,
[451871] = 966903,
[451965] = 966903,
[451224] = 975095,
[451971] = 970999,
[462216] = 966903,
[456711] = 966903,
[456713] = 966903,
},
["Default"] = {
[451391] = 966903,
[451965] = 966903,
[451939] = 966903,
[451613] = 966903,
[76711] = 966903,
[456711] = 966903,
[456713] = 966903,
[451224] = 975095,
[462216] = 966903,
[451871] = 966903,
[451971] = 970999,
[456696] = 966903,
},
},
},
["BigWigs_Bosses_Kurtalos Ravencrest"] = {
["profiles"] = {
["All classes"] = {
[202019] = 3129591,
},
},
},
["BigWigs_Bosses_Mailroom Mayhem"] = {
["profiles"] = {
["All classes"] = {
[346742] = 3129591,
},
},
},
["BigWigs_Bosses_Tussle Tonks"] = {
["profiles"] = {
["All classes"] = {
[1215102] = 3129591,
},
},
},
["BigWigs_Bosses_Azureblade"] = {
["profiles"] = {
["All classes"] = {
[372222] = 3129591,
},
},
},
["BigWigs_Bosses_Xav the Unfallen"] = {
["profiles"] = {
["All classes"] = {
[320050] = 3129591,
},
},
},
["BigWigs_Bosses_Crawth"] = {
["profiles"] = {
["All classes"] = {
[377004] = 3129591,
},
},
},
["BigWigs_Bosses_The Queen's Court"] = {
["profiles"] = {
["All classes"] = {
[301807] = 1032439,
},
},
},
["BigWigs_Bosses_Commander Ulthok"] = {
["profiles"] = {
["All classes"] = {
[427668] = 3129591,
},
},
},
["BigWigs_Plugins_Proximity"] = {
["profiles"] = {
["Default"] = {
["posx"] = 420.266807051503,
["font"] = "Friz Quadrata TT",
["lock"] = true,
["height"] = 120.000007629395,
["sound"] = true,
["posy"] = 366.222448103963,
},
["All classes"] = {
["posx"] = 631.466457966555,
["fontName"] = "ITCAvantGardeGothicDemi",
["width"] = 139.999984741211,
["font"] = "Friz Quadrata TT",
["lock"] = true,
["height"] = 120.000007629395,
["posy"] = 146.489085843792,
},
},
},
["BigWigs_Bosses_G'huun"] = {
["profiles"] = {
["All classes"] = {
[267409] = 1032439,
[-18109] = 966887,
[263235] = 1032439,
},
},
},
["BigWigs_Bosses_The One-Armed Bandit"] = {
["profiles"] = {
["All classes"] = {
[469993] = 3129591,
},
},
},
["BigWigs_Bosses_Gunker"] = {
["profiles"] = {
["All classes"] = {
[297834] = 3129591,
[297835] = 3129591,
},
},
},
["BigWigs_Bosses_Kin-Tara"] = {
["profiles"] = {
["All classes"] = {
[320966] = 3133687,
},
},
},
["BigWigs_Bosses_Cinderbrew Meadery Trash"] = {
["profiles"] = {
["All classes"] = {
[441119] = 966903,
[463218] = 3131639,
[434756] = 967159,
[441214] = 975095,
[437956] = 966903,
[440876] = 966903,
[463206] = 3129591,
[434998] = 966903,
[441434] = 966903,
[434706] = 966903,
[442589] = 966903,
},
},
},
["BigWigs_Bosses_Avatar of Sethraliss"] = {
["profiles"] = {
["All classes"] = {
[269686] = 966887,
[269688] = 966887,
[268024] = 966887,
},
},
},
["BigWigs_Bosses_Orgozoa"] = {
["profiles"] = {
["All classes"] = {
[305048] = 1032439,
},
},
},
["BigWigs_Bosses_The Stonevault Trash"] = {
["profiles"] = {
["Default"] = {
[449455] = 966903,
[428879] = 966903,
[428703] = 966903,
[429427] = 966903,
[426345] = 966903,
[429109] = 966903,
[426308] = 975095,
[445207] = 966903,
[447141] = 966903,
[448640] = 966903,
[449154] = 968951,
[429545] = 966903,
[425027] = 966903,
[426771] = 968951,
[449130] = 966903,
},
},
},
["BigWigs_Bosses_Fleshrender Nok'gar"] = {
["profiles"] = {
["All classes"] = {
[164426] = 3129591,
},
},
},
["BigWigs_Bosses_King Gobbamak"] = {
["profiles"] = {
["All classes"] = {
[297261] = 3129591,
},
},
},
["BigWigs_Bosses_Underrot Trash"] = {
["profiles"] = {
["All classes"] = {
[265540] = 1032439,
[265019] = 966903,
[265668] = 966887,
[266107] = 966887,
[266209] = 966887,
[265568] = 966887,
[272592] = 966903,
[265081] = 966887,
[272609] = 966887,
[265487] = 1032439,
[266106] = 966903,
[278961] = 1032439,
},
},
},
["BigWigs_Bosses_Lady Ashvane"] = {
["profiles"] = {
["All classes"] = {
[-20096] = 1032439,
},
},
},
["BigWigs_Bosses_Hakkar the Soulflayer"] = {
["profiles"] = {
["All classes"] = {
[322759] = 3129591,
},
},
},
["BigWigs_Plugins_Victory"] = {
["profiles"] = {
["All classes"] = {
["soundName"] = "None",
},
},
},
["BigWigs_Bosses_Skylord Tovra"] = {
["profiles"] = {
["All classes"] = {
[161801] = 3129591,
},
},
},
["BigWigs_Bosses_Watcher Irideus"] = {
["profiles"] = {
["All classes"] = {
[384014] = 3129591,
},
},
},
["BigWigs_Bosses_The Dawnbreaker Trash"] = {
["profiles"] = {
["All classes"] = {
[432565] = 966903,
[450854] = 3064055,
[451117] = 3129591,
[431494] = 966903,
[431491] = 967927,
[451102] = 3129591,
[431364] = 3129591,
[432448] = 966903,
[451112] = 975095,
[451119] = 967159,
[431309] = 975095,
},
["Default"] = {
[432565] = 966903,
[431309] = 975095,
[451098] = 966903,
[431494] = 966903,
[451107] = 966903,
[431364] = 966903,
[431304] = 966903,
[432448] = 966903,
[451097] = 966903,
[450756] = 966903,
[432520] = 966903,
},
},
},
["BigWigs_Bosses_Kul'tharok"] = {
["profiles"] = {
["All classes"] = {
[1215787] = 3129591,
},
},
},
["BigWigs_Bosses_Halls of Atonement Trash"] = {
["profiles"] = {
["All classes"] = {
[326441] = 966903,
[1236614] = 1032439,
[326997] = 966903,
[325876] = 966903,
[326450] = 3064055,
[326409] = 3129591,
[1237071] = 967927,
[1235762] = 966903,
[1235326] = 3129591,
},
},
},
["BigWigs_Bosses_Zo'phex the Sentinel"] = {
["profiles"] = {
["All classes"] = {
[345990] = 3129591,
},
},
},
["BigWigs_Bosses_Vexamus"] = {
["profiles"] = {
["All classes"] = {
[386173] = 3129591,
},
},
},
["BigWigs_Bosses_Tred'ova"] = {
["profiles"] = {
["All classes"] = {
[322614] = 3129591,
},
},
},
["BigWigs_Bosses_Eco-Dome Al'dani Trash"] = {
["profiles"] = {
["All classes"] = {
[1248699] = 1032439,
[1237195] = 966903,
[1226111] = 966903,
[1223007] = 966903,
[1235368] = 966903,
[1221152] = 3129591,
[1221483] = 966903,
[1237220] = 3129591,
[1222356] = 966903,
[1221190] = 966903,
[1215850] = 966903,
},
},
},
["BigWigs_Bosses_Gorechop"] = {
["profiles"] = {
["All classes"] = {
[323515] = 3133687,
[318406] = 3129591,
},
},
},
["BigWigs_Bosses_Granyth"] = {
["profiles"] = {
["All classes"] = {
[388817] = 3129591,
},
},
},
["BigWigs_Bosses_Fangs of the Queen"] = {
["profiles"] = {
["All classes"] = {
[440218] = 3137783,
},
},
},
["BigWigs_Bosses_The Curator"] = {
["profiles"] = {
["All classes"] = {
[227254] = 3129591,
},
},
},
["BigWigs_Bosses_Attumen the Huntsman"] = {
["profiles"] = {
["All classes"] = {
[228852] = 3129591,
},
},
},
["BigWigs_Bosses_Mogul Razdunk"] = {
["profiles"] = {
["All classes"] = {
[276229] = 3129591,
[260813] = 4178167,
},
},
},
["BigWigs_Bosses_Brackenhide Hollow Trash"] = {
["profiles"] = {
["All classes"] = {
[367503] = 3129591,
},
},
},
["BigWigs_Bosses_Sentinel Talondras"] = {
["profiles"] = {
["All classes"] = {
[372701] = 3129591,
},
},
},
["BigWigs_Bosses_Broodkeeper Diurna"] = {
["profiles"] = {
["All classes"] = {
[388918] = 3129591,
},
},
},
["BigWigs_Bosses_The Vortex Pinnacle Trash"] = {
["profiles"] = {
["All classes"] = {
[88194] = 3129591,
},
},
},
["BigWigs_Bosses_Chopper Redhook"] = {
["profiles"] = {
["All classes"] = {
[257288] = 966903,
},
},
},
["BigWigs_Bosses_Grimrail Depot Trash"] = {
["profiles"] = {
["All classes"] = {
[176127] = 3129591,
},
},
},
["BigWigs_Bosses_Soulbound Goliath"] = {
["profiles"] = {
["All classes"] = {
[267907] = 1032439,
[260508] = 1033463,
[260512] = 966887,
[260569] = 966887,
[260541] = 966887,
},
},
},
["BigWigs_Bosses_Ingra Maloch"] = {
["profiles"] = {
["All classes"] = {
[328756] = 3129591,
},
},
},
["BigWigs_Bosses_Mueh'zala"] = {
["profiles"] = {
["All classes"] = {
[327646] = 3129591,
},
},
},
["BigWigs_Bosses_Infested Crawg"] = {
["profiles"] = {
["All classes"] = {
[260793] = 966887,
[260333] = 1032439,
[260292] = 966887,
},
},
},
["BigWigs_Bosses_Teera and Maruuk"] = {
["profiles"] = {
["All classes"] = {
[382670] = 3129591,
},
},
},
["BigWigs_Bosses_Swampface"] = {
["profiles"] = {
["All classes"] = {
[473070] = 3129591,
},
},
},
["BigWigs_Plugins_Sounds"] = {
["profiles"] = {
["All classes"] = {
["Long"] = {
["BigWigs_Bosses_Fyrakk the Blazing"] = {
[422837] = "|cFFFF0000AoE|r",
},
["BigWigs_Bosses_Council o' Captains"] = {
[256589] = "Bam",
},
["BigWigs_Bosses_The Coaglamation"] = {
[441289] = "Bam",
},
["BigWigs_Bosses_The Rookery Trash"] = {
[1214546] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Siege of Boralus Trash"] = {
[257170] = "Bam",
},
["BigWigs_Bosses_Underrot Trash"] = {
[272592] = "|cFFFF0000Avoid|r",
},
["BigWigs_Bosses_Fractillus"] = {
[1227373] = "None",
},
["BigWigs_Bosses_Opera Hall: Wikket"] = {
[227776] = "Air Horn",
},
["BigWigs_Bosses_Brackenhide Hollow Trash"] = {
[367484] = "|cFFFF0000Targeted|r",
},
["BigWigs_Bosses_Moroes"] = {
[227672] = "Banana Peel Slip",
},
["BigWigs_Bosses_Sentinel Talondras"] = {
[372719] = "Brass",
},
["BigWigs_Bosses_Archmage Sol"] = {
[427899] = "|cFFFF0000AoE|r",
},
["BigWigs_Bosses_Neltharus Trash"] = {
[376200] = "Brass",
[381663] = "BigWigs: Info",
},
},
["Warning"] = {
["BigWigs_Bosses_Atal'Dazar Trash"] = {
[255041] = "Brass",
[253544] = "Brass",
},
["BigWigs_Bosses_Kokia Blazehoof"] = {
[373017] = "Brass",
},
["BigWigs_Bosses_The Stonevault Trash"] = {
[449455] = "Brass",
},
["BigWigs_Bosses_Vol'kaal"] = {
[259572] = "Brass",
},
["BigWigs_Bosses_Underrot Trash"] = {
[413044] = "Brass",
[278755] = "Brass",
[265089] = "Brass",
[266106] = "Brass",
},
["BigWigs_Bosses_Neltharus Trash"] = {
[378282] = "Brass",
},
["BigWigs_Bosses_The Candle King"] = {
[426145] = "Brass",
},
["BigWigs_Bosses_Captain Dailcry"] = {
[424419] = "Brass",
},
["BigWigs_Bosses_Mindbender Ghur'sha"] = {
[429172] = "|cFFFF0000LoS|r",
},
["BigWigs_Bosses_Waycrest Manor Trash"] = {
[265876] = "Brass",
[265407] = "Bam",
[263959] = "Brass",
},
["BigWigs_Bosses_Overgrown Ancient"] = {
[396640] = "Brass",
},
["BigWigs_Bosses_Karazhan Trash"] = {
[228625] = "Banana Peel Slip",
[241774] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mistcaller"] = {
[321828] = "Brass",
},
["BigWigs_Bosses_Myza's Oasis"] = {
[350922] = "Brass",
},
["BigWigs_Bosses_Fractillus"] = {
[1233416] = "|cFFFF0000Move|r",
},
["BigWigs_Bosses_So'leah"] = {
[351119] = "Brass",
},
["BigWigs_Bosses_Iron Docks Trash"] = {
[172952] = "Air Horn",
},
["BigWigs_Bosses_Freehold Trash"] = {
[257784] = "Brass",
[257736] = "|cFFFF0000Stop|r",
},
["BigWigs_Bosses_Sentinel Talondras"] = {
[372719] = "Brass",
},
["BigWigs_Bosses_Ozumat"] = {
[428889] = "Awww Crap",
},
["BigWigs_Bosses_Sennarth, The Cold Breath"] = {
[371983] = "Brass",
[373405] = "Brass",
},
["BigWigs_Bosses_Dimensius, the All-Devouring"] = {
[1233539] = "|cFFFF0000Hide|r",
},
["BigWigs_Bosses_Surgeon Stitchflesh"] = {
[343556] = "|cFFFF0000Fixate|r",
},
["BigWigs_Bosses_Tazavesh Trash"] = {
[355057] = "Brass",
[357260] = "Brass",
[356407] = "Brass",
},
["BigWigs_Bosses_Priory of the Sacred Flame Trash"] = {
[427356] = "Brass",
[424420] = "BigWigs: Alert",
},
["BigWigs_Bosses_Decatriarch Wratheye"] = {
[373944] = "|cFFFF0000Switch|r",
},
["BigWigs_Bosses_Halls of Atonement Trash"] = {
[326450] = "Brass",
},
["BigWigs_Bosses_Theater Of Pain Trash"] = {
[341969] = "Brass",
[330868] = "Brass",
},
["BigWigs_Bosses_Mists of Tirna Scithe Trash"] = {
[326046] = "BigWigs: Info",
},
["BigWigs_Bosses_Ara-Kara, City of Echoes Trash"] = {
[434802] = "Brass",
},
["BigWigs_Bosses_Ancient Protectors"] = {
[168082] = "Brass",
[427459] = "Brass",
},
["BigWigs_Bosses_Unbound Abomination"] = {
[269843] = "Banana Peel Slip",
},
["BigWigs_Bosses_Amalgam of Souls"] = {
[194956] = "Banana Peel Slip",
},
["BigWigs_Bosses_Big M.O.M.M.A."] = {
[1214780] = "Brass",
},
["BigWigs_Bosses_The MOTHERLODE!! Trash"] = {
[268702] = "Brass",
},
["BigWigs_Bosses_The Dawnbreaker Trash"] = {
[450756] = "Brass",
},
["BigWigs_Bosses_Scalecommander Sarkareth"] = {
[408429] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Vortex Pinnacle Trash"] = {
[87779] = "Brass",
},
["BigWigs_Bosses_Blightbone"] = {
[320596] = "Banana Peel Slip",
},
["BigWigs_Bosses_Halls of Infusion Trash"] = {
[374045] = "Brass",
[374699] = "Brass",
},
["BigWigs_Bosses_The Nokhud Offensive Trash"] = {
[384365] = "Brass",
[373395] = "Brass",
},
["BigWigs_Bosses_Raal the Gluttonous"] = {
[264734] = "Awww Crap",
},
["BigWigs_Bosses_Dawn of the Infinite Trash"] = {
[412378] = "Brass",
[417011] = "Brass",
[407891] = "Brass",
},
["BigWigs_Bosses_Kyrakka and Erkhart Stormvein"] = {
[381516] = "|cFFFF0000AoE|r",
},
["BigWigs_Bosses_Neltharions Lair Trash"] = {
[193803] = "Brass",
},
["BigWigs_Bosses_Brackenhide Hollow Trash"] = {
[367500] = "Brass",
},
["BigWigs_Bosses_Manifested Timeways"] = {
[414307] = "Awww Crap",
},
["BigWigs_Bosses_Baron Braunpyke"] = {
[423051] = "Brass",
},
["BigWigs_Bosses_Siege of Boralus Trash"] = {
[256957] = "Brass",
[257169] = "Bam",
},
["BigWigs_Bosses_Hylbrande"] = {
[346957] = "|cFFFF0000Kite|r",
},
},
["Info"] = {
["BigWigs_Bosses_Attumen the Huntsman"] = {
[228852] = "Air Horn",
},
["BigWigs_Bosses_Operation: Mechagon Trash"] = {
[294290] = "Banana Peel Slip",
},
["BigWigs_Bosses_Erudax"] = {
[449939] = "BigWigs: Info",
},
["BigWigs_Bosses_Shade of Xavius"] = {
[200185] = "Brass",
},
["BigWigs_Bosses_Darkflame Cleft Trash"] = {
[430171] = "BigWigs: Info",
},
["BigWigs_Bosses_Black Rook Hold Trash"] = {
[200105] = "Brass",
},
["BigWigs_Bosses_Underrot Trash"] = {
[265019] = "Banana Peel Slip",
},
["BigWigs_Bosses_Nymue, Weaver of the Cycle"] = {
[429615] = "BigWigs: Info",
},
["BigWigs_Bosses_Hackclaw's War-Band"] = {
[381694] = "Synth Chord",
},
["BigWigs_Bosses_Opera Hall: Beautiful Beast"] = {
[228025] = "Air Horn",
},
["BigWigs_Bosses_Uldaman: Legacy of Tyr Trash"] = {
[369465] = "|cFFFF0000Stop|r",
},
["BigWigs_Bosses_Karazhan Trash"] = {
[227966] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mana Devourer"] = {
[227523] = "BigWigs: Alert",
},
["BigWigs_Bosses_Sentinel Talondras"] = {
[372719] = "None",
},
["BigWigs_Bosses_Council of Dreams"] = {
[420525] = "Brass",
},
["BigWigs_Bosses_Yalnu"] = {
[428823] = "Bam",
},
["BigWigs_Bosses_Neltharions Lair Trash"] = {
[188587] = "Brass",
},
["BigWigs_Bosses_The Necrotic Wake Trash"] = {
[323496] = "Banana Peel Slip",
[338357] = "Huh?",
},
["BigWigs_Bosses_The Everbloom Trash"] = {
[164965] = "Brass",
},
["BigWigs_Bosses_Bromach"] = {
[369700] = "|cFFFF0000Switch|r",
},
["BigWigs_Bosses_Ara-Kara, City of Echoes Trash"] = {
[438877] = "BigWigs: Info",
},
["BigWigs_Bosses_Blazikon"] = {
[425394] = "Banana Peel Slip",
},
},
["media"] = {
["Warning"] = "BigWigs: Alert",
["Alert"] = "BigWigs: Info",
},
["Alarm"] = {
["BigWigs_Bosses_Attumen the Huntsman"] = {
[227493] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mana Devourer"] = {
[227457] = "Air Horn",
},
["BigWigs_Bosses_Witherbark"] = {
[164357] = "Banana Peel Slip",
},
["BigWigs_Bosses_Drahga Shadowburner"] = {
[448105] = "Banana Peel Slip",
},
["BigWigs_Bosses_Black Rook Hold Trash"] = {
[200343] = "|cFFFF0000Dodge|r",
[214001] = "Bam",
[200261] = "Banana Peel Slip",
[200913] = "Banana Peel Slip",
[196916] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Vortex Pinnacle Trash"] = {
[411001] = "Brass",
[410999] = "Bam",
[411012] = "Banana Peel Slip",
[411005] = "BigWigs: Alert",
},
["BigWigs_Bosses_The Infinite Dragonflight"] = {
[416139] = "Banana Peel Slip",
},
["BigWigs_Bosses_Throne of the Tides Trash"] = {
[428542] = "Synth Chord",
[76590] = "Bam",
[426808] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Captain Dailcry"] = {
[447270] = "Banana Peel Slip",
},
["BigWigs_Bosses_Dread Captain Lockwood"] = {
[268260] = "Banana Peel Slip",
[269029] = "Banana Peel Slip",
},
["BigWigs_Bosses_Uldaman: Legacy of Tyr Trash"] = {
[369409] = "Banana Peel Slip",
[369366] = "|cFFFF0000Dispell|r",
[369465] = "Brass",
[369811] = "Bam",
[369335] = "BigWigs: Alarm",
},
["BigWigs_Bosses_Ruby Life Pools Trash"] = {
[391726] = "Banana Peel Slip",
[372696] = "Bam",
[372087] = "Banana Peel Slip",
[391723] = "Banana Peel Slip",
},
["BigWigs_Bosses_Lord Chamberlain"] = {
[323236] = "Banana Peel Slip",
},
["BigWigs_Bosses_Grand Vizier Ertan"] = {
[413562] = "Brass",
},
["BigWigs_Bosses_Iron Docks Trash"] = {
[172982] = "Banana Peel Slip",
[173384] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Freehold Trash"] = {
[257756] = "|cFFFF0000CC|r",
[274400] = "|cFFFF0000Move|r",
[257870] = "|cFFFF0000CC|r",
[258777] = "|cFFFF0000Move|r",
[257739] = "|cFFFF0000Fixate|r",
[258199] = "Bam",
[257426] = "Banana Peel Slip",
[257784] = "Brass",
},
["BigWigs_Bosses_Ozumat"] = {
[428530] = "Banana Peel Slip",
},
["BigWigs_Bosses_Tazavesh Trash"] = {
[357229] = "BigWigs: Alert",
[357226] = "Banana Peel Slip",
[355464] = "BigWigs: Alarm",
[356404] = "None",
[357197] = "Bam",
},
["BigWigs_Bosses_Cragmaw the Infested"] = {
[260793] = "Banana Peel Slip",
},
["BigWigs_Bosses_Dargrul"] = {
[200700] = "Banana Peel Slip",
},
["BigWigs_Bosses_Smashspite"] = {
[198079] = "Banana Peel Slip",
},
["BigWigs_Bosses_Emberon"] = {
[369061] = "Banana Peel Slip",
},
["BigWigs_Bosses_Elder Leaxa"] = {
[260894] = "Banana Peel Slip",
[264757] = "Bam",
},
["BigWigs_Bosses_Illysanna Ravencrest"] = {
[197974] = "Banana Peel Slip",
[197478] = "|cFFFF0000Split|r",
[197696] = "|cFFFF0000Fixate|r",
},
["BigWigs_Bosses_Umbrelskul"] = {
[384699] = "Banana Peel Slip",
},
["BigWigs_Bosses_Neltharions Lair Trash"] = {
[183465] = "BigWigs: Alarm",
[183088] = "Banana Peel Slip",
[202108] = "Brass",
[226406] = "Banana Peel Slip",
[226296] = "Banana Peel Slip",
[226287] = "Bam",
},
["BigWigs_Bosses_Algeth'ar Academy Trash"] = {
[377383] = "Banana Peel Slip",
},
["BigWigs_Bosses_Atal'Dazar Trash"] = {
[253583] = "Brass",
[255567] = "Banana Peel Slip",
},
["BigWigs_Bosses_Amarth, The Harvester"] = {
[333488] = "BigWigs: Info",
},
["BigWigs_Bosses_Kokia Blazehoof"] = {
[372107] = "Banana Peel Slip",
[373087] = "Bam",
},
["BigWigs_Bosses_Azerokk"] = {
[275907] = "Banana Peel Slip",
},
["BigWigs_Bosses_Echo of Doragosa"] = {
[388822] = "Bam",
[374361] = "Banana Peel Slip",
},
["BigWigs_Bosses_Geezle Gigazap"] = {
[466190] = "Huh?",
},
["BigWigs_Bosses_Balakar Khan"] = {
[375943] = "Banana Peel Slip",
[376634] = "BigWigs: Alarm",
[376683] = "Banana Peel Slip",
[376892] = "Banana Peel Slip",
},
["BigWigs_Bosses_Anub'zekt"] = {
[435012] = "Banana Peel Slip",
[439506] = "|cFFFF0000Move|r",
},
["BigWigs_Bosses_Kazzara, the Hellforged"] = {
[400430] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Everbloom Trash"] = {
[172578] = "|cFFFF0000Move|r",
},
["BigWigs_Bosses_Altairus"] = {
[88308] = "Banana Peel Slip",
},
["BigWigs_Bosses_Fangs of the Queen"] = {
[439621] = "Banana Peel Slip",
},
["BigWigs_Bosses_Bromach"] = {
[369703] = "Bam",
},
["BigWigs_Bosses_Skarmorak"] = {
[423538] = "Bam",
},
["BigWigs_Bosses_Shadowcrown"] = {
[453212] = "Huh?",
},
["BigWigs_Bosses_Brew Master Aldryr"] = {
[432198] = "Banana Peel Slip",
},
["BigWigs_Bosses_Rokmora"] = {
[188169] = "Banana Peel Slip",
},
["BigWigs_Bosses_Ol' Waxbeard"] = {
[422116] = "Banana Peel Slip",
},
["BigWigs_Bosses_Grimrail Depot Trash"] = {
[176127] = "Air Horn",
[166380] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Azure Vault Trash"] = {
[387067] = "Banana Peel Slip",
[391118] = "Banana Peel Slip",
[370764] = "Banana Peel Slip",
},
["BigWigs_Bosses_City of Threads Trash"] = {
[451543] = "Banana Peel Slip",
[443500] = "Banana Peel Slip",
[447271] = "Bam",
},
["BigWigs_Bosses_Chargath, Bane of Scales"] = {
[373742] = "Banana Peel Slip",
},
["BigWigs_Bosses_Magmatusk"] = {
[375439] = "Banana Peel Slip",
},
["BigWigs_Bosses_Vol'kaal"] = {
[250258] = "Bam",
},
["BigWigs_Bosses_Azureblade"] = {
[372222] = "Banana Peel Slip",
[385578] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Treemouth"] = {
[377559] = "Banana Peel Slip",
},
["BigWigs_Bosses_Gulping Goliath"] = {
[385531] = "Bam",
},
["BigWigs_Bosses_Viz'aduum the Watcher"] = {
[229151] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mindbender Ghur'sha"] = {
[429051] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Sanguine Depths Trash"] = {
[320991] = "Banana Peel Slip",
},
["BigWigs_Bosses_Raszageth the Storm-Eater"] = {
[377594] = "Banana Peel Slip",
},
["BigWigs_Bosses_Machinist's Garden"] = {
[285440] = "Air Horn",
},
["BigWigs_Bosses_Izo, the Grand Splicer"] = {
[437700] = "Bam",
},
["BigWigs_Bosses_Kyrioss"] = {
[474018] = "Banana Peel Slip",
},
["BigWigs_Bosses_Leymor"] = {
[386660] = "Banana Peel Slip",
[374567] = "Bam",
},
["BigWigs_Bosses_Cinderbrew Meadery Trash"] = {
[448619] = "Banana Peel Slip",
[442589] = "Bam",
[441119] = "Banana Peel Slip",
},
["BigWigs_Bosses_Priory of the Sacred Flame Trash"] = {
[424621] = "Bam",
},
["BigWigs_Bosses_Decatriarch Wratheye"] = {
[376170] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Coaglamation"] = {
[461880] = "Bam",
},
["BigWigs_Bosses_Igira the Cruel"] = {
[426056] = "Brass",
},
["BigWigs_Bosses_Amalgam of Souls"] = {
[195254] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Void Speaker Eirich"] = {
[427869] = "Banana Peel Slip",
},
["BigWigs_Bosses_Skycap'n Kragg"] = {
[272046] = "Banana Peel Slip",
},
["BigWigs_Bosses_Dresaron"] = {
[191325] = "Banana Peel Slip",
},
["BigWigs_Bosses_Grim Batol Trash"] = {
[456711] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Lost Dwarves"] = {
[369573] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Xav the Unfallen"] = {
[320729] = "Banana Peel Slip",
[317231] = "Banana Peel Slip",
},
["BigWigs_Bosses_Terros"] = {
[383073] = "Bam",
},
["BigWigs_Bosses_Khajin the Unyielding"] = {
[390111] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Stonevault Trash"] = {
[449130] = "Banana Peel Slip",
[448640] = "Banana Peel Slip",
[447141] = "BigWigs: Info",
[425027] = "Banana Peel Slip",
},
["BigWigs_Bosses_Myza's Oasis"] = {
[356482] = "Bam",
},
["BigWigs_Bosses_Underrot Trash"] = {
[265540] = "Banana Peel Slip",
[272609] = "Banana Peel Slip",
[265019] = "Banana Peel Slip",
[413044] = "Brass",
},
["BigWigs_Bosses_Zo'phex the Sentinel"] = {
[1236348] = "Banana Peel Slip",
},
["BigWigs_Bosses_Brackenhide Hollow Trash"] = {
[373943] = "Bam",
[374544] = "Bam",
[367503] = "Brass",
[382712] = "Banana Peel Slip",
[388060] = "Banana Peel Slip",
[384854] = "Banana Peel Slip",
},
["BigWigs_Bosses_Neltharus Trash"] = {
[372561] = "Bam",
[372311] = "Banana Peel Slip",
[372201] = "Banana Peel Slip",
[376186] = "Bam",
[378827] = "Bam",
[382708] = "Banana Peel Slip",
},
["BigWigs_Bosses_Demolition Duo"] = {
[459779] = "Banana Peel Slip",
},
["BigWigs_Bosses_Darkflame Cleft Trash"] = {
[440652] = "Bam",
[423501] = "Bam",
[426261] = "Banana Peel Slip",
},
["BigWigs_Bosses_Watcher Irideus"] = {
[384524] = "Banana Peel Slip",
},
["BigWigs_Bosses_Tyr, the Infinite Keeper"] = {
[401248] = "Banana Peel Slip",
[401482] = "Banana Peel Slip",
},
["BigWigs_Bosses_Kul'tharok"] = {
[474087] = "Banana Peel Slip",
},
["BigWigs_Bosses_Halls of Atonement Trash"] = {
[326997] = "Banana Peel Slip",
},
["BigWigs_Bosses_Forgemaster Throngus"] = {
[447395] = "Banana Peel Slip",
},
["BigWigs_Bosses_Archdruid Glaidalis"] = {
[198379] = "Banana Peel Slip",
},
["BigWigs_Bosses_Ara-Kara, City of Echoes Trash"] = {
[434824] = "Banana Peel Slip",
[453161] = "Banana Peel Slip",
},
["BigWigs_Bosses_Eco-Dome Al'dani Trash"] = {
[1226111] = "Banana Peel Slip",
[1235368] = "Banana Peel Slip",
},
["BigWigs_Bosses_Gorechop"] = {
[318406] = "Bam",
},
["BigWigs_Bosses_Granyth"] = {
[385916] = "Bam",
},
["BigWigs_Bosses_Dawn of the Infinite Trash"] = {
[407125] = "Banana Peel Slip",
[419351] = "Banana Peel Slip",
[412200] = "Banana Peel Slip",
[412129] = "Banana Peel Slip",
[412156] = "|cFFFF0000Move|r",
[413529] = "Banana Peel Slip",
[412063] = "|cFFFF0000Move|r",
[413621] = "|cFFFF0000Move|r",
[412806] = "Bam",
[412136] = "|cFFFF0000Move|r",
},
["BigWigs_Bosses_Vexamus"] = {
[385958] = "Banana Peel Slip",
},
["BigWigs_Bosses_Viq'Goth"] = {
[269266] = "|cFFFF0000AoE|r",
},
["BigWigs_Bosses_Darkheart Thicket Trash"] = {
[200768] = "Banana Peel Slip",
[201226] = "Banana Peel Slip",
},
["BigWigs_Bosses_Blight of Galakrond"] = {
[408141] = "Banana Peel Slip",
[407159] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Nokhud Offensive Trash"] = {
[387614] = "Bam",
[382233] = "Banana Peel Slip",
[382277] = "Banana Peel Slip",
[386024] = "|cFFFF0000Stop|r",
[386028] = "Bam",
[384336] = "Bam",
},
["BigWigs_Bosses_Spires of Ascension Trash"] = {
[317985] = "Banana Peel Slip",
[328458] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Dawnbreaker Trash"] = {
[431494] = "Banana Peel Slip",
[450854] = "Banana Peel Slip",
[451117] = "Huh?",
},
["BigWigs_Bosses_Chopper Redhook"] = {
[257326] = "Bam",
[257288] = "Banana Peel Slip",
},
["BigWigs_Bosses_Kyrakka and Erkhart Stormvein"] = {
[381525] = "Banana Peel Slip",
},
["BigWigs_Bosses_Operation: Mechagon Trash"] = {
[300424] = "Banana Peel Slip",
[293986] = "Banana Peel Slip",
[301667] = "Banana Peel Slip",
[300188] = "Banana Peel Slip",
[300777] = "Banana Peel Slip",
[299475] = "Banana Peel Slip",
[294324] = "Bam",
},
["BigWigs_Bosses_Ingra Maloch"] = {
[323137] = "Banana Peel Slip",
},
["BigWigs_Bosses_Orator Krix'vizk"] = {
[434779] = "Banana Peel Slip",
},
["BigWigs_Bosses_Crawth"] = {
[377034] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mists of Tirna Scithe Trash"] = {
[321968] = "Banana Peel Slip",
[340305] = "Bam",
[340160] = "Banana Peel Slip",
[326021] = "BigWigs: Info",
[463256] = "Bam",
},
["BigWigs_Bosses_Anub'ikkaj"] = {
[427001] = "Huh?",
[426860] = "Banana Peel Slip",
},
["BigWigs_Bosses_Skylord Tovra"] = {
[162058] = "Banana Peel Slip",
},
["BigWigs_Bosses_Time-Lost Battlefield"] = {
[418054] = "Banana Peel Slip",
[408227] = "Banana Peel Slip",
},
["BigWigs_Bosses_Oakheart"] = {
[204667] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Necrotic Wake Trash"] = {
[333477] = "Banana Peel Slip",
[324293] = "Brass",
},
["BigWigs_Bosses_Trixie & Naeno"] = {
[302682] = "Awww Crap",
},
["BigWigs_Bosses_Warlord Sargha"] = {
[377204] = "Banana Peel Slip",
},
["BigWigs_Bosses_Lady Naz'jar"] = {
[428293] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mistcaller"] = {
[321834] = "Banana Peel Slip",
},
["BigWigs_Bosses_Soulbound Goliath"] = {
[267907] = "Synth Chord",
},
["BigWigs_Bosses_Plaguefall Trash"] = {
[330403] = "Banana Peel Slip",
[327233] = "Banana Peel Slip",
},
["BigWigs_Bosses_Raal the Gluttonous"] = {
[264923] = "Banana Peel Slip",
},
["BigWigs_Bosses_Yalnu"] = {
[169929] = "Brass",
[169179] = "Banana Peel Slip",
},
["BigWigs_Bosses_Blightbone"] = {
[320596] = "Banana Peel Slip",
},
["BigWigs_Bosses_Halls of Infusion Trash"] = {
[375348] = "Banana Peel Slip",
[374741] = "Bam",
[393432] = "Banana Peel Slip",
[375384] = "Bam",
[390290] = "Bam",
[395694] = "Brass",
[374563] = "Banana Peel Slip",
[374073] = "Bam",
[375351] = "Banana Peel Slip",
[375327] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Rookery Trash"] = {
[474018] = "Banana Peel Slip",
[426893] = "Banana Peel Slip",
},
["BigWigs_Bosses_Master Machinists"] = {
[449167] = "Banana Peel Slip",
},
["BigWigs_Bosses_Waycrest Manor Trash"] = {
[265372] = "Banana Peel Slip",
[271174] = "Banana Peel Slip",
},
["BigWigs_Bosses_Thrall"] = {
[306828] = "Banana Peel Slip",
},
["BigWigs_Bosses_Morchie"] = {
[404916] = "Banana Peel Slip",
[404364] = "Banana Peel Slip",
},
["BigWigs_Bosses_Chrono-Lord Deios"] = {
[375727] = "Banana Peel Slip",
},
["BigWigs_Bosses_Manifested Timeways"] = {
[414303] = "Banana Peel Slip",
},
["BigWigs_Bosses_Hylbrande"] = {
[347094] = "Banana Peel Slip",
},
["BigWigs_Bosses_Siege of Boralus Trash"] = {
[257288] = "Banana Peel Slip",
[454437] = "BigWigs: Info",
[268260] = "Banana Peel Slip",
[272546] = "Bam",
[256627] = "Banana Peel Slip",
},
["BigWigs_Bosses_Dimensius, the All-Devouring"] = {
[1238765] = "Awww Crap",
},
},
["Alert"] = {
["BigWigs_Bosses_Avanoxx"] = {
[438471] = "Huh?",
},
["BigWigs_Bosses_Rocketspark and Borka"] = {
[162617] = "Bam",
},
["BigWigs_Bosses_Tyr, the Infinite Keeper"] = {
[400641] = "|cFFFF0000Stack|r",
},
["BigWigs_Bosses_Shade of Xavius"] = {
[200238] = "Brass",
},
["BigWigs_Bosses_Black Rook Hold Trash"] = {
[200248] = "BigWigs: Info",
[203163] = "|cFFFF0000Fixate|r",
[200291] = "Brass",
},
["BigWigs_Bosses_The Vortex Pinnacle Trash"] = {
[88170] = "Brass",
},
["BigWigs_Bosses_Treemouth"] = {
[376811] = "BigWigs: Alarm",
},
["BigWigs_Bosses_Heartsbane Triad"] = {
[260741] = "Synth Chord",
},
["BigWigs_Bosses_Captain Dailcry"] = {
[424414] = "Bite",
},
["BigWigs_Bosses_Dawn of the Infinite Trash"] = {
[413607] = "Brass",
[411994] = "Brass",
[412215] = "Banana Peel Slip",
[415437] = "Brass",
[411300] = "Brass",
},
["BigWigs_Bosses_Sanguine Depths Trash"] = {
[334329] = "Banana Peel Slip",
},
["BigWigs_Bosses_Raszageth the Storm-Eater"] = {
[385065] = "Awww Crap",
},
["BigWigs_Bosses_Darkheart Thicket Trash"] = {
[225562] = "Brass",
[201399] = "Brass",
[200630] = "Brass",
},
["BigWigs_Bosses_Uldaman: Legacy of Tyr Trash"] = {
[369675] = "Brass",
},
["BigWigs_Bosses_Gutshot"] = {
[384416] = "BigWigs: Alert",
},
["BigWigs_Bosses_Ruby Life Pools Trash"] = {
[392640] = "Synth Chord",
[372743] = "|cFFFF0000Stop|r",
[385536] = "|cFFFF0000Stop|r",
[372735] = "Brass",
[392451] = "Brass",
},
["BigWigs_Bosses_The Nokhud Offensive Trash"] = {
[387411] = "Brass",
[383823] = "|cFFFF0000Stop|r",
[436841] = "|cFFFF0000Stop|r",
[384365] = "Brass",
[387125] = "Brass",
[387127] = "|cFFFF0000Spread|r",
[373395] = "Brass",
[372147] = "Bam",
},
["BigWigs_Bosses_Sylvanas Windrunner"] = {
[354068] = "|cFFFF0000Dispell|r",
},
["BigWigs_Bosses_Leymor"] = {
[374789] = "BigWigs: Alarm",
},
["BigWigs_Bosses_Hylbrande"] = {
[358131] = "Brass",
[346116] = "Huh?",
},
["BigWigs_Bosses_Sennarth, The Cold Breath"] = {
[374112] = "Banana Peel Slip",
},
["BigWigs_Bosses_Erudax"] = {
[450100] = "Huh?",
},
["BigWigs_Bosses_Surgeon Stitchflesh"] = {
[334488] = "Huh?",
[320376] = "Huh?",
},
["BigWigs_Bosses_Operation: Floodgate Trash"] = {
[471733] = "Brass",
},
["BigWigs_Bosses_Dathea, Ascended"] = {
[388410] = "Banana Peel Slip",
[375580] = "|cFFFF0000Gather|r",
},
["BigWigs_Bosses_Dimensius, the All-Devouring"] = {
[1237694] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Coaglamation"] = {
[461842] = "Huh?",
},
["BigWigs_Bosses_Mists of Tirna Scithe Trash"] = {
[340300] = "Banana Peel Slip",
[340289] = "Huh?",
[322938] = "Brass",
[463248] = "Banana Peel Slip",
[322557] = "Huh?",
[325021] = "Synth Chord",
[340544] = "BigWigs: Info",
[331718] = "Banana Peel Slip",
},
["BigWigs_Bosses_Nymue, Weaver of the Cycle"] = {
[429108] = "Banana Peel Slip",
},
["BigWigs_Bosses_Hackclaw's War-Band"] = {
[381470] = "|cFFFF0000Switch|r",
[381444] = "Banana Peel Slip",
},
["BigWigs_Bosses_Amalgam of Souls"] = {
[194956] = "Banana Peel Slip",
},
["BigWigs_Bosses_Ki'katal the Harvester"] = {
[432227] = "|cFFFF0000Spread|r",
},
["BigWigs_Bosses_Lord and Lady Waycrest"] = {
[268278] = "Brass",
},
["BigWigs_Bosses_Scalecommander Sarkareth"] = {
[402050] = "Banana Peel Slip",
[404456] = "Banana Peel Slip",
},
["BigWigs_Bosses_Grim Batol Trash"] = {
[76711] = "Brass",
[451241] = "Huh?",
[451971] = "Huh?",
[451871] = "Brass",
},
["BigWigs_Bosses_The Lost Dwarves"] = {
[369563] = "Banana Peel Slip",
},
["BigWigs_Bosses_Illysanna Ravencrest"] = {
[197797] = "Brass",
[197546] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Echelon"] = {
[326389] = "Bam",
},
["BigWigs_Bosses_Neltharions Lair Trash"] = {
[202181] = "BigWigs: Raid Warning",
[193505] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Necrotic Wake Trash"] = {
[328667] = "Brass",
[324394] = "Huh?",
[320464] = "|cFFFF0000Move|r",
[334748] = "BigWigs: Info",
[338353] = "Brass",
},
["BigWigs_Bosses_Terros"] = {
[376279] = "Banana Peel Slip",
},
["BigWigs_Bosses_Atal'Dazar Trash"] = {
[253517] = "Brass",
[255567] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Stonevault Trash"] = {
[449154] = "Synth Chord",
[445207] = "Brass",
},
["BigWigs_Bosses_Underrot Trash"] = {
[266209] = "Brass",
[265091] = "BigWigs: Info",
[265487] = "Brass",
},
["BigWigs_Bosses_Neltharus Trash"] = {
[372223] = "Brass",
[372561] = "Bam",
[378282] = "Brass",
[378818] = "|cFFFF0000Stop|r",
[372225] = "|cFFFF0000Stop|r",
},
["BigWigs_Bosses_Tazavesh Trash"] = {
[355642] = "Brass",
[355934] = "Brass",
[355057] = "Brass",
},
["BigWigs_Bosses_Siege of Boralus Trash"] = {
[256957] = "Brass",
[257288] = "Banana Peel Slip",
[257732] = "|cFFFF0000AoE|r",
},
["BigWigs_Bosses_Algeth'ar Academy Trash"] = {
[396812] = "Brass",
},
["BigWigs_Bosses_Sporecaller Zancha"] = {
[272457] = "Banana Peel Slip",
},
["BigWigs_Bosses_Theater Of Pain Trash"] = {
[341949] = "BigWigs: Info",
[342675] = "Brass",
},
["BigWigs_Bosses_The Dawnbreaker Trash"] = {
[431491] = "Huh?",
[432520] = "BigWigs: Long",
[431304] = "Brass",
[431364] = "BigWigs: Info",
},
["BigWigs_Bosses_Orator Krix'vizk"] = {
[434722] = "Huh?",
},
["BigWigs_Bosses_Cinderbrew Meadery Trash"] = {
[463206] = "Bam",
[440687] = "Brass",
},
["BigWigs_Bosses_Ara-Kara, City of Echoes Trash"] = {
[433841] = "Brass",
[448248] = "Brass",
[434793] = "Brass",
},
["BigWigs_Bosses_Eco-Dome Al'dani Trash"] = {
[1229510] = "Brass",
},
["BigWigs_Bosses_E.D.N.A."] = {
[424888] = "Huh?",
},
["BigWigs_Bosses_Master Machinists"] = {
[428711] = "Huh?",
[430097] = "Brass",
},
["BigWigs_Bosses_The Everbloom Trash"] = {
[164887] = "Brass",
[427223] = "|cFFFF0000AoE|r",
},
["BigWigs_Bosses_Hadal Darkfathom"] = {
[261563] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Silken Court"] = {
[440504] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mogul Razdunk"] = {
[260280] = "Banana Peel Slip",
},
["BigWigs_Bosses_Blightbone"] = {
[320655] = "Huh?",
},
["BigWigs_Bosses_Sentinel Talondras"] = {
[372718] = "|cFFFF0000Selfcd|r",
},
["BigWigs_Bosses_Skarmorak"] = {
[422233] = "Huh?",
},
["BigWigs_Bosses_De Other Side Trash"] = {
[334051] = "Banana Peel Slip",
},
["BigWigs_Bosses_Chopper Redhook"] = {
[257348] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Bromach"] = {
[369675] = "Brass",
},
["BigWigs_Bosses_Mindbender Ghur'sha"] = {
[429048] = "Synth Chord",
},
["BigWigs_Bosses_Cragmaw the Infested"] = {
[260292] = "Banana Peel Slip",
},
["BigWigs_Bosses_Mordretha, the Endless Empress"] = {
[324079] = "Bite",
},
["BigWigs_Bosses_Darkflame Cleft Trash"] = {
[424322] = "Brass",
},
["BigWigs_Bosses_Brackenhide Hollow Trash"] = {
[382435] = "|cFFFF0000Switch|r",
[374057] = "|cFFFF0000Switch|r",
[385029] = "Brass",
[367484] = "|cFFFF0000Targeted|r",
},
["BigWigs_Bosses_Yazma"] = {
[250096] = "Brass",
},
["BigWigs_Bosses_Priestess Alun'za"] = {
[255579] = "|cFFFF0000Dispell|r",
},
["BigWigs_Bosses_Kurtalos Ravencrest"] = {
[198641] = "|cFFFF0000Dodge|r",
},
["BigWigs_Bosses_Harlan Sweete"] = {
[257278] = "Banana Peel Slip",
},
["BigWigs_Bosses_Primal Tsunami"] = {
[388882] = "Brass",
[389875] = "Awww Crap",
},
["BigWigs_Bosses_Trixie & Naeno"] = {
[298940] = "Banana Peel Slip",
[298651] = "Air Horn",
},
["BigWigs_Bosses_Throne of the Tides Trash"] = {
[426645] = "Banana Peel Slip",
[76813] = "Brass",
},
["BigWigs_Bosses_Taah'bat and A'wazj"] = {
[1219482] = "Huh?",
},
["BigWigs_Bosses_Big M.O.M.M.A."] = {
[473351] = "Bite",
},
["BigWigs_Bosses_Freehold Trash"] = {
[257397] = "Brass",
},
["BigWigs_Bosses_Sergeant Bainbridge"] = {
[279761] = "Banana Peel Slip",
},
["BigWigs_Bosses_Raal the Gluttonous"] = {
[264694] = "Banana Peel Slip",
},
["BigWigs_Bosses_Skycap'n Kragg"] = {
[255952] = "Banana Peel Slip",
},
["BigWigs_Bosses_Council o' Captains"] = {
[258338] = "BigWigs: Alert",
},
["BigWigs_Bosses_Halls of Infusion Trash"] = {
[395694] = "Brass",
[374339] = "|cFFFF0000Stop|r",
[437719] = "|cFFFF0000Stop|r",
[377402] = "Brass",
[377341] = "|cFFFF0000Stop|r",
[374724] = "Synth Chord",
[376171] = "Brass",
},
["BigWigs_Bosses_Ring of Booty"] = {
[257904] = "Banana Peel Slip",
},
["BigWigs_Bosses_The Azure Vault Trash"] = {
[377488] = "Brass",
},
["BigWigs_Bosses_Myza's Oasis"] = {
[350919] = "Banana Peel Slip",
},
["BigWigs_Bosses_Waycrest Manor Trash"] = {
[264520] = "Brass",
[264050] = "Brass",
[263943] = "|cFFFF0000Selfcd|r",
[278474] = "Brass",
},
["BigWigs_Bosses_Forgemaster Throngus"] = {
[449444] = "Huh?",
},
["BigWigs_Bosses_Halls of Atonement Trash"] = {
[325701] = "Brass",
[1235766] = "Huh?",
[325523] = "Banana Peel Slip",
[1237071] = "Huh?",
[326450] = "Brass",
},
["BigWigs_Bosses_City of Threads Trash"] = {
[443430] = "Brass",
},
["BigWigs_Bosses_Priory of the Sacred Flame Trash"] = {
[444743] = "Brass",
},
["BigWigs_Bosses_The Curator"] = {
[227279] = "|cFFFF0000Avoid|r",
},
["BigWigs_Bosses_General Umbriss"] = {
[447261] = "Huh?",
},
},
["underyou"] = {
["BigWigs_Bosses_Grimrail Depot Trash"] = {
[176032] = "|cFFFF0000Out|r",
},
["BigWigs_Bosses_Dawn of the Infinite Trash"] = {
[417002] = "Bam",
},
},
},
},
},
["BigWigs_Bosses_Darkheart Thicket Trash"] = {
["profiles"] = {
["All classes"] = {
[200580] = 3129591,
},
},
},
["BigWigs_Bosses_Galvazzt"] = {
["profiles"] = {
["All classes"] = {
[266923] = 966887,
},
},
},
["BigWigs_Bosses_Dazar, The First King"] = {
["profiles"] = {
["All classes"] = {
[268586] = 1036535,
[268403] = 966887,
[269231] = 966887,
[268932] = 966887,
[269369] = 1032439,
},
},
},
["BigWigs_Bosses_Anub'ikkaj"] = {
["profiles"] = {
["All classes"] = {
[426787] = 3129591,
},
},
},
["BigWigs_Bosses_Harlan Sweete"] = {
["profiles"] = {
["All classes"] = {
[257305] = 966903,
[257316] = 1032423,
[257278] = 966887,
},
},
},
["BigWigs_Bosses_Lady Naz'jar"] = {
["profiles"] = {
["All classes"] = {
[428374] = 3129591,
},
},
},
["BigWigs_Plugins_Countdown"] = {
["profiles"] = {
["All classes"] = {
["fontName"] = "ITCAvantGardeGothicDemi",
["bossCountdowns"] = {
["BigWigs_Bosses_Izo, the Grand Splicer"] = {
},
["BigWigs_Bosses_Nalthor the Rimebinder"] = {
},
},
},
},
},
["BigWigs_Bosses_The MOTHERLODE!! Trash"] = {
["profiles"] = {
["All classes"] = {
[263215] = 966903,
[1214754] = 966903,
[263628] = 966903,
[1213139] = 975095,
[262383] = 966903,
[268362] = 966903,
[262092] = 975095,
[269090] = 966903,
[473304] = 966903,
[1214751] = 967159,
[1215411] = 967927,
[472041] = 966903,
[269429] = 966903,
},
},
},
["BigWigs_Bosses_Sergeant Bainbridge"] = {
["profiles"] = {
["All classes"] = {
[260924] = 966887,
[277965] = 966887,
[257585] = 966887,
[261428] = 3129591,
[260954] = 966887,
["adds"] = 966887,
},
},
},
["BigWigs_Bosses_Raal the Gluttonous"] = {
["profiles"] = {
["All classes"] = {
[264694] = 966887,
[264923] = 966887,
[264931] = 966887,
},
},
},
["BigWigs_Bosses_Operation: Floodgate Trash"] = {
["profiles"] = {
["All classes"] = {
[474337] = 966903,
[465666] = 967927,
[465754] = 966903,
[468726] = 966903,
[463058] = 966903,
[471736] = 966903,
},
},
},
["BigWigs_Bosses_Blightbone"] = {
["profiles"] = {
["All classes"] = {
[320717] = 966903,
[320655] = 3130615,
},
},
},
["BigWigs_Bosses_Halls of Infusion Trash"] = {
["profiles"] = {
["All classes"] = {
[374724] = 3129591,
},
},
},
["BigWigs_Bosses_The Rookery Trash"] = {
["profiles"] = {
["All classes"] = {
[474018] = 966903,
[1214546] = 1032439,
[427616] = 966903,
[427260] = 966903,
[426893] = 966903,
[430812] = 966903,
[430805] = 966903,
[430179] = 966903,
[450628] = 966903,
[472764] = 966903,
},
},
},
["BigWigs_Bosses_Master Machinists"] = {
["profiles"] = {
["All classes"] = {
[428508] = 3129591,
[428202] = 3129591,
},
},
},
["BigWigs_Bosses_Moroes"] = {
["profiles"] = {
["All classes"] = {
[227672] = 3129591,
},
},
},
["BigWigs_Bosses_Hackclaw's War-Band"] = {
["profiles"] = {
["All classes"] = {
[378029] = 3129591,
},
},
},
["BigWigs_Bosses_Drahga Shadowburner"] = {
["profiles"] = {
["All classes"] = {
[448105] = 3129591,
[82850] = 2015479,
[456751] = 3129591,
},
},
},
["BigWigs_Bosses_Illysanna Ravencrest"] = {
["profiles"] = {
["All classes"] = {
[197696] = 3064311,
},
},
},
["BigWigs_Bosses_Manifested Timeways"] = {
["profiles"] = {
["All classes"] = {
[405696] = 3129591,
},
},
},
["BigWigs_Bosses_Opera Hall: Beautiful Beast"] = {
["profiles"] = {
["All classes"] = {
[227985] = 3133687,
[228025] = 3129591,
},
},
},
["BigWigs_Bosses_Siege of Boralus Trash"] = {
["profiles"] = {
["All classes"] = {
[272571] = 966903,
[272711] = 966903,
[275835] = 967927,
[256640] = 966903,
[257288] = 966903,
[256709] = 967927,
[454437] = 966903,
[454440] = 966903,
[272421] = 966903,
[257270] = 966903,
[257169] = 966903,
[268260] = 966903,
[272546] = 966903,
[256616] = 967927,
[256627] = 966903,
[272662] = 966903,
[257732] = 966903,
[275826] = 966903,
[257170] = 966903,
[256957] = 966903,
},
["Default"] = {
[256957] = 966903,
[257169] = 966903,
[272711] = 966903,
[275835] = 967927,
[272546] = 966903,
[454437] = 966903,
[257170] = 966903,
[272571] = 966903,
[275826] = 966903,
[257288] = 966903,
[272421] = 966903,
[256640] = 966903,
[256627] = 966903,
},
},
},
["BigWigs_Bosses_Lord Stormsong"] = {
["profiles"] = {
["All classes"] = {
[269097] = 966887,
[268347] = 966887,
},
},
},
},
["myKeystones"] = {
["Player-1615-0B536A51"] = {
["playerRating"] = 2858,
["specId"] = 102,
["keyMap"] = 499,
["name"] = "Бимладен",
["keyLevel"] = 12,
["realm"] = "Ревущий фьорд",
},
["Player-1604-0AA7EF3A"] = {
["playerRating"] = 2593,
["specId"] = 256,
["keyMap"] = 542,
["name"] = "Мальдика",
["keyLevel"] = 10,
["realm"] = "Свежеватель Душ",
},
["Player-1604-0AA824D2"] = {
["playerRating"] = 2890,
["specId"] = 264,
["keyMap"] = 542,
["name"] = "Вольтчара",
["keyLevel"] = 10,
["realm"] = "Свежеватель Душ",
},
},
["prevWeeklyReset"] = 1755662400,
["profiles"] = {
["Default"] = {
},
["All classes"] = {
["flash"] = false,
},
},
}
BigWigsIconDB = {
["minimapPos"] = 180.65855778832,
["hide"] = true,
}
BigWigsStatsDB = {
[1448] = {
[1392] = {
["normal"] = {
["best"] = 100.891000000003,
["kills"] = 2,
},
["heroic"] = {
["best"] = 97.8799999999756,
["kills"] = 1,
},
["mythic"] = {
["best"] = 154.648000000016,
["kills"] = 1,
},
["LFR"] = {
["best"] = 86.1020000000135,
["kills"] = 1,
},
},
[1396] = {
["heroic"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 203.635999999999,
},
["normal"] = {
["best"] = 129.293999999994,
["kills"] = 1,
},
["LFR"] = {
["best"] = 220.187999999995,
["kills"] = 1,
},
},
[1438] = {
["heroic"] = {
["kills"] = 2,
["wipes"] = 2,
["best"] = 153.059999999998,
},
["normal"] = {
["best"] = 204.516000000003,
["kills"] = 1,
},
},
[1427] = {
["heroic"] = {
["best"] = 161,
["kills"] = 1,
},
},
[1426] = {
["normal"] = {
["best"] = 291.672000000021,
["kills"] = 2,
},
["heroic"] = {
["best"] = 322.089000000007,
["kills"] = 1,
},
["mythic"] = {
["best"] = 413.542999999976,
["kills"] = 1,
},
["LFR"] = {
},
},
[1394] = {
["heroic"] = {
["best"] = 158.255000000005,
["kills"] = 1,
},
["LFR"] = {
["best"] = 226.624000000011,
["kills"] = 1,
},
},
[1425] = {
["normal"] = {
["kills"] = 2,
["best"] = 112.263999999996,
["wipes"] = 1,
},
["mythic"] = {
["best"] = 138.600000000006,
["kills"] = 1,
},
["LFR"] = {
["best"] = 211.96100000001,
["kills"] = 1,
},
},
[1372] = {
["heroic"] = {
["best"] = 160.02900000001,
["kills"] = 1,
},
["mythic"] = {
["wipes"] = 3,
},
["normal"] = {
["best"] = 287.395000000019,
["kills"] = 1,
},
["LFR"] = {
["best"] = 219.608999999997,
["kills"] = 1,
},
},
[1391] = {
["heroic"] = {
["best"] = 97.1119999999937,
["kills"] = 1,
},
["normal"] = {
["best"] = 94.1879999999656,
["kills"] = 1,
},
["LFR"] = {
["best"] = 134.687000000005,
["kills"] = 1,
},
},
[1395] = {
["heroic"] = {
["kills"] = 2,
["wipes"] = 2,
["best"] = 235.795000000013,
},
["normal"] = {
["best"] = 237.217999999994,
["kills"] = 1,
},
["LFR"] = {
["best"] = 381.84599999999,
["kills"] = 1,
},
},
[1447] = {
["heroic"] = {
["best"] = 138.327000000019,
["kills"] = 1,
},
["normal"] = {
["best"] = 140.625,
["kills"] = 1,
},
["LFR"] = {
["best"] = 213.141000000003,
["kills"] = 1,
},
},
[1433] = {
["heroic"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 214.978000000003,
},
["normal"] = {
["best"] = 233.02099999995,
["kills"] = 1,
},
},
[1432] = {
["mythic"] = {
["wipes"] = 13,
},
["heroic"] = {
["best"] = 128.249000000011,
["kills"] = 1,
},
["normal"] = {
["kills"] = 2,
["wipes"] = 1,
["best"] = 148.049999999988,
},
["LFR"] = {
["best"] = 224.717999999994,
["kills"] = 1,
},
},
},
[2096] = {
[2328] = {
["heroic"] = {
["kills"] = 4,
["wipes"] = 5,
["best"] = 262.6159999999945,
},
["mythic"] = {
["wipes"] = 93,
},
},
[2332] = {
["heroic"] = {
["kills"] = 4,
["wipes"] = 2,
["best"] = 248.176999999996,
},
},
},
[1205] = {
[1122] = {
["LFR"] = {
["best"] = 173.815000000002,
["kills"] = 1,
},
},
[959] = {
["LFR"] = {
["best"] = 134.155999999988,
["kills"] = 2,
},
},
[1123] = {
["LFR"] = {
["best"] = 90.7099999999628,
["kills"] = 1,
},
},
[1202] = {
["LFR"] = {
["best"] = 113.152000000002,
["kills"] = 1,
},
},
[1161] = {
["LFR"] = {
["best"] = 108.485000000015,
["kills"] = 1,
},
},
[1154] = {
["LFR"] = {
["best"] = 324.191000000021,
["kills"] = 1,
},
},
[1203] = {
["LFR"] = {
["best"] = 214.671999999991,
["kills"] = 1,
},
},
[1147] = {
["LFR"] = {
["best"] = 143.018000000011,
["kills"] = 1,
},
},
[1155] = {
["LFR"] = {
["best"] = 121.431999999972,
["kills"] = 1,
},
},
[1162] = {
["LFR"] = {
["best"] = 123.724999999977,
["kills"] = 1,
},
},
},
[2164] = {
[2361] = {
["heroic"] = {
["kills"] = 13,
["wipes"] = 62,
["best"] = 237.9800000000105,
},
["mythic"] = {
["wipes"] = 5,
},
["normal"] = {
["kills"] = 5,
["wipes"] = 2,
["best"] = 242.872000000003,
},
},
[2351] = {
["normal"] = {
["kills"] = 6,
["best"] = 158.439000000013,
["wipes"] = 2,
},
["heroic"] = {
["kills"] = 16,
["wipes"] = 9,
["best"] = 186.9260000000068,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 66,
["best"] = 430.0970000000671,
},
},
[2359] = {
["normal"] = {
["kills"] = 6,
["best"] = 207.429999999993,
["wipes"] = 3,
},
["heroic"] = {
["kills"] = 29,
["wipes"] = 25,
["best"] = 197.1320000000123,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 96,
["best"] = 306.3050000000512,
},
},
[2353] = {
["normal"] = {
["best"] = 131.923000000068,
["kills"] = 8,
},
["mythic"] = {
["kills"] = 18,
["wipes"] = 18,
["best"] = 137.6939999999595,
},
["heroic"] = {
["best"] = 152.1589999999997,
["kills"] = 19,
},
},
[2347] = {
["heroic"] = {
["kills"] = 16,
["best"] = 155.3479999999981,
["wipes"] = 2,
},
["normal"] = {
["best"] = 124.8830000000016,
["kills"] = 7,
},
["mythic"] = {
["kills"] = 17,
["wipes"] = 34,
["best"] = 151.9830000000075,
},
},
[2354] = {
["heroic"] = {
["kills"] = 19,
["best"] = 106.7390000000014,
["wipes"] = 13,
},
["normal"] = {
["best"] = 84.19599999999627,
["kills"] = 5,
},
["mythic"] = {
["kills"] = 9,
["wipes"] = 191,
["best"] = 145.5899999999674,
},
},
[2349] = {
["normal"] = {
["kills"] = 4,
["best"] = 146.926999999996,
["wipes"] = 1,
},
["heroic"] = {
["kills"] = 14,
["wipes"] = 25,
["best"] = 160.5080000000016,
},
["mythic"] = {
["kills"] = 1,
["wipes"] = 182,
["best"] = 463.6860000000452,
},
},
[2352] = {
["normal"] = {
["best"] = 99.6030000000028,
["kills"] = 9,
},
["mythic"] = {
["kills"] = 20,
["wipes"] = 26,
["best"] = 116.5050000000047,
},
["heroic"] = {
["kills"] = 18,
["best"] = 130.0119999999879,
["wipes"] = 3,
},
},
},
[2569] = {
[2529] = {
["heroic"] = {
["kills"] = 16,
["wipes"] = 3,
["best"] = 126.4899999999907,
},
["mythic"] = {
["kills"] = 20,
["wipes"] = 31,
["best"] = 207.685999999987,
},
["normal"] = {
["kills"] = 11,
["best"] = 133.6209999999846,
["wipes"] = 1,
},
["LFR"] = {
["best"] = 136.2880000000005,
["kills"] = 4,
},
},
[2522] = {
["heroic"] = {
["kills"] = 16,
["best"] = 111.0939999999828,
["wipes"] = 2,
},
["normal"] = {
["best"] = 108.1470000000263,
["kills"] = 17,
},
["mythic"] = {
["kills"] = 23,
["wipes"] = 27,
["best"] = 173.9480000000003,
},
["LFR"] = {
["best"] = 115.6160000000382,
["kills"] = 4,
},
},
[2530] = {
["heroic"] = {
["kills"] = 18,
["best"] = 146.2060000000056,
["wipes"] = 2,
},
["normal"] = {
["best"] = 166.8439999999828,
["kills"] = 13,
},
["mythic"] = {
["kills"] = 9,
["wipes"] = 34,
["best"] = 230.2469999999739,
},
["LFR"] = {
["best"] = 158.2390000000014,
["kills"] = 4,
},
},
[2523] = {
["heroic"] = {
["kills"] = 25,
["wipes"] = 28,
["best"] = 228.4990000000107,
},
["mythic"] = {
["kills"] = 1,
["wipes"] = 4,
["best"] = 376.7299999999814,
},
["normal"] = {
["kills"] = 22,
["wipes"] = 12,
["best"] = 181.8040000000037,
},
["LFR"] = {
["kills"] = 10,
["best"] = 229.6209999999846,
["wipes"] = 1,
},
},
[2524] = {
["heroic"] = {
["kills"] = 13,
["wipes"] = 1,
["best"] = 36.14399999997113,
},
["normal"] = {
["kills"] = 6,
["wipes"] = 9,
["best"] = 101.24099999998,
},
["mythic"] = {
["kills"] = 22,
["wipes"] = 10,
["best"] = 123.4769999999553,
},
["LFR"] = {
["best"] = 118.2089999999735,
["kills"] = 2,
},
},
[2532] = {
["heroic"] = {
["kills"] = 19,
["wipes"] = 11,
["best"] = 125.7110000000102,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 5,
["best"] = 294.3290000001434,
},
["normal"] = {
["kills"] = 8,
["wipes"] = 1,
["best"] = 136.3930000001565,
},
["LFR"] = {
["best"] = 141.9510000000009,
["kills"] = 2,
},
},
[2525] = {
["heroic"] = {
["kills"] = 19,
["wipes"] = 24,
["best"] = 148.929999999993,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 42,
["best"] = 357.2929999998305,
},
["normal"] = {
["kills"] = 9,
["wipes"] = 5,
["best"] = 184.5580000001937,
},
["LFR"] = {
["best"] = 189.2360000000335,
["kills"] = 2,
},
},
[2527] = {
["heroic"] = {
["kills"] = 20,
["best"] = 133.9749999999767,
["wipes"] = 3,
},
["mythic"] = {
["best"] = 304.9150000000373,
["kills"] = 2,
},
["normal"] = {
["kills"] = 10,
["best"] = 146.1949999998324,
["wipes"] = 1,
},
["LFR"] = {
["best"] = 164.7619999999879,
["kills"] = 9,
},
},
[2520] = {
["heroic"] = {
["kills"] = 16,
["wipes"] = 22,
["best"] = 264.7039999999106,
},
["mythic"] = {
},
["normal"] = {
["kills"] = 17,
["wipes"] = 6,
["best"] = 249.4189999999944,
},
["LFR"] = {
["kills"] = 9,
["best"] = 279.0569999999716,
["wipes"] = 1,
},
},
},
[1520] = {
[1667] = {
["heroic"] = {
["best"] = 171.875,
["kills"] = 1,
},
["normal"] = {
["kills"] = 3,
["wipes"] = 2,
["best"] = 32.9500000001863,
},
["LFR"] = {
["best"] = 137.139000000003,
["kills"] = 1,
},
},
[1703] = {
["normal"] = {
["kills"] = 3,
["wipes"] = 1,
["best"] = 47.5460000000894,
},
["mythic"] = {
["kills"] = 1,
["wipes"] = 2,
["best"] = 359.255000000005,
},
["heroic"] = {
["best"] = 209.155999999995,
["kills"] = 1,
},
["LFR"] = {
["best"] = 173.812999999998,
["kills"] = 1,
},
},
[1738] = {
["normal"] = {
["kills"] = 3,
["wipes"] = 4,
["best"] = 140.776000000071,
},
["heroic"] = {
["best"] = 210.529000000002,
["kills"] = 1,
},
["LFR"] = {
["kills"] = 1,
["wipes"] = 2,
["best"] = 165.600999999999,
},
},
[1704] = {
["heroic"] = {
["best"] = 258.675999999999,
["kills"] = 1,
},
["normal"] = {
["best"] = 43.5519999999087,
["kills"] = 2,
},
["LFR"] = {
["best"] = 197.709999999999,
["kills"] = 1,
},
},
[1750] = {
["heroic"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 217.648999999998,
},
["normal"] = {
["best"] = 38.3079999999609,
["kills"] = 2,
},
["LFR"] = {
["best"] = 178.343999999997,
["kills"] = 1,
},
},
[1726] = {
["heroic"] = {
["best"] = 319.695,
["kills"] = 1,
},
["normal"] = {
["best"] = 70.5930000001099,
["kills"] = 2,
},
["LFR"] = {
["best"] = 44.3870000000025,
["kills"] = 1,
},
},
[1744] = {
["normal"] = {
["kills"] = 3,
["wipes"] = 5,
["best"] = 48.5030000000261,
},
["heroic"] = {
["kills"] = 1,
["wipes"] = 2,
["best"] = 234.671999999999,
},
["LFR"] = {
["best"] = 219.401999999998,
["kills"] = 1,
},
},
},
[1676] = {
[1861] = {
["LFR"] = {
["best"] = 183.168999999762,
["kills"] = 1,
},
},
[1873] = {
["LFR"] = {
["best"] = 208.244000000181,
["kills"] = 1,
},
},
[1862] = {
["mythic"] = {
["wipes"] = 1,
},
["LFR"] = {
["best"] = 108.011000000013,
["kills"] = 2,
},
},
[1896] = {
["LFR"] = {
["best"] = 187.164000000339,
["kills"] = 3,
},
},
[1897] = {
["LFR"] = {
["best"] = 260.77099999995,
["kills"] = 1,
},
},
[1856] = {
["LFR"] = {
["best"] = 107.567999999999,
["kills"] = 2,
},
},
[1903] = {
["LFR"] = {
["best"] = 202.540000000037,
["kills"] = 2,
},
},
[1898] = {
["LFR"] = {
["best"] = 370.040999999997,
["kills"] = 1,
},
},
[1867] = {
["LFR"] = {
["best"] = 235.433999999979,
["kills"] = 3,
},
},
},
[1648] = {
[1830] = {
["normal"] = {
["kills"] = 2,
["wipes"] = 3,
["best"] = 249.253000000026,
},
["mythic"] = {
["best"] = 39.528999999864,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 1,
["wipes"] = 2,
["best"] = 116.912999999942,
},
["LFR"] = {
["best"] = 41.7369999999937,
["kills"] = 1,
},
},
[1819] = {
["normal"] = {
["kills"] = 2,
["wipes"] = 2,
["best"] = 318.503000000026,
},
["heroic"] = {
["best"] = 156.150000000023,
["kills"] = 1,
},
["LFR"] = {
["best"] = 103.785000000004,
["kills"] = 1,
},
},
[1829] = {
["normal"] = {
["kills"] = 2,
["wipes"] = 23,
["best"] = 506.699999999983,
},
["mythic"] = {
["wipes"] = 1,
},
["heroic"] = {
["kills"] = 1,
["wipes"] = 2,
["best"] = 168.907000000007,
},
["LFR"] = {
["best"] = 99.6100000000006,
["kills"] = 1,
},
},
},
[2769] = {
[2644] = {
["heroic"] = {
["kills"] = 6,
["fkDate"] = "2025/05/27",
["bestDate"] = "2025/06/04",
["fkWipes"] = 2,
["best"] = 174.7669999999926,
["wipes"] = 9,
["fkDuration"] = 316.1100000000442,
},
["mythic"] = {
["kills"] = 1,
["fkDate"] = "2025/06/19",
["bestDate"] = "2025/06/19",
["fkWipes"] = 4,
["best"] = 354.0840000000317,
["wipes"] = 4,
["fkDuration"] = 354.0840000000317,
},
},
[2645] = {
["heroic"] = {
["kills"] = 10,
["fkDate"] = "2025/05/27",
["bestDate"] = "2025/06/18",
["fkWipes"] = 7,
["best"] = 181.0399999999791,
["wipes"] = 20,
["fkDuration"] = 236.1590000000142,
},
},
[2639] = {
["normal"] = {
["kills"] = 1,
["fkDate"] = "2025/05/24",
["bestDate"] = "2025/05/24",
["best"] = 196.6850000000013,
["fkDuration"] = 196.6850000000013,
},
["heroic"] = {
["kills"] = 1,
["fkDuration"] = 255.3580000000075,
["best"] = 255.3580000000075,
["bestDate"] = "2025/05/26",
["fkDate"] = "2025/05/26",
},
},
[2640] = {
["normal"] = {
["kills"] = 1,
["fkDate"] = "2025/05/24",
["bestDate"] = "2025/05/24",
["best"] = 187.1630000000005,
["fkDuration"] = 187.1630000000005,
},
["heroic"] = {
["wipes"] = 2,
},
},
[2641] = {
["normal"] = {
["kills"] = 1,
["fkDate"] = "2025/05/24",
["bestDate"] = "2025/05/24",
["fkWipes"] = 1,
["best"] = 227.1679999999979,
["wipes"] = 1,
["fkDuration"] = 227.1679999999979,
},
["heroic"] = {
["kills"] = 1,
["fkDate"] = "2025/05/26",
["bestDate"] = "2025/05/26",
["best"] = 312.2600000000093,
["fkDuration"] = 312.2600000000093,
},
},
[2642] = {
["normal"] = {
["kills"] = 1,
["fkDuration"] = 278.5689999999995,
["best"] = 278.5689999999995,
["bestDate"] = "2025/05/24",
["fkDate"] = "2025/05/24",
},
["heroic"] = {
["kills"] = 2,
["fkDuration"] = 375.7660000000033,
["best"] = 356.7150000000256,
["bestDate"] = "2025/05/26",
["fkDate"] = "2025/05/25",
},
},
[2646] = {
["heroic"] = {
["kills"] = 10,
["fkDate"] = "2025/05/27",
["bestDate"] = "2025/07/16",
["fkWipes"] = 2,
["best"] = 298.8470000000089,
["wipes"] = 23,
["fkDuration"] = 341.7799999999988,
},
["LFR"] = {
["kills"] = 2,
["fkDuration"] = 314.8360000000102,
["best"] = 314.8360000000102,
["bestDate"] = "2025/05/24",
["fkDate"] = "2025/05/24",
},
},
[2653] = {
["heroic"] = {
["kills"] = 1,
["fkDate"] = "2025/05/27",
["bestDate"] = "2025/05/27",
["fkWipes"] = 7,
["best"] = 258.0270000000019,
["wipes"] = 7,
["fkDuration"] = 258.0270000000019,
},
},
},
[1712] = {
[1992] = {
["mythic"] = {
["kills"] = 7,
["best"] = 248.244999999995,
["wipes"] = 2,
},
["normal"] = {
["best"] = 162.947999999975,
["kills"] = 6,
},
["heroic"] = {
["best"] = 183.793999999994,
["kills"] = 15,
},
["LFR"] = {
["best"] = 234.931000000041,
["kills"] = 4,
},
},
[1985] = {
["mythic"] = {
["kills"] = 6,
["wipes"] = 13,
["best"] = 392.033999999985,
},
["normal"] = {
["kills"] = 7,
["best"] = 280.891000000003,
["wipes"] = 1,
},
["heroic"] = {
["kills"] = 15,
["best"] = 255.381999999983,
["wipes"] = 4,
},
["LFR"] = {
["kills"] = 3,
["best"] = 300.799999999988,
["wipes"] = 2,
},
},
[2004] = {
["normal"] = {
["kills"] = 9,
["best"] = 303.515000000014,
["wipes"] = 2,
},
["mythic"] = {
["kills"] = 6,
["wipes"] = 72,
["best"] = 460.812999999995,
},
["heroic"] = {
["kills"] = 15,
["best"] = 48.890000000014,
["wipes"] = 8,
},
["LFR"] = {
["kills"] = 5,
["wipes"] = 1,
["best"] = 310.428000000073,
},
},
[1997] = {
["mythic"] = {
["best"] = 363.483000000007,
["kills"] = 7,
},
["heroic"] = {
["kills"] = 15,
["best"] = 256.148999999976,
["wipes"] = 12,
},
["normal"] = {
["best"] = 251.881999999998,
["kills"] = 8,
},
["LFR"] = {
["best"] = 288.954000000027,
["kills"] = 3,
},
},
[1986] = {
["normal"] = {
["kills"] = 7,
["wipes"] = 2,
["best"] = 339.653999999995,
},
["heroic"] = {
["kills"] = 9,
["best"] = 301.80700000003,
["wipes"] = 4,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 65,
["best"] = 489.824000000022,
},
["LFR"] = {
["kills"] = 4,
["wipes"] = 1,
["best"] = 304.409000000043,
},
},
[2009] = {
["mythic"] = {
["kills"] = 7,
["wipes"] = 56,
["best"] = 420.185999999987,
},
["normal"] = {
["best"] = 232.385999999999,
["kills"] = 8,
},
["heroic"] = {
["kills"] = 15,
["best"] = 207.418999999994,
["wipes"] = 5,
},
["LFR"] = {
["kills"] = 3,
["best"] = 293.236000000004,
["wipes"] = 2,
},
},
[1983] = {
["normal"] = {
["kills"] = 7,
["best"] = 194.684999999998,
["wipes"] = 4,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 222,
["best"] = 256.275000000023,
},
["heroic"] = {
["kills"] = 11,
["best"] = 183.339000000036,
["wipes"] = 4,
},
["LFR"] = {
["best"] = 203.590000000026,
["kills"] = 5,
},
},
[1987] = {
["mythic"] = {
["kills"] = 7,
["best"] = 241.520999999979,
["wipes"] = 2,
},
["normal"] = {
["kills"] = 7,
["best"] = 141.379000000001,
["wipes"] = 1,
},
["heroic"] = {
["kills"] = 15,
["best"] = 190.20700000017,
["wipes"] = 5,
},
["LFR"] = {
["kills"] = 4,
["wipes"] = 2,
["best"] = 197.911000000022,
},
},
[2025] = {
["mythic"] = {
["kills"] = 7,
["wipes"] = 7,
["best"] = 497.104999999981,
},
["normal"] = {
["best"] = 278.688000000082,
["kills"] = 8,
},
["heroic"] = {
["kills"] = 14,
["best"] = 342.634000000078,
["wipes"] = 1,
},
["LFR"] = {
["best"] = 261.989000000001,
["kills"] = 3,
},
},
[1984] = {
["normal"] = {
["kills"] = 8,
["best"] = 258.486999999965,
["wipes"] = 1,
},
["mythic"] = {
["wipes"] = 33,
},
["heroic"] = {
["kills"] = 10,
["wipes"] = 24,
["best"] = 329.026000000071,
},
["LFR"] = {
["best"] = 244.489000000001,
["kills"] = 2,
},
},
[2031] = {
["normal"] = {
["kills"] = 11,
["best"] = 420.937999999966,
["wipes"] = 1,
},
["heroic"] = {
["kills"] = 28,
["best"] = 413.222999999998,
["wipes"] = 22,
},
["LFR"] = {
["kills"] = 2,
["wipes"] = 1,
["best"] = 519.673999999999,
},
},
},
[2217] = {
[2364] = {
["normal"] = {
["best"] = 227.5709999999963,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 12,
["wipes"] = 5,
["best"] = 180.2519999999786,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 89,
["best"] = 277.127000000095,
},
},
[2372] = {
["normal"] = {
["best"] = 177.625,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 11,
["best"] = 163.5030000000261,
["wipes"] = 1,
},
["mythic"] = {
["kills"] = 9,
["wipes"] = 73,
["best"] = 288.4379999998491,
},
},
[2365] = {
["normal"] = {
["best"] = 166.890000000014,
["kills"] = 1,
},
["mythic"] = {
["kills"] = 11,
["wipes"] = 55,
["best"] = 224.4920000000857,
},
["heroic"] = {
["kills"] = 7,
["wipes"] = 3,
["best"] = 175.1749999999302,
},
},
[2373] = {
["normal"] = {
["best"] = 264.0010000000475,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 6,
["best"] = 239.280999999959,
["wipes"] = 1,
},
["mythic"] = {
["kills"] = 3,
["wipes"] = 59,
["best"] = 454.9079999999376,
},
},
[2366] = {
["heroic"] = {
["kills"] = 9,
["wipes"] = 4,
["best"] = 372.8780000000261,
},
["normal"] = {
["best"] = 503.2950000000419,
["kills"] = 1,
},
["LFR"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 614.9169999998994,
},
},
[2374] = {
["normal"] = {
["best"] = 293.0070000000997,
["kills"] = 1,
},
["mythic"] = {
["kills"] = 1,
["wipes"] = 23,
["best"] = 576.8240000000224,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 10,
["best"] = 259.0870000000577,
},
},
[2367] = {
["normal"] = {
["best"] = 155.0299999999115,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 2,
["best"] = 157.4070000000065,
},
["mythic"] = {
["kills"] = 7,
["wipes"] = 62,
["best"] = 252.435999999987,
},
},
[2375] = {
["normal"] = {
["kills"] = 1,
["wipes"] = 9,
["best"] = 494.3249999999534,
},
["heroic"] = {
["kills"] = 12,
["wipes"] = 20,
["best"] = 486.560999999987,
},
["LFR"] = {
["wipes"] = 4,
},
},
[2368] = {
["normal"] = {
["best"] = 223.8399999999674,
["kills"] = 1,
},
["heroic"] = {
["best"] = 124.6689999999944,
["kills"] = 8,
},
["mythic"] = {
["kills"] = 12,
["wipes"] = 20,
["best"] = 261.685999999987,
},
},
[2369] = {
["normal"] = {
["best"] = 251.5250000000233,
["kills"] = 1,
},
["heroic"] = {
["best"] = 167.4189999999944,
["kills"] = 7,
},
["mythic"] = {
["kills"] = 9,
["wipes"] = 10,
["best"] = 167.2949999999255,
},
},
[2377] = {
["normal"] = {
["best"] = 243.4790000000503,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 13,
["best"] = 202.5270000000019,
},
["mythic"] = {
["kills"] = 6,
["wipes"] = 118,
["best"] = 302.1370000001043,
},
},
[2370] = {
["normal"] = {
["best"] = 220.2590000000782,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 9,
["best"] = 217.4930000000168,
},
["mythic"] = {
["kills"] = 5,
["wipes"] = 52,
["best"] = 388.0610000000015,
},
},
},
[1530] = {
[1737] = {
["mythic"] = {
["kills"] = 1,
["wipes"] = 5,
["best"] = 333.652000000002,
},
["LFR"] = {
["best"] = 274.09599999999,
["kills"] = 1,
},
},
[1731] = {
["LFR"] = {
["best"] = 109.491999999998,
["kills"] = 1,
},
},
[1706] = {
["LFR"] = {
["best"] = 91.7300000000105,
["kills"] = 1,
},
},
[1725] = {
["LFR"] = {
["best"] = 81.3499999999913,
["kills"] = 1,
},
},
},
[2657] = {
[2609] = {
["heroic"] = {
["kills"] = 13,
["fkDate"] = "2024/09/14",
["bestDate"] = "2024/12/18",
["fkWipes"] = 4,
["best"] = 178.0739999999933,
["wipes"] = 7,
["fkDuration"] = 472.4569999999949,
},
["mythic"] = {
["kills"] = 26,
["fkDuration"] = 331.2269999999553,
["wipes"] = 88,
["fkWipes"] = 36,
["best"] = 235.0419999998994,
["bestDate"] = "2025/01/08",
["fkDate"] = "2024/10/27",
},
["normal"] = {
["kills"] = 6,
["fkDate"] = "2024/09/11",
["wipes"] = 1,
["bestDate"] = "2024/09/19",
["best"] = 172.4479999999749,
["fkDuration"] = 234.9790000000212,
},
["LFR"] = {
["kills"] = 7,
["fkDuration"] = 235.9650000000256,
["best"] = 187.1399999999994,
["bestDate"] = "2024/09/25",
["fkDate"] = "2024/09/18",
},
},
[2601] = {
["heroic"] = {
["kills"] = 22,
["fkDuration"] = 346.6809999999823,
["wipes"] = 79,
["fkWipes"] = 27,
["best"] = 192.3009999999777,
["bestDate"] = "2024/11/20",
["fkDate"] = "2024/09/15",
},
["normal"] = {
["kills"] = 12,
["fkDate"] = "2024/09/12",
["bestDate"] = "2024/10/30",
["fkWipes"] = 1,
["best"] = 136.7539999999572,
["wipes"] = 2,
["fkDuration"] = 243.25,
},
["LFR"] = {
["kills"] = 7,
["fkDuration"] = 204.4270000000252,
["best"] = 160.2550000000047,
["bestDate"] = "2024/09/25",
["fkDate"] = "2024/09/18",
},
},
[2611] = {
["normal"] = {
["kills"] = 6,
["fkDate"] = "2024/09/11",
["bestDate"] = "2024/09/19",
["fkWipes"] = 1,
["best"] = 185.7090000000317,
["wipes"] = 5,
["fkDuration"] = 223.6790000000037,
},
["mythic"] = {
["kills"] = 31,
["fkDate"] = "2024/10/09",
["bestDate"] = "2025/01/08",
["fkWipes"] = 14,
["best"] = 164.6320000002161,
["wipes"] = 41,
["fkDuration"] = 294.5780000000013,
},
["heroic"] = {
["kills"] = 19,
["fkDate"] = "2024/09/14",
["bestDate"] = "2024/12/18",
["fkWipes"] = 12,
["best"] = 163.6649999999936,
["wipes"] = 30,
["fkDuration"] = 428.5200000000186,
},
["LFR"] = {
["kills"] = 6,
["fkDuration"] = 251.9910000000091,
["wipes"] = 1,
["best"] = 188.4970000000321,
["bestDate"] = "2024/09/18",
["fkDate"] = "2024/09/11",
},
},
[2612] = {
["heroic"] = {
["kills"] = 11,
["fkDate"] = "2024/09/15",
["bestDate"] = "2024/12/18",
["fkWipes"] = 6,
["best"] = 267.0950000000012,
["wipes"] = 113,
["fkDuration"] = 499.6869999999763,
},
["mythic"] = {
},
["normal"] = {
["kills"] = 8,
["fkDate"] = "2024/09/12",
["bestDate"] = "2024/09/19",
["best"] = 201.5240000000922,
["wipes"] = 1,
["fkDuration"] = 276.4709999999905,
},
["LFR"] = {
["kills"] = 7,
["fkDuration"] = 295.0690000000177,
["best"] = 219.6860000000015,
["bestDate"] = "2024/09/25",
["wipes"] = 1,
["fkDate"] = "2024/09/18",
},
},
[2599] = {
["normal"] = {
["kills"] = 6,
["fkDate"] = "2024/09/11",
["bestDate"] = "2024/09/19",
["best"] = 154.8200000000652,
["fkDuration"] = 202.7889999999898,
},
["mythic"] = {
["kills"] = 29,
["fkDate"] = "2024/10/09",
["bestDate"] = "2025/01/08",
["fkWipes"] = 4,
["best"] = 210.7490000000689,
["wipes"] = 12,
["fkDuration"] = 381.1129999999976,
},
["heroic"] = {
["kills"] = 20,
["fkDate"] = "2024/09/14",
["bestDate"] = "2024/12/04",
["fkWipes"] = 3,
["best"] = 133.0180000000109,
["wipes"] = 7,
["fkDuration"] = 331.9060000000172,
},
["LFR"] = {
["kills"] = 6,
["fkDuration"] = 212.060999999987,
["best"] = 174.4780000000028,
["bestDate"] = "2024/09/19",
["fkDate"] = "2024/09/11",
},
},
[2607] = {
["normal"] = {
["kills"] = 7,
["fkDate"] = "2024/09/11",
["bestDate"] = "2024/09/19",
["best"] = 191.3610000000335,
["fkDuration"] = 255.6490000000049,
},
["mythic"] = {
["kills"] = 35,
["fkDate"] = "2024/09/29",
["bestDate"] = "2025/01/08",
["fkWipes"] = 12,
["best"] = 259.7779999999329,
["wipes"] = 42,
["fkDuration"] = 577.3139999999839,
},
["heroic"] = {
["kills"] = 18,
["fkDate"] = "2024/09/14",
["bestDate"] = "2024/12/18",
["fkWipes"] = 3,
["best"] = 173.4799999999959,
["wipes"] = 5,
["fkDuration"] = 591.0940000000119,
},
["LFR"] = {
["kills"] = 6,
["fkDuration"] = 217.0080000000016,
["best"] = 195.7390000000014,
["bestDate"] = "2024/09/18",
["fkDate"] = "2024/09/11",
},
},
[2608] = {
["heroic"] = {
["kills"] = 23,
["fkDate"] = "2024/09/20",
["bestDate"] = "2024/12/04",
["fkWipes"] = 29,
["best"] = 257.2829999999958,
["wipes"] = 53,
["fkDuration"] = 490.5250000000233,
},
["normal"] = {
["kills"] = 19,
["fkDuration"] = 383.2309999999998,
["wipes"] = 15,
["fkWipes"] = 6,
["best"] = 178,
["bestDate"] = "2024/12/11",
["fkDate"] = "2024/09/12",
},
["LFR"] = {
["kills"] = 12,
["fkDuration"] = 271.4619999999995,
["best"] = 158.3699999999953,
["bestDate"] = "2024/12/18",
["fkDate"] = "2024/09/25",
},
},
[2602] = {
["normal"] = {
["kills"] = 6,
["fkDate"] = "2024/09/12",
["bestDate"] = "2024/09/19",
["fkWipes"] = 7,
["best"] = 326.1650000000373,
["wipes"] = 31,
["fkDuration"] = 346.0499999999956,
},
["story"] = {
["kills"] = 1,
["fkDuration"] = 284.1569999998901,
["best"] = 284.1569999998901,
["bestDate"] = "2024/09/24",
["fkDate"] = "2024/09/24",
},
["heroic"] = {
["kills"] = 1,
["fkDuration"] = 535.2789999999804,
["wipes"] = 5,
["fkWipes"] = 5,
["best"] = 535.2789999999804,
["bestDate"] = "2024/10/26",
["fkDate"] = "2024/10/26",
},
["LFR"] = {
["kills"] = 3,
["fkDuration"] = 380.4709999999977,
["best"] = 358.6790000000037,
["bestDate"] = "2024/09/25",
["fkDate"] = "2024/09/25",
},
},
},
[2070] = {
[2341] = {
["heroic"] = {
["kills"] = 11,
["wipes"] = 17,
["best"] = 222.963999999978,
},
["normal"] = {
["kills"] = 12,
["best"] = 105.2449999999953,
["wipes"] = 1,
},
["mythic"] = {
["kills"] = 13,
["wipes"] = 13,
["best"] = 235.4719999999943,
},
},
[2334] = {
["normal"] = {
["best"] = 187.2989999999991,
["kills"] = 6,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 73,
["best"] = 353.319000000134,
},
["mythic"] = {
["kills"] = 9,
["wipes"] = 160,
["best"] = 339.0720000000001,
},
},
[2342] = {
["heroic"] = {
["kills"] = 7,
["wipes"] = 12,
["best"] = 361.804000000004,
},
["normal"] = {
["kills"] = 9,
["wipes"] = 4,
["best"] = 210.3260000000009,
},
["mythic"] = {
["kills"] = 11,
["wipes"] = 74,
["best"] = 387.6940000000031,
},
["LFR"] = {
["kills"] = 1,
["wipes"] = 2,
["best"] = 265.8999999999942,
},
},
[2335] = {
["normal"] = {
["kills"] = 7,
["best"] = 153.7060000000056,
["wipes"] = 3,
},
["mythic"] = {
["kills"] = 10,
["wipes"] = 47,
["best"] = 366.0529999999999,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 44,
["best"] = 338.049000000116,
},
},
[2343] = {
["heroic"] = {
["kills"] = 4,
["wipes"] = 29,
["best"] = 400.506999999998,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 309,
["best"] = 484.2599999999948,
},
["normal"] = {
["kills"] = 6,
["wipes"] = 6,
["best"] = 290.5329999999958,
},
},
[2337] = {
["normal"] = {
["kills"] = 7,
["wipes"] = 5,
["best"] = 143.5409999999683,
},
["mythic"] = {
["kills"] = 7,
["wipes"] = 74,
["best"] = 354.636999999988,
},
["heroic"] = {
["kills"] = 6,
["wipes"] = 39,
["best"] = 283.523000000001,
},
},
[2330] = {
["normal"] = {
["kills"] = 7,
["best"] = 114.3690000000061,
["wipes"] = 5,
},
["heroic"] = {
["kills"] = 10,
["wipes"] = 60,
["best"] = 241.406000000017,
},
["mythic"] = {
["kills"] = 12,
["wipes"] = 32,
["best"] = 236.4349999999977,
},
},
[2325] = {
["heroic"] = {
["kills"] = 16,
["wipes"] = 17,
["best"] = 185.26800000004,
},
["normal"] = {
["kills"] = 10,
["best"] = 58.03899999998976,
["wipes"] = 2,
},
["mythic"] = {
["kills"] = 13,
["wipes"] = 42,
["best"] = 183.7280000000028,
},
},
[2333] = {
["heroic"] = {
["kills"] = 21,
["best"] = 100.306000000011,
["wipes"] = 9,
},
["normal"] = {
["kills"] = 11,
["wipes"] = 6,
["best"] = 31.04899999999907,
},
["mythic"] = {
["kills"] = 32,
["wipes"] = 31,
["best"] = 76.49199999999837,
},
},
},
[2296] = {
[2394] = {
["heroic"] = {
["kills"] = 13,
["wipes"] = 16,
["best"] = 201.3000000000466,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 199,
["best"] = 338.7160000000149,
},
["normal"] = {
["kills"] = 2,
["wipes"] = 6,
["best"] = 216.7350000000006,
},
["LFR"] = {
["kills"] = 6,
["best"] = 141.0929999999989,
["wipes"] = 1,
},
},
[2425] = {
["normal"] = {
["kills"] = 3,
["wipes"] = 1,
["best"] = 266.7950000000128,
},
["mythic"] = {
["wipes"] = 25,
},
["heroic"] = {
["kills"] = 16,
["wipes"] = 20,
["best"] = 279.9619999999995,
},
["LFR"] = {
["best"] = 221.5799999999999,
["kills"] = 6,
},
},
[2418] = {
["heroic"] = {
["kills"] = 8,
["wipes"] = 7,
["best"] = 161.7849999999744,
},
["mythic"] = {
["kills"] = 6,
["wipes"] = 75,
["best"] = 319.0580000000191,
},
["normal"] = {
["kills"] = 2,
["wipes"] = 1,
["best"] = 297.0679999999993,
},
["LFR"] = {
["best"] = 210.3739999999998,
["kills"] = 7,
},
},
[2426] = {
["heroic"] = {
["kills"] = 8,
["wipes"] = 12,
["best"] = 332.6879999999655,
},
["normal"] = {
["kills"] = 1,
["wipes"] = 3,
["best"] = 452.2819999999992,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 98,
["best"] = 603.2430000000168,
},
["LFR"] = {
["kills"] = 7,
["best"] = 243.875,
["wipes"] = 1,
},
},
[2420] = {
["heroic"] = {
["kills"] = 8,
["best"] = 122.875,
["wipes"] = 1,
},
["mythic"] = {
["kills"] = 5,
["wipes"] = 44,
["best"] = 221.195000000007,
},
["normal"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 305.4949999999953,
},
["LFR"] = {
["best"] = 109.1579999999995,
["kills"] = 6,
},
},
[2428] = {
["normal"] = {
["best"] = 262.8400000000038,
["kills"] = 1,
},
["mythic"] = {
["kills"] = 10,
["wipes"] = 49,
["best"] = 248.7889999999898,
},
["heroic"] = {
["kills"] = 8,
["wipes"] = 12,
["best"] = 128.8040000000037,
},
["LFR"] = {
["best"] = 139.3230000000003,
["kills"] = 6,
},
},
[2429] = {
["normal"] = {
["best"] = 253.8559999999998,
["kills"] = 1,
},
["heroic"] = {
["kills"] = 10,
["wipes"] = 14,
["best"] = 146.0769999999902,
},
["mythic"] = {
["kills"] = 18,
["wipes"] = 53,
["best"] = 177.9370000000345,
},
["LFR"] = {
["best"] = 210.2620000000006,
["kills"] = 6,
},
},
[2422] = {
["heroic"] = {
["kills"] = 14,
["wipes"] = 3,
["best"] = 172.4300000000076,
},
["normal"] = {
["best"] = 167.6260000000038,
["kills"] = 6,
},
["mythic"] = {
["kills"] = 7,
["wipes"] = 32,
["best"] = 291.5509999999995,
},
["LFR"] = {
["kills"] = 12,
["best"] = 159.2579999999998,
["wipes"] = 2,
},
},
[2393] = {
["normal"] = {
["best"] = 193.974000000002,
["kills"] = 2,
},
["mythic"] = {
["kills"] = 14,
["wipes"] = 36,
["best"] = 177.8940000000293,
},
["heroic"] = {
["kills"] = 16,
["wipes"] = 6,
["best"] = 87.96199999999953,
},
["LFR"] = {
["best"] = 151.228000000001,
["kills"] = 7,
},
},
[2424] = {
["heroic"] = {
["kills"] = 26,
["wipes"] = 138,
["best"] = 318.3050000000003,
},
["normal"] = {
["kills"] = 4,
["wipes"] = 3,
["best"] = 393.1050000000105,
},
["LFR"] = {
["best"] = 324.6949999999997,
["kills"] = 8,
},
},
},
[1861] = {
[2168] = {
["heroic"] = {
["kills"] = 14,
["wipes"] = 1,
["best"] = 212.792000000132,
},
["mythic"] = {
["kills"] = 9,
["wipes"] = 25,
["best"] = 297.220999999903,
},
["normal"] = {
["best"] = 149.3849999999948,
["kills"] = 9,
},
["LFR"] = {
["best"] = 283.119999999995,
["kills"] = 1,
},
},
[2169] = {
["heroic"] = {
["kills"] = 13,
["wipes"] = 19,
["best"] = 224.939000000013,
},
["normal"] = {
["kills"] = 8,
["wipes"] = 2,
["best"] = 99.64300000001094,
},
["mythic"] = {
["kills"] = 6,
["wipes"] = 99,
["best"] = 414.429000000004,
},
["LFR"] = {
["best"] = 267.478000000003,
["kills"] = 1,
},
},
[2147] = {
["heroic"] = {
["kills"] = 6,
["wipes"] = 86,
["best"] = 339.189000000013,
},
["normal"] = {
["kills"] = 7,
["wipes"] = 25,
["best"] = 387.887000000017,
},
["LFR"] = {
["best"] = 424.018999999971,
["kills"] = 1,
},
},
[2195] = {
["heroic"] = {
["kills"] = 10,
["wipes"] = 63,
["best"] = 133.783999999985,
},
["normal"] = {
["best"] = 58.51800000001094,
["kills"] = 8,
},
["LFR"] = {
["wipes"] = 3,
},
},
[2194] = {
["heroic"] = {
["kills"] = 11,
["wipes"] = 38,
["best"] = 263.503999999957,
},
["normal"] = {
["kills"] = 8,
["wipes"] = 7,
["best"] = 107.775999999998,
},
["LFR"] = {
["best"] = 346.641999999993,
["kills"] = 1,
},
},
[2166] = {
["heroic"] = {
["kills"] = 12,
["best"] = 171.780000000028,
["wipes"] = 10,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 82,
["best"] = 427.105999999912,
},
["normal"] = {
["kills"] = 8,
["best"] = 67.28499999998894,
["wipes"] = 2,
},
["LFR"] = {
["best"] = 455.511999999988,
["kills"] = 1,
},
},
[2146] = {
["heroic"] = {
["kills"] = 13,
["best"] = 79.3019999999087,
["wipes"] = 1,
},
["mythic"] = {
["wipes"] = 87,
},
["normal"] = {
["kills"] = 9,
["wipes"] = 1,
["best"] = 35.51900000000023,
},
["LFR"] = {
["best"] = 204.831999999937,
["kills"] = 1,
},
},
[2167] = {
["heroic"] = {
["kills"] = 14,
["wipes"] = 18,
["best"] = 144.564999999944,
},
["mythic"] = {
["kills"] = 7,
["wipes"] = 56,
["best"] = 262.434000000358,
},
["normal"] = {
["best"] = 64.18400000000838,
["kills"] = 9,
},
["LFR"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 305.32799999998,
},
},
},
[2481] = {
[2461] = {
["heroic"] = {
["kills"] = 12,
["wipes"] = 23,
["best"] = 282.385000000002,
},
["normal"] = {
["kills"] = 12,
["wipes"] = 7,
["best"] = 178.2420000000057,
},
["LFR"] = {
["kills"] = 7,
["wipes"] = 2,
["best"] = 171.1539999999995,
},
},
[2469] = {
["heroic"] = {
["kills"] = 22,
["wipes"] = 131,
["best"] = 464.9500000000007,
},
["normal"] = {
["kills"] = 21,
["wipes"] = 105,
["best"] = 386.8479999999981,
},
["LFR"] = {
["best"] = 364.223,
["kills"] = 14,
},
},
[2470] = {
["heroic"] = {
["kills"] = 5,
["wipes"] = 9,
["best"] = 229.3170000000027,
},
["normal"] = {
["kills"] = 3,
["wipes"] = 6,
["best"] = 342.5720000000001,
},
["LFR"] = {
["kills"] = 18,
["best"] = 192.8699999999999,
["wipes"] = 1,
},
},
[2463] = {
["heroic"] = {
["kills"] = 23,
["wipes"] = 85,
["best"] = 305.1589999999997,
},
["normal"] = {
["kills"] = 24,
["wipes"] = 10,
["best"] = 251.8240000000005,
},
["LFR"] = {
["kills"] = 21,
["best"] = 204.3770000000004,
["wipes"] = 3,
},
},
[2464] = {
["heroic"] = {
["kills"] = 2,
["wipes"] = 6,
["best"] = 354.9499999999971,
},
["LFR"] = {
["best"] = 493.719000000001,
["kills"] = 3,
},
},
[2457] = {
["heroic"] = {
["kills"] = 11,
["wipes"] = 57,
["best"] = 287.2490000000007,
},
["normal"] = {
["kills"] = 14,
["wipes"] = 21,
["best"] = 363.3580000000075,
},
["LFR"] = {
["best"] = 172.5149999999994,
["kills"] = 10,
},
},
[2465] = {
["heroic"] = {
["kills"] = 7,
["wipes"] = 27,
["best"] = 203.2520000000004,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 21,
["best"] = 351.851999999999,
},
["normal"] = {
["best"] = 279.0630000000092,
["kills"] = 3,
},
["LFR"] = {
["best"] = 172.0630000000001,
["kills"] = 18,
},
},
[2458] = {
["heroic"] = {
["kills"] = 11,
["wipes"] = 12,
["best"] = 352.1800000000003,
},
["mythic"] = {
["kills"] = 4,
["best"] = 366.426999999996,
["wipes"] = 13,
},
["normal"] = {
["kills"] = 3,
["wipes"] = 3,
["best"] = 429.6900000000023,
},
["LFR"] = {
["kills"] = 18,
["best"] = 343.9860000000008,
["wipes"] = 2,
},
},
[2459] = {
["heroic"] = {
["kills"] = 28,
["wipes"] = 18,
["best"] = 140.6679999999906,
},
["mythic"] = {
["kills"] = 1,
["wipes"] = 4,
["best"] = 432.0610000000015,
},
["normal"] = {
["kills"] = 13,
["wipes"] = 2,
["best"] = 178.7309999999998,
},
["LFR"] = {
["best"] = 148.2510000000002,
["kills"] = 9,
},
},
[2467] = {
["heroic"] = {
["kills"] = 11,
["wipes"] = 203,
["best"] = 213.7100000000064,
},
["normal"] = {
["kills"] = 19,
["wipes"] = 14,
["best"] = 258.7450000000026,
},
["LFR"] = {
["best"] = 181.1149999999998,
["kills"] = 8,
},
},
[2460] = {
["heroic"] = {
["kills"] = 24,
["wipes"] = 47,
["best"] = 221.2829999999958,
},
["normal"] = {
["kills"] = 9,
["wipes"] = 5,
["best"] = 224.851999999999,
},
["LFR"] = {
["kills"] = 9,
["best"] = 194.8060000000005,
["wipes"] = 1,
},
},
},
[2450] = {
[2446] = {
["heroic"] = {
["kills"] = 22,
["wipes"] = 59,
["best"] = 198.3810000000012,
},
["normal"] = {
["kills"] = 2,
["wipes"] = 4,
["best"] = 294.4619999999995,
},
["LFR"] = {
["best"] = 229.6139999999996,
["kills"] = 3,
},
},
[2439] = {
["heroic"] = {
["kills"] = 26,
["wipes"] = 21,
["best"] = 175.9729999999981,
},
["normal"] = {
["best"] = 344.0490000000009,
["kills"] = 1,
},
["mythic"] = {
["kills"] = 17,
["wipes"] = 13,
["best"] = 340.6440000000002,
},
["LFR"] = {
["best"] = 324.603000000001,
["kills"] = 2,
},
},
[2447] = {
["heroic"] = {
["kills"] = 14,
["wipes"] = 42,
["best"] = 361.3080000000009,
},
["normal"] = {
["kills"] = 1,
["wipes"] = 13,
["best"] = 553.7190000000046,
},
["LFR"] = {
["kills"] = 3,
["wipes"] = 1,
["best"] = 373.7459999999992,
},
},
[2440] = {
["heroic"] = {
["kills"] = 18,
["wipes"] = 60,
["best"] = 305.541999999994,
},
["normal"] = {
["kills"] = 10,
["wipes"] = 9,
["best"] = 307.0930000000008,
},
["LFR"] = {
["kills"] = 3,
["best"] = 394.1160000000018,
["wipes"] = 1,
},
},
[2441] = {
["heroic"] = {
["kills"] = 15,
["wipes"] = 98,
["best"] = 667.7710000000079,
},
["normal"] = {
["kills"] = 10,
["wipes"] = 14,
["best"] = 578.4660000000003,
},
["LFR"] = {
["best"] = 730.5419999999976,
["kills"] = 3,
},
},
[2442] = {
["heroic"] = {
["kills"] = 26,
["wipes"] = 14,
["best"] = 184.3290000000052,
},
["normal"] = {
["best"] = 242.9660000000004,
["kills"] = 4,
},
["mythic"] = {
["kills"] = 18,
["wipes"] = 56,
["best"] = 323.288999999997,
},
["LFR"] = {
["best"] = 260.741,
["kills"] = 2,
},
},
[2435] = {
["heroic"] = {
["kills"] = 25,
["wipes"] = 6,
["best"] = 142.6949999999997,
},
["mythic"] = {
["kills"] = 26,
["wipes"] = 42,
["best"] = 233.8499999999985,
},
["normal"] = {
["best"] = 179.3210000000036,
["kills"] = 5,
},
["LFR"] = {
["best"] = 216.5120000000006,
["kills"] = 2,
},
},
[2443] = {
["heroic"] = {
["kills"] = 14,
["wipes"] = 23,
["best"] = 267.7129999999961,
},
["normal"] = {
["kills"] = 1,
["wipes"] = 9,
["best"] = 411.2410000000018,
},
["LFR"] = {
["best"] = 347.0730000000003,
["kills"] = 3,
},
},
[2444] = {
["heroic"] = {
["kills"] = 18,
["wipes"] = 77,
["best"] = 175.8539999999994,
},
["normal"] = {
["kills"] = 1,
["wipes"] = 1,
["best"] = 264.9180000000015,
},
["mythic"] = {
["wipes"] = 8,
},
["LFR"] = {
["best"] = 218.9600000000028,
["kills"] = 3,
},
},
[2445] = {
["heroic"] = {
["kills"] = 20,
["wipes"] = 29,
["best"] = 192.9289999999965,
},
["mythic"] = {
["wipes"] = 7,
},
["normal"] = {
["best"] = 282.7249999999985,
["kills"] = 1,
},
["LFR"] = {
["best"] = 260.7720000000008,
["kills"] = 3,
},
},
},
[1228] = {
[1197] = {
["LFR"] = {
["best"] = 276.290999999997,
["kills"] = 1,
},
},
[1153] = {
["LFR"] = {
["best"] = 77.2239999999874,
["kills"] = 1,
},
},
[1148] = {
["LFR"] = {
["best"] = 133.878000000026,
["kills"] = 1,
},
},
},
[2549] = {
[2553] = {
["heroic"] = {
["kills"] = 21,
["wipes"] = 4,
["best"] = 198.1310000000522,
},
["normal"] = {
["best"] = 156.6450000000186,
["kills"] = 4,
},
["mythic"] = {
["kills"] = 16,
["wipes"] = 35,
["best"] = 281.8989999999758,
},
["LFR"] = {
["best"] = 125.9830000000075,
["kills"] = 3,
},
},
[2554] = {
["heroic"] = {
["best"] = 169.8610000000335,
["kills"] = 21,
},
["mythic"] = {
["kills"] = 21,
["wipes"] = 14,
["best"] = 233.6580000000031,
},
["normal"] = {
["best"] = 174.2929999999469,
["kills"] = 2,
},
["LFR"] = {
["best"] = 121.5870000000577,
["kills"] = 8,
},
},
[2555] = {
["heroic"] = {
["kills"] = 21,
["wipes"] = 7,
["best"] = 167.8129999999655,
},
["mythic"] = {
["kills"] = 19,
["wipes"] = 30,
["best"] = 282.7589999999982,
},
["normal"] = {
["best"] = 134.4670000000624,
["kills"] = 4,
},
["LFR"] = {
["best"] = 128.2600000000093,
["kills"] = 3,
},
},
[2563] = {
["heroic"] = {
["kills"] = 22,
["wipes"] = 14,
["best"] = 197.3429999999935,
},
["mythic"] = {
["kills"] = 14,
["wipes"] = 136,
["best"] = 374.8449999999721,
},
["normal"] = {
["best"] = 141.48199999996,
["kills"] = 5,
},
["LFR"] = {
["best"] = 113.5970000000089,
["kills"] = 5,
},
},
[2556] = {
["heroic"] = {
["kills"] = 21,
["wipes"] = 5,
["best"] = 168.5500000000466,
},
["mythic"] = {
["kills"] = 15,
["wipes"] = 36,
["best"] = 303.2949999999837,
},
["normal"] = {
["kills"] = 4,
["best"] = 135.8499999999767,
["wipes"] = 1,
},
["LFR"] = {
["best"] = 142.1659999999683,
["kills"] = 3,
},
},
[2564] = {
["heroic"] = {
["kills"] = 21,
["best"] = 141.4270000000252,
["wipes"] = 4,
},
["mythic"] = {
["kills"] = 17,
["best"] = 175.9580000001006,
["wipes"] = 1,
},
["normal"] = {
["best"] = 131.7129999999997,
["kills"] = 4,
},
["LFR"] = {
["best"] = 86.09900000004563,
["kills"] = 7,
},
},
[2557] = {
["heroic"] = {
["kills"] = 21,
["wipes"] = 1,
["best"] = 131.9029999999329,
},
["mythic"] = {
["kills"] = 18,
["wipes"] = 10,
["best"] = 187.7250000000058,
},
["normal"] = {
["kills"] = 4,
["best"] = 103.6369999999879,
["wipes"] = 1,
},
["LFR"] = {
["best"] = 80.03099999995902,
["kills"] = 5,
},
},
[2565] = {
["heroic"] = {
["kills"] = 36,
["wipes"] = 31,
["best"] = 300.8150000000023,
},
["normal"] = {
["best"] = 219.3159999999916,
["kills"] = 9,
},
["mythic"] = {
["kills"] = 13,
["wipes"] = 346,
["best"] = 384.8270000000484,
},
["LFR"] = {
["kills"] = 22,
["best"] = 215.4280000000726,
["wipes"] = 1,
},
},
[2519] = {
["heroic"] = {
["kills"] = 36,
["wipes"] = 39,
["best"] = 357.8690000000061,
},
["mythic"] = {
["kills"] = 13,
["wipes"] = 507,
["best"] = 522.0519999999087,
},
["normal"] = {
["kills"] = 23,
["wipes"] = 2,
["best"] = 256.3379999999888,
},
["LFR"] = {
["best"] = 252.0339999999851,
["kills"] = 22,
},
},
},
[2522] = {
[2500] = {
["normal"] = {
["best"] = 190.1790000000037,
["kills"] = 2,
},
["mythic"] = {
["kills"] = 2,
["wipes"] = 2,
["best"] = 294.2609999999404,
},
["heroic"] = {
["best"] = 146.6489999999758,
["kills"] = 2,
},
["LFR"] = {
["best"] = 130.3870000000461,
["kills"] = 2,
},
},
[2491] = {
["normal"] = {
["best"] = 263.9279999999999,
["kills"] = 2,
},
["heroic"] = {
["kills"] = 2,
["wipes"] = 1,
["best"] = 186.6370000000461,
},
["LFR"] = {
["best"] = 181.0830000000424,
["kills"] = 2,
},
},
[2499] = {
["normal"] = {
["kills"] = 2,
["wipes"] = 2,
["best"] = 367.2289999999921,
},
["heroic"] = {
["kills"] = 1,
["wipes"] = 5,
["best"] = 663.2999999999884,
},
["LFR"] = {
["kills"] = 2,
["best"] = 344.2820000000065,
["wipes"] = 1,
},
},
[2493] = {
["normal"] = {
["best"] = 257.7039999999688,
["kills"] = 2,
},
["heroic"] = {
["kills"] = 2,
["wipes"] = 1,
["best"] = 262.8030000000144,
},
["LFR"] = {
["kills"] = 2,
["wipes"] = 2,
["best"] = 300.5050000000047,
},
},
[2480] = {
["normal"] = {
["best"] = 150.2829999999995,
["kills"] = 1,
},
["mythic"] = {
["kills"] = 4,
["wipes"] = 1,
["best"] = 131.4780000000028,
},
["heroic"] = {
["best"] = 74.16299999994226,
["kills"] = 2,
},
["LFR"] = {
["best"] = 101.0489999999991,
["kills"] = 2,
},
},
[2502] = {
["normal"] = {
["best"] = 111.7980000000098,
["kills"] = 2,
},
["heroic"] = {
["kills"] = 2,
["wipes"] = 3,
["best"] = 252.4530000000377,
},
["LFR"] = {
["best"] = 99.27399999997579,
["kills"] = 2,
},
},
[2482] = {
["normal"] = {
["best"] = 213.3470000000089,
["kills"] = 2,
},
["mythic"] = {
["wipes"] = 5,
},
["heroic"] = {
["best"] = 191.4210000000312,
["kills"] = 2,
},
["LFR"] = {
["best"] = 176.1599999999744,
["kills"] = 2,
},
},
[2486] = {
["normal"] = {
["best"] = 138.4130000000005,
["kills"] = 3,
},
["mythic"] = {
["best"] = 156.9560000000056,
["kills"] = 4,
},
["heroic"] = {
["best"] = 107.8329999999842,
["kills"] = 3,
},
["LFR"] = {
["kills"] = 2,
["wipes"] = 1,
["best"] = 156.7719999999972,
},
},
},
[2810] = {
[2686] = {
["normal"] = {
["kills"] = 6,
["fkDuration"] = 254.4679999999935,
["best"] = 175.7119999999995,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["mythic"] = {
["wipes"] = 2,
},
["heroic"] = {
["kills"] = 6,
["fkDuration"] = 396.8950000000041,
["wipes"] = 8,
["fkWipes"] = 1,
["best"] = 290.8110000000015,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["LFR"] = {
["kills"] = 5,
["fkDuration"] = 262.6879999999946,
["best"] = 234.4400000000023,
["bestDate"] = "2025/08/21",
["fkDate"] = "2025/08/13",
},
},
[2687] = {
["heroic"] = {
["kills"] = 6,
["fkDate"] = "2025/08/16",
["bestDate"] = "2025/08/22",
["fkWipes"] = 3,
["best"] = 343.6840000000084,
["wipes"] = 16,
["fkDuration"] = 450.6879999999946,
},
["normal"] = {
["kills"] = 6,
["fkDuration"] = 334.6510000000126,
["wipes"] = 2,
["fkWipes"] = 1,
["best"] = 199.6359999999986,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["LFR"] = {
["kills"] = 2,
["fkDate"] = "2025/08/21",
["bestDate"] = "2025/08/21",
["best"] = 283.4360000000015,
["wipes"] = 2,
["fkDuration"] = 283.4360000000015,
},
},
[2688] = {
["heroic"] = {
["kills"] = 6,
["fkDate"] = "2025/08/16",
["bestDate"] = "2025/08/20",
["fkWipes"] = 2,
["best"] = 368.0529999999999,
["wipes"] = 7,
["fkDuration"] = 424.2029999999941,
},
["normal"] = {
["kills"] = 6,
["fkDuration"] = 384.0299999999988,
["wipes"] = 1,
["best"] = 264.4290000000037,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["LFR"] = {
["kills"] = 2,
["fkDate"] = "2025/08/21",
["bestDate"] = "2025/08/21",
["best"] = 287.4789999999921,
["fkDuration"] = 287.4789999999921,
},
},
[2691] = {
["normal"] = {
["kills"] = 6,
["fkDuration"] = 534.2520000000077,
["wipes"] = 30,
["fkWipes"] = 12,
["best"] = 468.2169999999969,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
},
[2690] = {
["normal"] = {
["kills"] = 6,
["fkDuration"] = 368.4790000000066,
["wipes"] = 5,
["best"] = 238.9689999999973,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
},
[2684] = {
["normal"] = {
["kills"] = 6,
["fkDuration"] = 258.0489999999991,
["best"] = 178.8220000000001,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["mythic"] = {
["kills"] = 1,
["fkDate"] = "2025/08/23",
["bestDate"] = "2025/08/23",
["fkWipes"] = 22,
["best"] = 477.0050000000047,
["wipes"] = 22,
["fkDuration"] = 477.0050000000047,
},
["heroic"] = {
["kills"] = 7,
["fkDuration"] = 421.7090000000026,
["wipes"] = 16,
["fkWipes"] = 5,
["best"] = 271.7419999999984,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["LFR"] = {
["kills"] = 5,
["fkDuration"] = 230.7479999999923,
["best"] = 230.7479999999923,
["bestDate"] = "2025/08/13",
["fkDate"] = "2025/08/13",
},
},
[2685] = {
["normal"] = {
["kills"] = 6,
["fkDuration"] = 237.1720000000059,
["best"] = 188.7620000000024,
["bestDate"] = "2025/08/20",
["wipes"] = 2,
["fkDate"] = "2025/08/16",
},
["mythic"] = {
["kills"] = 1,
["fkDate"] = "2025/08/23",
["bestDate"] = "2025/08/23",
["fkWipes"] = 10,
["best"] = 419.6869999999763,
["wipes"] = 10,
["fkDuration"] = 419.6869999999763,
},
["heroic"] = {
["kills"] = 6,
["fkDuration"] = 415.2740000000049,
["wipes"] = 6,
["fkWipes"] = 3,
["best"] = 264.9629999999888,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["LFR"] = {
["kills"] = 5,
["fkDuration"] = 221.0109999999986,
["best"] = 221.0109999999986,
["bestDate"] = "2025/08/13",
["fkDate"] = "2025/08/13",
},
},
[2747] = {
["heroic"] = {
["kills"] = 6,
["fkDuration"] = 327.6340000000055,
["wipes"] = 9,
["fkWipes"] = 2,
["best"] = 284.2449999999953,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["normal"] = {
["kills"] = 6,
["fkDuration"] = 200.656999999992,
["wipes"] = 4,
["fkWipes"] = 1,
["best"] = 165.0699999999997,
["bestDate"] = "2025/08/20",
["fkDate"] = "2025/08/16",
},
["LFR"] = {
["kills"] = 2,
["fkDate"] = "2025/08/21",
["bestDate"] = "2025/08/21",
["best"] = 181.593000000008,
["fkDuration"] = 181.593000000008,
},
},
},
}
