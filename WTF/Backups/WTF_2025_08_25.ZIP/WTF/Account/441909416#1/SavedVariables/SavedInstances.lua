
SavedInstancesDB = {
["QuestDB"] = {
["Daily"] = {
[53885] = -1,
[61075] = -1,
[60762] = -1,
[61079] = -1,
[60646] = -1,
[11924] = 84,
[61103] = -1,
[87548] = 2472,
[87426] = 2472,
[77165] = 2112,
[51982] = -1,
[77303] = 2112,
[87324] = 2371,
[54132] = -1,
[63206] = -1,
[58168] = -1,
[54138] = -1,
[87285] = 2371,
[61765] = -1,
[54134] = -1,
[54137] = -1,
[87358] = 2371,
[62214] = -1,
[82080] = 84,
[58156] = -1,
[53939] = -1,
[61088] = -1,
[60775] = -1,
[54136] = -1,
[53701] = -1,
[53711] = -1,
[87597] = 2472,
[87010] = 2371,
[61104] = -1,
[87420] = 2472,
[87298] = 2371,
[84222] = 2369,
[58151] = -1,
[84286] = 2292,
[58155] = -1,
[62234] = -1,
[53883] = -1,
[84680] = 2369,
[84432] = 2369,
[60622] = -1,
[58167] = -1,
[54135] = -1,
},
["Darkmoon"] = {
["expires"] = 1754863140,
[47767] = -1,
},
["AccountDaily"] = {
[40753] = -1,
[34774] = -1,
[56042] = -1,
[31752] = -1,
[86486] = 2369,
},
["Weekly"] = {
[66937] = -1,
[62452] = -1,
[72175] = -1,
[82491] = -1,
[50316] = 147,
[59019] = -1,
[80671] = -1,
[52951] = -1,
[48911] = -1,
[89039] = 2339,
[72719] = -1,
[78915] = -1,
[60249] = -1,
[66364] = -1,
[76169] = -1,
[91052] = -1,
[72720] = -1,
[75307] = -1,
[82493] = 2339,
[57008] = -1,
[66940] = -1,
[85879] = -1,
[56050] = -1,
[70613] = -1,
[78821] = -1,
[75308] = -1,
[82494] = -1,
[76394] = -1,
[60250] = -1,
[81632] = -1,
[83229] = -1,
[79173] = -1,
[66941] = -1,
[70582] = -1,
[70614] = -1,
[72722] = -1,
[70199] = -1,
[82495] = -1,
[80004] = -1,
[86775] = -1,
[66942] = -1,
[81793] = -1,
[83358] = 2339,
[70615] = -1,
[72723] = -1,
[70200] = -1,
[82496] = -1,
[60251] = -1,
[57728] = -1,
[85722] = 2371,
[70935] = -1,
[66943] = -1,
[81794] = -1,
[83359] = -1,
[70616] = -1,
[72724] = -1,
[70201] = -1,
[70233] = -1,
["expires"] = 1756267199,
[91855] = 2339,
[66944] = -1,
[81795] = -1,
[83360] = 2339,
[70617] = -1,
[72725] = -1,
[70202] = -1,
[70234] = -1,
[56148] = -1,
[60252] = -1,
[84127] = -1,
[72438] = -1,
[66945] = -1,
[81796] = -1,
[56308] = -1,
[70618] = -1,
[82946] = 2214,
[55350] = -1,
[82499] = -1,
[82531] = -1,
[84128] = -1,
[72407] = -1,
[82659] = -1,
[82787] = -1,
[75665] = -1,
[70587] = -1,
[70619] = -1,
[72727] = -1,
[40787] = -1,
[82500] = -1,
[78444] = -1,
[60253] = -1,
[81574] = -1,
[87419] = -1,
[62441] = -1,
[70620] = -1,
[72728] = -1,
[82501] = -1,
[84130] = -1,
[66884] = -1,
[52956] = -1,
[70557] = -1,
[70589] = -1,
[91093] = 2371,
[82502] = -1,
[60254] = -1,
[84131] = -1,
[72410] = -1,
[66949] = -1,
[83333] = 2214,
[83365] = 2339,
[72155] = -1,
[78319] = -1,
[82503] = -1,
[84132] = -1,
[53436] = -1,
[66950] = -1,
[70559] = -1,
[83366] = 2339,
[72156] = -1,
[75286] = -1,
[57157] = -1,
[72686] = -1,
[60255] = -1,
[84133] = -1,
[85947] = 85,
[66951] = -1,
[87423] = -1,
[70592] = -1,
[72157] = -1,
[52782] = -1,
[70752] = -1,
[82510] = -1,
[70530] = -1,
[83529] = -1,
[83240] = 2328,
[66952] = -1,
[87424] = -1,
[70593] = -1,
[72158] = -1,
[70558] = -1,
[75288] = -1,
[82497] = 2339,
[70753] = -1,
[62284] = -1,
[60256] = -1,
[83347] = 2339,
[47523] = 111,
[47148] = -1,
[66953] = -1,
[70562] = -1,
[70594] = -1,
[72159] = -1,
[56649] = -1,
[75289] = -1,
[70211] = -1,
[70754] = -1,
[83362] = 2339,
[66890] = -1,
[55498] = 622,
[70531] = -1,
[70563] = -1,
[89502] = -1,
[79346] = -1,
[70723] = -1,
[82508] = -1,
[62285] = -1,
[60257] = -1,
[66891] = -1,
[70532] = -1,
[70564] = -1,
[62445] = -1,
[33334] = -1,
[82509] = -1,
[82453] = -1,
[90781] = -1,
[55499] = -1,
[70533] = -1,
[70565] = -1,
[82414] = -1,
[83532] = -1,
[60242] = -1,
[80562] = -1,
[64522] = -1,
[82511] = -1,
[56969] = -1,
[81649] = -1,
[79158] = -1,
[70567] = -1,
[82512] = -1,
[60243] = -1,
[89492] = -1,
[70203] = -1,
[82506] = -1,
[83364] = 2339,
[70568] = -1,
[52958] = -1,
[40786] = -1,
[82507] = -1,
[82449] = -1,
[76122] = -1,
[82458] = -1,
[52954] = -1,
[48910] = -1,
[72726] = -1,
[88805] = -1,
[52944] = -1,
[66938] = -1,
[78933] = -1,
[52952] = -1,
[70569] = -1,
[76733] = -1,
[75309] = -1,
[89061] = 2371,
[87422] = -1,
[82482] = -1,
[32640] = -1,
[62288] = -1,
[75351] = -1,
[56648] = -1,
[70235] = -1,
[72291] = 2024,
[82706] = 2339,
[66897] = -1,
[83530] = -1,
[85459] = 2371,
[83345] = -1,
[82355] = -1,
[84129] = -1,
[70750] = -1,
[82483] = -1,
[78427] = -1,
[89222] = -1,
[78656] = -1,
[86731] = -1,
[82707] = -1,
[80184] = -1,
[53435] = -1,
[79226] = -1,
[70571] = -1,
[82852] = -1,
[85461] = 2371,
[72423] = -1,
[82452] = 2339,
[85869] = -1,
[82516] = -1,
[60245] = -1,
[89223] = 1165,
[45563] = 554,
[84776] = -1,
[70586] = -1,
[82708] = -1,
[80185] = -1,
[62289] = -1,
[70540] = -1,
[70572] = -1,
[62449] = -1,
[33338] = -1,
[85487] = -1,
[64541] = -1,
[82485] = -1,
[70560] = -1,
[78972] = -1,
[78428] = -1,
[60244] = -1,
[59016] = -1,
[70561] = -1,
[82709] = -1,
[80186] = 2339,
[52948] = -1,
[90545] = 2371,
[66517] = -1,
[72427] = -1,
[85488] = -1,
[66516] = -1,
[82486] = -1,
[91205] = 2339,
[60246] = -1,
[66363] = -1,
[40173] = 125,
[82678] = 2367,
[82710] = -1,
[80187] = -1,
[83285] = 85,
[70595] = -1,
[62450] = -1,
[83531] = -1,
[80672] = -1,
[75301] = -1,
[82487] = -1,
[72810] = -1,
[76600] = -1,
[66900] = -1,
[59017] = -1,
[82679] = 2367,
[82711] = -1,
[80188] = -1,
[52949] = -1,
[89294] = -1,
[89514] = -1,
[72172] = -1,
[82504] = -1,
[82488] = -1,
[55121] = -1,
[60247] = -1,
[87417] = 2339,
[48912] = -1,
[72428] = -1,
[82505] = -1,
[82712] = -1,
[80189] = -1,
[66935] = -1,
[62286] = -1,
[52957] = -1,
[52953] = -1,
[72173] = -1,
[82492] = -1,
[56650] = -1,
[82489] = -1,
[40168] = 111,
[82778] = -1,
[70591] = -1,
[59018] = -1,
[82498] = -1,
[81691] = -1,
[62287] = -1,
[52950] = -1,
[70545] = -1,
[79216] = -1,
[56064] = -1,
[85460] = -1,
[64710] = 627,
[75304] = -1,
[82490] = -1,
[60248] = -1,
[76997] = -1,
[89293] = -1,
[83363] = 2339,
[80670] = 2255,
[82746] = -1,
[32641] = -1,
},
["AccountWeekly"] = {
[45539] = -1,
[80592] = 2255,
[77236] = -1,
[72721] = -1,
[83357] = -1,
[72528] = -1,
[90124] = 2472,
["expires"] = 1756267199,
[90126] = 2472,
[46292] = -1,
[58458] = -1,
[56492] = -1,
[84370] = 2339,
[54186] = -1,
[90123] = 2472,
},
},
["Progress"] = {
["Enable"] = {
["tww-free-chett-list"] = false,
["tww-anniversary-restored-coffer-key"] = false,
["tww-spreading-the-light"] = false,
["df-shipment-of-goods"] = false,
["df-fighting-is-its-own-reward"] = false,
["df-aiding-the-accord"] = false,
["the-world-awaits"] = false,
["timewalking"] = false,
["df-primal-storms-elementals"] = false,
["tww-biergoth-dungeon-quest"] = false,
["great-vault-raid"] = false,
["df-grand-hunt"] = false,
["tww-algari-treatise"] = false,
["df-blooming-dreamseeds"] = false,
["call-to-battle"] = false,
["df-a-worthy-ally-loamm-niffen"] = false,
["bfa-horrific-vision"] = false,
["tww-gearing-up-for-trouble"] = false,
["call-to-delves"] = false,
["tww-siren-isle-weekly"] = false,
["tww-the-theater-trope"] = false,
["tww-special-assignments"] = false,
["tww-pvp-world"] = false,
["tww-radiant-echoes"] = true,
["sl-patterns-within-patterns"] = false,
["tww-tazavesh-warrant-quests"] = true,
["df-trial-of-flood"] = false,
["tww-chett-list"] = false,
["tww-nightfall-scenario"] = false,
["tww-ecological-succession"] = true,
["df-time-rift"] = false,
["tww-nightfall-daily"] = false,
["tww-the-key-to-success"] = false,
["emissary-of-war"] = false,
["bfa-lesser-vision"] = false,
["df-siege-on-dragonbane-keep"] = false,
["tww-weekly-cache"] = false,
["df-a-worthy-ally-dream-wardens"] = false,
["tww-rollin-down-in-the-deeps"] = false,
["sl-replenish-the-reservoir"] = false,
["tww-more-than-just-a-phase"] = true,
["tww-delvers-bounty"] = false,
["df-researchers-under-fire"] = false,
["tww-services-requested"] = false,
["df-the-superbloom"] = false,
["tww-archives"] = false,
["df-the-big-dig-traitors-rest"] = false,
["tww-brawl-weekly"] = false,
["df-services-requested"] = false,
["df-trial-of-elements"] = false,
["The Severed Threads"] = false,
["great-vault-world"] = false,
["df-disciple-of-fyrakk"] = false,
["tww-s3-weekly-cache"] = true,
["df-secured-shipment"] = false,
["sl-covenant-assault"] = false,
["df-community-feast"] = false,
["df-dreamsurge"] = false,
["great-vault-pvp"] = false,
["df-primal-storms-core"] = false,
["tww-lesser-keyflame"] = false,
["sl-shaping-fate"] = false,
["sl-return-lost-souls"] = false,
["tww-delves"] = false,
["bfa-island"] = false,
["df-sparks-of-life"] = false,
["bfa-nzoth-assault"] = false,
["tww-the-call-of-the-worldsoul"] = false,
["tww-pvp-weekly"] = false,
["tww-reduce-reuse-resell"] = true,
["tww-many-jobs-handle-it"] = true,
["tww-urge-to-surge"] = true,
["tww-karesh-warrants"] = true,
},
["Order"] = {
["tww-free-chett-list"] = 50,
["tww-anniversary-restored-coffer-key"] = 50,
["tww-spreading-the-light"] = 50,
["df-shipment-of-goods"] = 50,
["df-fighting-is-its-own-reward"] = 50,
["df-aiding-the-accord"] = 50,
["the-world-awaits"] = 50,
["timewalking"] = 50,
["df-primal-storms-elementals"] = 50,
["tww-biergoth-dungeon-quest"] = 50,
["great-vault-raid"] = 50,
["df-grand-hunt"] = 50,
["tww-algari-treatise"] = 50,
["df-blooming-dreamseeds"] = 50,
["call-to-battle"] = 50,
["df-a-worthy-ally-loamm-niffen"] = 50,
["bfa-horrific-vision"] = 50,
["tww-gearing-up-for-trouble"] = 50,
["call-to-delves"] = 50,
["tww-siren-isle-weekly"] = 50,
["tww-the-theater-trope"] = 50,
["tww-special-assignments"] = 50,
["tww-pvp-world"] = 50,
["tww-radiant-echoes"] = 50,
["sl-patterns-within-patterns"] = 50,
["tww-tazavesh-warrant-quests"] = 50,
["df-trial-of-flood"] = 50,
["tww-chett-list"] = 50,
["tww-nightfall-scenario"] = 50,
["tww-ecological-succession"] = 50,
["df-time-rift"] = 50,
["tww-nightfall-daily"] = 50,
["tww-the-key-to-success"] = 50,
["emissary-of-war"] = 50,
["bfa-lesser-vision"] = 50,
["df-siege-on-dragonbane-keep"] = 50,
["tww-weekly-cache"] = 50,
["df-a-worthy-ally-dream-wardens"] = 50,
["tww-rollin-down-in-the-deeps"] = 50,
["sl-replenish-the-reservoir"] = 50,
["tww-more-than-just-a-phase"] = 50,
["tww-delvers-bounty"] = 50,
["df-researchers-under-fire"] = 50,
["tww-services-requested"] = 50,
["df-the-superbloom"] = 50,
["tww-archives"] = 50,
["df-the-big-dig-traitors-rest"] = 50,
["tww-brawl-weekly"] = 50,
["df-services-requested"] = 50,
["df-trial-of-elements"] = 50,
["The Severed Threads"] = 50,
["great-vault-world"] = 50,
["df-disciple-of-fyrakk"] = 50,
["tww-s3-weekly-cache"] = 50,
["df-secured-shipment"] = 50,
["sl-covenant-assault"] = 50,
["df-community-feast"] = 50,
["df-dreamsurge"] = 50,
["great-vault-pvp"] = 50,
["df-primal-storms-core"] = 50,
["tww-lesser-keyflame"] = 50,
["sl-shaping-fate"] = 50,
["sl-return-lost-souls"] = 50,
["tww-delves"] = 50,
["bfa-island"] = 50,
["df-sparks-of-life"] = 50,
["bfa-nzoth-assault"] = 50,
["tww-the-call-of-the-worldsoul"] = 50,
["tww-pvp-weekly"] = 50,
["tww-reduce-reuse-resell"] = 50,
["tww-many-jobs-handle-it"] = 50,
["tww-urge-to-surge"] = 50,
["tww-karesh-warrants"] = 50,
},
["User"] = {
},
},
["spelltip"] = {
[71041] = {
"Покинувший подземелье",
"Вы покинули подземелье. Должно пройти некоторое время, прежде чем вы снова сможете воспользоваться поиском подземелья или рейда.",
"Осталось: 29 |4минута:минуты:минут;",
},
},
["Instances"] = {
["Трон Четырех Ветров"] = {
["LFDID"] = 318,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Battle for Azeroth)"] = {
["LFDID"] = 2874,
["Expansion"] = 7,
["Show"] = "saved",
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Квартал Звезд"] = {
["LFDID"] = 2280,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Малификус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1884,
["RecLevel"] = 45,
["Raid"] = true,
},
["Огненные Просторы"] = {
["LFDID"] = 362,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Театр Боли"] = {
["LFDID"] = 2815,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Депо Мрачных Путей"] = {
["LFDID"] = 2319,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ара-Кара, Город Отголосков"] = {
["LFDID"] = 3000,
["Expansion"] = 10,
["Show"] = "never",
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2660:23:7|h[Ара-Кара, Город Отголосков]|h|r",
["ID"] = 595816237,
["Locked"] = false,
},
},
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2660:23:0|h[Ара-Кара, Город Отголосков]|h|r",
["ID"] = 512028627,
["Locked"] = false,
},
},
["Raid"] = false,
},
["Некрополь Призрачной Луны"] = {
["LFDID"] = 1976,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Сотанатор"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2014,
["RecLevel"] = 45,
["Raid"] = true,
},
["Змеиное святилище"] = {
["LFDID"] = 194,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Стратхольм – черный ход"] = {
["LFDID"] = 2641,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Битва за Дазар'алор"] = {
["LFDID"] = 1944,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Базуал"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2517,
["RecLevel"] = 70,
["Raid"] = true,
},
["Т'зейн"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2139,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное героическое подземелье (2-й сезон The War Within)"] = {
["LFDID"] = 2807,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Крепость Черной Ладьи"] = {
["LFDID"] = 2275,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Аркатрац"] = {
["LFDID"] = 1011,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Город Нитей"] = {
["LFDID"] = 2722,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Инквизитор Мето"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2012,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 462,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Вольная Гавань"] = {
["LFDID"] = 2875,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Непроглядная Пучина"] = {
["LFDID"] = 10,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное героическое подземелье (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2537,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Коварные Дуо"] = {
["LFDID"] = 2803,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = false,
["Show"] = "saved",
},
["Тазавеш: гамбит Со'леи"] = {
["LFDID"] = 2996,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Нексус"] = {
["LFDID"] = 1019,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Испытание крестоносца"] = {
["LFDID"] = 248,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Твердыня Крыла Тьмы"] = {
["LFDID"] = 314,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье (Dragonflight)"] = {
["Show"] = "saved",
["Expansion"] = 9,
["LFDID"] = 2350,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Кузня Душ"] = {
["LFDID"] = 2322,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Тайный рынок Тазавеш"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2225,
["RecLevel"] = 60,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2441:23:102|h[Тайный рынок Тазавеш]|h|r",
["ID"] = 512041014,
["Locked"] = true,
},
},
["Raid"] = false,
},
["Случайное подземелье (Mists of Pandaria, героич.)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2539,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Каламир"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1774,
["RecLevel"] = 45,
["Raid"] = true,
},
["Престол Гроз"] = {
["LFDID"] = 634,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Аметистовая крепость"] = {
["LFDID"] = 221,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Темный лабиринт"] = {
["LFDID"] = 181,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Операция \"Мехагон\" – свалка"] = {
["LFDID"] = 2027,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Натанос Гнилостень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 9005,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Lich King (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 262,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Анторус, Пылающий Трон"] = {
["LFDID"] = 1642,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Апокрон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1956,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ботаника"] = {
["LFDID"] = 2325,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Огненная Пропасть"] = {
["LFDID"] = 4,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Логово Магтеридона"] = {
["LFDID"] = 176,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Вечный дворец"] = {
["LFDID"] = 2016,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Ауростор"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2562,
["RecLevel"] = 70,
["Raid"] = true,
},
["Азжол-Неруб"] = {
["LFDID"] = 2324,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Горнило Штормов"] = {
["LFDID"] = 1954,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Шуррай"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2636,
["RecLevel"] = 80,
["Raid"] = true,
},
["Забытый город - квартал Криводревов"] = {
["LFDID"] = 34,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье Shadowlands (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2087,
["RecLevel"] = 60,
["Random"] = true,
["Raid"] = false,
},
["Рубиновые Омуты Жизни"] = {
["LFDID"] = 2436,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Принц Сарсарун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 310,
},
["Случайное подземелье, путеш. во времени (Legion)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 2274,
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Госпожа Аллюрадель"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2011,
["RecLevel"] = 45,
["Raid"] = true,
},
["Казематы Стражей"] = {
["LFDID"] = 2278,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Штурм Аметистовой крепости"] = {
["LFDID"] = 1209,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Око Азшары"] = {
["LFDID"] = 2276,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Лисканот"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2518,
["RecLevel"] = 70,
["Raid"] = true,
},
["На'зак Одержимый"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1783,
["RecLevel"] = 45,
["Raid"] = true,
},
["Крепость Темного Клыка"] = {
["LFDID"] = 327,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Великий посол Огнехлыст"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 308,
},
["Островные экспедиции"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 1762,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Хмелеварня Буйных Портеров"] = {
["LFDID"] = 2543,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Кузня Крови"] = {
["LFDID"] = 2326,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Око Вечности"] = {
["LFDID"] = 237,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Случайный сценарий Mists of Pandaria (героич.)"] = {
["LFDID"] = 641,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Глубины Черной горы - Верхний город"] = {
["LFDID"] = 276,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Корен Худовар"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 287,
},
["Гномреган"] = {
["LFDID"] = 14,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Расселина Темного Пламени"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["LFDID"] = 2809,
},
["Собор Вечной Ночи"] = {
["LFDID"] = 1488,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Операция: шлюз"] = {
["Expansion"] = 10,
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2773:23:15|h[Операция: шлюз]|h|r",
["ID"] = 595853292,
["Locked"] = false,
},
},
["Вольтчара - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2773:23:15|h[Операция: шлюз]|h|r",
["ID"] = 595831089,
["Locked"] = false,
},
},
["Show"] = "saved",
["LFDID"] = 2998,
["Raid"] = false,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2773:23:15|h[Операция: шлюз]|h|r",
["ID"] = 1185856500,
["Locked"] = false,
},
},
["RecLevel"] = 1,
},
["Зул'Гуруб"] = {
["LFDID"] = 334,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Лазурное хранилище"] = {
["LFDID"] = 2498,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Храм Нефритовой Змеи"] = {
["LFDID"] = 2541,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ашран"] = {
["LFDID"] = 1127,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Забытый город – квартал Криводревов"] = {
["LFDID"] = 2635,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Сердце Страха"] = {
["LFDID"] = 534,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Черный храм"] = {
["LFDID"] = 196,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Случайное подземелье классической игры"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 258,
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = false,
},
["Грим Батол"] = {
["LFDID"] = 2730,
["Expansion"] = 10,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "never",
},
["Каменный Свод"] = {
["LFDID"] = 2724,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Случайное подземелье, путеш. во времени (Warlords of Draenor)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 1971,
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Нижняя часть пика Черной горы"] = {
["LFDID"] = 32,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Окулярус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2013,
["RecLevel"] = 45,
["Raid"] = true,
},
["Терраса Вечной Весны"] = {
["LFDID"] = 536,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайный сценарий путешествия во времени (Mists of Pandaria)"] = {
["LFDID"] = 2558,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Каражан"] = {
["LFDID"] = 175,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Аукиндон"] = {
["LFDID"] = 1975,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Shadowlands"] = {
["Show"] = "saved",
["Expansion"] = 8,
["LFDID"] = 2086,
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Иссохший Дж'им"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1796,
["RecLevel"] = 45,
["Raid"] = true,
},
["Крепость Бурь"] = {
["LFDID"] = 193,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Решанор"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2762,
["Raid"] = true,
["Бимладен - Ревущий фьорд"] = {
[2] = {
true,
["ID"] = -1,
["Expires"] = 1756267199,
},
},
["RecLevel"] = 80,
},
["Заповедник \"Аль'дани\""] = {
["LFDID"] = 2991,
["Expansion"] = 10,
["Show"] = "saved",
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2830:23:7|h[Заповедник \"Аль'дани\"]|h|r",
["ID"] = 595854024,
["Locked"] = false,
},
},
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2830:23:7|h[Заповедник \"Аль'дани\"]|h|r",
["ID"] = 1185859970,
["Locked"] = false,
},
},
["Raid"] = false,
},
["Стратхольм – главные врата"] = {
["LFDID"] = 2639,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Островные экспедиции – индивидуальный тур"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2251,
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Храм Ан'Киража"] = {
["LFDID"] = 161,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Антрос"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9013,
["RecLevel"] = 60,
["Raid"] = true,
},
["Ульдир"] = {
["LFDID"] = 1889,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Терраса Магистров"] = {
["LFDID"] = 1154,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Прошлое Хиджала"] = {
["LFDID"] = 195,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Подземелья Могу'шан"] = {
["LFDID"] = 532,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Некроситет"] = {
["LFDID"] = 2557,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Забытый город - палаты Гордока"] = {
["LFDID"] = 38,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Тол Дагор"] = {
["LFDID"] = 1714,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье (The War Within, героический режим)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2517,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Легиона"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 1045,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайный сценарий (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2559,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Си'ваш"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1885,
["RecLevel"] = 45,
["Raid"] = true,
},
["Кронпринцесса Терадрас"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 309,
},
["Ульдаман"] = {
["LFDID"] = 22,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Операция \"Мехагон\" – мастерская"] = {
["LFDID"] = 2813,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Зул'Аман"] = {
["LFDID"] = 340,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Ульдуар"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 1677,
},
["Охотники за душами"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1756,
["RecLevel"] = 45,
["Raid"] = true,
},
["Гоблионе"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2683,
["RecLevel"] = 80,
["Raid"] = true,
},
["Кодекс Хроми"] = {
["LFDID"] = 2714,
["Expansion"] = 8,
["Raid"] = true,
["RecLevel"] = 10,
["Holiday"] = true,
["Show"] = "saved",
},
["Лабиринты Иглошкурых"] = {
["LFDID"] = 16,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Источник Вечности"] = {
["LFDID"] = 437,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["\"Сияющий Рассвет\""] = {
["LFDID"] = 2994,
["Expansion"] = 10,
["Show"] = "never",
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2662:23:7|h[\"Сияющий Рассвет\"]|h|r",
["ID"] = 595853727,
["Locked"] = false,
},
},
["Raid"] = false,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2662:23:7|h[\"Сияющий Рассвет\"]|h|r",
["ID"] = 1185854907,
["Locked"] = false,
},
},
["RecLevel"] = 1,
},
["Замок Нафрия"] = {
["LFDID"] = 2095,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Утроба Душ"] = {
["LFDID"] = 1192,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Открытие Темного портала"] = {
["LFDID"] = 1012,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Камня"] = {
["LFDID"] = 213,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Случайный сценарий Mists of Pandaria"] = {
["LFDID"] = 493,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Нижетопь"] = {
["LFDID"] = 2327,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Престол Триумвирата"] = {
["LFDID"] = 1535,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Атал'Дазар"] = {
["LFDID"] = 2876,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Очищение Стратхольма"] = {
["LFDID"] = 2992,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Глубины Черной горы - Тюремный блок"] = {
["LFDID"] = 30,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Кордак"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2637,
["RecLevel"] = 80,
["Raid"] = true,
},
["Неруб'арский дворец"] = {
["Show"] = "saved",
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["LFDID"] = 2645,
},
["Хранилище Воплощений"] = {
["LFDID"] = 2390,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Искроварня"] = {
["LFDID"] = 2811,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Паровое подземелье"] = {
["LFDID"] = 185,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Ан'кахет: Старое Королевство"] = {
["LFDID"] = 1016,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Верховный Молот"] = {
["LFDID"] = 897,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Курганы Иглошкурых"] = {
["LFDID"] = 20,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (The Burning Crusade)"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 744,
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Затонувший храм"] = {
["LFDID"] = 28,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Осада Оргриммара"] = {
["LFDID"] = 766,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Забытый город - центральный сад"] = {
["LFDID"] = 36,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье Легиона (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 6,
["LFDID"] = 1046,
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Логово Ониксии"] = {
["LFDID"] = 257,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Трон Приливов"] = {
["LFDID"] = 1150,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Черный храм"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 1533,
},
["Гарнизон босс"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 9001,
["RecLevel"] = 40,
["Raid"] = true,
},
["Окулус"] = {
["LFDID"] = 211,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Пещеры Стенаний"] = {
["LFDID"] = 1,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Улмат"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2362,
["RecLevel"] = 50,
["Raid"] = true,
},
["Чертоги Покаяния"] = {
["Expansion"] = 8,
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2287:23:15|h[Чертоги Покаяния]|h|r",
["ID"] = 595854338,
["Locked"] = false,
},
},
["Вольтчара - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2287:23:15|h[Чертоги Покаяния]|h|r",
["ID"] = 595831601,
["Locked"] = false,
},
},
["Show"] = "saved",
["LFDID"] = 2997,
["Raid"] = false,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2287:23:15|h[Чертоги Покаяния]|h|r",
["ID"] = 1185857264,
["Locked"] = false,
},
},
["RecLevel"] = 50,
},
["Пещеры Времени: годовщина"] = {
["LFDID"] = 1911,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Лордеронский гарнизон"] = {
["LFDID"] = 2804,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Вечное Цветение"] = {
["LFDID"] = 1972,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Мародон - Зловонная пещера"] = {
["LFDID"] = 26,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Повелитель Холода Ахун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 1,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 286,
},
["Крепость Утгард"] = {
["LFDID"] = 2323,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Хранилище Аркавона"] = {
["LFDID"] = 240,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Обломок"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1795,
["RecLevel"] = 45,
["Raid"] = true,
},
["Возвращение в Каражан"] = {
["LFDID"] = 1347,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 110,
["Show"] = "saved",
},
["Наксрамас"] = {
["LFDID"] = 227,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Верхняя часть пика Черной горы"] = {
["LFDID"] = 1004,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Испытание доблести"] = {
["LFDID"] = 1439,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Цитадель Ледяной Короны"] = {
["LFDID"] = 280,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Ульдуар"] = {
["Expansion"] = 2,
["Мальдика - Свежеватель Душ"] = {
[33] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:603:33:8208|h[Ульдуар]|h|r",
["ID"] = 2623853034,
["Locked"] = false,
},
},
["Вольтчара - Свежеватель Душ"] = {
[33] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:603:33:8208|h[Ульдуар]|h|r",
["ID"] = 2623935307,
["Locked"] = false,
},
},
["LFDID"] = 244,
["Show"] = "saved",
["Raid"] = true,
["Бимладен - Ревущий фьорд"] = {
[33] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:603:33:8208|h[Ульдуар]|h|r",
["ID"] = 2619088119,
["Locked"] = false,
},
},
["RecLevel"] = 30,
},
["Наступление клана Нокхуд"] = {
["LFDID"] = 2442,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Гробницы маны"] = {
["LFDID"] = 1013,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ни'алота, Пробуждающийся Город"] = {
["LFDID"] = 2035,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Гнев Тюремщика"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9006,
["RecLevel"] = 60,
["Raid"] = true,
},
["Затерянный город Тол'вир"] = {
["LFDID"] = 1151,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Катакомбы Сурамара"] = {
["LFDID"] = 1190,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["Рассвет Бесконечности: подъем Дорнозму"] = {
["LFDID"] = 2530,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Смертельная тризна"] = {
["LFDID"] = 2728,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "never",
},
["Испытание великого крестоносца"] = {
["LFDID"] = 250,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Мучители из Торгаста"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9007,
["RecLevel"] = 60,
["Raid"] = true,
},
["Небесный Путь"] = {
["LFDID"] = 1977,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Бастионы Адского Пламени"] = {
["LFDID"] = 188,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Хумонгрис"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1770,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Burning Crusade (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 260,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Кай'жу Газ'рилла"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 306,
},
["Случайное героическое подземелье (3-й сезон The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2993,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Солнечный Колодец"] = {
["LFDID"] = 199,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Конец Времен"] = {
["LFDID"] = 1152,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путешествие во времени (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 2538,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Тихая Сень"] = {
["LFDID"] = 2025,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["Show"] = "saved",
},
["Возвращение в Каражан (верхняя часть)"] = {
["LFDID"] = 1474,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Крепость Барадин"] = {
["LFDID"] = 329,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Вакан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2531,
["RecLevel"] = 70,
["Raid"] = true,
},
["Освобождение Нижней Шахты"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2893,
["RecLevel"] = 80,
["Бимладен - Ревущий фьорд"] = {
[15] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2769:15:192|h[Освобождение Нижней Шахты]|h|r",
["ID"] = 374846025,
["Locked"] = false,
},
},
["Raid"] = true,
},
["Хромовый король"] = {
["LFDID"] = 2798,
["Expansion"] = 10,
["RecLevel"] = 80,
["Raid"] = true,
["Show"] = "saved",
},
["Храм Сетралисс"] = {
["LFDID"] = 2879,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Гнездовье (версия из задания)"] = {
["LFDID"] = 2657,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "never",
},
["Случайное подземелье, путеш. во времени (Wrath of the Lich King)"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 995,
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Тюрьма Штормграда"] = {
["LFDID"] = 12,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Залы Отражений"] = {
["LFDID"] = 256,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Монастырь Шадо-Пан"] = {
["LFDID"] = 2545,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 788,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Скопище кошмаров"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2635,
["RecLevel"] = 80,
["Raid"] = true,
},
["Забытый город – центральный сад"] = {
["LFDID"] = 2646,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное героическое подземелье (1-й сезон The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2723,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Орта"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2625,
["RecLevel"] = 80,
["Raid"] = true,
},
["Побег из Дарнхольда"] = {
["LFDID"] = 183,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Ордос"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 861,
["RecLevel"] = 35,
["Raid"] = true,
},
["Мародон - Поющие водопады"] = {
["LFDID"] = 273,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Душа Дракона"] = {
["LFDID"] = 448,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
["LFDID"] = 2814,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ша Злости"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 691,
["RecLevel"] = 35,
["Raid"] = true,
},
["Налак"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 814,
["RecLevel"] = 35,
["Raid"] = true,
},
["Лощина Бурошкуров"] = {
["LFDID"] = 2439,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Залы Алого ордена"] = {
["LFDID"] = 2553,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Врата Заходящего Солнца"] = {
["LFDID"] = 2549,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Battle For Azeroth"] = {
["Show"] = "saved",
["Expansion"] = 7,
["LFDID"] = 1670,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Яма Сарона"] = {
["LFDID"] = 1153,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Операция \"Мехагон\""] = {
["LFDID"] = 2006,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Воспоминания Азерот: Burning Crusade"] = {
["LFDID"] = 2004,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Воспоминания Азерот: Wrath of the Lich King"] = {
["LFDID"] = 2017,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Аукенайские гробницы"] = {
["LFDID"] = 178,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Цитадель Адского Пламени"] = {
["LFDID"] = 989,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["10.2.5 - VS Mode - LFG Dungeon (OJF)"] = {
["LFDID"] = 2484,
["Expansion"] = 5,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Созидания"] = {
["LFDID"] = 321,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Ундаста"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 826,
["RecLevel"] = 35,
["Raid"] = true,
},
["Мортанис"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2431,
["RecLevel"] = 60,
["Raid"] = true,
},
["Обсидиановое святилище"] = {
["LFDID"] = 238,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Cataclysm)"] = {
["LFDID"] = 1146,
["Expansion"] = 3,
["Show"] = "saved",
["Holiday"] = true,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Battle For Azeroth (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 7,
["LFDID"] = 1671,
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье, путеш. во времени (Mists of Pandaria)"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 1453,
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Чертоги Насыщения"] = {
["LFDID"] = 2444,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Глубины Черной горы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 80,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 2754,
},
["Логово Груула"] = {
["LFDID"] = 177,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Дюнный пожиратель Краулок"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2210,
["RecLevel"] = 50,
["Raid"] = true,
},
["Галеон"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 725,
["RecLevel"] = 35,
["Raid"] = true,
},
["Королева Ансурек"] = {
["LFDID"] = 2715,
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Classic)"] = {
["Show"] = "saved",
["Expansion"] = 0,
["LFDID"] = 2634,
["Random"] = true,
["Raid"] = false,
["Holiday"] = true,
["RecLevel"] = 10,
},
["Стратхольм - Черный ход"] = {
["LFDID"] = 274,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Туманы Тирна Скитта"] = {
["LFDID"] = 2727,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "never",
},
["Ораномонос Вечноветвящаяся"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9010,
["RecLevel"] = 60,
["Raid"] = true,
},
["Гробница королей"] = {
["LFDID"] = 2880,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Пещеры Черной горы"] = {
["LFDID"] = 2321,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Гнездовье"] = {
["LFDID"] = 2808,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Мародон - Оскверненный грот"] = {
["LFDID"] = 272,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Рухмар"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1262,
["RecLevel"] = 40,
["Raid"] = true,
},
["Чертоги Доблести"] = {
["LFDID"] = 1194,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Крыла Тьмы"] = {
["LFDID"] = 50,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Мертвые копи"] = {
["LFDID"] = 2636,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Академия Алгет'ар"] = {
["LFDID"] = 2464,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Шпили Перерождения"] = {
["LFDID"] = 2122,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Cataclysm"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 300,
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Драгон Зиморожденный"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1789,
["RecLevel"] = 45,
["Raid"] = true,
},
["Лазуретос"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2199,
["RecLevel"] = 50,
["Raid"] = true,
},
["Крепость Драк'Тарон"] = {
["LFDID"] = 215,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Цитадель Ночи"] = {
["LFDID"] = 1353,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Огненные Просторы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 2026,
},
["Нургаш Жижерожденный"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2433,
["RecLevel"] = 60,
["Raid"] = true,
},
["Рассвет Бесконечности"] = {
["LFDID"] = 2430,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Рассвет Бесконечности: падение Галакронда"] = {
["LFDID"] = 2529,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Сетеккские залы"] = {
["LFDID"] = 180,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Осада Боралуса"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2729,
},
["Мор'гет"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2456,
["RecLevel"] = 60,
["Raid"] = true,
},
["Вук'лаз Землелом"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2381,
["RecLevel"] = 50,
["Raid"] = true,
},
["Шлаковые шахты Кровавого Молота"] = {
["LFDID"] = 1973,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Гробница Саргераса"] = {
["LFDID"] = 1527,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Разрушенные залы"] = {
["LFDID"] = 1014,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Каменные Недра"] = {
["LFDID"] = 1148,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Шар'тос"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1763,
["RecLevel"] = 45,
["Raid"] = true,
},
["Испытание чемпиона"] = {
["LFDID"] = 249,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Литейная клана Черной горы"] = {
["LFDID"] = 900,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Дворец Могу'шан"] = {
["LFDID"] = 2551,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Воспоминания Азерот: Cataclysm"] = {
["LFDID"] = 2018,
["Expansion"] = 7,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Тазавеш: улицы чудес"] = {
["LFDID"] = 2995,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Изумрудный Кошмар"] = {
["LFDID"] = 1350,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Чаща Темного Сердца"] = {
["LFDID"] = 2277,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье \"Времени Сумерек\" (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 434,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Рубиновое святилище"] = {
["LFDID"] = 294,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Вершина Утгард"] = {
["LFDID"] = 1020,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Всадник без головы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 285,
},
["Королевская химическая компания"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 1,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 288,
},
["Та Сторона"] = {
["LFDID"] = 2118,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Кровавые катакомбы"] = {
["LFDID"] = 2117,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Цитадель Темного Молота"] = {
["LFDID"] = 2043,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 7,
["Show"] = "saved",
},
["Случайное подземелье Burning Crusade"] = {
["Show"] = "saved",
["Expansion"] = 1,
["LFDID"] = 259,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Экспедиции на остров Кишащий"] = {
["LFDID"] = 2054,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = true,
},
["Руины Ан'Киража"] = {
["LFDID"] = 160,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Базрикрон"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2506,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ана-Муз"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1790,
["RecLevel"] = 45,
["Raid"] = true,
},
["Чертоги Молний"] = {
["LFDID"] = 1018,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Возвращение в Каражан (нижняя часть)"] = {
["LFDID"] = 1475,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Градовый голем"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2197,
["RecLevel"] = 50,
["Raid"] = true,
},
["Йорундалль"] = {
["LFDID"] = 2041,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["Show"] = "saved",
},
["Джи'арак"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2141,
["RecLevel"] = 50,
["Raid"] = true,
},
["Нитхегг"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1749,
["RecLevel"] = 45,
["Raid"] = true,
},
["Вершина Смерча"] = {
["LFDID"] = 1147,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайные островные экспедиции – эпохальный режим"] = {
["LFDID"] = 1891,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 50,
},
["Святилище Господства"] = {
["LFDID"] = 2228,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Госпожа Фолнуна"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2010,
["RecLevel"] = 45,
["Raid"] = true,
},
["Четыре небожителя"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 857,
["RecLevel"] = 35,
["Raid"] = true,
},
["Подгнилье"] = {
["LFDID"] = 1712,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Монастырь Алого ордена"] = {
["LFDID"] = 2555,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Властитель преисподней Веролом"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2015,
["RecLevel"] = 45,
["Raid"] = true,
},
["Струнраан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2515,
["RecLevel"] = 70,
["Raid"] = true,
},
["Верховный владыка Каззак"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1452,
["RecLevel"] = 40,
["Raid"] = true,
},
["Бруталл"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1883,
["RecLevel"] = 45,
["Raid"] = true,
},
["Механар"] = {
["LFDID"] = 192,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Нелтариона"] = {
["LFDID"] = 2279,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чумные каскады"] = {
["LFDID"] = 2121,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Mists of Pandaria"] = {
["Show"] = "saved",
["Expansion"] = 4,
["LFDID"] = 463,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Приорат Священного Пламени"] = {
["Expansion"] = 10,
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2649:23:7|h[Приорат Священного Пламени]|h|r",
["ID"] = 595814890,
["Locked"] = false,
},
},
["Вольтчара - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2649:23:7|h[Приорат Священного Пламени]|h|r",
["ID"] = 595830832,
["Locked"] = false,
},
},
["Show"] = "never",
["LFDID"] = 2999,
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2649:23:7|h[Приорат Священного Пламени]|h|r",
["ID"] = 1185852242,
["Locked"] = false,
},
},
["Raid"] = false,
},
["Манагорн Омега"] = {
["Expansion"] = 10,
["Мальдика - Свежеватель Душ"] = {
[14] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2810:14:255|h[Манагорн Омега]|h|r",
["ID"] = 433190775,
["Locked"] = true,
},
[17] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2810:17:63|h[Манагорн Омега]|h|r",
["ID"] = 2627421567,
["Locked"] = true,
},
[15] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2810:15:63|h[Манагорн Омега]|h|r",
["ID"] = 1186872991,
["Locked"] = true,
},
},
["Вольтчара - Свежеватель Душ"] = {
[14] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2810:14:255|h[Манагорн Омега]|h|r",
["ID"] = 375768083,
["Locked"] = true,
},
[17] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2810:17:63|h[Манагорн Омега]|h|r",
["ID"] = 2627560778,
["Locked"] = true,
},
[15] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2810:15:63|h[Манагорн Омега]|h|r",
["ID"] = 468039260,
["Locked"] = true,
},
},
["LFDID"] = 2805,
["Show"] = "saved",
["RecLevel"] = 80,
["Бимладен - Ревущий фьорд"] = {
[14] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2810:14:255|h[Манагорн Омега]|h|r",
["ID"] = 433138573,
["Locked"] = true,
},
[16] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2810:16:6|h[Манагорн Омега]|h|r",
["ID"] = 433272188,
["Locked"] = true,
},
[17] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2810:17:14|h[Манагорн Омега]|h|r",
["ID"] = 2617823525,
["Locked"] = false,
},
[15] = {
["Expires"] = 1756267202,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2810:15:63|h[Манагорн Омега]|h|r",
["ID"] = 2626386442,
["Locked"] = true,
},
},
["Raid"] = true,
},
["Левантия"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1769,
["RecLevel"] = 45,
["Raid"] = true,
},
["Железные доки"] = {
["LFDID"] = 1974,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Святилище Штормов"] = {
["LFDID"] = 2877,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Стратхольм - Главные врата"] = {
["LFDID"] = 40,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Мор'гет Мучитель проклятых"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9012,
["RecLevel"] = 60,
["Raid"] = true,
},
["Время Сумерек"] = {
["LFDID"] = 439,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Вестник войны Йенаж"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2198,
["RecLevel"] = 50,
["Raid"] = true,
},
["Усадьба Уэйкрестов"] = {
["LFDID"] = 2878,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Зул'Фаррак"] = {
["LFDID"] = 2640,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Узилище"] = {
["LFDID"] = 1015,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ульдаман: наследие Тира"] = {
["LFDID"] = 2465,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Lich King"] = {
["Show"] = "saved",
["Expansion"] = 2,
["LFDID"] = 261,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["\"Валинор\""] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2430,
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье Cataclysm (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 301,
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Амирдрассил, Надежда Сна"] = {
["LFDID"] = 2504,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Гробница Предвечных"] = {
["LFDID"] = 2290,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье (The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2516,
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье в героическом режиме (Dragonflight)"] = {
["Show"] = "saved",
["Expansion"] = 9,
["LFDID"] = 2351,
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Осада храма Нюцзао"] = {
["LFDID"] = 2547,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Сумеречный бастион"] = {
["LFDID"] = 316,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Векемара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2363,
["RecLevel"] = 50,
["Raid"] = true,
},
["Великая императрица Шек'зара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2378,
["RecLevel"] = 50,
["Raid"] = true,
},
["Огненные Недра"] = {
["LFDID"] = 48,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Дров / Тарлна"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1211,
["RecLevel"] = 40,
["Raid"] = true,
},
["Гундрак"] = {
["LFDID"] = 1017,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["\"Валинор\", Светоч Эпох"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9008,
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье Warlords of Draenor (героич.)"] = {
["Show"] = "saved",
["Expansion"] = 5,
["LFDID"] = 789,
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["Аберрий, Затененное Горнило"] = {
["LFDID"] = 2405,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Нелтарий"] = {
["LFDID"] = 2440,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
},
["histGeneration"] = 5576,
["Warfront"] = {
{
["contributing"] = false,
["captureSide"] = "Alliance",
},
{
["contributing"] = false,
["captureSide"] = "Horde",
},
},
["DBVersion"] = 12,
["Tooltip"] = {
["CurrencySortName"] = false,
["Emissary6"] = false,
["TrackBonus"] = true,
["TrackParagon"] = false,
["Currency3220"] = false,
["Currency3008"] = true,
["CombineWorldBosses"] = false,
["HistoryText"] = false,
["ShowCategories"] = false,
["Currency2807"] = false,
["Currency3090"] = false,
["Currency3141"] = true,
["Currency2806"] = false,
["ShowRandom"] = false,
["Currency3010"] = false,
["Currency2917"] = false,
["TimewornMythicKey"] = true,
["Currency3110"] = false,
["TrackDeserter"] = true,
["Currency2812"] = false,
["Currency2915"] = false,
["Currency2003"] = false,
["Currency2778"] = false,
["Currency3116"] = false,
["Currency3023"] = false,
["MythicKeyBest"] = true,
["ServerSort"] = true,
["TrackLFG"] = true,
["Currency3269"] = true,
["ReverseInstances"] = false,
["CurrencyMax"] = false,
["Currency2800"] = false,
["Scale"] = 1,
["Currency3286"] = true,
["Currency3109"] = false,
["ReportResets"] = false,
["Currency2813"] = false,
["NewFirst"] = true,
["Currency2809"] = false,
["posx"] = 689.501220703125,
["CategorySort"] = "EXPANSION",
["SelfAlways"] = false,
["ShowServer"] = false,
["NumberFormat"] = true,
["Warfront1"] = false,
["EmissaryShowCompleted"] = true,
["CombineEmissary"] = false,
["posy"] = 369.857421875,
["Currency3284"] = true,
["CombineCalling"] = false,
["Currency3226"] = false,
["Currency3288"] = true,
["Currency3356"] = true,
["CombineLFR"] = true,
["CurrencyEarned"] = true,
["Currency3278"] = false,
["ServerOnly"] = false,
["CurrencyValueColor"] = true,
["TrackDailyQuests"] = true,
["Currency3028"] = false,
["Currency3132"] = false,
["TrackWeeklyQuests"] = true,
["Currency3089"] = false,
["LimitWarn"] = true,
["Calling"] = false,
["Currency3149"] = false,
["Currency3290"] = true,
["Currency2914"] = false,
["MythicKey"] = true,
["ShowHoliday"] = false,
["Currency3303"] = false,
["CategorySpaces"] = false,
["Currency3108"] = false,
["Currency3218"] = false,
["KeystoneReportTarget"] = "EXPORT",
["Currency3107"] = false,
["ShowSoloCategory"] = false,
["Currency3056"] = false,
["ShowExpired"] = false,
["RaidsFirst"] = true,
["ConnectedRealms"] = "group",
["FitToScreen"] = true,
["Emissary7"] = false,
["Currency2815"] = false,
["AbbreviateKeystone"] = false,
["EmissaryFullName"] = true,
["Currency2916"] = false,
["Currency3100"] = false,
["ShowHints"] = true,
["RowHighlight"] = 0.1,
["AugmentBonus"] = true,
["Warfront2"] = false,
["TrackPlayed"] = true,
["Currency2245"] = false,
["TrackSkills"] = false,
["CallingShowCompleted"] = false,
["SelfFirst"] = true,
["Currency3216"] = false,
["Currency2803"] = false,
},
["RealmMap"] = {
{
"Aegwynn",
"Bonechewer",
"Daggerspine",
"Garrosh",
"Gurubashi",
"Hakkar",
},
["Daggerspine"] = 1,
["Hakkar"] = 1,
["Garrosh"] = 1,
["Gurubashi"] = 1,
["Aegwynn"] = 1,
["Bonechewer"] = 1,
},
["History"] = {
},
["MinimapIcon"] = {
["hide"] = false,
["showInCompartment"] = true,
},
["Toons"] = {
["Джуставар - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["BGBRating"] = {
[3] = 0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 383.4375,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 644.5625,
["LastSeen"] = 1754959337,
["Order"] = 50,
["Class"] = "WARRIOR",
["ILPvp"] = 644.5625,
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 1,
},
[3278] = {
["totalEarned"] = 6,
["totalMax"] = 6,
["amount"] = 6,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1710] = {
["amount"] = 20,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 14,
},
[1716] = {
["amount"] = 21,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 7,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 20,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 1400,
},
[3107] = {
["amount"] = 0,
},
[1602] = {
["amount"] = 0,
},
[3269] = {
["totalMax"] = 8,
["amount"] = 0,
},
},
["Warmode"] = true,
["Zone"] = "Дорногал",
["Level"] = 80,
["oRace"] = "BloodElf",
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1756267199,
},
["PlayedTotal"] = 486496,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1756180799,
["Money"] = 123559026,
["Covenant"] = 1,
["WeeklyResetTime"] = 1756267199,
["Progress"] = {
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-karesh-warrants"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-urge-to-surge"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[89293] = {
["show"] = false,
},
[89294] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[81691] = {
["show"] = false,
},
[81647] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[81650] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
["show"] = true,
[82355] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
["show"] = true,
[87306] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-ecological-succession"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-more-than-just-a-phase"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-s3-weekly-cache"] = {
["show"] = true,
[91175] = {
["show"] = false,
},
[91176] = {
["show"] = false,
},
[91177] = {
["show"] = false,
},
[91178] = {
["show"] = false,
},
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-reduce-reuse-resell"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-many-jobs-handle-it"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["SpecializationIDs"] = {
71,
72,
73,
},
["PlayedLevel"] = 747,
["LClass"] = "Воин",
["MaxXP"] = 100000000,
["Skills"] = {
},
["MythicKey"] = {
},
["Calling"] = {
},
},
["Мальдика - Свежеватель Душ"] = {
["lastbossyell"] = "Переписчица душ: Эпохальный ключ",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["money"] = 2000000,
},
},
{
["questReward"] = {
["itemName"] = "Сундук со снаряжением империи Зандалари",
["itemLvl"] = 99,
["quality"] = 4,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["currencyID"] = 1553,
["quantity"] = 600,
},
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Жрица",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
[3] = 0,
},
["lastbosstime"] = 1756067179,
["Covenant"] = 3,
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 690.3125,
["Quests"] = {
[82678] = {
["Expires"] = 1756267199,
["Zone"] = {
["mapType"] = 4,
["mapID"] = 2367,
["name"] = "Хранилище воспоминаний",
["parentMapID"] = 2248,
["flags"] = 524288,
},
["Title"] = "Архивы: первый диск",
["Link"] = "|cffffff00|Hquest:82678:90|h[Архивы: первый диск]|h|r",
},
[82679] = {
["Expires"] = 1756267199,
["Zone"] = {
["mapType"] = 4,
["mapID"] = 2367,
["name"] = "Хранилище воспоминаний",
["parentMapID"] = 2248,
["flags"] = 524288,
},
["Title"] = "Архивы: в поисках истины",
["Link"] = "|cffffff00|Hquest:82679:90|h[Архивы: в поисках истины]|h|r",
},
},
["Paragon"] = {
},
["IL"] = 699.0625,
["LastSeen"] = 1756114432,
["SpecializationIDs"] = {
256,
257,
258,
},
["Class"] = "PRIEST",
["WeeklyResetTime"] = 1756267199,
["ILPvp"] = 699.0625,
["Progress"] = {
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = true,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[89293] = {
["show"] = false,
},
[89294] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[81650] = {
["show"] = false,
},
[81647] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[81649] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-ecological-succession"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-more-than-just-a-phase"] = {
"Выполните задачи с фазовыми переходами (0%)",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 100,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0%",
["objectiveType"] = "progressbar",
["isFinish"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = true,
["isComplete"] = true,
},
["tww-urge-to-surge"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-many-jobs-handle-it"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-reduce-reuse-resell"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["great-vault-raid"] = {
15,
15,
15,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-s3-weekly-cache"] = {
["show"] = true,
[91175] = {
["show"] = false,
},
[91176] = {
["show"] = false,
},
[91177] = {
["show"] = false,
},
[91178] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-karesh-warrants"] = {
["show"] = true,
["isComplete"] = true,
},
},
["currency"] = {
[1191] = {
["amount"] = 0,
},
[2815] = {
["amount"] = 3025,
},
[1904] = {
["totalEarned"] = 1779,
["totalMax"] = 3510,
["amount"] = 109,
},
[1719] = {
["amount"] = 2469,
},
[3288] = {
["totalEarned"] = 180,
["totalMax"] = 180,
["amount"] = 105,
},
[3107] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[3] = 33190,
},
["totalMax"] = 200000,
["amount"] = 33190,
},
[1718] = {
["amount"] = 0,
},
[1979] = {
["amount"] = 522,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[2706] = {
["amount"] = 0,
},
[2774] = {
["amount"] = 17,
},
[3100] = {
["amount"] = 0,
},
[3108] = {
["amount"] = 0,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 7,
},
[1767] = {
["amount"] = 2,
},
[3132] = {
["totalMax"] = 25,
["amount"] = 7,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1716] = {
["amount"] = 100,
},
[2000] = {
["amount"] = 44,
},
[3290] = {
["totalEarned"] = 180,
["totalMax"] = 180,
["amount"] = 180,
},
[3109] = {
["amount"] = 0,
},
[1166] = {
["amount"] = 5400,
},
[2707] = {
["amount"] = 0,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 2290,
},
[3141] = {
["totalEarned"] = 3,
["totalMax"] = 4,
["amount"] = 3,
},
[3023] = {
["totalEarned"] = 19,
["totalMax"] = 28,
["amount"] = 19,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2914] = {
["amount"] = 0,
},
[3110] = {
["amount"] = 0,
},
[2803] = {
["amount"] = 230,
},
[3149] = {
["amount"] = 193,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 2000,
},
[2708] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 8970,
},
[3284] = {
["totalEarned"] = 270,
["totalMax"] = 270,
["amount"] = 285,
},
[1977] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3056] = {
["amount"] = 3825,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[2709] = {
["amount"] = 0,
},
[3269] = {
["totalMax"] = 8,
["amount"] = 1,
},
[1560] = {
["amount"] = 5617,
},
[1721] = {
["amount"] = 27,
},
[2915] = {
["amount"] = 0,
},
[2009] = {
["amount"] = 47052,
},
[1828] = {
["amount"] = 59010,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 250,
},
[1822] = {
["covenant"] = {
[3] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[3278] = {
["totalEarned"] = 12,
["totalMax"] = 12,
["amount"] = 12,
},
[3286] = {
["totalEarned"] = 270,
["totalMax"] = 270,
["amount"] = 185,
},
[2916] = {
["amount"] = 0,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1885] = {
["amount"] = 1,
},
[1602] = {
["totalMax"] = 2200,
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1810] = {
["covenant"] = {
[3] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[3090] = {
["amount"] = 6172,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 3,
},
[2917] = {
["amount"] = 0,
},
},
["DailyResetTime"] = 1756180799,
["Warmode"] = false,
["BGBRating"] = {
0,
[3] = 0,
},
["Level"] = 80,
["Show"] = "saved",
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
10,
10,
10,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["mapChallengeModeID"] = 378,
["level"] = 10,
["runScore"] = 330,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: улицы Чудес",
["thisWeek"] = true,
["mapChallengeModeID"] = 391,
["level"] = 10,
["runScore"] = 330,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: улицы Чудес",
["thisWeek"] = true,
["mapChallengeModeID"] = 391,
["level"] = 10,
["runScore"] = 324,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: гамбит Со'леи",
["thisWeek"] = true,
["mapChallengeModeID"] = 392,
["level"] = 10,
["runScore"] = 328,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: гамбит Со'леи",
["thisWeek"] = true,
["mapChallengeModeID"] = 392,
["level"] = 10,
["runScore"] = 328,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "\"Сияющий Рассвет\"",
["thisWeek"] = true,
["mapChallengeModeID"] = 505,
["level"] = 10,
["runScore"] = 327,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "\"Сияющий Рассвет\"",
["thisWeek"] = true,
["mapChallengeModeID"] = 505,
["level"] = 10,
["runScore"] = 323,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["mapChallengeModeID"] = 542,
["level"] = 10,
["runScore"] = 325,
["rewardLevel"] = 707,
},
},
["ResetTime"] = 1756267199,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["PlayedTotal"] = 5504477,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1756067180,
["Money"] = 5620433868,
["MaxXP"] = 100000000,
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Испытания Арденвельда",
["questID"] = 60438,
["expiredTime"] = 1756180799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Помощь Ревендрету",
["questID"] = 60382,
["expiredTime"] = 1756267199,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Беды на родине",
["questID"] = 60419,
["expiredTime"] = 1756353599,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["MythicPlusScore"] = 2593,
["lastboss"] = "Переписчица душ: Эпохальный ключ",
["Order"] = 50,
["PlayedLevel"] = 1607560,
["MythicKey"] = {
["level"] = 10,
["mapID"] = 542,
["ResetTime"] = 1756267199,
["link"] = "|cnIQ4:|Hkeystone:180653:542:10:162:10:9:0:0|h[Ключ: Заповедник \"Аль'дани\" (10)]|h|r",
},
["Arena3v3rating"] = 0,
["Skills"] = {
},
["oRace"] = "BloodElf",
["Zone"] = "Дорногал",
},
["Сорчистино - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["BGBRating"] = {
0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 466.25,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 613.6875,
["LastSeen"] = 1754478477,
["Order"] = 50,
["Class"] = "WARLOCK",
["ILPvp"] = 613.6875,
["currency"] = {
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 4,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 442,
},
[1803] = {
["amount"] = 1265,
},
[1719] = {
["amount"] = 122,
},
[1166] = {
["amount"] = 3530,
},
[3269] = {
["totalMax"] = 8,
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 45,
},
[1560] = {
["amount"] = 1181,
},
[1220] = {
["amount"] = 5255,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 5728,
},
[1275] = {
["amount"] = 150,
},
[1710] = {
["amount"] = 4,
},
[1226] = {
["amount"] = 11010,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 12450,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 46,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 195,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 40,
},
},
["Warmode"] = false,
["Calling"] = {
},
["Level"] = 80,
["MythicKey"] = {
},
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1756267199,
},
["PlayedTotal"] = 3096931,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["Money"] = 119628666,
["MaxXP"] = 100000000,
["LClass"] = "Чернокнижница",
["Progress"] = {
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-many-jobs-handle-it"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-urge-to-surge"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[89293] = {
["show"] = false,
},
[89294] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[81691] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[81650] = {
["show"] = false,
},
["show"] = true,
[82852] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
[81647] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
["show"] = true,
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-ecological-succession"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
["show"] = true,
[88945] = {
["show"] = false,
},
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-more-than-just-a-phase"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["The Severed Threads"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["tww-reduce-reuse-resell"] = {
["show"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["SpecializationIDs"] = {
265,
266,
267,
},
["PlayedLevel"] = 177,
["WeeklyResetTime"] = 1756267199,
["Covenant"] = 3,
["DailyResetTime"] = 1756180799,
["oRace"] = "BloodElf",
["Zone"] = "Дорногал",
},
["Сэйвмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["BGBRating"] = {
0,
0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 604.4375,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 640.25,
["LastSeen"] = 1754945044,
["Order"] = 50,
["Class"] = "PALADIN",
["ILPvp"] = 640.25,
["currency"] = {
[824] = {
["totalMax"] = 10000,
["amount"] = 4076,
},
[2815] = {
["amount"] = 6181,
},
[1904] = {
["totalEarned"] = 3148,
["totalMax"] = 3510,
["amount"] = 188,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 0,
},
[1979] = {
["amount"] = 487,
},
[1810] = {
["covenant"] = {
[4] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1767] = {
["amount"] = 5749,
},
[738] = {
["amount"] = 1,
},
[1716] = {
["amount"] = 25,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 75,
},
[1220] = {
["amount"] = 770,
},
[1602] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1129] = {
["weeklyMax"] = 3,
["totalMax"] = 20,
["amount"] = 0,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 1483,
},
[3023] = {
["totalEarned"] = 4,
["totalMax"] = 28,
["amount"] = 4,
},
[2914] = {
["amount"] = 0,
},
[823] = {
["amount"] = 183,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 126,
},
[2803] = {
["amount"] = 0,
},
[3056] = {
["amount"] = 1890,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 60,
},
[1906] = {
["amount"] = 330,
},
[1721] = {
["amount"] = 0,
},
[1977] = {
["amount"] = 83,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 225,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1718] = {
["amount"] = 0,
},
[3269] = {
["totalMax"] = 8,
["amount"] = 0,
},
[1560] = {
["amount"] = 4,
},
[1501] = {
["amount"] = 1,
},
[2009] = {
["amount"] = 20421,
},
[1155] = {
["totalMax"] = 1600,
["amount"] = 1229,
},
[1828] = {
["amount"] = 14146,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1710] = {
["amount"] = 27,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 3,
},
[3278] = {
["totalEarned"] = 6,
["totalMax"] = 6,
["amount"] = 6,
},
[1533] = {
["amount"] = 2302,
},
[2916] = {
["amount"] = 0,
},
[1226] = {
["amount"] = 7179,
},
[2915] = {
["amount"] = 0,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1931] = {
["amount"] = 398,
},
[2000] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[4] = 37675,
},
["totalMax"] = 200000,
["amount"] = 37675,
},
[1191] = {
["amount"] = 0,
},
[1275] = {
["amount"] = 234,
},
},
["Warmode"] = false,
["Zone"] = "Оргриммар",
["Level"] = 80,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1756180799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1756267199,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1756353599,
},
["unlocked"] = true,
},
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 10502061,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1756180799,
["Money"] = 156289277,
["Covenant"] = 4,
["WeeklyResetTime"] = 1756267199,
["Progress"] = {
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-karesh-warrants"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-urge-to-surge"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[89293] = {
["show"] = false,
},
[89294] = {
["show"] = false,
},
[81647] = {
["show"] = false,
},
[81691] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
["show"] = true,
[81650] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-ecological-succession"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-more-than-just-a-phase"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-s3-weekly-cache"] = {
["show"] = true,
[91175] = {
["show"] = false,
},
[91176] = {
["show"] = false,
},
[91177] = {
["show"] = false,
},
[91178] = {
["show"] = false,
},
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-reduce-reuse-resell"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["The Severed Threads"] = {
"Выполняйте задачи в Аз-Кахете (95%)",
"Осмотрите товары пактов у поставщицы Ямас: 1/1 (необязательно)",
["show"] = true,
["numFulfilled"] = 95,
["numRequired"] = 100,
["isComplete"] = false,
["leaderboardCount"] = 2,
["text"] = "95%",
["objectiveType"] = "progressbar",
["isFinish"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-many-jobs-handle-it"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
},
["MythicPlusScore"] = 0,
["SpecializationIDs"] = {
65,
66,
70,
},
["PlayedLevel"] = 175167,
["MaxXP"] = 100000000,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1756267199,
},
["Skills"] = {
},
["oRace"] = "BloodElf",
["LClass"] = "Паладин",
},
["Бимладен - Ревущий фьорд"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Полевой набор стража",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["quantity"] = 600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["money"] = 2000000,
},
},
{
["questReward"] = {
["quantity"] = 600,
["currencyID"] = 1553,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Ночная эльфийка",
["LClass"] = "Друид",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
0,
},
["lastbosstime"] = 1755991372,
["lastbossyell"] = "Глашатай Бреция",
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Money"] = 2938492492,
["Faction"] = "Alliance",
["ILe"] = 705.375,
["Quests"] = {
[82491] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Ара-Кара, Город Отголосков",
["Link"] = "|cffffff00|Hquest:82491:90|h[Душа мира: Ара-Кара, Город Отголосков]|h|r",
},
[82495] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Искроварня",
["Link"] = "|cffffff00|Hquest:82495:90|h[Душа мира: Искроварня]|h|r",
},
[82499] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: приорат Священного Пламени",
["Link"] = "|cffffff00|Hquest:82499:90|h[Душа мира: приорат Священного Пламени]|h|r",
},
[87417] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:87417:90|h[Душа мира: подземелья]|h|r",
["Title"] = "Душа мира: подземелья",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82511] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Машина пробуждения",
["Link"] = "|cffffff00|Hquest:82511:90|h[Душа мира: Машина пробуждения]|h|r",
},
[82452] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:82452:90|h[Воспоминание души мира: локальные задания]|h|r",
["Title"] = "Воспоминание души мира: локальные задания",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[91855] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:91855:2838|h[Душа мира: локальные задания на К'ареше]|h|r",
["Title"] = "Душа мира: локальные задания на К'ареше",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[91052] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: перегруженные вылазки",
["Link"] = "|cffffff00|Hquest:91052:90|h[Душа мира: перегруженные вылазки]|h|r",
},
[82496] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Город Нитей",
["Link"] = "|cffffff00|Hquest:82496:90|h[Душа мира: Город Нитей]|h|r",
},
[85461] = {
["Expires"] = 1756267199,
["Title"] = "Поход за едой",
["Link"] = "|cffffff00|Hquest:85461:3007|h[Поход за едой]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2371,
["name"] = "К'ареш",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
[87422] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: локальные задания в Нижней Шахте",
["Link"] = "|cffffff00|Hquest:87422:90|h[Душа мира: локальные задания в Нижней Шахте]|h|r",
},
[82449] = {
["Expires"] = 1756267199,
["Title"] = "Зов души мира",
["Link"] = "|cffffff00|Hquest:82449:90|h[Зов души мира]|h|r",
},
[82453] = {
["Expires"] = 1756267199,
["Title"] = "Воспоминание души мира: на бис!",
["Link"] = "|cffffff00|Hquest:82453:90|h[Воспоминание души мира: на бис!]|h|r",
},
[90545] = {
["Expires"] = 1756267199,
["Title"] = "Проблематичная рыбалка",
["Link"] = "|cffffff00|Hquest:90545:3007|h[Проблематичная рыбалка]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2371,
["name"] = "К'ареш",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
[82493] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:82493:90|h[Душа мира: \"Сияющий Рассвет\"]|h|r",
["Title"] = "Душа мира: \"Сияющий Рассвет\"",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[87419] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: вылазки",
["Link"] = "|cffffff00|Hquest:87419:90|h[Душа мира: вылазки]|h|r",
},
[87423] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: исследователь Нижней Шахты",
["Link"] = "|cffffff00|Hquest:87423:90|h[Душа мира: исследователь Нижней Шахты]|h|r",
},
[82706] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:82706:90|h[Вылазки: изучение мира]|h|r",
["Title"] = "Вылазки: изучение мира",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[89514] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: возвращение в жуткие видения",
["Link"] = "|cffffff00|Hquest:89514:90|h[Душа мира: возвращение в жуткие видения]|h|r",
},
[91093] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:91093:4159|h[Фазовая фантастика]|h|r",
["Title"] = "Фазовая фантастика",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2371,
["name"] = "К'ареш",
["parentMapID"] = 2274,
["flags"] = 6,
},
},
[82659] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Неруб'арский дворец",
["Link"] = "|cffffff00|Hquest:82659:90|h[Душа мира: Неруб'арский дворец]|h|r",
},
[82482] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: разнюхивание",
["Link"] = "|cffffff00|Hquest:82482:90|h[Душа мира: разнюхивание]|h|r",
},
[82679] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:82679:90|h[Архивы: в поисках истины]|h|r",
["Title"] = "Архивы: в поисках истины",
["Zone"] = {
["mapType"] = 4,
["mapID"] = 2367,
["name"] = "Хранилище воспоминаний",
["parentMapID"] = 2248,
["flags"] = 524288,
},
},
[82498] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: расселина Темного Пламени",
["Link"] = "|cffffff00|Hquest:82498:90|h[Душа мира: расселина Темного Пламени]|h|r",
},
[87424] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: боссы вне подземелья",
["Link"] = "|cffffff00|Hquest:87424:90|h[Душа мира: боссы вне подземелья]|h|r",
},
[89492] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Коварные Дуо под Куполом!",
["Link"] = "|cffffff00|Hquest:89492:90|h[Душа мира: Коварные Дуо под Куполом!]|h|r",
},
[82505] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Каменный Свод",
["Link"] = "|cffffff00|Hquest:82505:90|h[Душа мира: Каменный Свод]|h|r",
},
[82512] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: босс вне подземелья",
["Link"] = "|cffffff00|Hquest:82512:90|h[Душа мира: босс вне подземелья]|h|r",
},
[82500] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Гнездовье",
["Link"] = "|cffffff00|Hquest:82500:90|h[Душа мира: Гнездовье]|h|r",
},
[89294] = {
["Expires"] = 1756267199,
["Title"] = "Особое поручение: схожие взгляды",
["Link"] = "|cffffff00|Hquest:89294:90|h[Особое поручение: схожие взгляды]|h|r",
},
[85460] = {
["Expires"] = 1756267199,
["Title"] = "Экологическая сукцессия",
["Link"] = "|cffffff00|Hquest:85460:90|h[Экологическая сукцессия]|h|r",
},
[85459] = {
["Expires"] = 1756267199,
["Title"] = "План возмещения анимы",
["Link"] = "|cffffff00|Hquest:85459:3007|h[План возмещения анимы]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2371,
["name"] = "К'ареш",
["parentMapID"] = 2274,
["flags"] = 6,
},
["isDaily"] = false,
},
[82483] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: благодать Света",
["Link"] = "|cffffff00|Hquest:82483:90|h[Душа мира: благодать Света]|h|r",
},
[82516] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: заключение пакта",
["Link"] = "|cffffff00|Hquest:82516:90|h[Душа мира: заключение пакта]|h|r",
},
[89502] = {
["Expires"] = 1756267199,
["Title"] = "Душа мира: Сумерки",
["Link"] = "|cffffff00|Hquest:89502:90|h[Душа мира: Сумерки]|h|r",
},
},
["Paragon"] = {
2413,
},
["IL"] = 705.375,
["LastSeen"] = 1756126692,
["Order"] = 50,
["Class"] = "DRUID",
["oRace"] = "NightElf",
["ILPvp"] = 705.375,
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Испытания Арденвельда",
["questID"] = 60440,
["expiredTime"] = 1756180799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Помощь Ревендрету",
["questID"] = 60398,
["expiredTime"] = 1756267199,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Призыв Арденвельда",
["questID"] = 60423,
["expiredTime"] = 1756353599,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["currency"] = {
[1904] = {
["totalEarned"] = 3510,
["amount"] = 0,
["totalMax"] = 3510,
},
[515] = {
["amount"] = 10,
},
[2650] = {
["amount"] = 659,
},
[2809] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 47,
},
[1889] = {
["amount"] = 18,
},
[3286] = {
["totalEarned"] = 270,
["amount"] = 270,
["totalMax"] = 270,
},
[1721] = {
["amount"] = 28,
},
[1810] = {
["covenant"] = {
[4] = 4,
},
["amount"] = 4,
["totalMax"] = 100,
},
[1191] = {
["amount"] = 0,
},
[3288] = {
["totalEarned"] = 180,
["amount"] = 0,
["totalMax"] = 180,
},
[2812] = {
["amount"] = 0,
},
[3010] = {
["totalEarned"] = 11,
["amount"] = 11,
["totalMax"] = 18,
},
[738] = {
["amount"] = 4,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3290] = {
["totalEarned"] = 180,
["amount"] = 120,
["totalMax"] = 180,
},
[3100] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 45801,
},
[1717] = {
["amount"] = 604,
},
[2815] = {
["amount"] = 30176,
},
[2003] = {
["amount"] = 24731,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 1,
},
[3303] = {
["amount"] = 21,
},
[2594] = {
["amount"] = 3431,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1068,
},
[1560] = {
["amount"] = 16480,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 2645,
},
[1275] = {
["amount"] = 5,
},
[2709] = {
["amount"] = 0,
},
[2122] = {
["amount"] = 19,
},
[2916] = {
["amount"] = 0,
},
[3107] = {
["amount"] = 0,
},
[2123] = {
["amount"] = 0,
["totalMax"] = 1900,
},
[2409] = {
["totalEarned"] = 807,
["amount"] = 807,
},
[3108] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 740,
},
[2410] = {
["totalEarned"] = 1364,
["amount"] = 1364,
},
[3109] = {
["amount"] = 0,
},
[3141] = {
["totalEarned"] = 4,
["amount"] = 4,
["totalMax"] = 4,
},
[2411] = {
["totalEarned"] = 1498,
["amount"] = 1498,
},
[1166] = {
["amount"] = 1325,
},
[3110] = {
["amount"] = 0,
},
[3269] = {
["totalMax"] = 8,
["amount"] = 0,
},
[2412] = {
["totalEarned"] = 3984,
["amount"] = 3984,
},
[2413] = {
["amount"] = 28,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 15000,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1977] = {
["amount"] = 22,
},
[2777] = {
["amount"] = 2,
},
[1755] = {
["amount"] = 6794,
["relatedItemCount"] = 0,
},
[2118] = {
["amount"] = 34197,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 6102,
},
[2807] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[4] = 34350,
},
["amount"] = 34350,
["totalMax"] = 200000,
},
[2009] = {
["amount"] = 41885,
},
[2774] = {
["amount"] = 23,
},
[1931] = {
["amount"] = 9542,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[2917] = {
["amount"] = 0,
},
[1979] = {
["amount"] = 558,
},
[2915] = {
["amount"] = 0,
},
[1767] = {
["amount"] = 13155,
},
[3149] = {
["amount"] = 2810,
},
[2800] = {
["totalEarned"] = 12,
["amount"] = 12,
["totalMax"] = 30,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 4,
},
[1533] = {
["amount"] = 3588,
},
[3023] = {
["totalEarned"] = 19,
["amount"] = 19,
["totalMax"] = 28,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 13,
},
[3278] = {
["totalEarned"] = 12,
["amount"] = 12,
["totalMax"] = 12,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 35,
},
[2707] = {
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["amount"] = 80,
["totalMax"] = 80,
},
[3132] = {
["totalMax"] = 25,
["amount"] = 21,
},
[2803] = {
["amount"] = 1517,
},
[2708] = {
["amount"] = 0,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3090] = {
["amount"] = 3207,
},
[3056] = {
["amount"] = 15076,
},
[1710] = {
["amount"] = 945,
},
[1220] = {
["amount"] = 3293,
},
[3218] = {
["amount"] = 1,
},
[1719] = {
["amount"] = 7096,
},
[3028] = {
["amount"] = 11,
["relatedItemCount"] = 0,
},
[2806] = {
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 25,
},
[3284] = {
["totalEarned"] = 270,
["amount"] = 315,
["totalMax"] = 270,
},
[1602] = {
["amount"] = 0,
["totalMax"] = 2200,
},
[2914] = {
["amount"] = 0,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 10,
},
},
["DailyResetTime"] = 1756180799,
["Warmode"] = false,
["WeeklyResetTime"] = 1756267199,
["Level"] = 80,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
13,
11,
10,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["level"] = 13,
["mapChallengeModeID"] = 542,
["runScore"] = 376,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Ара-Кара, Город Отголосков",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 503,
["runScore"] = 367,
["rewardLevel"] = 707,
},
{
["completed"] = false,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 378,
["runScore"] = 297,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: улицы Чудес",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 391,
["runScore"] = 339,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 378,
["runScore"] = 326,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 378,
["runScore"] = 328,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: гамбит Со'леи",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 392,
["runScore"] = 330,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: гамбит Со'леи",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 392,
["runScore"] = 325,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Ара-Кара, Город Отголосков",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 503,
["runScore"] = 328,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "\"Сияющий Рассвет\"",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 505,
["runScore"] = 329,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 525,
["runScore"] = 328,
["rewardLevel"] = 707,
},
{
["completed"] = false,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 542,
["runScore"] = 294,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 542,
["runScore"] = 330,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 542,
["runScore"] = 328,
["rewardLevel"] = 707,
},
},
["ResetTime"] = 1756267199,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["PlayedTotal"] = 30924332,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1756126583,
["MaxXP"] = 100000000,
["MythicKey"] = {
["level"] = 12,
["mapID"] = 499,
["ResetTime"] = 1756267199,
["link"] = "|cnIQ4:|Hkeystone:180653:499:12:10:9:147:0:0|h[Ключ: Приорат Священного Пламени (12)]|h|r",
},
["lastboss"] = "Со'азми: Эпохальный ключ",
["MythicPlusScore"] = 2858,
["Covenant"] = 4,
["PlayedLevel"] = 3295186,
["BGBRating"] = {
0,
0,
0,
0,
},
["SpecializationIDs"] = {
102,
103,
104,
105,
},
["Skills"] = {
},
["Progress"] = {
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["tww-biergoth-dungeon-quest"] = {
["show"] = true,
["isComplete"] = true,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = true,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[89293] = {
["show"] = false,
},
[89294] = {
["show"] = true,
["isComplete"] = true,
},
[82787] = {
["show"] = false,
},
[81691] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
["show"] = true,
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
[81647] = {
["show"] = false,
},
[81650] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-ecological-succession"] = {
["show"] = true,
["isComplete"] = true,
},
["df-time-rift"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-more-than-just-a-phase"] = {
["show"] = true,
["isComplete"] = true,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = true,
["isComplete"] = true,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = true,
["isComplete"] = true,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-s3-weekly-cache"] = {
["show"] = true,
[91175] = {
["show"] = true,
["isComplete"] = true,
},
[91176] = {
["show"] = true,
["isComplete"] = true,
},
[91177] = {
["show"] = true,
["isComplete"] = true,
},
[91178] = {
["show"] = false,
},
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = true,
["isComplete"] = true,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["great-vault-raid"] = {
16,
15,
15,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["great-vault-world"] = {
1,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-reduce-reuse-resell"] = {
["show"] = false,
},
["tww-many-jobs-handle-it"] = {
["show"] = false,
},
["tww-urge-to-surge"] = {
["show"] = false,
},
["tww-karesh-warrants"] = {
["show"] = true,
["isComplete"] = true,
},
},
["Zone"] = "Дорногал",
},
["Вольтчара - Свежеватель Душ"] = {
["lastbossyell"] = "Глашатай Бреция",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["itemName"] = "Ветхий крокульский тайник",
["itemLvl"] = 45,
["quality"] = 3,
},
},
{
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["isFinish"] = false,
["questDone"] = 0,
["isComplete"] = false,
["questReward"] = {
["money"] = 2000000,
},
},
{
["questReward"] = {
["itemName"] = "Сундук со снаряжением империи Зандалари",
["itemLvl"] = 99,
["quality"] = 4,
},
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
},
},
},
["Race"] = "Тауренка",
["BGBRating"] = {
[3] = 0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
[3] = 0,
},
["lastbosstime"] = 1756075220,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Испытания Арденвельда",
["questID"] = 60439,
["expiredTime"] = 1756180799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Помощь Ревендрету",
["questID"] = 60400,
["expiredTime"] = 1756267199,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1756353599,
},
["unlocked"] = true,
},
["ILe"] = 704.75,
["Quests"] = {
[82679] = {
["Expires"] = 1756267199,
["Link"] = "|cffffff00|Hquest:82679:90|h[Архивы: в поисках истины]|h|r",
["Title"] = "Архивы: в поисках истины",
["Zone"] = {
["mapType"] = 4,
["mapID"] = 2367,
["name"] = "Хранилище воспоминаний",
["parentMapID"] = 2248,
["flags"] = 524288,
},
},
},
["Paragon"] = {
},
["oRace"] = "Tauren",
["LastSeen"] = 1756078244,
["SpecializationIDs"] = {
262,
263,
264,
},
["Class"] = "SHAMAN",
["Arena3v3rating"] = 0,
["ILPvp"] = 704.75,
["Faction"] = "Horde",
["currency"] = {
[1191] = {
["amount"] = 0,
},
[2815] = {
["amount"] = 6072,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 3,
},
[3288] = {
["totalEarned"] = 180,
["totalMax"] = 180,
["amount"] = 45,
},
[1979] = {
["amount"] = 807,
},
[1810] = {
["covenant"] = {
7,
},
["totalMax"] = 100,
["amount"] = 7,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3108] = {
["amount"] = 0,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 6,
},
[1767] = {
["amount"] = 28146,
},
[3132] = {
["totalMax"] = 25,
["amount"] = 17,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[3109] = {
["amount"] = 0,
},
[3141] = {
["totalEarned"] = 3,
["totalMax"] = 4,
["amount"] = 3,
},
[3023] = {
["totalEarned"] = 16,
["totalMax"] = 28,
["amount"] = 16,
},
[2917] = {
["amount"] = 0,
},
[3110] = {
["amount"] = 0,
},
[2803] = {
["amount"] = 201,
},
[1885] = {
["amount"] = 21,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1275,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1906] = {
["amount"] = 7480,
},
[3284] = {
["totalEarned"] = 270,
["totalMax"] = 270,
["amount"] = 285,
},
[2914] = {
["amount"] = 0,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 3325,
},
[3056] = {
["amount"] = 6715,
},
[3290] = {
["totalEarned"] = 180,
["totalMax"] = 180,
["amount"] = 60,
},
[3269] = {
["totalMax"] = 8,
["amount"] = 0,
},
[1560] = {
["amount"] = 3,
},
[2009] = {
["amount"] = 38086,
},
[2915] = {
["amount"] = 0,
},
[1977] = {
["amount"] = 16,
},
[1828] = {
["amount"] = 96655,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3149] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[3278] = {
["totalEarned"] = 12,
["totalMax"] = 12,
["amount"] = 12,
},
[3286] = {
["totalEarned"] = 270,
["totalMax"] = 270,
["amount"] = 180,
},
[2916] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 1092,
},
[1602] = {
["totalMax"] = 2200,
["amount"] = 0,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1931] = {
["amount"] = 1579,
},
[3107] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
140482,
},
["totalMax"] = 200000,
["amount"] = 140482,
},
[2000] = {
["amount"] = 37,
},
[1822] = {
["covenant"] = {
80,
},
["totalMax"] = 80,
["amount"] = 80,
},
},
["DailyResetTime"] = 1756180799,
["Warmode"] = false,
["MythicKey"] = {
["mapID"] = 542,
["level"] = 10,
["ResetTime"] = 1756267199,
["link"] = "|cnIQ4:|Hkeystone:180653:542:10:162:10:9:0:0|h[Ключ: Заповедник \"Аль'дани\" (10)]|h|r",
},
["Level"] = 80,
["MaxXP"] = 100000000,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
14,
13,
10,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["mapChallengeModeID"] = 378,
["level"] = 14,
["runScore"] = 391,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: гамбит Со'леи",
["thisWeek"] = true,
["mapChallengeModeID"] = 392,
["level"] = 14,
["runScore"] = 395,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["mapChallengeModeID"] = 542,
["level"] = 14,
["runScore"] = 396,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["mapChallengeModeID"] = 525,
["level"] = 13,
["runScore"] = 379,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["mapChallengeModeID"] = 542,
["level"] = 13,
["runScore"] = 382,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["mapChallengeModeID"] = 378,
["level"] = 12,
["runScore"] = 366,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["mapChallengeModeID"] = 378,
["level"] = 10,
["runScore"] = 327,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Чертоги Покаяния",
["thisWeek"] = true,
["mapChallengeModeID"] = 378,
["level"] = 10,
["runScore"] = 333,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Тазавеш: гамбит Со'леи",
["thisWeek"] = true,
["mapChallengeModeID"] = 392,
["level"] = 10,
["runScore"] = 335,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Приорат Священного Пламени",
["thisWeek"] = true,
["mapChallengeModeID"] = 499,
["level"] = 10,
["runScore"] = 326,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Ара-Кара, Город Отголосков",
["thisWeek"] = true,
["mapChallengeModeID"] = 503,
["level"] = 10,
["runScore"] = 330,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Ара-Кара, Город Отголосков",
["thisWeek"] = true,
["mapChallengeModeID"] = 503,
["level"] = 10,
["runScore"] = 326,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["mapChallengeModeID"] = 525,
["level"] = 10,
["runScore"] = 327,
["rewardLevel"] = 707,
},
{
["completed"] = true,
["name"] = "Заповедник \"Аль'дани\"",
["thisWeek"] = true,
["mapChallengeModeID"] = 542,
["level"] = 10,
["runScore"] = 334,
["rewardLevel"] = 707,
},
},
["ResetTime"] = 1756267199,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["PlayedTotal"] = 5569313,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1756076184,
["Money"] = 1464820347,
["Progress"] = {
["tww-free-chett-list"] = {
["show"] = false,
},
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
15,
15,
15,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[89293] = {
["show"] = false,
},
[89294] = {
["show"] = false,
},
[85487] = {
["show"] = false,
},
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[85488] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[81650] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
["show"] = true,
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
[81647] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-chett-list"] = {
[86923] = {
["show"] = false,
},
[86924] = {
["show"] = false,
},
[86917] = {
["show"] = false,
},
[87302] = {
["show"] = false,
},
[87303] = {
["show"] = false,
},
[87304] = {
["show"] = false,
},
[86915] = {
["show"] = false,
},
[87306] = {
["show"] = false,
},
[87307] = {
["show"] = false,
},
[86918] = {
["show"] = false,
},
[86919] = {
["show"] = false,
},
[86920] = {
["show"] = false,
},
[87305] = {
["show"] = false,
},
["show"] = true,
},
["tww-nightfall-scenario"] = {
["show"] = false,
},
["tww-ecological-succession"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["tww-nightfall-daily"] = {
[87475] = {
["show"] = false,
},
[88711] = {
["show"] = false,
},
[87480] = {
["show"] = false,
},
[87477] = {
["show"] = false,
},
[88916] = {
["show"] = false,
},
[88945] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-more-than-just-a-phase"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-services-requested"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = true,
["isComplete"] = true,
},
["tww-karesh-warrants"] = {
["show"] = true,
["isComplete"] = true,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-s3-weekly-cache"] = {
["show"] = true,
[91175] = {
["show"] = false,
},
[91176] = {
["show"] = false,
},
[91177] = {
["show"] = false,
},
[91178] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-delvers-bounty"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-reduce-reuse-resell"] = {
["show"] = false,
},
["tww-many-jobs-handle-it"] = {
["show"] = false,
},
["tww-urge-to-surge"] = {
["show"] = false,
},
},
["Zone"] = "Дорногал",
["MythicPlusScore"] = 2890,
["lastboss"] = "Гизл Гигабжик: Эпохальный ключ",
["WeeklyResetTime"] = 1756267199,
["PlayedLevel"] = 1432143,
["Covenant"] = 1,
["LClass"] = "Шаманка",
["Skills"] = {
},
["Order"] = 50,
["IL"] = 704.75,
},
},
["Emissary"] = {
["Cache"] = {
[43179] = "Маги Кирин-Тора в Даларане",
[56120] = "Освобожденные",
[50602] = "Экспедиция Таланджи",
[42234] = "Валарьяры",
[48639] = "Армия Света",
[50562] = "Защитники Азерот",
[48641] = "Армия погибели Легиона",
[48642] = "Защитники Аргуса",
[50606] = "Военная кампания Орды",
[50605] = "Военная кампания Альянса",
[50598] = "Империя Зандалари",
[50599] = "Адмиралтейство Праудмуров",
[50600] = "Орден Пылающих Углей",
[56119] = "Клинки Волн",
[42170] = "Ткачи Снов",
[42233] = "Племена Крутогорья",
[50604] = "Тортолланские искатели",
[42421] = "Помраченные",
[42422] = "Стражи",
[42420] = "Двор Фарондиса",
[50603] = "Жители Вол'дуна",
[50601] = "Возрождение Шторма",
},
["Expansion"] = {
[6] = {
{
["questID"] = {
["Horde"] = 48642,
["Alliance"] = 48642,
},
["questNeed"] = 4,
["expiredTime"] = 1756180886,
},
{
["questID"] = {
["Horde"] = 42170,
["Alliance"] = 42170,
},
["questNeed"] = 4,
["expiredTime"] = 1756267286,
},
{
["questID"] = {
["Horde"] = 42422,
["Alliance"] = 42422,
},
["questNeed"] = 4,
["expiredTime"] = 1756353686,
},
},
[7] = {
{
["questID"] = {
["Horde"] = 56120,
["Alliance"] = 56119,
},
["questNeed"] = 4,
["expiredTime"] = 1756180886,
},
{
["questID"] = {
["Horde"] = 50598,
["Alliance"] = 50599,
},
["questNeed"] = 4,
["expiredTime"] = 1756267286,
},
{
["questID"] = {
["Horde"] = 50604,
["Alliance"] = 50604,
},
["questNeed"] = 3,
["expiredTime"] = 1756353686,
},
},
},
},
["DailyResetTime"] = 1756180799,
["Quests"] = {
[90123] = {
["Expires"] = 1756267199,
["Title"] = "Устранение Пустогибели",
["Link"] = "|cffffff00|Hquest:90123:3008|h[Устранение Пустогибели]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2472,
["name"] = "Тазавеш",
["parentMapID"] = 2371,
["flags"] = 0,
},
["isDaily"] = false,
},
},
["Indicators"] = {
["R2ClassColor"] = true,
["D2Indicator"] = "BLANK",
["R7Color"] = {
1,
1,
0,
},
["R5Color"] = {
0,
0,
1,
},
["R1Text"] = "KILLED/TOTAL",
["R4Indicator"] = "BLANK",
["R1Color"] = {
0.6,
0.6,
0,
},
["R0Indicator"] = "BLANK",
["R8ClassColor"] = true,
["D2ClassColor"] = true,
["R4ClassColor"] = true,
["R6ClassColor"] = true,
["D2Color"] = {
0,
1,
0,
},
["D1Text"] = "KILLED/TOTAL",
["R0ClassColor"] = true,
["R1ClassColor"] = true,
["D1Indicator"] = "BLANK",
["R2Indicator"] = "BLANK",
["R8Color"] = {
1,
0,
0,
},
["D3ClassColor"] = true,
["D2Text"] = "KILLED/TOTALH",
["R6Color"] = {
0,
1,
0,
},
["D3Text"] = "KILLED/TOTALM",
["R4Color"] = {
1,
0,
0,
},
["R7Indicator"] = "BLANK",
["R2Text"] = "KILLED/TOTAL",
["D3Color"] = {
1,
0,
0,
},
["R0Text"] = "KILLED/TOTAL",
["R0Color"] = {
0.6,
0.6,
0,
},
["R1Indicator"] = "BLANK",
["R2Color"] = {
0.6,
0,
0,
},
["R3Indicator"] = "BLANK",
["R7ClassColor"] = true,
["R3Text"] = "KILLED/TOTALH",
["D1ClassColor"] = true,
["R4Text"] = "KILLED/TOTALH",
["R3Color"] = {
1,
1,
0,
},
["R3ClassColor"] = true,
["R5Indicator"] = "BLANK",
["R5ClassColor"] = true,
["R6Text"] = "KILLED/TOTAL",
["R8Indicator"] = "BLANK",
["R8Text"] = "KILLED/TOTALM",
["D1Color"] = {
0,
0.6,
0,
},
["R6Indicator"] = "BLANK",
["D3Indicator"] = "BLANK",
["R7Text"] = "KILLED/TOTALH",
["R5Text"] = "KILLED/TOTALL",
},
}
