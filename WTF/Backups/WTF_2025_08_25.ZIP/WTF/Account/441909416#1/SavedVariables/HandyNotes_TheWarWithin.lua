
HandyNotes_TheWarWithinDB = {
["profileKeys"] = {
["Beamladen - Twisting Nether"] = "Default",
["Дракобес - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Пва - Свежеватель Душ"] = "Default",
["Вантачмэн - Ревущий фьорд"] = "Default",
["Прециза - Свежеватель Душ"] = "Default",
["Спленда - Свежеватель Душ"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
["Сорчистино - Свежеватель Душ"] = "Default",
["Garrettino - Aegwynn"] = "Default",
["Алианкано - Свежеватель Душ"] = "Default",
["Джуставар - Свежеватель Душ"] = "Default",
["Топмэн - Свежеватель Душ"] = "Default",
["Виандисто - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["icon_display_skyriding_glyph"] = false,
["icon_scale_treasures"] = 1,
["icon_display_flat_earthen"] = false,
["icon_display_disturbed_earth"] = false,
["icon_display_rares"] = false,
["icon_display_treasures"] = false,
["icon_display_profession_treasures"] = false,
["icon_scale_karesh_lore_hunter"] = 2,
["icon_display_karesh_lore_hunter"] = false,
},
},
}
