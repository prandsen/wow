
RaiderIO_Config = {
["replayAlpha"] = 1,
["enableKeystoneTooltips"] = true,
["profilePoint"] = {
["y"] = 0,
["x"] = -16,
["point"] = "TOPLEFT",
},
["enableReplay"] = true,
["enableLFGDropdown"] = true,
["minimapIcon"] = {
["minimapPos"] = 180,
["showInCompartment"] = true,
["lock"] = false,
["hide"] = true,
},
["showMainsScore"] = true,
["showRaidEncountersInProfile"] = true,
["showAverageScore"] = true,
["enableWhoMessages"] = false,
["useEnglishAbbreviations"] = true,
["disableScoreColors"] = false,
["showMainBestScore"] = true,
["allowClientToControlCombatLog"] = false,
["replayBackground"] = {
["a"] = 0.5,
["r"] = 0,
["g"] = 0,
["b"] = 0,
},
["showRaiderIOProfile"] = true,
["showSimpleScoreColors"] = false,
["replaySelection"] = "user_best_replay",
["inverseProfileModifier"] = false,
["enableGuildTooltips"] = true,
["enableWhoTooltips"] = false,
["showScoreModifier"] = false,
["enableProfileModifier"] = true,
["showRoleIcons"] = true,
["enableUnitTooltips"] = true,
["enableFriendsTooltips"] = true,
["hidePersonalRaiderIOProfile"] = false,
["showDropDownCopyURL"] = true,
["positionProfileAuto"] = true,
["enableLFGTooltips"] = true,
["enableClientEnhancements"] = true,
["enableCombatLogTracking"] = false,
["lockProfile"] = false,
["showScoreInCombat"] = true,
["mplusHeadlineMode"] = 0,
["showClientGuildBest"] = true,
}
RaiderIO_LastCharacter = "eu-Бимладен-howling-fjord"
RaiderIO_MissingCharacters = {
["eu-Мэлвэн-howling-fjord"] = true,
["eu-Hoyxáy-silvermoon"] = true,
["eu-Бимладен-Ревущий фьорд"] = true,
["eu-Кукансвета-howling-fjord"] = true,
["eu-Кучерманн-howling-fjord"] = true,
["eu-Яггита-howling-fjord"] = true,
["eu-Тимьяша-howling-fjord"] = true,
["eu-Семкарио-howling-fjord"] = true,
["eu-Зитрис-howling-fjord"] = true,
["eu-Мягколапка-soulflayer"] = true,
["eu-Kaldoran-elune"] = true,
["eu-Ксорник-howling-fjord"] = true,
["eu-Пуфикярости-howling-fjord"] = true,
["eu-Лилскиллед-howling-fjord"] = true,
["eu-Hanako-marécage-de-zangar"] = true,
["eu-Крапоприст-soulflayer"] = true,
["eu-Битьебало-howling-fjord"] = true,
["eu-Бумини-howling-fjord"] = true,
["eu-party5-howling-fjord"] = true,
["eu-Найгхт-soulflayer"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
