
HandyNotes_DornogalDB = {
["profileKeys"] = {
["Мальдика - Свежеватель Душ"] = "Default",
["Джуставар - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
},
},
}
