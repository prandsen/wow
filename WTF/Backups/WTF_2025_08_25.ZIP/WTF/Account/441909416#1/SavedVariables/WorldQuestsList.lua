
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[82120] = true,
[64531] = true,
[81818] = true,
[66419] = true,
[81675] = true,
[82456] = true,
[82582] = true,
[82584] = true,
[82088] = true,
[82552] = true,
[81806] = true,
[81808] = true,
[81639] = true,
[64273] = true,
[81767] = true,
[82451] = true,
[76586] = true,
[75257] = true,
[82519] = true,
[81653] = true,
[82580] = true,
},
["VERSION"] = 117,
},
["Сорчистино-СвежевательДуш"] = {
["FilterType"] = {
},
["VERSION"] = 117,
["Quests"] = {
},
["Filter"] = 63,
},
["Мальдика-СвежевательДуш"] = {
["VERSION"] = 117,
["FilterType"] = {
},
["Quests"] = {
[82523] = true,
[81818] = true,
[82225] = true,
[82291] = true,
[82293] = true,
[81615] = true,
[82206] = true,
[82088] = true,
[82584] = true,
[81639] = true,
[82585] = true,
[76586] = true,
[82292] = true,
[81767] = true,
[82451] = true,
[83538] = true,
[81808] = true,
[81806] = true,
[81653] = true,
[82552] = true,
},
["Filter"] = 63,
},
["Вольтчара-СвежевательДуш"] = {
["VERSION"] = 117,
["Filter"] = 63,
["Quests"] = {
[81615] = true,
[82456] = true,
[81767] = true,
[82519] = true,
[82088] = true,
[76586] = true,
[82120] = true,
[82451] = true,
[81653] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Виандисто-СвежевательДуш"] = {
["FilterType"] = {
},
["VERSION"] = 116,
["Quests"] = {
[51496] = true,
[55344] = true,
[51175] = true,
},
["Filter"] = 63,
},
["Sort"] = 5,
["VERSION"] = 117,
["Алианкано-СвежевательДуш"] = {
["VERSION"] = 116,
["Filter"] = 63,
["Quests"] = {
},
["FilterType"] = {
},
},
["Сэйвмэн-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["VERSION"] = 117,
["Quests"] = {
[76586] = true,
},
["Filter"] = 63,
},
["Дракобес-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 115,
},
["Топмэн-СвежевательДуш"] = {
["VERSION"] = 116,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Ignore"] = {
},
["SortPrio"] = {
},
["Garrettino-Aegwynn"] = {
["VERSION"] = 116,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Пва-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 114,
},
["Спленда-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 116,
["Quests"] = {
},
["FilterType"] = {
},
},
["Вантачмэн-Ревущийфьорд"] = {
["VERSION"] = 116,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[69927] = true,
[50497] = true,
[74835] = true,
[82292] = true,
[70068] = true,
[58747] = true,
[71180] = true,
[54896] = true,
[55466] = true,
[75280] = true,
[58743] = true,
[71140] = true,
[66551] = true,
[73146] = true,
},
["Filter"] = 63,
},
["Прециза-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 116,
["Quests"] = {
},
["FilterType"] = {
},
},
["AzeriteFormat"] = 20,
["Beamladen-TwistingNether"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Джуставар-СвежевательДуш"] = {
["FilterType"] = {
},
["Filter"] = 63,
["Quests"] = {
},
["VERSION"] = 117,
},
["HideLegion"] = true,
}
