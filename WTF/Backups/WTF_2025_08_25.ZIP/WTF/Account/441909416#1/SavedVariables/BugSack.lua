
BugSackDB = {
["soundMedia"] = "BugSack: Fatality",
["altwipe"] = true,
["useMaster"] = false,
["fontSize"] = "GameFontHighlight",
["mute"] = false,
["auto"] = false,
["chatframe"] = false,
}
BugSackLDBIconDB = {
}
