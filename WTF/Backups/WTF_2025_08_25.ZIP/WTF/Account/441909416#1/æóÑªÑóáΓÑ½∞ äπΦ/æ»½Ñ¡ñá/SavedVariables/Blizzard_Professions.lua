
g_professionsSpecsSelectedTabs = {
}
g_professionsSpecsSelectedPaths = {
}
