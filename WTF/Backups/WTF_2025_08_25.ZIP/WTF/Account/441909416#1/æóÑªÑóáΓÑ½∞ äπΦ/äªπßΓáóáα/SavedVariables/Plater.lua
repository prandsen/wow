
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[73] = 30,
[71] = 30,
[72] = 30,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA7EEAA"] = true,
},
["minimap"] = {
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[73] = 30,
[71] = 30,
[72] = 30,
},
}
