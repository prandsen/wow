
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[255] = 40,
[254] = 40,
[253] = 40,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA7EEE7"] = true,
},
["spellRangeCheckRangeEnemy"] = {
[255] = 40,
[254] = 40,
[253] = 40,
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["minimap"] = {
},
}
