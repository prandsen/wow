
BlizzardStopwatchOptions = {
["position"] = {
["y"] = 785.8094482421875,
["x"] = 602.8563232421875,
},
}
