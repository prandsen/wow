
_detalhes_database = {
["savedbuffs"] = {
},
["mythic_dungeon_id"] = 3,
["tabela_historico"] = {
["tabelas"] = {
},
},
["ocd_tracker"] = {
["show_title"] = true,
["current_cooldowns"] = {
},
["lines_per_column"] = 12,
["group_frames"] = true,
["show_options"] = false,
["frames"] = {
["defensive-raid"] = {
},
["main"] = {
},
["ofensive"] = {
},
["defensive-target"] = {
},
["utility"] = {
},
["defensive-personal"] = {
},
},
["width"] = 120,
["ignored_cooldowns"] = {
},
["cooldowns"] = {
},
["height"] = 18,
["own_frame"] = {
["defensive-raid"] = false,
["ofensive"] = false,
["defensive-target"] = false,
["utility"] = false,
["defensive-personal"] = false,
},
["framme_locked"] = false,
["show_conditions"] = {
["only_inside_instance"] = true,
["only_in_group"] = true,
},
["enabled"] = false,
["filters"] = {
["itemutil"] = false,
["itempower"] = false,
["defensive-target"] = false,
["itemheal"] = false,
["defensive-personal"] = false,
["defensive-raid"] = false,
["ofensive"] = true,
["crowdcontrol"] = false,
["utility"] = false,
},
},
["last_version"] = "11.2.0 13666",
["player_stats"] = {
["mythicdungeoncompletedDF2"] = {
[375] = {
[5] = {
["completed"] = 1,
["history"] = {
{
["onTime"] = true,
["deaths"] = 0,
["date"] = 1727222996,
["affix"] = 9,
["runTime"] = 1369,
["combatTime"] = 1212.040000000001,
},
},
["totalTime"] = 1369175,
["minTime"] = 0,
},
[6] = {
["completed"] = 1,
["history"] = {
{
["onTime"] = true,
["deaths"] = 6,
["date"] = 1727296985,
["affix"] = 10,
["runTime"] = 1475,
["combatTime"] = 1227.228000000017,
},
},
["totalTime"] = 1475682,
["minTime"] = 0,
},
},
[376] = {
[6] = {
["completed"] = 1,
["history"] = {
{
["onTime"] = false,
["deaths"] = 11,
["date"] = 1727299736,
["affix"] = 10,
["runTime"] = 1937,
["combatTime"] = 1626.612000000008,
},
},
["totalTime"] = 1937159,
["minTime"] = 0,
},
},
},
},
["force_font_outline"] = "",
["tabela_instancias"] = {
},
["coach"] = {
["enabled"] = false,
["welcome_panel_pos"] = {
},
["last_coach_name"] = false,
},
["arena_data_index_selected"] = 1,
["local_instances_config"] = {
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 2,
["pos"] = {
["normal"] = {
["y"] = -257.0172424316406,
["x"] = 851.7876586914062,
["w"] = 244.8981781005859,
["h"] = 100.9114608764648,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
5,
1,
},
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -376.4429168701172,
["x"] = 851.2880249023438,
["w"] = 245.8994140625,
["h"] = 100.9109649658203,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
},
["segment"] = -1,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -497.3539428710938,
["x"] = 851.2881469726562,
["w"] = 245.8991394042969,
["h"] = 100.9111175537109,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
},
["cached_talents"] = {
},
["last_instance_id"] = 2286,
["data_harvest_for_charsts"] = {
["players"] = {
{
["playerKey"] = "total",
["combatObjectContainer"] = 1,
["name"] = "Damage of Each Individual Player",
["playerOnly"] = true,
},
},
["totals"] = {
{
["combatObjectSubTableKey"] = 1,
["name"] = "Damage of All Player Combined",
["combatObjectSubTableName"] = "totals",
},
},
},
["announce_interrupts"] = {
["enabled"] = false,
["whisper"] = "",
["channel"] = "SAY",
["custom"] = "",
["next"] = "",
},
["announce_prepots"] = {
["enabled"] = false,
["channel"] = "SELF",
["reverse"] = false,
},
["active_profile"] = "beamladen",
["mythic_dungeon_currentsaved"] = {
["players"] = {
"Player-1602-0F864FF1",
"Player-1602-0F9B2E15",
"Player-1615-0B66B5BF",
"Player-1602-0F976839",
},
["dungeon_name"] = "Смертельная тризна",
["started"] = false,
["segment_id"] = 5,
["ej_id"] = 0,
["started_at"] = 1727297861.7,
["run_id"] = 3,
["level"] = 6,
["dungeon_zone_id"] = 2286,
["previous_boss_killed_at"] = 1727299693,
},
["announce_firsthit"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["benchmark_db"] = {
["frame"] = {
},
},
["SoloTablesSaved"] = {
["Mode"] = 1,
},
["announce_damagerecord"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["combat_log"] = {
["inverse_deathlog_overalldata"] = false,
["merge_gemstones_1007"] = false,
["track_hunter_frenzy"] = false,
["merge_critical_heals"] = false,
["inverse_deathlog_raid"] = false,
["calc_evoker_damage"] = true,
["evoker_show_realtimedps"] = false,
["inverse_deathlog_mplus"] = false,
},
["arena_data_compressed"] = {
},
["mythic_plus_log"] = {
"26/09/24 01:28:56|Activity Time: 1626.612",
"26/09/24 01:28:56|GetCompletionInfo() Found, Time: 1937",
"26/09/24 01:28:56|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"26/09/24 01:28:56|delete_trash_after_merge | concluded",
"26/09/24 01:28:56|running MergeRemainingTrashAfterAllBossesDone.",
"26/09/24 01:28:56|MythicDungeonFinished() | merge_boss_trash = true",
"26/09/24 01:28:56|MythicDungeonFinished() | Details was in combat.",
"26/09/24 01:28:54|===== Mythic+ Finished =====",
"26/09/24 01:28:13|MergeTrashCleanup | no segments to merge.",
"26/09/24 01:28:13|BossDefeated | key level: | 6 | Налтор Криомант | Смертельная тризна",
"26/09/24 01:25:48|MergeTrashCleanup started.",
"26/09/24 01:25:48|BossDefeated | key level: | 6 | Хирург Трупошов | Смертельная тризна",
"26/09/24 01:17:22|MergeTrashCleanup started.",
"26/09/24 01:17:22|BossDefeated | key level: | 6 | Амарт Жнец | Смертельная тризна",
"26/09/24 01:01:39|MergeTrashCleanup started.",
"26/09/24 01:01:39|BossDefeated | key level: | 6 | Чумокост | Смертельная тризна",
"26/09/24 00:57:32|OnChallengeModeStart()",
"26/09/24 00:57:32|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | autoclose_time = 40 | reverse_death_log = false | make_overall_when_done = true | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 6 | zone: Смертельная тризна | zoneId: 2286",
"26/09/24 00:57:32|Event: WORLD_STATE_TIMER_START | payload1: 1 | payload2:  | payload3: ",
"26/09/24 00:57:24|Event: CHALLENGE_MODE_START",
"26/09/24 00:43:05|Activity Time: 1227.228",
"26/09/24 00:43:05|GetCompletionInfo() Found, Time: 1475",
"26/09/24 00:43:05|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"26/09/24 00:43:05|delete_trash_after_merge | concluded",
"26/09/24 00:43:05|running MergeRemainingTrashAfterAllBossesDone.",
"26/09/24 00:43:05|MythicDungeonFinished() | merge_boss_trash = true",
"26/09/24 00:43:05|MythicDungeonFinished() | Details was in combat.",
"26/09/24 00:43:03|===== Mythic+ Finished =====",
"26/09/24 00:42:42|MergeTrashCleanup started.",
"26/09/24 00:42:42|BossDefeated | key level: | 6 | Тред'ова | Туманы Тирна Скитта",
"26/09/24 00:36:16|MergeTrashCleanup started.",
"26/09/24 00:36:16|BossDefeated | key level: | 6 | Призывательница Туманов | Туманы Тирна Скитта",
"26/09/24 00:25:54|MergeTrashCleanup started.",
"26/09/24 00:25:54|BossDefeated | key level: | 6 | Ингра Малох | Туманы Тирна Скитта",
"26/09/24 00:18:57|OnChallengeModeStart()",
"26/09/24 00:18:57|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | autoclose_time = 40 | reverse_death_log = false | make_overall_when_done = true | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 6 | zone: Туманы Тирна Скитта | zoneId: 2290",
"26/09/24 00:18:57|Event: WORLD_STATE_TIMER_START | payload1: 1 | payload2:  | payload3: ",
"26/09/24 00:18:48|Event: CHALLENGE_MODE_START",
"25/09/24 04:09:56|Activity Time: 1212.04",
"25/09/24 04:09:56|GetCompletionInfo() Found, Time: 1369",
"25/09/24 04:09:56|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"25/09/24 04:09:56|MythicDungeonFinished() | merge_boss_trash = true",
"25/09/24 04:09:56|MythicDungeonFinished() | Details was in combat.",
"25/09/24 04:09:54|===== Mythic+ Finished =====",
"25/09/24 04:09:54|MergeTrashCleanup started.",
"25/09/24 04:09:54|BossDefeated | key level: | 5 | Тред'ова | Туманы Тирна Скитта",
"25/09/24 04:03:15|MergeTrashCleanup started.",
"25/09/24 04:03:15|BossDefeated | key level: | 5 | Призывательница Туманов | Туманы Тирна Скитта",
"25/09/24 03:54:02|MergeTrashCleanup started.",
},
["combat_counter"] = 169,
["nick_tag_cache"] = {
["nextreset"] = 1756157520,
["last_version"] = 16,
},
["ignore_nicktag"] = false,
["last_realversion"] = 165,
["on_death_menu"] = false,
["character_data"] = {
["logons"] = 22,
},
["last_day"] = "12",
["combat_id"] = 132,
["savedStyles"] = {
},
["last_instance_time"] = 1727297810,
["plugin_database"] = {
["DETAILS_PLUGIN_TINY_THREAT"] = {
["enabled"] = true,
["only_my_group"] = false,
["animate"] = false,
["useclasscolors"] = false,
["hide_pull_bar"] = false,
["author"] = "Terciob",
["playercolor"] = {
1,
1,
1,
},
["show_party_pets"] = false,
["updatespeed"] = 1,
["disable_gouge"] = false,
["showamount"] = false,
["useplayercolor"] = false,
["absolute_mode"] = false,
["playSound"] = false,
["playSoundFile"] = "Details Threat Warning Volume 3",
["usefocus"] = false,
},
["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
["enabled"] = true,
["author"] = "Terciob",
["max_compares"] = 4,
["compare_type"] = 1,
},
["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
["enabled"] = true,
["last_boss"] = false,
["author"] = "Details! Team",
["captures"] = {
false,
true,
true,
true,
},
["timeline_cutoff_delete_time"] = 3,
["last_player"] = false,
["max_deaths_for_current"] = 20,
["max_deaths_for_timeline"] = 5,
["last_encounter_hash"] = false,
["endurance_threshold"] = 3,
["timeline_cutoff_time"] = 3,
["last_segment"] = false,
["show_icon"] = 1,
["InstalledAt"] = 1726904668,
["max_segments_for_current"] = 2,
["showing_type"] = 4,
},
["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
["enabled"] = true,
["encounter_timers_bw"] = {
},
["max_emote_segments"] = 3,
["last_section_selected"] = "main",
["author"] = "Terciob",
["window_scale"] = 1,
["encounter_timers_dbm"] = {
},
["show_icon"] = 5,
["opened"] = 0,
["hide_on_combat"] = false,
},
["DETAILS_PLUGIN_RAIDCHECK"] = {
["enabled"] = true,
["food_tier1"] = true,
["mythic_1_4"] = true,
["food_tier2"] = true,
["author"] = "Terciob",
["use_report_panel"] = true,
["pre_pot_healers"] = false,
["pre_pot_tanks"] = false,
["food_tier3"] = true,
},
["DETAILS_PLUGIN_VANGUARD"] = {
["tank_block_size_height"] = 50,
["show_power_bar"] = false,
["first_run"] = false,
["aura_timer_text_size"] = 14,
["tank_block_castbar_size_height"] = 16,
["show_health_bar"] = true,
["aura_offset_y"] = 0,
["enabled"] = true,
["show_cast_bar"] = false,
["author"] = "Terciob",
["tank_block_size"] = 150,
["bar_height"] = 24,
["tank_block_texture"] = "Details Serenity",
["show_inc_bars"] = true,
["tank_block_powerbar_size_height"] = 10,
["tank_block_height"] = 40,
["tank_block_color"] = {
0.074509,
0.035294,
0.035294,
0.832845,
},
},
["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
["use_square_mode"] = false,
["is_first_run"] = false,
["grow_direction"] = "right",
["arrow_color"] = {
1,
1,
1,
0.5,
},
["main_frame_size"] = {
307.0000610351563,
100,
},
["arrow_anchor_y"] = 0,
["minimap"] = {
["minimapPos"] = 160,
["radius"] = 160,
["hide"] = true,
},
["main_frame_locked"] = true,
["arrow_anchor_x"] = 0,
["author"] = "Terciob",
["row_texture"] = "Melli",
["square_grow_direction"] = "right",
["y"] = 0.7619104385375977,
["row_color"] = {
0.1019607931375504,
0.1019607931375504,
0.1019607931375504,
0.4000000357627869,
},
["square_amount"] = 5,
["enabled"] = true,
["arrow_size"] = 14,
["per_second"] = {
["enabled"] = false,
["point"] = "CENTER",
["scale"] = 1,
["font_shadow"] = true,
["y"] = 0.00018310546875,
["x"] = -3.0517578125e-05,
["attribute_type"] = 2,
["update_speed"] = 0.05,
["size"] = 32,
},
["row_spacement"] = 20,
["main_frame_color"] = {
0,
0,
0,
0,
},
["main_frame_strata"] = "LOW",
["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
["use_spark"] = false,
["font_size"] = 11,
["x"] = -248.4752197265625,
["font_face"] = "ITCAvantGardeGothicDemi",
["square_size"] = 32,
["point"] = "BOTTOMRIGHT",
["font_color"] = {
1,
1,
1,
1,
},
["row_height"] = 20,
["scale"] = 1,
},
},
["announce_deaths"] = {
["enabled"] = false,
["last_hits"] = 1,
["only_first"] = 5,
["where"] = 1,
},
["tabela_overall"] = {
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
{
["tipo"] = 3,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["tempo_start"] = 440983.672,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["bossTimers"] = {
},
["trinketProcs"] = {
},
["playerTalents"] = {
},
["totals"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["totals_grupo"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["frags_need_refresh"] = false,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = 0,
["amountCasts"] = {
},
["mapId"] = 1,
["cleu_events"] = {
["n"] = 1,
},
["zoneName"] = "Калимдор",
["boss_hp"] = 1,
["is_challenge"] = false,
["frags"] = {
},
["data_fim"] = 0,
["cleu_timeline"] = {
},
["spells_cast_timeline"] = {
},
["PhaseData"] = {
{
1,
1,
},
["heal_section"] = {
},
["heal"] = {
},
["damage_section"] = {
},
["damage"] = {
},
},
["start_time"] = 0,
["TimeData"] = {
},
["combat_counter"] = 168,
},
["data_harvested_for_charts"] = {
},
["arena_data_headers"] = {
},
["last_encounter"] = "Принцесса Нексуса Ки'веза",
["announce_cooldowns"] = {
["ignored_cooldowns"] = {
},
["enabled"] = false,
["custom"] = "",
["channel"] = "RAID",
},
["rank_window"] = {
["last_difficulty"] = 15,
["last_raid"] = "",
},
["cached_roles"] = {
},
["cached_specs"] = {
["Player-1604-09765C91"] = 66,
},
}
