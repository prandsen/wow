
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[577] = 30,
[581] = 30,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA6A2F6"] = true,
},
["minimap"] = {
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[577] = 30,
[581] = 30,
},
}
