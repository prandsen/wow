
EncounterDetailsDB = {
["chartData"] = {
[24] = {
["Raid Damage Done"] = {
1566,
0,
7288,
0,
10106,
38981,
20861,
38174,
26288,
26757,
23101,
61391,
68937,
32476,
52826,
38503,
39811,
43046,
44323,
61149,
41072,
52599,
45346,
45142,
52310,
32886,
42638,
32038,
50890,
42109,
64349,
64676,
21250,
32784,
33584,
36884,
62388,
31768,
34352,
55322,
61475,
35008,
57854,
41258,
50160,
27698,
["max_value"] = 68937,
["__time"] = 1753559219,
},
},
[7] = {
["Raid Damage Done"] = {
914,
["max_value"] = 914,
["__time"] = 1753557772,
},
},
[27] = {
["Raid Damage Done"] = {
31213,
32981,
14563,
34437,
30577,
29662,
23168,
28653,
45379,
44321,
38388,
22894,
34520,
36867,
18174,
20801,
28389,
115110,
55573,
77938,
42934,
80640,
30279,
85631,
35705,
60389,
79493,
48102,
36645,
56304,
63570,
31376,
35518,
31902,
55525,
163900,
22034,
56760,
18592,
45722,
46242,
47811,
21153,
46293,
12132,
53568,
24936,
54779,
18860,
21956,
36964,
45551,
41087,
73991,
80945,
36680,
54346,
41683,
["max_value"] = 163900,
["__time"] = 1753559342,
},
},
[15] = {
["Raid Damage Done"] = {
70663,
14671,
25693,
68298,
11686,
70025,
67458,
46249,
24652,
67600,
79787,
79575,
75005,
43302,
68512,
45147,
36221,
21831,
49751,
41963,
23436,
25369,
24223,
30179,
49785,
51066,
42061,
7215,
3366,
21646,
29736,
46305,
21295,
22180,
25069,
61602,
25810,
29746,
24750,
28261,
4311,
35645,
20186,
24830,
18252,
49731,
22679,
27846,
19105,
["max_value"] = 79787,
["__time"] = 1753558806,
},
},
[18] = {
["Raid Damage Done"] = {
18480,
8890,
33035,
63234,
86557,
35742,
49463,
41901,
108229,
56636,
120428,
53001,
26134,
35175,
12083,
30709,
25460,
13333,
41260,
52714,
41129,
18683,
33758,
34188,
19837,
45466,
36876,
20685,
63663,
34568,
23482,
33001,
19560,
18722,
45432,
54807,
28607,
35487,
33294,
22878,
42286,
31507,
53977,
41248,
34591,
42401,
40911,
15953,
18546,
41275,
47199,
41466,
38250,
26096,
41352,
38523,
["max_value"] = 120428,
["__time"] = 1753558917,
},
},
[21] = {
["Raid Damage Done"] = {
7866,
3968,
4431,
1141,
25310,
17958,
30771,
29459,
40312,
40153,
36119,
27547,
52113,
53106,
58139,
31501,
31837,
46223,
25561,
34943,
35250,
12820,
52010,
21837,
26561,
79308,
34270,
22606,
25261,
25620,
32175,
18494,
23298,
71609,
21454,
32321,
33812,
56899,
14455,
15748,
42924,
27516,
38506,
21223,
44319,
39001,
["max_value"] = 79308,
["__time"] = 1753559061,
},
},
[6] = {
["Raid Damage Done"] = {
5999,
["max_value"] = 5999,
["__time"] = 1753557764,
},
},
[12] = {
["Raid Damage Done"] = {
35288,
1788,
5648,
33859,
53337,
32649,
11348,
78148,
68506,
46698,
77803,
29284,
74205,
33458,
18707,
33058,
44774,
68331,
34580,
67827,
46139,
32158,
69121,
56997,
32498,
40239,
9755,
39157,
37068,
66087,
32193,
44801,
123264,
28352,
52957,
128130,
119983,
60668,
19850,
60607,
57098,
146983,
76364,
71583,
44098,
75469,
51974,
45670,
52068,
6493,
69920,
35943,
1612,
15531,
18667,
29993,
25849,
41329,
7961,
265,
35637,
26879,
40485,
36975,
23496,
44797,
74533,
90314,
51481,
40025,
63559,
18537,
35645,
39359,
68518,
49361,
56969,
59960,
25844,
61349,
48839,
33922,
54821,
27957,
22357,
104328,
30081,
42914,
40313,
36091,
870,
0,
0,
0,
18208,
13969,
64220,
64018,
0,
30721,
57128,
13726,
47396,
26950,
27900,
42968,
41835,
23190,
["max_value"] = 146983,
["__time"] = 1753558604,
},
},
[29] = {
["Raid Damage Done"] = {
["__time"] = 1753559574,
},
},
},
["encounter_spells"] = {
[373268] = {
["school"] = 4,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[7068] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фантомный горожанин",
},
[8092] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Некроэло",
},
[16172] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вурдалак-стервятник",
},
[22651] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зеврим Терновое Копыто",
},
[204521] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[431398] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ситапал",
},
[22715] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гидралинг",
},
[51514] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[11641] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Темный охотник из племени Песчаной Бури",
},
[16244] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Певчий Форрестен",
},
[54644] = {
["school"] = 24,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Химера",
},
[9613] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Темный чародей из секты Тузадин",
},
[8599] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чумной вурдалак",
},
[458357] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Пульсирующий тотем",
},
[193473] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Щупальце Бездны",
},
[375576] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ситапал",
},
[13737] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший кавалер",
},
[454015] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[402916] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[384648] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Железная Кора - заступник",
},
[118455] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[31602] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Неруб'энкан",
},
[16791] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мировой судья Бартилас",
},
[22420] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гидротварь",
},
[22939] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рудиментное чудовище",
},
[6136] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Малекай Бледный",
},
[207400] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[188046] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Обитатель Сна",
},
[373281] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некроэло",
},
[52042] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[3589] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Визжащая банши",
},
[34189] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Черный страж из братства Справедливости",
},
[44425] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[16380] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Око Наксрамаса",
},
[365362] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[262652] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[13338] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лефтендрис",
},
[67037] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Принц Тортелдрин",
},
[17470] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Тимми Беспощадный",
},
[405350] = {
["school"] = 6,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[122832] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Непрощенный",
},
[11829] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вызыватель из братства Справедливости",
},
[364343] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[11837] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вождь Укорз Песчаный Череп",
},
[8264] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Знахарь из племени Песчаной Бури",
},
[78535] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элдретарский фантазм",
},
[201846] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[355913] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[1236111] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[6713] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Охранник из Багрового Легиона",
},
[19131] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Охранник из Багрового Легиона",
},
[450961] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мировой судья Бартилас",
},
[197568] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[10887] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мировой судья Бартилас",
},
[13446] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Уничтоженный кадавр",
},
[5200] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эдвин ван Клиф",
},
[310949] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[372014] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[5208] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Зеленямс",
},
[114051] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[458502] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Одинт-Ревущийфьорд",
},
[361029] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Баронесса Анастари",
},
[14516] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кровопийца из племени Песчаной Бури",
},
[7268] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[15043] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший окудник",
},
[108271] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[22924] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тендрис Криводрев",
},
[22421] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гидротварь",
},
[15063] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Восставший окудник",
},
[6264] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мистер Каюк",
},
[16856] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[12544] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Восставший колдун",
},
[444966] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[1064] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[16141] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изломанный кадавр",
},
[383648] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[20537] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принц Тортелдрин",
},
[15654] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Восставший посвященный",
},
[6304] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рак'Зор",
},
[336126] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[2139] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[98021] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем духовной связи",
},
[22661] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Алззин Перевертень",
},
[16553] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Вурдалак-стервятник",
},
[373304] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Некроэло",
},
[406647] = {
["school"] = 6,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ситапал",
},
[22709] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Лефтендрис",
},
[373305] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некроэло",
},
[406648] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[80009] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сторож из братства Справедливости",
},
[344179] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[458388] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[8600] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Некрум Кишкожуй",
},
[383783] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[447403] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Призыватель огня из племени Буйного Нрава",
},
[13730] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скелет-берсерк",
},
[13738] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Плотоядный живодер",
},
[366155] = {
["school"] = 64,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[15802] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элдретарский фантазм",
},
[18813] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лоскутный ужас",
},
[447406] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Споры Кривого дерева",
},
[16793] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мировой судья Бартилас",
},
[22422] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Гидротварь",
},
[143924] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[450346] = {
["school"] = 72,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Одинт-Ревущийфьорд",
},
[1604] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сул'литуз-поганище",
},
[22478] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Зеврим Терновое Копыто",
},
[6408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Черный страж из братства Справедливости",
},
[458524] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[387113] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[362969] = {
["school"] = 80,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[6432] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мистер Каюк",
},
[224729] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Некрорахнид-ползун",
},
[8269] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вождь Укорз Песчаный Череп",
},
[1234189] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[472325] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[22662] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Алззин Перевертень",
},
[450864] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лефтендрис",
},
[305485] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[22710] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лефтендрис",
},
[146739] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воа-Гордунни",
},
[17105] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Завывающая банши",
},
[15471] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некрорахнид-ползун",
},
[24275] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[450866] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призыватель огня из племени Буйного Нрава",
},
[18670] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Железная Кора - заступник",
},
[22766] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тенелов из племени Буйного Нрава",
},
[444735] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[118] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дэска",
},
[80780] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Визжащая банши",
},
[17201] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элдретарский призрак",
},
[454632] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вождь Укорз Песчаный Череп",
},
[455596] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мировой судья Бартилас",
},
[370898] = {
["school"] = 80,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[11962] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший боевой маг",
},
[153640] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[374348] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[77720] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Руузлу",
},
[474760] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Удомля-Ревущийфьорд",
},
[12493] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плут из племени Буйного Нрава",
},
[374349] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[18327] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Баронесса Анастари",
},
[17843] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Знахарь из племени Песчаной Бури",
},
[80781] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скалокрылая крикунья",
},
[8936] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Удомля-Ревущийфьорд",
},
[341263] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Некроэло",
},
[15587] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший посвященный",
},
[3256] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Скарабей",
},
[11898] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Кровопийца из племени Песчаной Бури",
},
[272790] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[382272] = {
["school"] = 64,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Дэска",
},
[443763] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[7154] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Элдретарский призрак",
},
[16866] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изрыгатель яда",
},
[11020] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сул'литуз-пескорыск",
},
[12557] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скелет-страж",
},
[316099] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воа-Гордунни",
},
[224127] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[80750] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бальназар",
},
[16427] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Некрорахнид-живоглот",
},
[377420] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[78802] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Гидромантка Велрата",
},
[17473] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[446789] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вызыватель из братства Справедливости",
},
[34914] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Некроэло",
},
[212792] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[449217] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[64695] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем хватки земли",
},
[455503] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[53390] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[263725] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[387846] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воа-Гордунни",
},
[345230] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[1223366] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[403695] = {
["school"] = 6,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[196884] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[17293] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Инструктор Галфорд",
},
[377552] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[19645] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Завывающая банши",
},
[5568] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Рамштайн Ненасытный",
},
[188443] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[11639] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глупец из племени Песчаной Бури",
},
[196881] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[264571] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Воа-Гордунни",
},
[61295] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_HEAL"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[197209] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[378076] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[452927] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бальназар",
},
[2645] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[120] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[61391] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Одинт-Ревущийфьорд",
},
[351239] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[423336] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[392375] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[22713] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пимгиб",
},
[384455] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[204598] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Баронесса Анастари",
},
[407480] = {
["school"] = 6,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[358267] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[81297] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[451014] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тендрис Криводрев",
},
[85673] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Ситапал",
},
[360823] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[31598] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Призыватель огня из племени Буйного Нрава",
},
[449115] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[465962] = {
["school"] = 24,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[22995] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принц Тортелдрин",
},
[13787] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скелет-страж",
},
[5115] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Надзиратель из братства Справедливости",
},
[465963] = {
["school"] = 24,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[14874] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Разбойник из племени Буйного Нрава",
},
[262115] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Уркгрюм-Голдринн",
},
[455474] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Удомля-Ревущийфьорд",
},
[78801] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Гидромантка Велрата",
},
[16867] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Баронесса Анастари",
},
[1216424] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Дэска",
},
[343527] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[3603] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Крошшер Снида",
},
[197277] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[6466] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Гоблин-древоруб",
},
[384029] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[17434] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[5143] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[16428] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Некрорахнид-живоглот",
},
[235450] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дэска",
},
[454214] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[40505] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумной вурдалак",
},
[427453] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[215802] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[11831] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Заклинатель штормов из братства Справедливости",
},
[5159] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Гоблин-ремесленник",
},
[405345] = {
["school"] = 6,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[373861] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[120679] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[461498] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[37583] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Принц Тортелдрин",
},
[373862] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[470058] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[586] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Некроэло",
},
[22688] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Алззин Перевертень",
},
[22696] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Одеревеневший страж",
},
[449108] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[362877] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[26297] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[384451] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[204242] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[16798] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Певчий Форрестен",
},
[466469] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[73921] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[13444] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скалокрылая горгулья",
},
[589] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Некроэло",
},
[15496] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[108287] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[122] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[439530] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Удомля-Ревущийфьорд",
},
[454394] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[102793] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Одинт-Ревущийфьорд",
},
[5213] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Гилнид",
},
[344548] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[422382] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Древень",
},
[17235] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Неруб'энкан",
},
[305483] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[10444] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[77978] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Лоскутный ужас",
},
[11971] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скелет-берсерк",
},
[19319] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Алззин Перевертень",
},
[192109] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[406957] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[22920] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Принц Тортелдрин",
},
[17307] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рамштайн Ненасытный",
},
[4979] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вызыватель из братства Справедливости",
},
[3391] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Принц Тортелдрин",
},
[392778] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[11086] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Знахарь Зум'ра",
},
[3600] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем оков земли",
},
[455504] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[8362] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Жрец Тьмы Шезз'зиз",
},
[12739] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[16868] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Баронесса Анастари",
},
[12039] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Жрец Тьмы Шезз'зиз",
},
[11976] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скелет-берсерк",
},
[12550] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Волшебное искажение",
},
[15620] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Певчий Форрестен",
},
[15547] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Темный охотник из племени Песчаной Бури",
},
[15982] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Гидромантка Велрата",
},
[17435] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лорд Аурий Ривендер",
},
[88423] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Удомля-Ревущийфьорд",
},
[16429] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Темный чародей из секты Тузадин",
},
[383061] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[225119] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[388539] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Уркгрюм-Голдринн",
},
[184575] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[341291] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некроэло",
},
[125439] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[341282] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некроэло",
},
[426401] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Некроэло",
},
[459992] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Некроэло",
},
[389372] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Воа-Гордунни",
},
[108366] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Воа-Гордунни",
},
[196840] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Фсо",
},
[12626] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Лоскутный ужас",
},
[9053] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пимгиб",
},
[453206] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Воа-Гордунни",
},
[246152] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[686] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Воа-Гордунни",
},
[367364] = {
["school"] = 64,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[455895] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рамштайн Ненасытный",
},
[407478] = {
["school"] = 6,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[1217528] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Механизм",
},
[18649] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Темный охотник из племени Песчаной Бури",
},
[980] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воа-Гордунни",
},
[382440] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[455130] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Фсо",
},
[470077] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[13704] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Бальназар",
},
[15241] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший окудник",
},
[33975] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Инструктор Галфорд",
},
[13323] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Восставший колдун",
},
[76583] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший монах",
},
[394195] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[453599] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[17366] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Инструктор Галфорд",
},
[17165] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Восставший инквизитор",
},
[17228] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Лефтендрис",
},
[17151] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Восставший инквизитор",
},
[17244] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Баронесса Анастари",
},
[12021] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тимми Беспощадный",
},
[453484] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гидротварь",
},
[9672] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Малекай Бледный",
},
[17162] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Восставший окудник",
},
[217200] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[382445] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[16331] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Певчий Форрестен",
},
[14443] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Певчий Форрестен",
},
[16143] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изуродованный кадавр",
},
[22945] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Волшебный поток",
},
[470466] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фсо",
},
[13376] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Призыватель огня из племени Буйного Нрава",
},
[452928] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бальназар",
},
[13298] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нежить-скарабей",
},
[16324] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Уничтоженный кадавр",
},
[378597] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[16869] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Малекай Бледный",
},
[77472] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[5141] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Крошшер Снида",
},
[13901] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Рудиментное чудовище",
},
[57755] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Уркгрюм-Голдринн",
},
[7948] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Алззин Перевертень",
},
[201754] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Механизм",
},
[80850] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тузадинский некромант",
},
[408383] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ситапал",
},
[16430] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Тузадинский некромант",
},
[6660] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сторож из братства Справедливости",
},
[3605] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гоблин-инженер",
},
[13340] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Дикий бес из племени Буйного Нрава",
},
[114893] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тотем каменной преграды",
},
[450542] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Гилнид",
},
[6435] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мистер Каюк",
},
[383346] = {
["school"] = 6,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[450513] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Рак'Зор",
},
[385042] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[145109] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Удомля-Ревущийфьорд",
},
[385391] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[450515] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рак'Зор",
},
[34026] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зогхан-ЧерныйШрам",
},
[377088] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[15667] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Разбойник из племени Буйного Нрава",
},
[114942] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем целительного прилива",
},
[29426] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Восставший кавалер",
},
[7992] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тенелов из племени Буйного Нрава",
},
[22714] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гидротварь",
},
[448885] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Волшебный поток",
},
[17620] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Малекай Бледный",
},
[22660] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Алззин Перевертень",
},
[1227303] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Искаженный отросток",
},
[8004] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[342242] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[394976] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плеточник Бездны",
},
[7399] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Крошшер Снида",
},
[30451] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[142421] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Древень",
},
[370960] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[16458] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чумной вурдалак",
},
[974] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[20271] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ситапал",
},
[17150] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Восставший колдун",
},
[20798] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Темный чародей из племени Песчаной Бури",
},
[4962] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Неруб'энкан",
},
[450550] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Мистер Каюк",
},
[12471] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Послушник из племени Песчаной Бури",
},
[386931] = {
["school"] = 32,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воа-Гордунни",
},
[22371] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плут из племени Буйного Нрава",
},
[11972] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Охранник из Багрового Легиона",
},
[23920] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[458503] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мёртвыыйцарь-Ревущийфьорд",
},
[31601] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Некрорахнид-ползун",
},
[22689] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Алззин Перевертень",
},
[22419] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Гидротварь",
},
[22938] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгусток маны",
},
[22946] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Волшебный поток",
},
[255937] = {
["school"] = 6,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ситапал",
},
[444736] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[370537] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[6016] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Неруб'энкан",
},
[288675] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Рикчари-ВечнаяПесня",
},
[22994] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Тендрис Криводрев",
},
[118297] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изначальный элементаль огня",
},
[383997] = {
["school"] = 64,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Диверсиона-Ревущийфьорд",
},
[459753] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фенрир",
},
[357170] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Целиталь-Ревущийфьорд",
},
[11443] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Темный чародей из секты Тузадин",
},
[127797] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Одинт-Ревущийфьорд",
},
[383104] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Уркгрюм-Голдринн",
},
[17405] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бальназар",
},
},
["emotes"] = {
{
["boss"] = "Лорд Аурий Ривендер",
},
{
["boss"] = "Рамштайн Ненасытный",
},
{
["boss"] = "Неруб'энкан",
},
},
}
