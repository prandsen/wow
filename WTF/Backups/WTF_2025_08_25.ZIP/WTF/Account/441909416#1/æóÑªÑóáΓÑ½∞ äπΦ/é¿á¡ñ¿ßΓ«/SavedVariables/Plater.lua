
PlaterDBChr = {
["spellRangeCheckRangeFriendly"] = {
[260] = 10,
[261] = 10,
[259] = 10,
},
["buffsBanned"] = {
},
["first_run3"] = {
["Player-1604-0AA7EEC3"] = true,
},
["minimap"] = {
},
["resources_on_target"] = false,
["debuffsBanned"] = {
},
["spellRangeCheckRangeEnemy"] = {
[260] = 20,
[261] = 30,
[259] = 30,
},
}
