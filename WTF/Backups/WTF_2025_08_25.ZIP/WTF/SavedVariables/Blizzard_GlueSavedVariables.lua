
g_collapsedServerAlert = nil
g_characterSelectToolTrayCollapsed = nil
g_newGameModeAvailableAcknowledged = nil
