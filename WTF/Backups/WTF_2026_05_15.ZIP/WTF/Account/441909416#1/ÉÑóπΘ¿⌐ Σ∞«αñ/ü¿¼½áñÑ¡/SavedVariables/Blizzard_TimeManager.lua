
BlizzardStopwatchOptions = {
["position"] = {
["y"] = 905.487548828125,
["x"] = 666.1541748046875,
},
}
