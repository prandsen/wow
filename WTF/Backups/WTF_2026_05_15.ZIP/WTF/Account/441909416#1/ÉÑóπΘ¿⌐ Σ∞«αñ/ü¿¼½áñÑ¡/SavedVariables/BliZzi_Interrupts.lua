
BliZziInterruptsSavedVarsChar = {
["posXUp"] = 1345.538940429688,
["posYUp"] = 396.9219970703125,
["posY"] = 444.0802001953125,
["posX"] = 1380.203369140625,
}
