
BlizzardStopwatchOptions = {
["position"] = {
["y"] = 945.6920776367188,
["x"] = 666.1541748046875,
},
}
