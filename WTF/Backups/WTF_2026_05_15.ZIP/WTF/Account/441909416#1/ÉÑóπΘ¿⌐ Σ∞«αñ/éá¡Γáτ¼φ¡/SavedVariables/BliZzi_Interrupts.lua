
BliZziInterruptsSavedVarsChar = {
["posXUp"] = 1345.5380859375,
["posYUp"] = 392.8206787109375,
}
