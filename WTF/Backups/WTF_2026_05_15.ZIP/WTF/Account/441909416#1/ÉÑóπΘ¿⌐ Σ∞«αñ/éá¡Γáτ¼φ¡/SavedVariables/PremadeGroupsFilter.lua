
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dungeon6"] = false,
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dungeon2"] = false,
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
["difficulty"] = {
},
["dungeon1"] = false,
["dungeon7"] = true,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
["dungeon8"] = false,
["dungeon3"] = false,
["dungeon5"] = false,
["dungeon4"] = false,
},
},
["c121f4"] = {
["enabled"] = true,
},
["version"] = 8,
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
["act"] = true,
["val"] = 3,
},
["heals"] = {
["max"] = "3",
["min"] = "",
["act"] = true,
},
["tanks"] = {
["max"] = "",
["min"] = "2",
["act"] = true,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c3f6"] = {
["enabled"] = true,
},
["c9f8"] = {
["enabled"] = true,
},
}
