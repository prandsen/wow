
_detalhes_database = {
["savedbuffs"] = {
},
["mythic_dungeon_id"] = 28,
["tabela_historico"] = {
["tabelas"] = {
},
},
["apocalypse_savedsegments"] = {
},
["ocd_tracker"] = {
["enabled"] = false,
["current_cooldowns"] = {
},
["lines_per_column"] = 12,
["group_frames"] = true,
["width"] = 120,
["frames"] = {
["defensive-raid"] = {
},
["main"] = {
},
["ofensive"] = {
},
["defensive-target"] = {
},
["utility"] = {
},
["defensive-personal"] = {
},
},
["show_options"] = false,
["ignored_cooldowns"] = {
},
["framme_locked"] = false,
["cooldowns"] = {
},
["own_frame"] = {
["defensive-raid"] = false,
["ofensive"] = false,
["defensive-target"] = false,
["utility"] = false,
["defensive-personal"] = false,
},
["height"] = 18,
["show_conditions"] = {
["only_inside_instance"] = true,
["only_in_group"] = true,
},
["show_title"] = true,
["filters"] = {
["itemutil"] = false,
["itempower"] = false,
["defensive-target"] = false,
["itemheal"] = false,
["defensive-personal"] = false,
["defensive-raid"] = false,
["ofensive"] = true,
["crowdcontrol"] = false,
["utility"] = false,
},
},
["combat_counter"] = 1693,
["damage_meter_sessions"] = {
},
["force_font_outline"] = "",
["tabela_instancias"] = {
},
["arena_data_compressed"] = {
},
["arena_data_index_selected"] = 1,
["on_death_menu"] = false,
["last_day"] = "05",
["SoloTablesSaved"] = {
["Mode"] = 1,
},
["announce_firsthit"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["last_instance_id"] = 658,
["data_harvest_for_charsts"] = {
["players"] = {
{
["name"] = "Damage of Each Individual Player",
["playerOnly"] = true,
["playerKey"] = "total",
["combatObjectContainer"] = 1,
},
},
["totals"] = {
{
["combatObjectSubTableKey"] = 1,
["name"] = "Damage of All Player Combined",
["combatObjectSubTableName"] = "totals",
},
},
},
["announce_interrupts"] = {
["enabled"] = false,
["whisper"] = "",
["channel"] = "SAY",
["custom"] = "",
["next"] = "",
},
["announce_prepots"] = {
["enabled"] = false,
["channel"] = "SELF",
["reverse"] = false,
},
["active_profile"] = "All classes",
["last_realversion"] = 172,
["damage_meter_session_info"] = {
},
["benchmark_db"] = {
["frame"] = {
},
},
["local_instances_config"] = {
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = false,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 2,
["pos"] = {
["normal"] = {
["y"] = -271.9340515136719,
["x"] = 905.9224853515625,
["w"] = 283.7429809570313,
["h"] = 52.12850570678711,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
5,
1,
},
["snap"] = {
[2] = 3,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -386.3196868896484,
["x"] = 904.2833251953125,
["w"] = 285.384033203125,
["h"] = 121.8720397949219,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
{
["modo"] = 2,
["sub_attribute"] = 1,
["horizontalSnap"] = false,
["verticalSnap"] = true,
["isLocked"] = true,
["is_open"] = true,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["snap"] = {
[4] = 2,
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -528.1917152404785,
["x"] = 904.2833251953125,
["w"] = 285.384033203125,
["h"] = 121.8720474243164,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
},
["ignore_nicktag"] = false,
["combat_log"] = {
["inverse_deathlog_overalldata"] = false,
["track_hunter_frenzy"] = false,
["merge_gemstones_1007"] = false,
["merge_critical_heals"] = false,
["inverse_deathlog_raid"] = false,
["calc_evoker_damage"] = true,
["evoker_show_realtimedps"] = false,
["inverse_deathlog_mplus"] = false,
},
["nick_tag_cache"] = {
["last_version"] = 16,
["nextreset"] = 1779225875,
},
["plugin_database"] = {
["DETAILS_PLUGIN_TINY_THREAT"] = {
["enabled"] = true,
["only_my_group"] = false,
["animate"] = false,
["disable_gouge"] = false,
["hide_pull_bar"] = false,
["author"] = "Terciob",
["playercolor"] = {
1,
1,
1,
},
["usefocus"] = false,
["updatespeed"] = 1,
["playSound"] = false,
["showamount"] = false,
["useplayercolor"] = false,
["absolute_mode"] = false,
["show_party_pets"] = false,
["playSoundFile"] = "Details Threat Warning Volume 3",
["useclasscolors"] = false,
},
["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
["enabled"] = true,
["author"] = "Terciob",
["max_compares"] = 4,
["compare_type"] = 1,
},
["DETAILS_PLUGIN_VANGUARD"] = {
["tank_block_size_height"] = 50,
["show_power_bar"] = false,
["first_run"] = false,
["aura_timer_text_size"] = 14,
["tank_block_castbar_size_height"] = 16,
["show_health_bar"] = true,
["aura_offset_y"] = 0,
["enabled"] = true,
["show_cast_bar"] = false,
["author"] = "Terciob",
["tank_block_size"] = 150,
["bar_height"] = 24,
["tank_block_texture"] = "Details Serenity",
["tank_block_color"] = {
0.074509,
0.035294,
0.035294,
0.832845,
},
["tank_block_height"] = 40,
["tank_block_powerbar_size_height"] = 10,
["show_inc_bars"] = true,
},
["DETAILS_PLUGIN_RAIDCHECK"] = {
["enabled"] = true,
["food_tier1"] = true,
["mythic_1_4"] = true,
["food_tier2"] = true,
["author"] = "Terciob",
["use_report_panel"] = true,
["pre_pot_healers"] = false,
["pre_pot_tanks"] = false,
["food_tier3"] = true,
},
["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
["use_square_mode"] = false,
["is_first_run"] = false,
["arrow_color"] = {
1,
1,
1,
0.7989778518676758,
},
["scale"] = 1,
["main_frame_size"] = {
300.0000915527344,
500.0000305175781,
},
["minimap"] = {
["minimapPos"] = 160,
["radius"] = 160,
["hide"] = true,
},
["row_height"] = 20,
["arrow_anchor_x"] = 0,
["font_color"] = {
1,
1,
1,
1,
},
["row_texture"] = "Melli",
["square_grow_direction"] = "right",
["point"] = "RIGHT",
["main_frame_strata"] = "LOW",
["square_amount"] = 5,
["enabled"] = false,
["arrow_size"] = 10,
["per_second"] = {
["enabled"] = false,
["point"] = "CENTER",
["scale"] = 1,
["font_shadow"] = true,
["y"] = 0,
["x"] = 0,
["size"] = 32,
["update_speed"] = 0.05,
["attribute_type"] = 1,
},
["row_spacement"] = 20,
["main_frame_color"] = {
0,
0,
0,
0,
},
["author"] = "Terciob",
["arrow_texture"] = "Interface\\OPTIONSFRAME\\VoiceChat-Play",
["y"] = -28.71774291992188,
["font_size"] = 11,
["x"] = -269.126708984375,
["font_face"] = "ITCAvantGardeGothicDemi",
["square_size"] = 32,
["use_spark"] = false,
["row_color"] = {
0,
0,
0,
0.4000000059604645,
},
["main_frame_locked"] = false,
["arrow_anchor_y"] = 0,
},
},
["mythic_plus_log"] = {
"14/04/26 22:56:17|Activity Time: 0",
"14/04/26 22:56:17|GetChallengeCompletionInfo() Found, Time: 1675",
"14/04/26 22:56:17|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"14/04/26 22:56:17|MythicDungeonFinished() | merge_boss_trash = true",
"14/04/26 22:56:15|===== Mythic+ Finished =====",
"14/04/26 22:27:01|OnChallengeModeStart()",
"14/04/26 22:27:01|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | reverse_death_log = false | autoclose_time = 90 | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 10 | zone: Яма Сарона | zoneId: 658",
"14/04/26 22:27:01|CHALLENGE_MODE_START timer ended, starting the dungeon.",
"14/04/26 22:26:51|Event: CHALLENGE_MODE_START, starting 10 seconds timer | Level: 10",
"14/04/26 22:12:17|Activity Time: 0",
"14/04/26 22:12:17|GetChallengeCompletionInfo() Found, Time: 1396",
"14/04/26 22:12:17|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"14/04/26 22:12:17|MythicDungeonFinished() | merge_boss_trash = true",
"14/04/26 22:12:15|===== Mythic+ Finished =====",
"14/04/26 21:48:20|OnChallengeModeStart()",
"14/04/26 21:48:20|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | reverse_death_log = false | autoclose_time = 90 | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 10 | zone: Пещеры Маисара | zoneId: 2874",
"14/04/26 21:48:20|CHALLENGE_MODE_START timer ended, starting the dungeon.",
"14/04/26 21:48:10|Event: CHALLENGE_MODE_START, starting 10 seconds timer | Level: 10",
"14/04/26 21:44:15|Activity Time: 0",
"14/04/26 21:44:15|GetChallengeCompletionInfo() Found, Time: 1195",
"14/04/26 21:44:15|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"14/04/26 21:44:15|MythicDungeonFinished() | merge_boss_trash = true",
"14/04/26 21:44:15|MergeTrashCleanup | no segments to merge.",
"14/04/26 21:44:15|BossDefeated | key level: | 0 | Неизвестно | Пещеры Маисара",
"14/04/26 21:44:15|ZONE_CHANGED_NEW_AREA | player has left the dungeon and Details! finished the dungeon because of that.",
"14/04/26 21:37:06|OnChallengeModeStart()",
"14/04/26 21:37:06|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | reverse_death_log = false | autoclose_time = 90 | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 12 | zone: Пещеры Маисара | zoneId: 2874",
"14/04/26 21:37:06|CHALLENGE_MODE_START timer ended, starting the dungeon.",
"14/04/26 21:36:56|Event: CHALLENGE_MODE_START, starting 10 seconds timer | Level: 12",
"14/04/26 21:31:03|Activity Time: 1270.816",
"14/04/26 21:31:03|GetChallengeCompletionInfo() Found, Time: 1195",
"14/04/26 21:31:03|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"14/04/26 21:31:03|MythicDungeonFinished() | merge_boss_trash = true",
"14/04/26 21:31:02|COMBAT_PLAYER_LEAVE | wiped on boss | key level: | 10 | Л'ура Престол Триумвирата",
"14/04/26 21:31:01|===== Mythic+ Finished =====",
"14/04/26 21:27:04|COMBAT_PLAYER_LEAVE | wiped on boss | key level: | 10 | Наместник Незжар Престол Триумвирата",
"14/04/26 21:21:56|COMBAT_PLAYER_LEAVE | wiped on boss | key level: | 10 | Сарпиш Престол Триумвирата",
"14/04/26 21:12:40|COMBAT_PLAYER_LEAVE | wiped on boss | key level: | 10 | Зураал Перерожденный Престол Триумвирата",
"14/04/26 21:09:07|OnChallengeModeStart()",
"14/04/26 21:09:06|COMBAT_MYTHICDUNGEON_START | settings: make_overall_boss_only = false | merge_boss_trash = true | delay_to_show_graphic = 1 | mythicrun_time_type = 1 | reverse_death_log = false | autoclose_time = 90 | show_damage_graphic = true | boss_dedicated_segment = true |  | level: 10 | zone: Престол Триумвирата | zoneId: 1753",
"14/04/26 21:09:06|CHALLENGE_MODE_START timer ended, starting the dungeon.",
"14/04/26 21:08:56|Event: CHALLENGE_MODE_START, starting 10 seconds timer | Level: 10",
"14/04/26 19:48:44|Activity Time: 895.625",
"14/04/26 19:48:44|GetChallengeCompletionInfo() Found, Time: 1071",
"14/04/26 19:48:44|MergeSegmentsOnEnd started | creating the overall segment at the end of the run.",
"14/04/26 19:48:44|MythicDungeonFinished() | merge_boss_trash = true",
"14/04/26 19:48:42|COMBAT_PLAYER_LEAVE | wiped on boss | key level: | 11 | Высший мудрец Вирикс Небесный Путь",
"14/04/26 19:48:42|===== Mythic+ Finished =====",
"14/04/26 19:42:02|COMBAT_PLAYER_LEAVE | wiped on boss | key level: | 11 | Рухран Небесный Путь",
},
["character_data"] = {
["logons"] = 131,
},
["data_harvested_for_charts"] = {
},
["player_stats"] = {
},
["mythic_dungeon_currentsaved"] = {
["players"] = {
"Player-1309-0BE4A8BF",
"Player-1602-0FD7EB33",
"Player-1309-04A432F6",
"Player-1929-0FD713FA",
},
["dungeon_name"] = "Яма Сарона",
["started"] = false,
["segment_id"] = 1,
["ej_id"] = 0,
["started_at"] = 1776191230.7,
["run_id"] = 28,
["level"] = 10,
["dungeon_zone_id"] = 658,
["previous_boss_killed_at"] = 1776191221,
},
["cached_talents"] = {
},
["last_version"] = "12.0.5 15050",
["combat_id"] = 660,
["savedStyles"] = {
},
["cached_roles"] = {
},
["last_encounter"] = "Ослепленный авангард",
["announce_deaths"] = {
["enabled"] = false,
["last_hits"] = 1,
["only_first"] = 5,
["where"] = 1,
},
["tabela_overall"] = {
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
{
["tipo"] = 3,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["tempo_start"] = 106986.077,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["totals_grupo"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["bossTimers"] = {
},
["trinketProcs"] = {
},
["playerTalents"] = {
},
["totals"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["cleu_events"] = {
["n"] = 1,
},
["frags_need_refresh"] = false,
["aura_timeline"] = {
},
["compressed_charts"] = {
},
["data_inicio"] = 0,
["amountCasts"] = {
},
["mapId"] = 0,
["instance_type"] = "none",
["zoneName"] = "Восточные королевства",
["boss_hp"] = 1,
["is_challenge"] = false,
["frags"] = {
},
["data_fim"] = 0,
["cleu_timeline"] = {
},
["spells_cast_timeline"] = {
},
["PhaseData"] = {
{
1,
1,
},
["heal_section"] = {
},
["heal"] = {
},
["damage_section"] = {
},
["damage"] = {
},
},
["start_time"] = 0,
["TimeData"] = {
},
["combat_counter"] = 1692,
},
["coach"] = {
["enabled"] = false,
["welcome_panel_pos"] = {
},
["last_coach_name"] = false,
},
["arena_data_headers"] = {
},
["last_instance_time"] = 1776191176,
["announce_cooldowns"] = {
["enabled"] = false,
["ignored_cooldowns"] = {
},
["custom"] = "",
["channel"] = "RAID",
},
["rank_window"] = {
["last_difficulty"] = 15,
["last_raid"] = "",
},
["announce_damagerecord"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["cached_specs"] = {
["Player-1604-09765C91"] = 65,
},
}
