
PremadeGroupsFilterState = {
["c114f4"] = {
["enabled"] = true,
},
["c4f8"] = {
["enabled"] = true,
},
["c1f4"] = {
["role"] = {
["heals"] = {
},
["tanks"] = {
},
["dps"] = {
},
["members"] = {
},
["expression"] = "",
},
},
["c2f4"] = {
["enabled"] = true,
["dungeon"] = {
["mprating"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["heals"] = {
["max"] = "0",
["min"] = "",
["act"] = true,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "3",
["min"] = "",
["act"] = true,
},
["expression"] = "",
["difficulty"] = {
},
["dungeon4"] = true,
["dungeon8"] = false,
["dungeon2"] = false,
["tanks"] = {
["max"] = "",
["min"] = "1",
["act"] = true,
},
},
},
["c121f4"] = {
["enabled"] = true,
},
["version"] = 8,
["c9f8"] = {
["enabled"] = true,
},
["c114f6"] = {
["enabled"] = true,
},
["c114f5"] = {
["enabled"] = true,
},
["c3f6"] = {
["enabled"] = true,
},
["c3f5"] = {
["enabled"] = true,
["raid"] = {
["difficulty"] = {
},
["heals"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["tanks"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["defeated"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["dps"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["members"] = {
["max"] = "",
["min"] = "",
["act"] = false,
},
["expression"] = "",
},
},
}
