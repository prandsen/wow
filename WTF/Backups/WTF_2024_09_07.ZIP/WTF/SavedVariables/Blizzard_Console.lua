
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 299.9999694824219,
["messageHistory"] = {
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"Got new connection 2",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 13:17",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 13h 53m 38s",
0,
},
{
"Level: 0d 1h 18m 44s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000000041",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004041",
0,
},
{
"Proficiency in item class 2 set to 0x0000004441",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x0000006441",
0,
},
{
"Proficiency in item class 2 set to 0x0000006451",
0,
},
{
"Proficiency in item class 2 set to 0x00000064d1",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x00000064d1",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 13:19",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 103d 4h 29m 2s",
0,
},
{
"Level: 0d 0h 10m 51s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2461.71, -2304.18, 1054.43)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2552 with translation: (0.340088, 0.820068, 1131.33)\n    Location : (2256.66, -2269.68, 563.432)\n    Location in previous map : (2256.32, -2270.5, -567.901)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2552. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2257.43, -2266.9, -569.183)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2464.88, -2302.07, 1044.77)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2552 with translation: (0.340088, 0.820068, 1131.33)\n    Location : (2264.52, -2253.29, 560.986)\n    Location in previous map : (2264.18, -2254.11, -570.347)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2552. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2265.67, -2252.35, -571.113)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 9/6/2024 (Fri) 14:24, newtime = 9/6/2024 (Fri) 14:26)",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2091.59, -2454.33, 739.533)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2040.56, -2454.13, 742.163)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2091.59, -2454.33, 739.533)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2043.22, -2455.22, 741.024)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2091.59, -2454.33, 739.533)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2040.09, -2455.24, 741.964)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2089.15, -2454.35, 739.318)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2040.97, -2455.28, 741.922)",
0,
},
{
"[Airlock] Preload initiated.",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"[Airlock] Received Cancel Preload for MapID 2601, but we have not preloaded it. Current preloaded map: -1",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.195944\n",
0,
},
{
"Weather changed to 2, intensity 0.292656\n",
0,
},
{
"Weather changed to 1, intensity 0.127707\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 15:44",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 13h 55m 42s",
0,
},
{
"Level: 0d 1h 20m 48s",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000001",
0,
},
{
"Proficiency in item class 2 set to 0x0000008001",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c001",
0,
},
{
"Proficiency in item class 2 set to 0x000000c003",
0,
},
{
"Proficiency in item class 2 set to 0x000000c403",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x000000c423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e423",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Proficiency in item class 2 set to 0x000000e433",
0,
},
{
"Proficiency in item class 4 set to 0x000000006f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 15:51",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 48d 2h 53m 25s",
0,
},
{
"Level: 0d 5h 40m 35s",
0,
},
{
"Weather changed to 1, intensity 0.175066\n",
0,
},
{
"Weather changed to 2, intensity 0.292548\n",
0,
},
{
"Weather changed to 1, intensity 0.120573\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 16:01",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 14h 1m 51s",
0,
},
{
"Level: 0d 1h 26m 57s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[GlueLogin] [F] Explicitly disconnecting from realm server",
0,
},
{
"Disconnecting for reason 14",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"[GlueLogin] [F] Disconnected from WoW previouslyConnected=\"false\"",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Destroying isInitialized=\"true\"",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Fatal error while logging in result=\"( code=\"\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"2\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"2\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[IBN_Login] [F] Destroying isInitialized=\"true\"",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725633285\" expirationTime=\"1725647685\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 16:34",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 14h 34m 4s",
0,
},
{
"Level: 0d 1h 59m 10s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725644338\" expirationTime=\"1725658738\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"Got new connection 2",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-33\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 19:38",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 321d 19h 0m 23s",
0,
},
{
"Level: 2d 0h 14m 37s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"[IBN_Login] [F] Requesting change realm list",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting realm lists numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"Disconnecting for reason 12",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net destroyed.",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 19:40",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 14h 55m 49s",
0,
},
{
"Level: 0d 2h 20m 55s",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.182470\n",
0,
},
{
"Weather changed to 2, intensity 0.217098\n",
0,
},
{
"Weather changed to 1, intensity 0.180496\n",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 9/6/2024 (Fri) 20:37, newtime = 9/6/2024 (Fri) 20:39)",
0,
},
{
"Weather changed to 2, intensity 0.298101\n",
0,
},
{
"Weather changed to 1, intensity 0.121557\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.135977\n",
0,
},
{
"Weather changed to 2, intensity 0.201286\n",
0,
},
{
"Weather changed to 1, intensity 0.108810\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/6/2024 (Fri) 21:49",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 16h 47m 52s",
0,
},
{
"Level: 0d 4h 12m 58s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"ModifierTree: 132484.  Modifier not supported on client (type=174, asset=59755, secondaryAsset=0, tertiaryAsset=0). Put in a task to add this.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 343955 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344017 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344018 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344024 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344028 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344115 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344223 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Spell 344224 tried to cast with a spellVisualScript evaluated on the client.  This is unsupported.",
3,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Use trigger on BeginDrawComplete enabled.",
4,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"[GlueLogin] [F] Starting login launcherPortal=\"eu.actual.battle.net\" loginPortal=\"eu.actual.battle.net:1119\"",
0,
},
{
"[GlueLogin] [F] Resetting",
0,
},
{
"[IBN_Login] [F] Initializing",
0,
},
{
"[IBN_Login] [F] Attempting logon host=\"eu.actual.battle.net\" port=\"1119\"",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Waiting for server response.",
0,
},
{
"[GlueLogin] [F] Logon complete.",
0,
},
{
"[GlueLogin] [F] Reconnect token saved;  creationTime=\"1725706526\" expirationTime=\"1725720926\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Requesting realm list ticket",
0,
},
{
"[IBN_Login] [F] Received realm list ticket code=\"ERROR_OK\"",
0,
},
{
"[GlueLogin] [F] Waiting for realm list.",
0,
},
{
"[IBN_Login] [F] Received sub region list code=\"ERROR_OK\"",
0,
},
{
"[IBN_Login] [F] Requesting last played chars numSubRegions=\"3\"",
0,
},
{
"[GlueLogin] [F] Realm list ready.",
0,
},
{
"[IBN_Login] [F] Joining realm subRegion=\"3-4-89\" realmAddress=\"3-7-18\"",
0,
},
{
"[IBN_Login] [F] OnRealmJoin code=\"ERROR_OK\"",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[GlueLogin] [F] Received AuthedToWoW result=\"ERROR_OK\"",
0,
},
{
"Got new connection 2",
0,
},
{
"[IBN_Login] [F] Front disconnecting connectionId=\"1\"",
0,
},
{
"[GlueLogin] [F] Disconnecting from authentication server.",
0,
},
{
"[IBN_BackInterface] [F] Session with Battle.net established.",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 18 entitlements.",
0,
},
{
"[IBN_Login] [F] Front disconnected connectionId=\"1\" result=\"( code=\"ERROR_NETWORK_MODULE_SOCKET_CLOSED\" localizedMessage=\"\" debugMessage=\"\")\"",
0,
},
{
"[GlueLogin] [F] Disconnected from authentication server.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/7/2024 (Sat) 12:55",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 20h 34m 38s",
0,
},
{
"Level: 0d 7h 59m 44s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: ShowObjUsage\n",
0,
},
{
"Attempted to register existing command: SetDifficulty\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000100",
0,
},
{
"Proficiency in item class 2 set to 0x0000000101",
0,
},
{
"Proficiency in item class 2 set to 0x0000000141",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x0000004141",
0,
},
{
"Proficiency in item class 2 set to 0x0000004143",
0,
},
{
"Proficiency in item class 4 set to 0x0000000061",
0,
},
{
"Proficiency in item class 4 set to 0x0000000069",
0,
},
{
"Proficiency in item class 4 set to 0x000000006d",
0,
},
{
"Proficiency in item class 2 set to 0x0000004163",
0,
},
{
"Proficiency in item class 4 set to 0x000000007d",
0,
},
{
"Proficiency in item class 2 set to 0x0000104163",
0,
},
{
"Proficiency in item class 2 set to 0x0000104173",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Proficiency in item class 2 set to 0x00001041f3",
0,
},
{
"Proficiency in item class 4 set to 0x000000007f",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 9/7/2024 (Sat) 13:27",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 119d 21h 3m 7s",
0,
},
{
"Level: 0d 8h 28m 13s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
