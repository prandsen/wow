
RaiderIO_Config = {
["replayAlpha"] = 1,
["enableKeystoneTooltips"] = true,
["profilePoint"] = {
["y"] = 0,
["x"] = -16,
["point"] = "TOPLEFT",
},
["enableReplay"] = true,
["enableLFGDropdown"] = true,
["minimapIcon"] = {
["minimapPos"] = 180,
["showInCompartment"] = true,
["hide"] = true,
["lock"] = false,
},
["showMainsScore"] = true,
["showRaidEncountersInProfile"] = true,
["showAverageScore"] = true,
["enableWhoMessages"] = false,
["useEnglishAbbreviations"] = true,
["disableScoreColors"] = false,
["showMainBestScore"] = true,
["allowClientToControlCombatLog"] = false,
["replayBackground"] = {
["a"] = 0.5,
["b"] = 0,
["g"] = 0,
["r"] = 0,
},
["mplusHeadlineMode"] = 0,
["showScoreInCombat"] = true,
["showRaiderIOProfile"] = true,
["inverseProfileModifier"] = false,
["enableGuildTooltips"] = true,
["enableCombatLogTracking"] = false,
["enableClientEnhancements"] = true,
["enableLFGTooltips"] = true,
["positionProfileAuto"] = true,
["showRoleIcons"] = true,
["enableFriendsTooltips"] = true,
["hidePersonalRaiderIOProfile"] = false,
["showDropDownCopyURL"] = true,
["enableUnitTooltips"] = true,
["enableProfileModifier"] = true,
["showScoreModifier"] = false,
["enableWhoTooltips"] = false,
["lockProfile"] = false,
["showSimpleScoreColors"] = false,
["replaySelection"] = "user_best_replay",
["showClientGuildBest"] = true,
}
RaiderIO_LastCharacter = "eu-Сэйвмэн-soulflayer"
RaiderIO_MissingCharacters = {
["eu-Тайдорбери-soulflayer"] = true,
["eu-Крыса-soulflayer"] = true,
["eu-Огиончек-soulflayer"] = true,
["eu-Bobbykotik-twisting-nether"] = true,
["eu-Гапс-soulflayer"] = true,
["eu-Архибич-soulflayer"] = true,
["eu-Бергрист-soulflayer"] = true,
["eu-Громолом-soulflayer"] = true,
["eu-Зоуни-soulflayer"] = true,
["eu-Кидульт-soulflayer"] = true,
["eu-Мрс-soulflayer"] = true,
["eu-Олтри-soulflayer"] = true,
["eu-Почата-soulflayer"] = true,
["eu-Баблблад-soulflayer"] = true,
["eu-Опенпалмсх-soulflayer"] = true,
["eu-Мачамба-soulflayer"] = true,
["eu-Яидваклоунах-soulflayer"] = true,
["eu-Инцелок-soulflayer"] = true,
["eu-Фарадея-soulflayer"] = true,
["eu-Сэйвмэн-soulflayer"] = true,
}
RaiderIO_MissingServers = {
}
RaiderIO_CachedRuns = nil
RaiderIO_RWF = {
}
RaiderIO_CompletedReplays = {
}
