
g_auctionHouseSortsBySearchContext = {
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = true,
["sortOrder"] = 2,
},
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
},
{
{
["reverseSort"] = true,
["sortOrder"] = 2,
},
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
},
{
{
["reverseSort"] = true,
["sortOrder"] = 2,
},
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 4,
},
{
["reverseSort"] = false,
["sortOrder"] = 3,
},
},
{
},
{
{
["reverseSort"] = false,
["sortOrder"] = 4,
},
{
["reverseSort"] = false,
["sortOrder"] = 3,
},
},
{
},
{
{
["reverseSort"] = false,
["sortOrder"] = 4,
},
{
["reverseSort"] = false,
["sortOrder"] = 3,
},
},
{
},
{
{
["reverseSort"] = false,
["sortOrder"] = 4,
},
{
["reverseSort"] = false,
["sortOrder"] = 3,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
},
{
{
["reverseSort"] = false,
["sortOrder"] = 1,
},
{
["reverseSort"] = false,
["sortOrder"] = 0,
},
},
["auctionHouseSortVersion"] = 2,
}
