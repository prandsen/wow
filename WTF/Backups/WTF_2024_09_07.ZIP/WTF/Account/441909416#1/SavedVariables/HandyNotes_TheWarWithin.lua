
HandyNotes_TheWarWithinDB = {
["profileKeys"] = {
["Сорчистино - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
["Вантачмэн - Ревущий фьорд"] = "Default",
["Дракобес - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["icon_display_profession_treasures"] = false,
["icon_display_flat_earthen"] = false,
},
},
}
