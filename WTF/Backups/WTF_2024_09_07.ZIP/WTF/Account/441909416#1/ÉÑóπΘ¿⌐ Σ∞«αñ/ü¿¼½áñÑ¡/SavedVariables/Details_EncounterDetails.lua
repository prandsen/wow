
EncounterDetailsDB = {
["chartData"] = {
[2413] = {
["Raid Damage Done"] = {
21932,
35778,
34515,
34517,
26099,
["max_value"] = 35778,
["__time"] = 1725621187,
},
},
[2303] = {
},
[2311] = {
},
[2382] = {
["Raid Damage Done"] = {
565956,
0,
77999,
64707,
104908,
20847,
170330,
642161,
20846,
327855,
126606,
463086,
104577,
568488,
105534,
411489,
78529,
321140,
237014,
239591,
79938,
301692,
84276,
63144,
192245,
["max_value"] = 642161,
["__time"] = 1725546866,
},
},
[2091] = {
},
[2320] = {
},
[2314] = {
},
[2304] = {
},
[2312] = {
},
[2383] = {
["Raid Damage Done"] = {
56121,
121344,
365414,
188244,
57148,
503349,
549555,
18296,
190080,
215811,
115191,
956729,
694079,
420171,
405014,
569461,
265886,
515283,
177339,
523082,
562610,
222790,
344589,
339219,
458716,
46020,
535084,
295962,
117828,
227071,
0,
201698,
93927,
92507,
28585,
38705,
90147,
291635,
0,
["max_value"] = 956729,
["__time"] = 1725546911,
},
},
[2322] = {
},
[2318] = {
},
[2305] = {
},
[2313] = {
},
[2384] = {
["Raid Damage Done"] = {
76202,
93848,
183072,
4637,
180325,
553303,
150687,
43628,
726384,
561190,
111135,
398790,
155945,
169653,
["max_value"] = 726384,
["__time"] = 1725546945,
},
},
[2060] = {
},
[2306] = {
},
[2062] = {
},
[2385] = {
["Raid Damage Done"] = {
47198,
153118,
555887,
86690,
417525,
1175604,
73483,
347108,
220697,
443105,
46268,
250511,
87913,
9413,
73077,
0,
["max_value"] = 1175604,
["__time"] = 1725546969,
},
},
[2064] = {
},
[2088] = {
},
[2307] = {
},
[2063] = {
},
[2386] = {
["Raid Damage Done"] = {
126505,
115067,
517361,
22013,
193160,
45984,
60295,
401081,
0,
["max_value"] = 517361,
["__time"] = 1725546995,
},
},
[2321] = {
},
[2300] = {
},
[2308] = {
},
[2316] = {
},
[2387] = {
["Raid Damage Done"] = {
50857,
137441,
344665,
118512,
398151,
100725,
605113,
189534,
366665,
327945,
34705,
471194,
0,
64902,
0,
177331,
176114,
10228,
431367,
111004,
212144,
211904,
179785,
368800,
110374,
640467,
381830,
213163,
424586,
149801,
137997,
82606,
180603,
33355,
237578,
213939,
0,
0,
99961,
89489,
210230,
106637,
325637,
445143,
292902,
107068,
49193,
91968,
40657,
332442,
74480,
217381,
51109,
604565,
790562,
754779,
130243,
716406,
["max_value"] = 790562,
["__time"] = 1725547061,
},
},
[2317] = {
},
[2301] = {
},
[2309] = {
},
[2380] = {
["Raid Damage Done"] = {
56864,
56079,
169296,
0,
92950,
138400,
62375,
51516,
77176,
327110,
124185,
81670,
462207,
279159,
108069,
381053,
338603,
996062,
1127250,
378536,
461446,
518184,
236445,
386869,
61066,
136180,
83964,
114524,
101945,
317474,
71361,
194209,
198486,
57881,
289234,
223227,
48416,
69176,
245594,
111218,
111492,
98247,
199701,
17178,
62136,
53872,
40903,
58894,
0,
67499,
39745,
19295,
20451,
39746,
57223,
0,
19293,
14582,
0,
0,
0,
0,
0,
4021,
52071,
46492,
173389,
44845,
337234,
183341,
127432,
189029,
345782,
109232,
71966,
162736,
215920,
136767,
436388,
10569,
0,
["max_value"] = 1127250,
["__time"] = 1725546669,
},
},
[2388] = {
["Raid Damage Done"] = {
219591,
404253,
35826,
530278,
603119,
345671,
117216,
230379,
109019,
300644,
41474,
465983,
409335,
496175,
123055,
415053,
427031,
513533,
442147,
628488,
123134,
276629,
181401,
411788,
182858,
227673,
86953,
348935,
331807,
121702,
62494,
222326,
285542,
130511,
231301,
641342,
235141,
50866,
146727,
111324,
85715,
173882,
101131,
["max_value"] = 641342,
["__time"] = 1725547105,
},
},
[2412] = {
["Raid Damage Done"] = {
86907,
134128,
157480,
715336,
289814,
["max_value"] = 715336,
["__time"] = 1725621178,
},
},
[2315] = {
},
[2095] = {
},
[2310] = {
},
[2381] = {
["Raid Damage Done"] = {
21707,
59458,
311019,
6464,
66374,
23312,
357359,
93648,
255275,
93583,
100640,
109974,
21283,
519202,
527384,
185544,
297872,
253405,
140180,
267528,
154365,
239030,
228880,
30885,
290432,
239058,
285282,
109043,
871687,
518039,
392675,
204672,
843465,
1782652,
999775,
404894,
1116487,
1531844,
858959,
959525,
1185897,
1502141,
258641,
298297,
0,
["max_value"] = 1782652,
["__time"] = 1725546789,
},
},
[2061] = {
},
},
["encounter_spells"] = {
[440653] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Блуждающая свеча",
},
[193473] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Щупальце Бездны",
},
[427100] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[427356] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Благочестивый жрец",
},
[434773] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Посетитель из Торговой компании",
},
[427357] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Благочестивый жрец",
},
[463418] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Исследователь Вен'кекс",
},
[427869] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[430171] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блуждающая свеча",
},
[454213] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Топетруб",
},
[445262] = {
["school"] = 127,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[422245] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[427616] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Непослушный буреклюв",
},
[439637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вторящая тень",
},
[434779] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[424805] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[450636] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_HEAL"] = true,
},
["source"] = "Нерубская владыка",
},
[76151] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный обманщик",
},
[450637] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нерубская владыка",
},
[448847] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Генерал Умбрисс",
},
[320717] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[425319] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кругогриб",
},
[463426] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ловчий",
},
[450128] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Воскоморд",
},
[228645] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[463428] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[432227] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[426345] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[441179] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[439645] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[450131] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[457804] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Безликий последователь",
},
[444250] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
},
[450133] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[426860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[423536] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[420212] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Мереди Крепкая Охота",
},
[423538] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[446300] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Поганище из Подморья",
},
[443232] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный дозорный",
},
[435560] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[196809] = {
["school"] = 2,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[98021] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем духовной связи",
},
[427378] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[424821] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скрипучая вагонетка (пустая)",
},
[434284] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[450142] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Воскоморд",
},
[439401] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[431985] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кровавый служитель",
},
[443494] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Осколок кристалла",
},
[427894] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер кузни Дамиан",
},
[445541] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Брокк",
},
[450145] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[457818] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Безликий последователь",
},
[322527] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[257170] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налетчик из братства Стальных Волн",
},
[436592] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[341709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призывательница Туманов",
},
[273681] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[433781] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ануб'зект",
},
[196816] = {
["school"] = 2,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Божественный образ",
},
[424322] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пылающий монстр",
},
[445038] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кобисс-ловкач",
},
[443504] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "[DNT] Beehive Trash Stalker",
},
[389541] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Статуя белого тигра",
},
[428161] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Брокк",
},
[181089] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чудище камня Бездны",
},
[426883] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кобольд-служитель",
},
[446321] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Поганище из Подморья",
},
[75328] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Валиона",
},
[321772] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Дроман Ульфарран",
},
[321005] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[321006] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ингра Малох",
},
[423051] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[431493] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный проклятый клинок",
},
[427402] = {
["school"] = 9,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый страж птенцов",
},
[433029] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер отражений Муркна",
},
[323057] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ингра Малох",
},
[426892] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Убегающий свеченосец",
},
[448887] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[448632] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[448888] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[322548] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[327664] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[448634] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[432522] = {
["school"] = 32,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[426896] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Убегающий свеченосец",
},
[423062] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Барон Браунпайк",
},
[444034] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[444546] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[458357] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[441222] = {
["school"] = 1,
["token"] = {
["SPELL_HEAL"] = true,
},
},
[464240] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Верховная жрица Эмия",
},
[434829] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[427157] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тьма",
},
[463218] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[433040] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кобисс-ловкач",
},
[450176] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Нерубский рассекатель",
},
[425113] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[434576] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[434832] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[439692] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[458874] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Страж тени – глашатай",
},
[436624] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голди Барондон",
},
[458875] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Страж тени – глашатай",
},
[434579] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[458876] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Страж тени – глашатай",
},
[423327] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[423839] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[320772] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Налтор Криомант",
},
[445834] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Аратийский утопленник",
},
[439697] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[281388] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[463227] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[448650] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Надсмотрщица Каскел",
},
[389572] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Бродящий потрошитель",
},
[450441] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Быстролапый членистоног",
},
[423076] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[423588] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[273720] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[415406] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кругогриб",
},
[433053] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кобисс-некромант",
},
[273721] = {
["school"] = 64,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тяжелое ядро",
},
[320012] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Амарт",
},
[424614] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Грибной пронзатель",
},
[432031] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Черная кровь",
},
[449167] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Дорлита",
},
[436637] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[449169] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[440218] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[273470] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[427176] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Извивающееся порождение Тьмы",
},
[428711] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Дорлита",
},
[436640] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[462216] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[424621] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сержант Шейнмейл",
},
[428202] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[450197] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Быстролапый членистоног",
},
[439200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[343294] = {
["school"] = 48,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[436644] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Голди Барондон",
},
[439202] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "И'па",
},
[435622] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Голди Барондон",
},
[426160] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[427439] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[451224] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чернокнижник Сумеречного Молота",
},
[434089] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[425394] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[438949] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[450714] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нерубская владыка",
},
[429487] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[429999] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[447135] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исследовательница вкусов",
},
[123996] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сюэнь",
},
[447136] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Исследовательница вкусов",
},
[434093] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[451996] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[426677] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Сажеморд",
},
[444324] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[428212] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Брокк",
},
[461460] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Гигантская свеча",
},
[424888] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[448673] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[445860] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер отражений Муркна",
},
[434096] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[429493] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Чудище камня Бездны",
},
[433841] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кровавый надсмотрщик",
},
[195182] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[424891] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Грибной копейщик",
},
[449444] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[447143] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исследователь Вен'кекс",
},
[440238] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[50842] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[447144] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исследователь Вен'кекс",
},
[442285] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сгустолиция",
},
[449702] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмельной выброс",
},
[274002] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[321828] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Призывательница Туманов",
},
[449448] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[427710] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Споровик",
},
[426943] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[430013] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Непослушный буреклюв",
},
[452008] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[394976] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Плеточник Бездны",
},
[423109] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[321834] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Призывательница Туманов",
},
[449965] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Топетруб",
},
[439991] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[76303] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[424903] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "ЗАЗУ",
},
[439481] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[427461] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
},
[438971] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хищная золопчела",
},
[424650] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кротопас-плебей",
},
[434113] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Паутинные нити",
},
[438975] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хищная золопчела",
},
[431303] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный маг тени",
},
[423121] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[455090] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Замораживающее устройство",
},
[434119] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[437700] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[437956] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[424913] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
},
[443839] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Гальвен",
},
[448443] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Паутинный генерал Аб'енар",
},
[443840] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Гальвен",
},
[227291] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нюцзао",
},
[448444] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Паутинный генерал Аб'енар",
},
[444608] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[439749] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[444609] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[428242] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Блок металла",
},
[429521] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[435148] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[414944] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Грибной копейщик",
},
[451261] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный заклинатель земли",
},
[414945] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Грибной заклинатель гнили",
},
[457144] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Брокк",
},
[441289] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[438476] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[443847] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[426712] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[446405] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Поганище из Подморья",
},
[446406] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Поганище из Подморья",
},
[426715] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[323137] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Дроман Ульфарран",
},
[435156] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживший пехотинец",
},
[449734] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[323138] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ингра Малох",
},
[257348] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[439506] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[443854] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пострадавший мирный житель",
},
[422628] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Коридорный ужас",
},
[59638] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зеркальное изображение",
},
[424419] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[424420] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[432605] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Странник Бездны",
},
[447439] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[456902] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[437721] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[450509] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нерубский капитан",
},
[424423] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сержант Шейнмейл",
},
[434655] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[447187] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Исследователь Вен'кекс",
},
[447443] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[424426] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сержант Шейнмейл",
},
[438494] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Аванокс",
},
[459210] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[188046] = {
["school"] = 72,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Обитатель Сна",
},
[438495] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[461513] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[429545] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Обращенный глашатай",
},
[444123] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[320596] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[424431] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[423664] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[424432] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[426734] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[104318] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Дикий бес",
},
[434407] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Раша'нан",
},
[440801] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нерл'атекк Крадущийся",
},
[426735] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[434408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[451032] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[449242] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Расхититель гробниц из племени Сухоусов",
},
[445406] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бродящий потрошитель",
},
[439524] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бенк Жужжикс",
},
[451033] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный головорез",
},
[321368] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Налтор Криомант",
},
[445407] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бродящий потрошитель",
},
[440549] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кобисс-костеглод",
},
[440805] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Нерл'атекк Крадущийся",
},
[445409] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[440550] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кобисс-костеглод",
},
[440806] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Нерл'атекк Крадущийся",
},
[422648] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Свечной Король",
},
[428019] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Королевский зажигатель",
},
[440551] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кобисс-костеглод",
},
[422393] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Снующая тьма",
},
[434926] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[269456] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вик'Гот",
},
[443111] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай-инквизитор",
},
[451040] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Сумеречный головорез",
},
[447205] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Исследователь Вен'кекс",
},
[427001] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'иккадж",
},
[432117] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[453856] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Житель Мерельдара",
},
[324447] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кобисс-гарпунщик",
},
[415495] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кругогриб",
},
[432119] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ки'катал Жница",
},
[427260] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый наставник буреклювов",
},
[453859] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[31707] = {
["school"] = 16,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Элементаль воды",
},
[440049] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[320614] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[433656] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Крылатый переносчик",
},
[423682] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[427007] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[415499] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Кругогриб",
},
[421638] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[433403] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Быстролапый членистоног",
},
[442611] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[439031] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[440310] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[424966] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[444915] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кобисс-ловкач",
},
[320365] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[269984] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[432130] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ки'катал Жница",
},
[449266] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Расхититель гробниц из племени Сухоусов",
},
[268963] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[459753] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Фенрир",
},
[444920] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кобисс-ловкач",
},
[423693] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Старый Воскобород",
},
[257882] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[442108] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "И'па",
},
[424462] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[444411] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[445435] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
},
[320630] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Червь-трупоед",
},
[224125] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[320631] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Червь-трупоед",
},
[423015] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Барон Браунпайк",
},
[425489] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[320376] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[443841] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Гальвен",
},
[434441] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Раша'нан",
},
[450042] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Прожорливый скарабей",
},
[440141] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Бенк Жужжикс",
},
[427025] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Тьма",
},
[424212] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пламекон",
},
[438960] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аванокс",
},
[448638] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[320788] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Налтор Криомант",
},
[428887] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Камнекрушитель",
},
[224127] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[426771] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[444418] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кириосс",
},
[438473] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[431494] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный тактик",
},
[438025] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бенк Жужжикс",
},
[430097] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Брокк",
},
[426261] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сажеморд",
},
[443908] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Глашатай Гальвен",
},
[443837] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глашатай Гальвен",
},
[320637] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чумокост",
},
[439518] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Вкс",
},
[443909] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Гальвен",
},
[428820] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[449939] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эрудакс",
},
[326629] = {
["school"] = 40,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хирург Трупошов",
},
[320580] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Амарт",
},
[457465] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[419870] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кириосс",
},
[462220] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[114942] = {
["school"] = 8,
["token"] = {
["SPELL_HEAL"] = true,
},
["source"] = "Тотем целительного прилива",
},
[336752] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Призывательница Туманов",
},
[419871] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[455932] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кобисс-некромант",
},
[451241] = {
["school"] = 36,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[447395] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Начальник кузни Тронг",
},
[321725] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Иллюзорный клон",
},
[118459] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Гончая Недр",
},
[434706] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Работница дегустационной",
},
[456696] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный громила",
},
[257063] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Заклинатель моря из братства Стальных Волн",
},
[438675] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Разъевшийся ползун",
},
[274991] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вик'Гот",
},
[449985] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[280389] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[438601] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[438471] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Аванокс",
},
[421665] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Старый Воскобород",
},
[273718] = {
["school"] = 64,
["token"] = {
["SPELL_DAMAGE"] = true,
},
},
[423200] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Скарморак",
},
[463408] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Исследователь Вен'кекс",
},
[431896] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Томимый жаждой посетитель",
},
[443405] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[431897] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Томимый жаждой посетитель",
},
[434710] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[443150] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[445452] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бродящий потрошитель",
},
[257326] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[440134] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бенк Жужжикс",
},
[424737] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[433740] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[272471] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Наводчик корпорации Эшвейнов",
},
[459264] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Магнитный погрузчик",
},
[430109] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый рокотун",
},
[444431] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Элейна Эмберланц",
},
[426736] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[445537] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Чудище камня Бездны",
},
[257459] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Головорез Краснокрюк",
},
[322681] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Создание Трупошва",
},
[463182] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[448013] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[426786] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Зачарованный Бездной расхититель",
},
[439696] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Нкс",
},
[434505] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[421277] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[426787] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'иккадж",
},
[445457] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Чудище камня Бездны",
},
[453897] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Топетруб",
},
[449038] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Надсмотрщица Каскел",
},
[320208] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Создание Трупошва",
},
[256616] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кишкодер из банды Резчиков",
},
[422261] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[432132] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Ки'катал Жница",
},
[449295] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Расхититель гробниц из племени Сухоусов",
},
[429091] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Верховная жрица Эмия",
},
[439577] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глашатай Дорлита",
},
[427015] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тьма",
},
[276068] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[448663] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Подземный лорд Вик'тис",
},
[428547] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Блок металла",
},
[326281] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Тред'ова",
},
[448515] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[320655] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Чумокост",
},
[423665] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[427404] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[439324] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[257641] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Фузилер из братства Стальных Волн",
},
[427180] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тьма",
},
[426793] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[446230] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Поганище из Подморья",
},
[439325] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "И'па",
},
[424889] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "ЗАЗУ",
},
[434722] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[82850] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пробужденный дух пламени Тьмы",
},
[383061] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Тотем жидкой магмы",
},
[426283] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проклятый завоеватель",
},
[434723] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Оратор Крикс'визк",
},
[268230] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Матрос корпорации Эшвейнов",
},
[456718] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мутировавший детеныш",
},
[454417] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Споровик",
},
[435012] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[424750] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Грибной заклинатель гнили",
},
[456719] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Мутировавший детеныш",
},
[450101] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[429099] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Оживший пехотинец",
},
[420659] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[451605] = {
["school"] = 2,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[421817] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Пламекон",
},
[439010] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Извивающееся порождение Тьмы",
},
[439586] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[451606] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[425264] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[434668] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Аратийская бомба",
},
[432520] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный заклинатель тьмы",
},
[423324] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Скарморак",
},
[453909] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[433731] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ануб'зект",
},
[421146] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Свечной Король",
},
[447261] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Генерал Умбрисс",
},
[425011] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Вечный огонь",
},
[451097] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Суреки-ополченец",
},
[450330] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Воскоморд",
},
[439333] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Изголодавшийся ползун",
},
[201754] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барбос",
},
[334476] = {
["school"] = 40,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[224126] = {
["school"] = 16,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Дух волка",
},
[423547] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[415492] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кругогриб",
},
[451099] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Суреки-ополченец",
},
[455447] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Уэйн",
},
[441381] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[423479] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Королевский зажигатель",
},
[450077] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[450546] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нерубский капитан",
},
[461842] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Сгустолиция",
},
[440615] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кобисс-иссушитель",
},
[424704] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Грибной потрошитель",
},
[440104] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Хмельной выброс",
},
[463210] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Туманный страж",
},
[268752] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Жуткий капитан Локвуд",
},
[450079] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Эрудакс",
},
[441384] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[449568] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Паутинный генерал Аб'енар",
},
[440617] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кобисс-иссушитель",
},
[432179] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[441129] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Темный бомбардир",
},
[428086] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[451871] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный заклинатель земли",
},
[451104] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сурекийский маг паутины",
},
[440107] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вкс",
},
[425018] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Аратийский неофит",
},
[423228] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[448644] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Надсмотрщица Каскел",
},
[426145] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
},
["source"] = "Свечной Король",
},
[439341] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[450095] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[424958] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бурестраж Горрен",
},
[447270] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[428089] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кротопас-плебей",
},
[449061] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Надсмотрщица Каскел",
},
[451107] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сурекийский маг паутины",
},
[449317] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Расхититель гробниц из племени Сухоусов",
},
[432182] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[427323] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Странник Бездны",
},
[434740] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай-инквизитор",
},
[447272] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Капитан Дейлкрай",
},
[440622] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кобисс-иссушитель",
},
[431333] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Сумеречная заклинательница тьмы",
},
[55078] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[428269] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгусток Бездны",
},
[334488] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хирург Трупошов",
},
[427325] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Странник Бездны",
},
[450087] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Щупальце Бездны",
},
[434998] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[445996] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[443694] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
},
[450088] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эрудакс",
},
[432229] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[421282] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Свечной Король",
},
[451112] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сумеречный тактик",
},
[427583] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Элейна Эмберланц",
},
[435000] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[445207] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Подчиненный Бездной завыватель",
},
[443954] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Ловчий из люка",
},
[434745] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[435797] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бомба Искроварни",
},
[451113] = {
["school"] = 8,
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сурекийский маг паутины",
},
[427329] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[451114] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Оживленная тьма",
},
[415404] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Кругогриб",
},
[320170] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[438658] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сгустолиция",
},
[320171] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Амарт",
},
[424421] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тейнер Дуэльмаль",
},
[441397] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Пчелка",
},
[426308] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Проклятый завоеватель",
},
[449070] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Меченый Бездной элементаль",
},
[435004] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Шеф-повар Жевастик",
},
[269266] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Крушащий ужас",
},
[426136] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[453946] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Топетруб",
},
[52042] = {
["school"] = 8,
["token"] = {
["SPELL_PERIODIC_HEAL"] = true,
},
["source"] = "Тотем исцеляющего потока",
},
[427002] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[440147] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "И'па",
},
[449072] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Надсмотрщица Каскел",
},
[435006] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Эпическое яйцо Бранна",
},
[445492] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бродящий потрошитель",
},
[451026] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Проповедница Темная Корона",
},
[462372] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Ловчий из люка",
},
[425315] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Кругогриб",
},
[422246] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Старый Воскобород",
},
[448818] = {
["school"] = 1,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Кобольд-черепоморд",
},
[462373] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Ловчий из люка",
},
[334322] = {
["school"] = 40,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Создание Трупошва",
},
[460839] = {
["school"] = 4,
["token"] = {
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Старый Воскобород",
},
[438620] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Сгустолиция",
},
[451098] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Суреки-ополченец",
},
[268260] = {
["school"] = 64,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Канонир дома Эшвейнов",
},
[432196] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[17253] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Барбос",
},
[423501] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Военный надзиратель",
},
[426826] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Ануб'иккадж",
},
[437733] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[423246] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Скарморак",
},
[450100] = {
["school"] = 33,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Эрудакс",
},
[427011] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Тьма",
},
[432198] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[442525] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Хмелевар Алдрир",
},
[434756] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Бугай",
},
[326574] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[456751] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Валиона",
},
[322450] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Тред'ова",
},
[326319] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Друст-жнец",
},
[427852] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[431309] = {
["school"] = 32,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Сумеречный маг тени",
},
[320200] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хирург Трупошов",
},
[434758] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[433766] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Ануб'зект",
},
[441408] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Пироман из Торговой компании",
},
[272662] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налетчик из братства Стальных Волн",
},
[455219] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Чудище камня Бездны",
},
[427854] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[321891] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Иллюзорный лисохвост",
},
[463220] = {
["school"] = 4,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Бугай",
},
[321669] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Иллюзорный клон",
},
[443482] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Страж тени – глашатай",
},
[388897] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Глубоководный крепкохват",
},
[135029] = {
["school"] = 16,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Элементаль воды",
},
[425554] = {
["school"] = 2,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[449339] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Расхититель гробниц из племени Сухоусов",
},
[439365] = {
["school"] = 4,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "И'па",
},
[439621] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Нкс",
},
[443969] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Пламекон",
},
[320771] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Налтор Криомант",
},
[256639] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Метатель черной смолы",
},
[427346] = {
["school"] = 2,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Благочестивый жрец",
},
[425556] = {
["school"] = 2,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Настоятельница Муррпрэй",
},
[455479] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Взять",
},
[256709] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Мастер клинков прилива",
},
[453945] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Топетруб",
},
[454201] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Топетруб",
},
[257288] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Рассекатель из братства Стальных Волн",
},
[256640] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Метатель черной смолы",
},
[422233] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Скарморак",
},
[435788] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Голди Барондон",
},
[49998] = {
["school"] = 1,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Руническое оружие",
},
[447966] = {
["school"] = 36,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Драгх Горячий Мрак",
},
[435533] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Глибб",
},
[448877] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Генерал Умбрисс",
},
[445252] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Кобисс-некромант",
},
[425048] = {
["school"] = 32,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Бурестраж Горрен",
},
[270590] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Крушащий ужас",
},
[256957] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Заклинатель моря из братства Стальных Волн",
},
[440138] = {
["school"] = 4,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бенк Жужжикс",
},
[462219] = {
["school"] = 36,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Сумеречный пламеруб",
},
[424148] = {
["school"] = 8,
["token"] = {
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_DAMAGE"] = true,
},
["source"] = "Кириосс",
},
[438860] = {
["school"] = 32,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Изо Великая Сращивательница",
},
[321471] = {
["school"] = 8,
["type"] = "BUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_CAST_START"] = true,
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Призывательница Туманов",
},
[257862] = {
["school"] = 16,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Хадал Черная Бездна",
},
[439522] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Нкс",
},
[160772] = {
["school"] = 1,
["type"] = "BUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "Житель Мерельдара",
},
[424795] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
},
["source"] = "ЗАЗУ",
},
[428120] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Глашатай Дорлита",
},
[440652] = {
["school"] = 4,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Блуждающая свеча",
},
[435793] = {
["school"] = 8,
["type"] = "DEBUFF",
["token"] = {
["SPELL_AURA_APPLIED"] = true,
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
},
["source"] = "Раша'нан",
},
[427865] = {
["school"] = 1,
["token"] = {
["SPELL_CAST_SUCCESS"] = true,
},
["source"] = "Вестник Бездны Эйрих",
},
[425052] = {
["school"] = 32,
["token"] = {
["SPELL_DAMAGE"] = true,
},
["source"] = "Бурестраж Горрен",
},
[424414] = {
["school"] = 1,
["type"] = "DEBUFF",
["token"] = {
["SPELL_DAMAGE"] = true,
["SPELL_CAST_SUCCESS"] = true,
["SPELL_AURA_APPLIED"] = true,
["SPELL_PERIODIC_DAMAGE"] = true,
["SPELL_CAST_START"] = true,
},
["source"] = "Капитан Дейлкрай",
},
},
["emotes"] = {
{
["boss"] = "Расхититель гробниц из племени Сухоусов",
},
{
["boss"] = "Настоятельница Муррпрэй",
},
{
["boss"] = "Барон Браунпайк",
},
},
}
