
NewSettingsSeen = {
["cooldownViewerEnabled"] = true,
["panelItemQualityColorOverrides"] = true,
}
