
SavedInstancesDB = {
["Toons"] = {
["Beamladen - Twisting Nether"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
},
["Race"] = "Nightborne",
["LClass"] = "Mage",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[5] = 0,
[2] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 8,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1748404799,
["Zone"] = "Orgrimmar",
["Order"] = 50,
["Class"] = "MAGE",
["ILPvp"] = 8,
["currency"] = {
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
},
["Calling"] = {
},
["Warmode"] = false,
["oRace"] = "Nightborne",
["Level"] = 10,
["XP"] = 0,
["DailyResetTime"] = 1748318399,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["PlayedTotal"] = 1695,
["Arena2v2rating"] = 0,
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["bfa-island"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
},
["Money"] = 760000,
["MythicKey"] = {
},
["LastSeen"] = 1734505365,
["SpecializationIDs"] = {
62,
63,
64,
105,
},
["MythicPlusScore"] = 0,
["Covenant"] = 0,
["PlayedLevel"] = 1695,
["MaxXP"] = 8490,
["RestXP"] = 12736,
["Skills"] = {
},
["IL"] = 8,
["BGBRating"] = {
[2] = 0,
},
},
["Мальдика - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["BGBRating"] = {
0,
0,
0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
},
["lastbosstime"] = 1736871356,
["Covenant"] = 3,
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["ILe"] = 637.8125,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1736922757,
["SpecializationIDs"] = {
256,
257,
258,
},
["Class"] = "PRIEST",
["Show"] = "saved",
["ILPvp"] = 638.625,
["Zone"] = "Дорногал",
["currency"] = {
[1191] = {
["amount"] = 0,
},
[2815] = {
["amount"] = 900,
},
[1904] = {
["totalEarned"] = 1779,
["totalMax"] = 3510,
["amount"] = 109,
},
[1719] = {
["amount"] = 2469,
},
[1979] = {
["amount"] = 522,
},
[2706] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1885] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 2,
},
[1716] = {
["amount"] = 100,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[3023] = {
["totalEarned"] = 19,
["totalMax"] = 21,
["amount"] = 19,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 1,
},
[2917] = {
["totalEarned"] = 2736,
["amount"] = 1401,
},
[1813] = {
["covenant"] = {
[3] = 33190,
},
["totalMax"] = 200000,
["amount"] = 33190,
},
[2708] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 2000,
},
[2709] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 8970,
},
[1721] = {
["amount"] = 27,
},
[2914] = {
["totalEarned"] = 26,
["amount"] = 41,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 1630,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1977] = {
["amount"] = 5,
},
[1810] = {
["covenant"] = {
[3] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1560] = {
["amount"] = 5617,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 2290,
},
[2009] = {
["amount"] = 47052,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1828] = {
["amount"] = 59010,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 2,
},
[1710] = {
["amount"] = 250,
},
[1718] = {
["amount"] = 0,
},
[2774] = {
["amount"] = 17,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 250,
},
[2916] = {
["totalEarned"] = 968,
["amount"] = 438,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[2915] = {
["totalEarned"] = 133,
["amount"] = 178,
},
[2707] = {
["amount"] = 0,
},
[3056] = {
["amount"] = 3375,
},
[1822] = {
["covenant"] = {
[3] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[3090] = {
["amount"] = 6172,
},
[3100] = {
["amount"] = 162,
},
[2000] = {
["amount"] = 44,
},
},
["DailyResetTime"] = 1748318399,
["Warmode"] = false,
["IL"] = 638.625,
["Level"] = 80,
["WeeklyResetTime"] = 1748404799,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["PlayedTotal"] = 5226076,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1736871393,
["Money"] = 307941566,
["LClass"] = "Жрица",
["MythicKey"] = {
},
["MythicPlusScore"] = 3553,
["lastboss"] = "Раша'нан: Эпохальный ключ",
["Order"] = 50,
["PlayedLevel"] = 1329159,
["MaxXP"] = 100000000,
["Faction"] = "Horde",
["Skills"] = {
},
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["tww-archives"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[84252] = {
["show"] = true,
["isComplete"] = true,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = true,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
},
["lastbossyell"] = "Генерал Стилстрайк: Эпохальный ключ",
},
["Вантачмэн - Ревущий фьорд"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Монахиня",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["lastbosstime"] = 1725626435,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["ILe"] = 516.25,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1748404799,
["Zone"] = "Аллея Силы",
["Order"] = 50,
["Class"] = "MONK",
["Covenant"] = 4,
["ILPvp"] = 595.8125,
["oRace"] = "BloodElf",
["currency"] = {
[2413] = {
["amount"] = 27,
},
[2815] = {
["amount"] = 0,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[1719] = {
["amount"] = 9929,
},
[1191] = {
["amount"] = 0,
},
[2650] = {
["amount"] = 9,
},
[1810] = {
["covenant"] = {
[4] = 9,
},
["totalMax"] = 100,
["amount"] = 9,
},
[2003] = {
["amount"] = 2139,
},
[2706] = {
["amount"] = 0,
},
[2777] = {
["amount"] = 1,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 18769,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1275] = {
["amount"] = 69,
},
[1767] = {
["amount"] = 15729,
},
[1716] = {
["amount"] = 342,
},
[738] = {
["amount"] = 2,
},
[2707] = {
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 93,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2709] = {
["amount"] = 0,
},
[1803] = {
["amount"] = 2173,
},
[2410] = {
["totalEarned"] = 103,
["amount"] = 103,
},
[2708] = {
["amount"] = 0,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 252,
},
[2409] = {
["totalEarned"] = 160,
["amount"] = 160,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 330,
},
[2774] = {
["amount"] = 20,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 693,
},
[1166] = {
["amount"] = 5830,
},
[1906] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 1,
},
[2914] = {
["totalEarned"] = 16,
["amount"] = 91,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3056] = {
["amount"] = 450,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1977] = {
["amount"] = 51,
},
[1560] = {
["amount"] = 39597,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 14,
},
[2411] = {
["totalEarned"] = 186,
["amount"] = 186,
},
[2915] = {
["totalEarned"] = 8,
["amount"] = 63,
},
[1828] = {
["amount"] = 21950,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 632,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 2,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 915,
},
[2412] = {
["totalEarned"] = 580,
["amount"] = 580,
},
[1226] = {
["amount"] = 12160,
},
[3023] = {
["totalEarned"] = 2,
["totalMax"] = 18,
["amount"] = 2,
},
[1220] = {
["amount"] = 20273,
},
[1931] = {
["amount"] = 7485,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[4] = 42597,
},
["totalMax"] = 200000,
["amount"] = 42597,
},
[3028] = {
["relatedItemCount"] = 25,
["amount"] = 4,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 68,
},
},
["DailyResetTime"] = 1748318399,
["Warmode"] = false,
["IL"] = 595.8125,
["Level"] = 80,
["BGBRating"] = {
0,
},
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 8923638,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1725627381,
["Money"] = 6243639215,
["LastSeen"] = 1735495831,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["lastboss"] = "Вестник Бездны Эйрих: Обычный",
["MythicPlusScore"] = 0,
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
"Соберите странные сгустки воска: 2/10",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 10,
["leaderboardCount"] = 1,
["text"] = "2/10",
["objectiveType"] = "monster",
["numFulfilled"] = 2,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[84252] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
},
["PlayedLevel"] = 8947,
["MaxXP"] = 100000000,
["SpecializationIDs"] = {
268,
270,
269,
},
["Skills"] = {
},
["lastbossyell"] = "Глашатай Бреция",
["Faction"] = "Horde",
},
["Дракобес - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
},
["Race"] = "Драктир",
["LClass"] = "Пробудитель",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
},
["lastbosstime"] = 1729716717,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["ILe"] = 503.5,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1748404799,
["Zone"] = "Аллея Силы",
["Order"] = 50,
["Class"] = "EVOKER",
["lastbossyell"] = "Ингра Малох: Обычный",
["ILPvp"] = 599.8125,
["IL"] = 599.8125,
["currency"] = {
[2003] = {
["amount"] = 3880,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1191] = {
["amount"] = 0,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 15,
},
},
["DailyResetTime"] = 1748318399,
["Warmode"] = false,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["Level"] = 80,
["Money"] = 78531078,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 921204,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1730161942,
["MaxXP"] = 100000000,
["Covenant"] = 0,
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["tww-archives"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[84252] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
},
["MythicPlusScore"] = 0,
["lastboss"] = "Ингра Малох: Обычный",
["oRace"] = "Dracthyr",
["PlayedLevel"] = 4800,
["BGBRating"] = {
[3] = 0,
},
["Faction"] = "Horde",
["Skills"] = {
},
["SpecializationIDs"] = {
1467,
1468,
1473,
},
["LastSeen"] = 1735496045,
},
["Сэйвмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Паладин",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 604.4375,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "BloodElf",
["LastSeen"] = 1735495806,
["Order"] = 50,
["Class"] = "PALADIN",
["ILPvp"] = 608,
["currency"] = {
[824] = {
["totalMax"] = 10000,
["amount"] = 4076,
},
[2815] = {
["amount"] = 5916,
},
[1904] = {
["totalEarned"] = 3148,
["totalMax"] = 3510,
["amount"] = 188,
},
[3028] = {
["relatedItemCount"] = 2,
["amount"] = 0,
},
[1979] = {
["amount"] = 487,
},
[1810] = {
["covenant"] = {
[4] = 5,
},
["totalMax"] = 100,
["amount"] = 5,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1129] = {
["weeklyMax"] = 3,
["totalMax"] = 20,
["amount"] = 0,
},
[1767] = {
["amount"] = 5749,
},
[738] = {
["amount"] = 1,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 1483,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 75,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[3023] = {
["totalEarned"] = 4,
["totalMax"] = 18,
["amount"] = 4,
},
[1220] = {
["amount"] = 770,
},
[823] = {
["amount"] = 183,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 126,
},
[2803] = {
["amount"] = 2127,
},
[1977] = {
["amount"] = 83,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 969,
},
[3056] = {
["amount"] = 1890,
},
[1906] = {
["amount"] = 330,
},
[1721] = {
["amount"] = 0,
},
[2914] = {
["totalEarned"] = 228,
["amount"] = 153,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1166] = {
["amount"] = 225,
},
[1275] = {
["amount"] = 234,
},
[2915] = {
["totalEarned"] = 248,
["amount"] = 268,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 4,
},
[1501] = {
["amount"] = 1,
},
[2009] = {
["amount"] = 20421,
},
[1155] = {
["totalMax"] = 1600,
["amount"] = 1229,
},
[1828] = {
["amount"] = 14146,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1710] = {
["amount"] = 27,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 3,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 2302,
},
[2916] = {
["totalEarned"] = 189,
["amount"] = 84,
},
[1226] = {
["amount"] = 7179,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 60,
},
[2000] = {
["amount"] = 0,
},
[1931] = {
["amount"] = 398,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1813] = {
["covenant"] = {
[4] = 37675,
},
["totalMax"] = 200000,
["amount"] = 37675,
},
[1191] = {
["amount"] = 0,
},
[1716] = {
["amount"] = 25,
},
},
["Warmode"] = false,
["Zone"] = "Аллея Силы",
["Level"] = 80,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["PlayedTotal"] = 10501917,
["Arena2v2rating"] = 0,
["DailyResetTime"] = 1748318399,
["Money"] = 156098277,
["WeeklyResetTime"] = 1748404799,
["Covenant"] = 4,
["SpecializationIDs"] = {
65,
66,
70,
},
["MythicPlusScore"] = 460,
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["tww-archives"] = {
["show"] = false,
},
["The Severed Threads"] = {
"Выполняйте задачи в Аз-Кахете (95%)",
"Осмотрите товары пактов у поставщицы Ямас: 1/1 (необязательно)",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 100,
["leaderboardCount"] = 2,
["text"] = "95%",
["objectiveType"] = "progressbar",
["numFulfilled"] = 95,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[84252] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
},
["PlayedLevel"] = 175023,
["MythicKey"] = {
},
["MaxXP"] = 100000000,
["Skills"] = {
},
["IL"] = 608,
["BGBRating"] = {
0,
0,
},
},
["Вольтчара - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Тауренка",
["LClass"] = "Шаманка",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
[3] = 0,
},
["lastbosstime"] = 1734543303,
["Covenant"] = 1,
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 636.125,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "Tauren",
["LastSeen"] = 1735495774,
["SpecializationIDs"] = {
262,
263,
264,
},
["Class"] = "SHAMAN",
["IL"] = 636.125,
["ILPvp"] = 636.125,
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["tww-archives"] = {
["show"] = false,
},
["The Severed Threads"] = {
"Выполняйте задачи в Аз-Кахете (0%)",
"Осмотрите товары пактов у поставщицы Ямас: 0/1 (необязательно)",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 100,
["leaderboardCount"] = 2,
["text"] = "0% 0/1",
["objectiveType"] = "progressbar",
["numFulfilled"] = 0,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[84252] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = false,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82414] = {
["show"] = false,
},
["show"] = true,
[82531] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["great-vault-world"] = {
["unlocked"] = true,
["rewardWaiting"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
},
["currency"] = {
[2917] = {
["totalEarned"] = 1245,
["amount"] = 90,
},
[2815] = {
["amount"] = 4589,
},
[1904] = {
["totalEarned"] = 3510,
["totalMax"] = 3510,
["amount"] = 0,
},
[3028] = {
["relatedItemCount"] = 0,
["amount"] = 4,
},
[1979] = {
["amount"] = 807,
},
[1810] = {
["covenant"] = {
7,
},
["totalMax"] = 100,
["amount"] = 7,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1885] = {
["amount"] = 21,
},
[1767] = {
["amount"] = 28146,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1602] = {
["amount"] = 0,
},
[3023] = {
["totalEarned"] = 16,
["totalMax"] = 18,
["amount"] = 16,
},
[2803] = {
["amount"] = 3187,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 1952,
},
[1906] = {
["amount"] = 7480,
},
[1977] = {
["amount"] = 16,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 0,
},
[1166] = {
["amount"] = 2775,
},
[1560] = {
["amount"] = 3,
},
[2009] = {
["amount"] = 38086,
},
[1828] = {
["amount"] = 96655,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 3,
},
[1191] = {
["amount"] = 0,
},
[3056] = {
["amount"] = 6715,
},
[1533] = {
["amount"] = 1092,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 257,
},
[2916] = {
["totalEarned"] = 1032,
["amount"] = 122,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[2914] = {
["totalEarned"] = 402,
["amount"] = 312,
},
[2915] = {
["totalEarned"] = 798,
["amount"] = 453,
},
[1931] = {
["amount"] = 1579,
},
[1822] = {
["covenant"] = {
80,
},
["totalMax"] = 80,
["amount"] = 80,
},
[1813] = {
["covenant"] = {
140482,
},
["totalMax"] = 200000,
["amount"] = 140482,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2000] = {
["amount"] = 37,
},
},
["DailyResetTime"] = 1748318399,
["Warmode"] = false,
["WeeklyResetTime"] = 1748404799,
["Level"] = 80,
["Show"] = "saved",
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["PlayedTotal"] = 5268289,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1734543864,
["Money"] = 2257097482,
["Order"] = 50,
["MaxXP"] = 100000000,
["lastboss"] = "Шелковый двор: Обычный",
["MythicPlusScore"] = 3138,
["BGBRating"] = {
[3] = 0,
},
["PlayedLevel"] = 1131119,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["Skills"] = {
},
["lastbossyell"] = "Королева Ансурек: Обычный",
["Zone"] = "Аллея Силы",
},
["Алианкано - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Охотник на демонов",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 327,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 327,
["LastSeen"] = 1725797846,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 18390/36000",
["show"] = true,
["numFulfilled"] = 18390,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "18390/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "DEMONHUNTER",
["ILPvp"] = 327,
["currency"] = {
[1602] = {
["amount"] = 0,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1220] = {
["amount"] = 4243,
},
[1719] = {
["amount"] = 2193,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 5195,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1716] = {
["amount"] = 159,
},
[1710] = {
["amount"] = 92,
},
[1166] = {
["amount"] = 495,
},
[1533] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1721] = {
["amount"] = 93,
},
[1560] = {
["amount"] = 2,
},
[1803] = {
["amount"] = 85,
},
[1718] = {
["amount"] = 0,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
},
["SpecializationIDs"] = {
577,
581,
},
["Warmode"] = true,
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1748404799,
},
["Level"] = 60,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKey"] = {
},
["RestXP"] = 83498,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["Money"] = 21231,
["oRace"] = "BloodElf",
["MaxXP"] = 55665,
["Covenant"] = 1,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1748404799,
["PlayedLevel"] = 2244,
["PlayedTotal"] = 1296590,
["Order"] = 50,
["DailyResetTime"] = 1748318399,
["Calling"] = {
},
["Zone"] = "Оргриммар",
},
["Пва - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = false,
["Emissary"] = {
},
["Race"] = "Ночная эльфийка",
["LClass"] = "Маг",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[5] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Alliance",
["ILe"] = 0.5,
["Quests"] = {
},
["Paragon"] = {
},
["oRace"] = "NightElf",
["LastSeen"] = 1730330546,
["Progress"] = {
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["bfa-island"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["df-trial-of-elements"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["call-to-delves"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = false,
},
[84737] = {
["show"] = false,
},
["show"] = true,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["great-vault-world"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
},
["Class"] = "MAGE",
["ILPvp"] = 0.5,
["currency"] = {
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 4,
},
},
["Warmode"] = false,
["Level"] = 1,
["XP"] = 0,
["Zone"] = "Остров Изгнанников",
["MythicKey"] = {
},
["PlayedTotal"] = 45,
["Arena2v2rating"] = 0,
["Calling"] = {
},
["Money"] = 0,
["Skills"] = {
},
["WeeklyResetTime"] = 1748404799,
["Covenant"] = 0,
["MythicPlusScore"] = 0,
["SpecializationIDs"] = {
62,
63,
64,
},
["PlayedLevel"] = 45,
["Order"] = 50,
["MythicKeyBest"] = {
["threshold"] = {
1,
4,
8,
},
["ResetTime"] = 1748404799,
},
["DailyResetTime"] = 1748318399,
["MaxXP"] = 250,
["IL"] = 0.5,
},
["Сорчистино - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Чернокнижница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 184.125,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 191.75,
["LastSeen"] = 1725797811,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "WARLOCK",
["ILPvp"] = 191.75,
["currency"] = {
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 40,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 442,
},
[1710] = {
["amount"] = 4,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1803] = {
["amount"] = 1265,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 195,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 45,
},
[1560] = {
["amount"] = 1041,
},
[1220] = {
["amount"] = 5255,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[1718] = {
["amount"] = 0,
},
[1719] = {
["amount"] = 122,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 4,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 12450,
},
[1226] = {
["amount"] = 11010,
},
[1275] = {
["amount"] = 150,
},
[1166] = {
["amount"] = 2165,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 46,
},
[1533] = {
["amount"] = 5728,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
},
["MythicKey"] = {
},
["Warmode"] = false,
["RestXP"] = 83498,
["Level"] = 60,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1748404799,
},
["PlayedTotal"] = 3075591,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["MaxXP"] = 55665,
["Money"] = 178639,
["oRace"] = "BloodElf",
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1748404799,
["PlayedLevel"] = 7184,
["SpecializationIDs"] = {
265,
266,
267,
},
["Calling"] = {
},
["DailyResetTime"] = 1748318399,
["Order"] = 50,
["Zone"] = "Орибос",
},
["Топмэн - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльф крови",
["LClass"] = "Маг",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 453.8125,
["Quests"] = {
},
["Paragon"] = {
},
["WeeklyResetTime"] = 1748404799,
["LastSeen"] = 1725797746,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
"1/1 Продолжите кампанию \"Хранители Сна\", чтобы открыть Изумрудный Сон",
"Получите цветок во время Цветочного бума: 0/50",
"Завершите Цветочный бум: 0/1",
"0/3000 Повысьте репутацию среди фракций Драконьих островов",
["show"] = true,
["numFulfilled"] = 1,
["numRequired"] = 1,
["isComplete"] = false,
["leaderboardCount"] = 4,
["text"] = "1/1 0/50 0/1 0/3000",
["objectiveType"] = "object",
["isFinish"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["emissary-of-war"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
},
["Class"] = "MAGE",
["ILPvp"] = 454.1875,
["currency"] = {
[824] = {
["totalMax"] = 10000,
["amount"] = 304,
},
[2650] = {
["amount"] = 50,
},
[2706] = {
["amount"] = 0,
},
[2003] = {
["amount"] = 647,
},
[1755] = {
["relatedItemCount"] = 0,
["amount"] = 9553,
},
[1822] = {
["covenant"] = {
[3] = 6,
},
["totalMax"] = 80,
["amount"] = 6,
},
[1889] = {
["amount"] = 1,
},
[1767] = {
["amount"] = 3502,
},
[2707] = {
["amount"] = 0,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 208,
},
[1220] = {
["amount"] = 7992,
},
[1803] = {
["amount"] = 4344,
},
[2409] = {
["totalEarned"] = 83,
["amount"] = 83,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 302,
},
[2118] = {
["amount"] = 50,
},
[2413] = {
["amount"] = 27,
},
[1719] = {
["amount"] = 725,
},
[2709] = {
["amount"] = 0,
},
[1721] = {
["amount"] = 112,
},
[2410] = {
["totalEarned"] = 124,
["amount"] = 124,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1166] = {
["amount"] = 3175,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1314] = {
["weeklyMax"] = 20,
["totalMax"] = 40,
["amount"] = 0,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 1410,
},
[1885] = {
["amount"] = 2,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 11,
},
[1275] = {
["amount"] = 190,
},
[1828] = {
["amount"] = 30,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 2,
},
[1710] = {
["amount"] = 7,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 6,
},
[2774] = {
["amount"] = 3,
},
[1533] = {
["amount"] = 1223,
},
[2412] = {
["totalEarned"] = 36,
["amount"] = 36,
},
[1226] = {
["amount"] = 23153,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[1155] = {
["totalMax"] = 900,
["amount"] = 204,
},
[1718] = {
["amount"] = 0,
},
[2411] = {
["totalEarned"] = 196,
["amount"] = 196,
},
[1813] = {
["covenant"] = {
[3] = 124,
},
["totalMax"] = 200000,
["amount"] = 124,
},
[1149] = {
["totalMax"] = 5000,
["amount"] = 170,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
},
["oRace"] = "BloodElf",
["Warmode"] = false,
["Order"] = 50,
["Level"] = 70,
["XP"] = 0,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1748404799,
},
["RestXP"] = 236374,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["MaxXP"] = 225105,
["Money"] = 61551664,
["MythicKey"] = {
},
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["IL"] = 454.1875,
["PlayedLevel"] = 159918,
["PlayedTotal"] = 4161157,
["Zone"] = "Вальдраккен",
["DailyResetTime"] = 1748318399,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["SpecializationIDs"] = {
62,
63,
64,
},
},
["Бимладен - Ревущий фьорд"] = {
["lastbossyell"] = "Голди Барондон: Эпохальный ключ",
["isResting"] = true,
["Emissary"] = {
[6] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Трофеи Армии погибели Легиона",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["itemName"] = "Припасы Ткачей Снов",
["itemLvl"] = 45,
["quality"] = 3,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сундук Кирин-Тора",
["itemLvl"] = 45,
["quality"] = 3,
},
},
},
},
[7] = {
["unlocked"] = true,
["days"] = {
{
["questReward"] = {
["itemName"] = "Сундук с азеритовым доспехом",
["itemLvl"] = 100,
["quality"] = 4,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questReward"] = {
["money"] = 2000000,
},
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["isComplete"] = false,
["questDone"] = 0,
["isFinish"] = false,
["questReward"] = {
["itemName"] = "Сундук со снаряжением адмиралтейства Праудмуров",
["itemLvl"] = 99,
["quality"] = 4,
},
},
},
},
},
["Race"] = "Ночная эльфийка",
["BGBRating"] = {
0,
0,
0,
0,
},
["RBGrating"] = 0,
["SoloShuffleRating"] = {
0,
0,
0,
0,
},
["lastbosstime"] = 1748298194,
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Calling"] = {
{
["isCompleted"] = false,
["title"] = "Призыв Бастиона",
["questID"] = 60426,
["expiredTime"] = 1748318399,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Буря в Утробе",
["questID"] = 60455,
["expiredTime"] = 1748404799,
["isOnQuest"] = false,
},
{
["isCompleted"] = false,
["title"] = "Обучение в Ревендрете",
["questID"] = 60411,
["expiredTime"] = 1748491199,
["isOnQuest"] = false,
},
["unlocked"] = true,
},
["ILe"] = 658.9375,
["Zone"] = "Дорногал",
["Quests"] = {
[91205] = {
["Expires"] = 1748404799,
["Title"] = "Ультраэлитное турбоускорение: испытания для сильнейших",
["Link"] = "|cffffff00|Hquest:91205:2888|h[Ультраэлитное турбоускорение: испытания для сильнейших]|h|r",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["isDaily"] = false,
},
[82496] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: Город Нитей",
["Link"] = "|cffffff00|Hquest:82496:90|h[Душа мира: Город Нитей]|h|r",
},
[82498] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: расселина Темного Пламени",
["Link"] = "|cffffff00|Hquest:82498:90|h[Душа мира: расселина Темного Пламени]|h|r",
},
[82500] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: Гнездовье",
["Link"] = "|cffffff00|Hquest:82500:90|h[Душа мира: Гнездовье]|h|r",
},
[82659] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: Неруб'арский дворец",
["Link"] = "|cffffff00|Hquest:82659:90|h[Душа мира: Неруб'арский дворец]|h|r",
},
[83347] = {
["Expires"] = 1748404799,
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["Title"] = "Посланник войны",
["Link"] = "|cffffff00|Hquest:83347:2892|h[Посланник войны]|h|r",
},
[82512] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: босс вне подземелья",
["Link"] = "|cffffff00|Hquest:82512:90|h[Душа мира: босс вне подземелья]|h|r",
},
[82452] = {
["Expires"] = 1748404799,
["Link"] = "|cffffff00|Hquest:82452:90|h[Воспоминание души мира: локальные задания]|h|r",
["Title"] = "Воспоминание души мира: локальные задания",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82516] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: заключение пакта",
["Link"] = "|cffffff00|Hquest:82516:90|h[Душа мира: заключение пакта]|h|r",
},
[82706] = {
["Expires"] = 1748404799,
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["Title"] = "Вылазки: изучение мира",
["Link"] = "|cffffff00|Hquest:82706:2838|h[Вылазки: изучение мира]|h|r",
},
[82491] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: Ара-Кара, Город Отголосков",
["Link"] = "|cffffff00|Hquest:82491:90|h[Душа мира: Ара-Кара, Город Отголосков]|h|r",
},
[82493] = {
["Expires"] = 1748404799,
["Link"] = "|cffffff00|Hquest:82493:90|h[Душа мира: \"Сияющий Рассвет\"]|h|r",
["Title"] = "Душа мира: \"Сияющий Рассвет\"",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82495] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: Искроварня",
["Link"] = "|cffffff00|Hquest:82495:90|h[Душа мира: Искроварня]|h|r",
},
[82497] = {
["Expires"] = 1748404799,
["Link"] = "|cffffff00|Hquest:82497:90|h[Душа мира: Каменный Свод]|h|r",
["Title"] = "Душа мира: Каменный Свод",
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
},
[82499] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: приорат Священного Пламени",
["Link"] = "|cffffff00|Hquest:82499:90|h[Душа мира: приорат Священного Пламени]|h|r",
},
[82511] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: Машина пробуждения",
["Link"] = "|cffffff00|Hquest:82511:90|h[Душа мира: Машина пробуждения]|h|r",
},
[82482] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: разнюхивание",
["Link"] = "|cffffff00|Hquest:82482:90|h[Душа мира: разнюхивание]|h|r",
},
[82453] = {
["Expires"] = 1748404799,
["Title"] = "Воспоминание души мира: на бис!",
["Link"] = "|cffffff00|Hquest:82453:90|h[Воспоминание души мира: на бис!]|h|r",
},
[82483] = {
["Expires"] = 1748404799,
["Title"] = "Душа мира: благодать Света",
["Link"] = "|cffffff00|Hquest:82483:90|h[Душа мира: благодать Света]|h|r",
},
[82449] = {
["Expires"] = 1748404799,
["Title"] = "Зов души мира",
["Link"] = "|cffffff00|Hquest:82449:90|h[Зов души мира]|h|r",
},
},
["WeeklyResetTime"] = 1748404799,
["Paragon"] = {
2413,
},
["oRace"] = "NightElf",
["LastSeen"] = 1748299889,
["Order"] = 50,
["Class"] = "DRUID",
["Arena3v3rating"] = 0,
["ILPvp"] = 658.9375,
["LClass"] = "Друид",
["currency"] = {
[1904] = {
["totalEarned"] = 3510,
["amount"] = 0,
["totalMax"] = 3510,
},
[2650] = {
["amount"] = 659,
},
[2809] = {
["amount"] = 0,
},
[2000] = {
["amount"] = 47,
},
[1508] = {
["totalMax"] = 2000,
["amount"] = 10,
},
[1810] = {
["covenant"] = {
[4] = 4,
},
["amount"] = 4,
["totalMax"] = 100,
},
[1191] = {
["amount"] = 0,
},
[1906] = {
["amount"] = 740,
},
[2812] = {
["amount"] = 0,
},
[2813] = {
["totalMax"] = 8,
["amount"] = 8,
},
[3100] = {
["amount"] = 0,
},
[1828] = {
["amount"] = 45801,
},
[1717] = {
["amount"] = 604,
},
[2815] = {
["amount"] = 14443,
},
[2003] = {
["amount"] = 24710,
},
[1273] = {
["weeklyMax"] = 3,
["totalMax"] = 6,
["amount"] = 1,
},
[2915] = {
["amount"] = 0,
},
[1813] = {
["covenant"] = {
[4] = 34350,
},
["amount"] = 34350,
["totalMax"] = 200000,
},
[2118] = {
["amount"] = 34197,
},
[1718] = {
["amount"] = 0,
},
[3008] = {
["totalMax"] = 2000,
["amount"] = 817,
},
[1560] = {
["amount"] = 16480,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 2645,
},
[3056] = {
["amount"] = 11926,
},
[3010] = {
["totalEarned"] = 11,
["amount"] = 11,
["totalMax"] = 18,
},
[1275] = {
["amount"] = 5,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[2122] = {
["amount"] = 19,
},
[2916] = {
["amount"] = 0,
},
[3107] = {
["totalEarned"] = 77,
["amount"] = 7,
},
[2123] = {
["amount"] = 0,
},
[515] = {
["amount"] = 10,
},
[3108] = {
["totalEarned"] = 123,
["amount"] = 168,
},
[2410] = {
["totalEarned"] = 1364,
["amount"] = 1364,
},
[3109] = {
["totalEarned"] = 98,
["amount"] = 8,
},
[2411] = {
["totalEarned"] = 1498,
["amount"] = 1498,
},
[1166] = {
["amount"] = 8490,
},
[3110] = {
["totalEarned"] = 335,
["amount"] = 185,
},
[2412] = {
["totalEarned"] = 3984,
["amount"] = 3984,
},
[2594] = {
["amount"] = 3431,
},
[2413] = {
["amount"] = 28,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
[1342] = {
["totalMax"] = 1000,
["amount"] = 25,
},
[1755] = {
["amount"] = 6794,
["relatedItemCount"] = 0,
},
[1533] = {
["amount"] = 3588,
},
[1803] = {
["amount"] = 6102,
},
[2409] = {
["totalEarned"] = 807,
["amount"] = 807,
},
[1767] = {
["amount"] = 13155,
},
[1602] = {
["amount"] = 0,
},
[1931] = {
["amount"] = 9542,
},
[1820] = {
["totalMax"] = 100,
["amount"] = 3,
},
[1889] = {
["amount"] = 18,
},
[1979] = {
["amount"] = 558,
},
[1977] = {
["amount"] = 22,
},
[2806] = {
["amount"] = 0,
},
[3028] = {
["amount"] = 1,
["relatedItemCount"] = 0,
},
[2800] = {
["totalEarned"] = 12,
["amount"] = 12,
["totalMax"] = 30,
},
[2914] = {
["amount"] = 0,
},
[3132] = {
["totalMax"] = 12,
["amount"] = 12,
},
[1710] = {
["amount"] = 945,
},
[2706] = {
["amount"] = 0,
},
[1885] = {
["amount"] = 13,
},
[2009] = {
["amount"] = 41885,
},
[1155] = {
["totalMax"] = 300,
["amount"] = 27,
},
[2707] = {
["amount"] = 0,
},
[1822] = {
["covenant"] = {
[4] = 80,
},
["amount"] = 80,
["totalMax"] = 80,
},
[3116] = {
["totalMax"] = 8,
["amount"] = 3,
},
[2803] = {
["amount"] = 579,
},
[2708] = {
["amount"] = 0,
},
[3090] = {
["amount"] = 3207,
},
[2709] = {
["amount"] = 0,
},
[2917] = {
["amount"] = 0,
},
[3023] = {
["totalEarned"] = 19,
["amount"] = 19,
["totalMax"] = 28,
},
[1220] = {
["amount"] = 3293,
},
[3218] = {
["amount"] = 1,
},
[2777] = {
["amount"] = 2,
},
[2774] = {
["amount"] = 23,
},
[1792] = {
["totalMax"] = 15000,
["amount"] = 859,
},
[1721] = {
["amount"] = 28,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2807] = {
["amount"] = 0,
},
[2245] = {
["totalMax"] = 2000,
["amount"] = 0,
},
[1719] = {
["amount"] = 7096,
},
},
["Covenant"] = 4,
["Warmode"] = false,
["Faction"] = "Alliance",
["Level"] = 80,
["Warfront"] = {
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
{
["scenario"] = {
false,
false,
},
["boss"] = false,
},
},
["MythicKey"] = {
["level"] = 14,
["mapID"] = 370,
["ResetTime"] = 1748404799,
["link"] = "|cnIQ4:|Hkeystone:180653:370:14:10:9:147:0:0|h[Ключ: Операция \"Мехагон\" – мастерская (14)]|h|r",
},
["PlayedTotal"] = 29260764,
["Arena2v2rating"] = 0,
["lastbossyelltime"] = 1748298194,
["MaxXP"] = 100000000,
["IL"] = 658.9375,
["Progress"] = {
["tww-anniversary-restored-coffer-key"] = {
["show"] = false,
},
["tww-spreading-the-light"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-time-rift"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["great-vault-raid"] = {
15,
15,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-services-requested"] = {
["show"] = false,
},
["the-world-awaits"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
},
["df-the-superbloom"] = {
["show"] = false,
},
["tww-weekly-cache"] = {
[84738] = {
["show"] = false,
},
[84739] = {
["show"] = false,
},
[84736] = {
["show"] = true,
["isComplete"] = true,
},
[84737] = {
["show"] = true,
["isComplete"] = true,
},
["show"] = true,
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
},
["tww-algari-treatise"] = {
[83727] = {
["show"] = false,
},
[83728] = {
["show"] = false,
},
[83729] = {
["show"] = false,
},
[83730] = {
["show"] = false,
},
[83731] = {
["show"] = false,
},
[83732] = {
["show"] = false,
},
[83733] = {
["show"] = false,
},
[83734] = {
["show"] = false,
},
["show"] = true,
[83725] = {
["show"] = false,
},
[83726] = {
["show"] = false,
},
[83735] = {
["show"] = false,
},
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["call-to-battle"] = {
["show"] = false,
},
["great-vault-world"] = {
10,
8,
5,
["unlocked"] = true,
["rewardWaiting"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["tww-rollin-down-in-the-deeps"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = true,
},
["sl-replenish-the-reservoir"] = {
["show"] = false,
},
["tww-services-requested"] = {
["show"] = false,
},
["sl-shaping-fate"] = {
["show"] = false,
},
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["The Severed Threads"] = {
["show"] = false,
},
["tww-archives"] = {
["show"] = false,
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
},
["tww-brawl-weekly"] = {
["show"] = false,
},
["tww-the-key-to-success"] = {
["show"] = true,
["isComplete"] = true,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = true,
[55350] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
},
["tww-siren-isle-weekly"] = {
[84850] = {
["show"] = false,
},
[84852] = {
["show"] = false,
},
[83932] = {
["show"] = false,
},
[84430] = {
["show"] = false,
},
[84680] = {
["show"] = false,
},
[84248] = {
["show"] = false,
},
[85589] = {
["show"] = false,
},
[84851] = {
["show"] = false,
},
[84299] = {
["show"] = false,
},
[83827] = {
["show"] = false,
},
["show"] = true,
[84619] = {
["show"] = false,
},
[83753] = {
["show"] = false,
},
[84001] = {
["show"] = false,
},
[84222] = {
["show"] = false,
},
[84627] = {
["show"] = false,
},
[85051] = {
["show"] = false,
},
[84432] = {
["show"] = false,
},
},
["call-to-delves"] = {
["show"] = false,
},
["tww-the-call-of-the-worldsoul"] = {
["show"] = true,
["isComplete"] = true,
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["isFinish"] = false,
["isComplete"] = false,
["numRequired"] = 36000,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["numFulfilled"] = 0,
},
["tww-the-theater-trope"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["tww-lesser-keyflame"] = {
[78933] = {
["show"] = false,
},
[78656] = {
["show"] = false,
},
[79216] = {
["show"] = false,
},
[81574] = {
["show"] = false,
},
[79158] = {
["show"] = false,
},
[79346] = {
["show"] = false,
},
[76169] = {
["show"] = false,
},
[76733] = {
["show"] = false,
},
[76394] = {
["show"] = false,
},
[81632] = {
["show"] = false,
},
["show"] = true,
[78915] = {
["show"] = false,
},
[76600] = {
["show"] = false,
},
[80004] = {
["show"] = false,
},
[80562] = {
["show"] = false,
},
[76997] = {
["show"] = false,
},
[79173] = {
["show"] = false,
},
[78972] = {
["show"] = false,
},
},
["tww-special-assignments"] = {
[81691] = {
["show"] = false,
},
[82787] = {
["show"] = false,
},
[81649] = {
["show"] = false,
},
[82355] = {
["show"] = false,
},
[82852] = {
["show"] = false,
},
[83229] = {
["show"] = false,
},
[82531] = {
["show"] = false,
},
["show"] = true,
[82414] = {
["show"] = false,
},
},
["tww-pvp-world"] = {
["show"] = false,
},
["tww-gearing-up-for-trouble"] = {
["show"] = false,
},
["sl-return-lost-souls"] = {
["show"] = false,
},
["tww-delves"] = {
["show"] = true,
["isComplete"] = true,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["emissary-of-war"] = {
["show"] = true,
["isComplete"] = true,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["tww-pvp-weekly"] = {
["show"] = false,
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["tww-biergoth-dungeon-quest"] = {
["show"] = false,
},
},
["lastboss"] = "Голди Барондон: Эпохальный ключ",
["MythicKeyBest"] = {
13,
12,
12,
["threshold"] = {
1,
4,
8,
},
["runHistory"] = {
{
["completed"] = false,
["name"] = "Искроварня",
["thisWeek"] = true,
["level"] = 13,
["mapChallengeModeID"] = 506,
["runScore"] = 316,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "ЗОЛОТАЯ ЖИЛА!!!",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 247,
["runScore"] = 365,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Приорат Священного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 499,
["runScore"] = 373,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 374,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 500,
["runScore"] = 369,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 504,
["runScore"] = 376,
["rewardLevel"] = 662,
},
{
["completed"] = false,
["name"] = "Расселина Темного Пламени",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 504,
["runScore"] = 0,
["rewardLevel"] = 662,
},
{
["completed"] = false,
["name"] = "Искроварня",
["thisWeek"] = true,
["level"] = 12,
["mapChallengeModeID"] = 506,
["runScore"] = 319,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Театр Боли",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 382,
["runScore"] = 343,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 500,
["runScore"] = 343,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 525,
["runScore"] = 344,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 525,
["runScore"] = 339,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 525,
["runScore"] = 342,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция: шлюз",
["thisWeek"] = true,
["level"] = 11,
["mapChallengeModeID"] = 525,
["runScore"] = 341,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 370,
["runScore"] = 326,
["rewardLevel"] = 662,
},
{
["completed"] = false,
["name"] = "Приорат Священного Пламени",
["thisWeek"] = true,
["level"] = 10,
["mapChallengeModeID"] = 499,
["runScore"] = 301,
["rewardLevel"] = 662,
},
{
["completed"] = true,
["name"] = "Операция \"Мехагон\" – мастерская",
["thisWeek"] = true,
["level"] = 9,
["mapChallengeModeID"] = 370,
["runScore"] = 302,
["rewardLevel"] = 658,
},
{
["completed"] = true,
["name"] = "Гнездовье",
["thisWeek"] = true,
["level"] = 9,
["mapChallengeModeID"] = 500,
["runScore"] = 299,
["rewardLevel"] = 658,
},
},
["ResetTime"] = 1748404799,
["rewardWaiting"] = false,
["lastCompletedIndex"] = 3,
},
["PlayedLevel"] = 1631618,
["Money"] = 6126815109,
["SpecializationIDs"] = {
102,
103,
104,
105,
},
["Skills"] = {
},
["MythicPlusScore"] = 2820,
["DailyResetTime"] = 1748318399,
},
["Прециза - Свежеватель Душ"] = {
["Arena3v3rating"] = 0,
["isResting"] = true,
["Emissary"] = {
[7] = {
["unlocked"] = true,
["days"] = {
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isFinish"] = false,
["isComplete"] = false,
},
{
["questDone"] = 0,
["isComplete"] = false,
["isFinish"] = false,
},
},
},
},
["Race"] = "Эльфийка крови",
["LClass"] = "Охотница",
["RBGrating"] = 0,
["SoloShuffleRating"] = {
[3] = 0,
},
["Show"] = "saved",
["TimewornMythicKey"] = {
},
["Faction"] = "Horde",
["ILe"] = 179.5,
["Quests"] = {
},
["Paragon"] = {
},
["IL"] = 190.1875,
["LastSeen"] = 1725797781,
["Progress"] = {
["df-a-worthy-ally-loamm-niffen"] = {
["show"] = false,
},
["bfa-horrific-vision"] = {
[57847] = {
["show"] = false,
},
[57848] = {
["show"] = false,
},
[57841] = {
["show"] = false,
},
[57842] = {
["show"] = false,
},
[57843] = {
["show"] = false,
},
[57844] = {
["show"] = false,
},
[57845] = {
["show"] = false,
},
[57846] = {
["show"] = false,
},
["show"] = false,
},
["sl-covenant-assault"] = {
["show"] = false,
},
["df-time-rift"] = {
["show"] = false,
},
["df-shipment-of-goods"] = {
["show"] = true,
[78427] = {
["show"] = false,
},
[78428] = {
["show"] = false,
},
},
["df-siege-on-dragonbane-keep"] = {
["show"] = false,
},
["df-the-big-dig-traitors-rest"] = {
["show"] = false,
},
["df-trial-of-elements"] = {
["show"] = false,
},
["df-secured-shipment"] = {
["show"] = false,
},
["df-aiding-the-accord"] = {
["show"] = false,
},
["df-dreamsurge"] = {
["show"] = false,
},
["bfa-nzoth-assault"] = {
["show"] = false,
[55350] = {
["show"] = false,
},
[56064] = {
["show"] = false,
},
[56308] = {
["show"] = false,
},
[57157] = {
["show"] = false,
},
[57008] = {
["show"] = false,
},
[57728] = {
["show"] = false,
},
},
["emissary-of-war"] = {
["show"] = false,
},
["timewalking"] = {
["show"] = false,
},
["bfa-lesser-vision"] = {
["show"] = false,
},
["df-the-superbloom"] = {
["show"] = false,
},
["great-vault-raid"] = {
["unlocked"] = false,
["rewardWaiting"] = false,
},
["df-disciple-of-fyrakk"] = {
["show"] = false,
},
["df-grand-hunt"] = {
["show"] = true,
[70906] = {
["show"] = false,
},
[71136] = {
["show"] = false,
},
[71137] = {
["show"] = false,
},
},
["df-a-worthy-ally-dream-wardens"] = {
["show"] = false,
},
["df-researchers-under-fire"] = {
["show"] = true,
[75628] = {
["show"] = false,
},
[75629] = {
["show"] = false,
},
[75630] = {
["show"] = false,
},
[75627] = {
["show"] = false,
},
},
["df-primal-storms-core"] = {
["show"] = true,
[70753] = {
["show"] = false,
},
[72686] = {
["show"] = false,
},
[73162] = {
["show"] = false,
},
[70723] = {
["show"] = false,
},
[70752] = {
["show"] = false,
},
[70754] = {
["show"] = false,
},
},
["bfa-island"] = {
"Добудьте 36 000 ед. азерита в островных экспедициях: 0/36000",
["show"] = true,
["numFulfilled"] = 0,
["numRequired"] = 36000,
["isComplete"] = false,
["leaderboardCount"] = 1,
["text"] = "0/36000",
["objectiveType"] = "monster",
["isFinish"] = false,
},
["df-blooming-dreamseeds"] = {
["show"] = false,
},
["sl-patterns-within-patterns"] = {
["show"] = false,
},
["df-fighting-is-its-own-reward"] = {
["show"] = false,
},
["df-primal-storms-elementals"] = {
[73998] = {
["show"] = false,
},
[74006] = {
["show"] = false,
},
[74039] = {
["show"] = false,
},
[74016] = {
["show"] = false,
},
[73989] = {
["show"] = false,
},
[73991] = {
["show"] = false,
},
[73993] = {
["show"] = false,
},
[73995] = {
["show"] = false,
},
[73999] = {
["show"] = false,
},
[74005] = {
["show"] = false,
},
[74007] = {
["show"] = false,
},
[74009] = {
["show"] = false,
},
["show"] = true,
[73986] = {
["show"] = false,
},
[74022] = {
["show"] = false,
},
[74027] = {
["show"] = false,
},
[74038] = {
["show"] = false,
},
},
["the-world-awaits"] = {
["show"] = false,
},
["df-trial-of-flood"] = {
["show"] = false,
},
["df-community-feast"] = {
["show"] = false,
},
["df-sparks-of-life"] = {
["show"] = false,
},
},
["Class"] = "HUNTER",
["ILPvp"] = 190.1875,
["currency"] = {
[1820] = {
["totalMax"] = 100,
["amount"] = 16,
},
[1822] = {
["covenant"] = {
[3] = 4,
},
["totalMax"] = 80,
["amount"] = 4,
},
[1885] = {
["amount"] = 2,
},
[1828] = {
["amount"] = 20,
},
[2912] = {
["totalMax"] = 9,
["amount"] = 9,
},
[2796] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1560] = {
["amount"] = 18,
},
[1716] = {
["amount"] = 16,
},
[2533] = {
["totalMax"] = 8,
["amount"] = 8,
},
[1718] = {
["amount"] = 0,
},
[1533] = {
["amount"] = 30,
},
[1813] = {
["covenant"] = {
[3] = 342,
},
["totalMax"] = 200000,
["amount"] = 342,
},
[1721] = {
["amount"] = 0,
},
[1810] = {
["covenant"] = {
[3] = 8,
},
["totalMax"] = 100,
["amount"] = 8,
},
[824] = {
["totalMax"] = 10000,
["amount"] = 198,
},
[1166] = {
["amount"] = 95,
},
[1220] = {
["amount"] = 2083,
},
[1767] = {
["amount"] = 2812,
},
[1580] = {
["weeklyMax"] = 2,
["totalMax"] = 5,
["amount"] = 5,
},
},
["Order"] = 50,
["Warmode"] = false,
["MythicKey"] = {
},
["Level"] = 60,
["XP"] = 195,
["Warfront"] = {
{
["scenario"] = {
},
["boss"] = false,
},
{
["scenario"] = {
},
["boss"] = false,
},
},
["MythicKeyBest"] = {
["threshold"] = {
},
["ResetTime"] = 1748404799,
},
["RestXP"] = 83498,
["Arena2v2rating"] = 0,
["Skills"] = {
},
["Money"] = 19781,
["oRace"] = "BloodElf",
["MaxXP"] = 55665,
["Covenant"] = 3,
["MythicPlusScore"] = 0,
["WeeklyResetTime"] = 1748404799,
["PlayedLevel"] = 124686,
["Calling"] = {
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748318399,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748404799,
},
{
["isCompleted"] = false,
["isOnQuest"] = false,
["expiredTime"] = 1748491199,
},
["unlocked"] = true,
},
["PlayedTotal"] = 655604,
["DailyResetTime"] = 1748318399,
["SpecializationIDs"] = {
253,
254,
255,
},
["Zone"] = "Оргриммар",
},
},
["Emissary"] = {
["Expansion"] = {
[6] = {
{
["questID"] = {
["Horde"] = 48641,
["Alliance"] = 48641,
},
["questNeed"] = 4,
["expiredTime"] = 1748318466,
},
{
["questID"] = {
["Horde"] = 42170,
["Alliance"] = 42170,
},
["questNeed"] = 4,
["expiredTime"] = 1748404866,
},
{
["questID"] = {
["Horde"] = 43179,
["Alliance"] = 43179,
},
["questNeed"] = 3,
["expiredTime"] = 1748491266,
},
},
[7] = {
{
["questID"] = {
["Horde"] = 50602,
["Alliance"] = 50601,
},
["questNeed"] = 4,
["expiredTime"] = 1748318466,
},
{
["questID"] = {
["Horde"] = 56120,
["Alliance"] = 56119,
},
["questNeed"] = 4,
["expiredTime"] = 1748404866,
},
{
["questID"] = {
["Horde"] = 50598,
["Alliance"] = 50599,
},
["questNeed"] = 4,
["expiredTime"] = 1748491266,
},
},
},
["Cache"] = {
[43179] = "Маги Кирин-Тора в Даларане",
[50601] = "Возрождение Шторма",
[50603] = "Жители Вол'дуна",
[50604] = "Тортолланские искатели",
[48639] = "Армия Света",
[50562] = "Защитники Азерот",
[48641] = "Армия погибели Легиона",
[48642] = "Защитники Аргуса",
[42422] = "Стражи",
[42421] = "Помраченные",
[50598] = "Империя Зандалари",
[50599] = "Адмиралтейство Праудмуров",
[50600] = "Орден Пылающих Углей",
[56119] = "Клинки Волн",
[42170] = "Ткачи Снов",
[42233] = "Племена Крутогорья",
[42420] = "Двор Фарондиса",
[50605] = "Военная кампания Альянса",
[50606] = "Военная кампания Орды",
[42234] = "Валарьяры",
[50602] = "Экспедиция Таланджи",
[56120] = "Освобожденные",
},
},
["spelltip"] = {
[71041] = {
"Покинувший подземелье",
"Вы покинули подземелье. Должно пройти некоторое время, прежде чем вы снова сможете воспользоваться поиском подземелья или рейда.",
"Осталось: 6 |4минута:минуты:минут;",
},
},
["Instances"] = {
["Трон Четырех Ветров"] = {
["LFDID"] = 318,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Квартал Звезд"] = {
["LFDID"] = 2280,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Малификус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1884,
["RecLevel"] = 45,
["Raid"] = true,
},
["Огненные Просторы"] = {
["LFDID"] = 362,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Театр Боли"] = {
["LFDID"] = 2815,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Депо Мрачных Путей"] = {
["LFDID"] = 2319,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ара-Кара, Город Отголосков"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 1,
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2660:23:7|h[Ара-Кара, Город Отголосков]|h|r",
["ID"] = 587741198,
["Locked"] = false,
},
},
["Raid"] = false,
["LFDID"] = 2726,
},
["Некрополь Призрачной Луны"] = {
["LFDID"] = 1976,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Сотанатор"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2014,
["RecLevel"] = 45,
["Raid"] = true,
},
["Змеиное святилище"] = {
["LFDID"] = 194,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Стратхольм – черный ход"] = {
["LFDID"] = 2641,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Битва за Дазар'алор"] = {
["LFDID"] = 1944,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Базуал"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2517,
["RecLevel"] = 70,
["Raid"] = true,
},
["Т'зейн"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2139,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное героическое подземелье (2-й сезон The War Within)"] = {
["Show"] = "saved",
["Expansion"] = 10,
["LFDID"] = 2807,
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Крепость Черной Ладьи"] = {
["LFDID"] = 2275,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Аркатрац"] = {
["LFDID"] = 1011,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Город Нитей"] = {
["LFDID"] = 2722,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Инквизитор Мето"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2012,
["RecLevel"] = 45,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria (героич.)"] = {
["LFDID"] = 462,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Вольная Гавань"] = {
["LFDID"] = 2178,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Непроглядная Пучина"] = {
["LFDID"] = 10,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное героическое подземелье (Mists of Pandaria)"] = {
["LFDID"] = 2537,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Коварные Дуо"] = {
["LFDID"] = 2803,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 80,
},
["Тазавеш: гамбит Со'леи"] = {
["LFDID"] = 2330,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Нексус"] = {
["LFDID"] = 1019,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Испытание крестоносца"] = {
["LFDID"] = 248,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Твердыня Крыла Тьмы"] = {
["LFDID"] = 314,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье (Dragonflight)"] = {
["LFDID"] = 2350,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Кузня Душ"] = {
["LFDID"] = 2322,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Тайный рынок Тазавеш"] = {
["LFDID"] = 2225,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Случайное подземелье (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2539,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Каламир"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1774,
["RecLevel"] = 45,
["Raid"] = true,
},
["Престол Гроз"] = {
["LFDID"] = 634,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Аметистовая крепость"] = {
["LFDID"] = 221,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Темный лабиринт"] = {
["LFDID"] = 181,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Операция \"Мехагон\" – свалка"] = {
["LFDID"] = 2027,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Натанос Гнилостень"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 9005,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Lich King (героич.)"] = {
["LFDID"] = 262,
["Expansion"] = 2,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Анторус, Пылающий Трон"] = {
["LFDID"] = 1642,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Апокрон"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1956,
["RecLevel"] = 45,
["Raid"] = true,
},
["Ботаника"] = {
["LFDID"] = 2325,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Огненная Пропасть"] = {
["LFDID"] = 4,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Логово Магтеридона"] = {
["LFDID"] = 176,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Вечный дворец"] = {
["LFDID"] = 2016,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Ауростор"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2562,
["RecLevel"] = 70,
["Raid"] = true,
},
["Азжол-Неруб"] = {
["LFDID"] = 2324,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Горнило Штормов"] = {
["LFDID"] = 1954,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Шуррай"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2636,
["RecLevel"] = 80,
["Raid"] = true,
},
["Забытый город - квартал Криводревов"] = {
["LFDID"] = 34,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье Shadowlands (героич.)"] = {
["LFDID"] = 2087,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 60,
["Random"] = true,
["Raid"] = false,
},
["Рубиновые Омуты Жизни"] = {
["LFDID"] = 2436,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Принц Сарсарун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 310,
},
["Случайное подземелье, путеш. во времени (Legion)"] = {
["Beamladen - Twisting Nether"] = {
},
["Expansion"] = 6,
["LFDID"] = 2274,
["Holiday"] = true,
["Raid"] = false,
["RecLevel"] = 10,
["Random"] = true,
["Show"] = "saved",
},
["Госпожа Аллюрадель"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2011,
["RecLevel"] = 45,
["Raid"] = true,
},
["Казематы Стражей"] = {
["LFDID"] = 2278,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Штурм Аметистовой крепости"] = {
["LFDID"] = 1209,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Око Азшары"] = {
["LFDID"] = 2276,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Лисканот"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2518,
["RecLevel"] = 70,
["Raid"] = true,
},
["На'зак Одержимый"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1783,
["RecLevel"] = 45,
["Raid"] = true,
},
["Крепость Темного Клыка"] = {
["LFDID"] = 327,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Великий посол Огнехлыст"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 308,
},
["Островные экспедиции"] = {
["LFDID"] = 1762,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["Raid"] = false,
["Random"] = true,
["RecLevel"] = 10,
},
["Хмелеварня Буйных Портеров"] = {
["LFDID"] = 2543,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Кузня Крови"] = {
["LFDID"] = 2326,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Око Вечности"] = {
["LFDID"] = 237,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Случайный сценарий Mists of Pandaria (героич.)"] = {
["LFDID"] = 641,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Глубины Черной горы - Верхний город"] = {
["LFDID"] = 276,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Корен Худовар"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 287,
},
["Гномреган"] = {
["LFDID"] = 14,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Расселина Темного Пламени"] = {
["LFDID"] = 2809,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Собор Вечной Ночи"] = {
["LFDID"] = 1488,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Операция: шлюз"] = {
["LFDID"] = 2812,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 1,
["Raid"] = false,
},
["Зул'Гуруб"] = {
["LFDID"] = 334,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Лазурное хранилище"] = {
["LFDID"] = 2498,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Храм Нефритовой Змеи"] = {
["LFDID"] = 2541,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Ашран"] = {
["LFDID"] = 1127,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 40,
["Show"] = "saved",
},
["Забытый город – квартал Криводревов"] = {
["LFDID"] = 2635,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Сердце Страха"] = {
["LFDID"] = 534,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Черный храм"] = {
["LFDID"] = 196,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Случайное подземелье классической игры"] = {
["LFDID"] = 258,
["Expansion"] = 0,
["Show"] = "saved",
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = false,
},
["Грим Батол"] = {
["LFDID"] = 2730,
["Expansion"] = 10,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "never",
},
["Каменный Свод"] = {
["LFDID"] = 2724,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Случайное подземелье, путеш. во времени (Warlords of Draenor)"] = {
["Beamladen - Twisting Nether"] = {
},
["Expansion"] = 5,
["LFDID"] = 1971,
["Holiday"] = true,
["Raid"] = false,
["RecLevel"] = 10,
["Random"] = true,
["Show"] = "saved",
},
["Нижняя часть пика Черной горы"] = {
["LFDID"] = 32,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Окулярус"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2013,
["RecLevel"] = 45,
["Raid"] = true,
},
["Терраса Вечной Весны"] = {
["LFDID"] = 536,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Случайный сценарий путешествия во времени (Mists of Pandaria)"] = {
["LFDID"] = 2558,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Каражан"] = {
["LFDID"] = 175,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Аукиндон"] = {
["LFDID"] = 1975,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Shadowlands"] = {
["LFDID"] = 2086,
["Expansion"] = 8,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Иссохший Дж'им"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1796,
["RecLevel"] = 45,
["Raid"] = true,
},
["Крепость Бурь"] = {
["LFDID"] = 193,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Стратхольм – главные врата"] = {
["LFDID"] = 2639,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Островные экспедиции – индивидуальный тур"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2251,
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Храм Ан'Киража"] = {
["LFDID"] = 161,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Антрос"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9013,
["RecLevel"] = 60,
["Raid"] = true,
},
["Ульдир"] = {
["LFDID"] = 1889,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Терраса Магистров"] = {
["LFDID"] = 1154,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Прошлое Хиджала"] = {
["LFDID"] = 195,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Подземелья Могу'шан"] = {
["LFDID"] = 532,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Некроситет"] = {
["LFDID"] = 2557,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Забытый город - палаты Гордока"] = {
["LFDID"] = 38,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Тол Дагор"] = {
["LFDID"] = 1714,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье (The War Within, героический режим)"] = {
["LFDID"] = 2517,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Легиона"] = {
["LFDID"] = 1045,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Случайный сценарий (Mists of Pandaria, героич.)"] = {
["LFDID"] = 2559,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Си'ваш"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1885,
["RecLevel"] = 45,
["Raid"] = true,
},
["Кронпринцесса Терадрас"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 309,
},
["Ульдаман"] = {
["LFDID"] = 22,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Операция \"Мехагон\" – мастерская"] = {
["LFDID"] = 2813,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Зул'Аман"] = {
["LFDID"] = 340,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Ульдуар"] = {
["Show"] = "saved",
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 1677,
},
["Охотники за душами"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1756,
["RecLevel"] = 45,
["Raid"] = true,
},
["Гоблионе"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2683,
["RecLevel"] = 80,
["Raid"] = true,
},
["Кодекс Хроми"] = {
["LFDID"] = 2714,
["Expansion"] = 8,
["Beamladen - Twisting Nether"] = {
},
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["Show"] = "saved",
},
["Лабиринты Иглошкурых"] = {
["LFDID"] = 16,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Источник Вечности"] = {
["LFDID"] = 437,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["\"Сияющий Рассвет\""] = {
["LFDID"] = 2725,
["Expansion"] = 10,
["RecLevel"] = 1,
["Мальдика - Свежеватель Душ"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2662:23:7|h[\"Сияющий Рассвет\"]|h|r",
["ID"] = 500594566,
["Locked"] = false,
},
},
["Raid"] = false,
["Show"] = "never",
},
["Замок Нафрия"] = {
["LFDID"] = 2095,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Утроба Душ"] = {
["LFDID"] = 1192,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Открытие Темного портала"] = {
["LFDID"] = 1012,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Камня"] = {
["LFDID"] = 213,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Случайный сценарий Mists of Pandaria"] = {
["LFDID"] = 493,
["Expansion"] = 4,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Нижетопь"] = {
["LFDID"] = 2327,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Престол Триумвирата"] = {
["LFDID"] = 1535,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Атал'Дазар"] = {
["LFDID"] = 2177,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Очищение Стратхольма"] = {
["LFDID"] = 210,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Глубины Черной горы - Тюремный блок"] = {
["LFDID"] = 30,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Кордак"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2637,
["RecLevel"] = 80,
["Raid"] = true,
},
["Неруб'арский дворец"] = {
["LFDID"] = 2645,
["Expansion"] = 10,
["RecLevel"] = 80,
["Мальдика - Свежеватель Душ"] = {
[16] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2657:16:15|h[Неруб'арский дворец]|h|r",
["ID"] = 501081465,
["Locked"] = false,
},
[15] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA7EF3A:2657:15:103|h[Неруб'арский дворец]|h|r",
["ID"] = 500590170,
["Locked"] = false,
},
},
["Show"] = "saved",
["Raid"] = true,
["Вольтчара - Свежеватель Душ"] = {
[14] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:14:64|h[Неруб'арский дворец]|h|r",
["ID"] = 1167874712,
["Locked"] = false,
},
[16] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:16:15|h[Неруб'арский дворец]|h|r",
["ID"] = 1167082419,
["Locked"] = false,
},
[15] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1604-0AA824D2:2657:15:64|h[Неруб'арский дворец]|h|r",
["ID"] = 500371263,
["Locked"] = false,
},
},
},
["Хранилище Воплощений"] = {
["LFDID"] = 2390,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Искроварня"] = {
["LFDID"] = 2811,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Паровое подземелье"] = {
["LFDID"] = 185,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Ан'кахет: Старое Королевство"] = {
["LFDID"] = 1016,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Верховный Молот"] = {
["LFDID"] = 897,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Курганы Иглошкурых"] = {
["LFDID"] = 20,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (The Burning Crusade)"] = {
["Beamladen - Twisting Nether"] = {
},
["Expansion"] = 1,
["LFDID"] = 744,
["Holiday"] = true,
["Raid"] = false,
["RecLevel"] = 10,
["Random"] = true,
["Show"] = "saved",
},
["Затонувший храм"] = {
["LFDID"] = 28,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Осада Оргриммара"] = {
["LFDID"] = 766,
["Expansion"] = 4,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Забытый город - центральный сад"] = {
["LFDID"] = 36,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье Легиона (героич.)"] = {
["LFDID"] = 1046,
["Expansion"] = 6,
["Show"] = "saved",
["RecLevel"] = 45,
["Random"] = true,
["Raid"] = false,
},
["Трон Приливов"] = {
["LFDID"] = 1150,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Черный храм"] = {
["Show"] = "saved",
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 1533,
},
["Гарнизон босс"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 9001,
["RecLevel"] = 40,
["Raid"] = true,
},
["Окулус"] = {
["LFDID"] = 211,
["Expansion"] = 2,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["10.2.5 - VS Mode - LFG Dungeon (OJF)"] = {
["LFDID"] = 2484,
["Expansion"] = 5,
["Show"] = "saved",
["Raid"] = false,
["RecLevel"] = 1,
},
["Улмат"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2362,
["RecLevel"] = 50,
["Raid"] = true,
},
["Чертоги Покаяния"] = {
["LFDID"] = 2119,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Пещеры Времени: годовщина"] = {
["LFDID"] = 1911,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Врата Заходящего Солнца"] = {
["LFDID"] = 2549,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Вечное Цветение"] = {
["LFDID"] = 1972,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Мародон - Зловонная пещера"] = {
["LFDID"] = 26,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Крепость Утгард"] = {
["LFDID"] = 2323,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Хранилище Аркавона"] = {
["LFDID"] = 240,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Возвращение в Каражан"] = {
["LFDID"] = 1347,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 110,
["Show"] = "saved",
},
["Ульдаман: наследие Тира"] = {
["LFDID"] = 2465,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Верхняя часть пика Черной горы"] = {
["LFDID"] = 1004,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Испытание доблести"] = {
["LFDID"] = 1439,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Воспоминания Азерот: Burning Crusade"] = {
["LFDID"] = 2004,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Аберрий, Затененное Горнило"] = {
["LFDID"] = 2405,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Случайное подземелье (The War Within)"] = {
["LFDID"] = 2516,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Ульдуар"] = {
["LFDID"] = 244,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Ни'алота, Пробуждающийся Город"] = {
["LFDID"] = 2035,
["Expansion"] = 7,
["RecLevel"] = 50,
["Raid"] = true,
["Show"] = "saved",
},
["Наступление клана Нокхуд"] = {
["LFDID"] = 2442,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Затерянный город Тол'вир"] = {
["LFDID"] = 1151,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Дров / Тарлна"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1211,
["RecLevel"] = 40,
["Raid"] = true,
},
["Рассвет Бесконечности: подъем Дорнозму"] = {
["LFDID"] = 2530,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Смертельная тризна"] = {
["LFDID"] = 2728,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "never",
},
["Испытание великого крестоносца"] = {
["LFDID"] = 250,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Мучители из Торгаста"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9007,
["RecLevel"] = 60,
["Raid"] = true,
},
["Случайное подземелье Burning Crusade (героич.)"] = {
["LFDID"] = 260,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Бастионы Адского Пламени"] = {
["LFDID"] = 188,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Хумонгрис"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1770,
["RecLevel"] = 45,
["Raid"] = true,
},
["Цитадель Ледяной Короны"] = {
["LFDID"] = 280,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Кай'жу Газ'рилла"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 30,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 306,
},
["Логово Ониксии"] = {
["LFDID"] = 257,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Солнечный Колодец"] = {
["LFDID"] = 199,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Конец Времен"] = {
["LFDID"] = 1152,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путешествие во времени (Mists of Pandaria)"] = {
["LFDID"] = 2538,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Гнездовье (версия из задания)"] = {
["LFDID"] = 2657,
["Expansion"] = 10,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "never",
},
["Случайное подземелье Cataclysm (героич.)"] = {
["LFDID"] = 301,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Воспоминания Азерот: Wrath of the Lich King"] = {
["LFDID"] = 2017,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Мор'гет Мучитель проклятых"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9012,
["RecLevel"] = 60,
["Raid"] = true,
},
["Тихая Сень"] = {
["LFDID"] = 2025,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["Show"] = "saved",
},
["Хромовый король"] = {
["LFDID"] = 2798,
["Expansion"] = 10,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 80,
},
["Амирдрассил, Надежда Сна"] = {
["LFDID"] = 2504,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = true,
["Show"] = "saved",
},
["Залы Отражений"] = {
["LFDID"] = 256,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Wrath of the Lich King)"] = {
["Beamladen - Twisting Nether"] = {
},
["Expansion"] = 2,
["LFDID"] = 995,
["Holiday"] = true,
["Raid"] = false,
["RecLevel"] = 10,
["Random"] = true,
["Show"] = "saved",
},
["Тюрьма Штормграда"] = {
["LFDID"] = 12,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor (героич.)"] = {
["LFDID"] = 789,
["Expansion"] = 5,
["Show"] = "saved",
["RecLevel"] = 40,
["Random"] = true,
["Raid"] = false,
},
["Вакан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2531,
["RecLevel"] = 70,
["Raid"] = true,
},
["\"Валинор\""] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2430,
["RecLevel"] = 60,
["Raid"] = true,
},
["Скопище кошмаров"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2635,
["RecLevel"] = 80,
["Raid"] = true,
},
["Забытый город – центральный сад"] = {
["LFDID"] = 2646,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Узилище"] = {
["LFDID"] = 1015,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Чумные каскады"] = {
["LFDID"] = 2121,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Побег из Дарнхольда"] = {
["LFDID"] = 183,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Возвращение в Каражан (верхняя часть)"] = {
["LFDID"] = 1474,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Мародон - Поющие водопады"] = {
["LFDID"] = 273,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Душа Дракона"] = {
["LFDID"] = 448,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Гробница Предвечных"] = {
["LFDID"] = 2290,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Ша Злости"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 691,
["RecLevel"] = 35,
["Raid"] = true,
},
["Время Сумерек"] = {
["LFDID"] = 439,
["Expansion"] = 3,
["Raid"] = false,
["RecLevel"] = 35,
["Show"] = "saved",
},
["Лощина Бурошкуров"] = {
["LFDID"] = 2439,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Верховный владыка Каззак"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1452,
["RecLevel"] = 40,
["Raid"] = true,
},
["Ундаста"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 826,
["RecLevel"] = 35,
["Raid"] = true,
},
["Случайное подземелье Battle For Azeroth"] = {
["LFDID"] = 1670,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Пещеры Стенаний"] = {
["LFDID"] = 1,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Святилище Штормов"] = {
["LFDID"] = 1774,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Яма Сарона"] = {
["LFDID"] = 1153,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Усадьба Уэйкрестов"] = {
["LFDID"] = 1706,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Левантия"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1769,
["RecLevel"] = 45,
["Raid"] = true,
},
["Налак"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 814,
["RecLevel"] = 35,
["Raid"] = true,
},
["Аукенайские гробницы"] = {
["LFDID"] = 178,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Созидания"] = {
["LFDID"] = 321,
["Expansion"] = 3,
["RecLevel"] = 31,
["Raid"] = false,
["Show"] = "saved",
},
["Повелитель Холода Ахун"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 1,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 286,
},
["Мортанис"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2431,
["RecLevel"] = 60,
["Raid"] = true,
},
["Монастырь Алого ордена"] = {
["LFDID"] = 2555,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Cataclysm)"] = {
["Show"] = "saved",
["Expansion"] = 3,
["LFDID"] = 1146,
["RecLevel"] = 10,
["Raid"] = false,
["Random"] = true,
["Holiday"] = true,
},
["Цитадель Адского Пламени"] = {
["LFDID"] = 989,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Операция \"Мехагон\""] = {
["LFDID"] = 2006,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Чертоги Насыщения"] = {
["LFDID"] = 2444,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Подгнилье"] = {
["LFDID"] = 1712,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Mists of Pandaria)"] = {
["Beamladen - Twisting Nether"] = {
},
["Expansion"] = 4,
["LFDID"] = 1453,
["Holiday"] = true,
["Raid"] = false,
["RecLevel"] = 10,
["Random"] = true,
["Show"] = "saved",
},
["Крепость Барадин"] = {
["LFDID"] = 329,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Туманы Тирна Скитта"] = {
["LFDID"] = 2727,
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "never",
},
["Королева Ансурек"] = {
["LFDID"] = 2715,
["Expansion"] = 10,
["Raid"] = true,
["RecLevel"] = 80,
["Show"] = "saved",
},
["Случайное подземелье, путеш. во времени (Classic)"] = {
["Beamladen - Twisting Nether"] = {
},
["Expansion"] = 0,
["LFDID"] = 2634,
["Holiday"] = true,
["Raid"] = false,
["RecLevel"] = 10,
["Random"] = true,
["Show"] = "saved",
},
["Дюнный пожиратель Краулок"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2210,
["RecLevel"] = 50,
["Raid"] = true,
},
["Логово Груула"] = {
["LFDID"] = 177,
["Expansion"] = 1,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Стратхольм - Черный ход"] = {
["LFDID"] = 274,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 21,
["Show"] = "saved",
},
["Случайные островные экспедиции – эпохальный режим"] = {
["LFDID"] = 1891,
["Expansion"] = 7,
["Scenario"] = true,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Пещеры Черной горы"] = {
["LFDID"] = 2321,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Гнездовье"] = {
["Show"] = "never",
["Expansion"] = 10,
["LFDID"] = 2808,
["RecLevel"] = 1,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2648:23:0|h[Гнездовье]|h|r",
["ID"] = 506569244,
["Locked"] = false,
},
},
["Raid"] = false,
},
["Крепость Драк'Тарон"] = {
["LFDID"] = 215,
["Expansion"] = 2,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Рухмар"] = {
["Show"] = "saved",
["Expansion"] = 5,
["WorldBoss"] = 1262,
["RecLevel"] = 40,
["Raid"] = true,
},
["Гробница королей"] = {
["LFDID"] = 1785,
["Expansion"] = 7,
["Raid"] = false,
["RecLevel"] = 50,
["Show"] = "saved",
},
["Логово Крыла Тьмы"] = {
["LFDID"] = 50,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Ораномонос Вечноветвящаяся"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9010,
["RecLevel"] = 60,
["Raid"] = true,
},
["Академия Алгет'ар"] = {
["LFDID"] = 2464,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Путешествие во времени, рейд: Огненные Просторы"] = {
["Show"] = "saved",
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 2026,
},
["Случайное подземелье Cataclysm"] = {
["LFDID"] = 300,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 30,
["Random"] = true,
["Raid"] = false,
},
["Чертоги Молний"] = {
["LFDID"] = 1018,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Лазуретос"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2199,
["RecLevel"] = 50,
["Raid"] = true,
},
["Йорундалль"] = {
["LFDID"] = 2041,
["Expansion"] = 7,
["Raid"] = true,
["RecLevel"] = 1,
["Show"] = "saved",
},
["Шпили Перерождения"] = {
["LFDID"] = 2122,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Чертоги Доблести"] = {
["LFDID"] = 1194,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Нургаш Жижерожденный"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2433,
["RecLevel"] = 60,
["Raid"] = true,
},
["Рассвет Бесконечности"] = {
["LFDID"] = 2430,
["Expansion"] = 9,
["Raid"] = false,
["RecLevel"] = 70,
["Show"] = "saved",
},
["Рассвет Бесконечности: падение Галакронда"] = {
["LFDID"] = 2529,
["Expansion"] = 9,
["RecLevel"] = 70,
["Raid"] = false,
["Show"] = "saved",
},
["Сетеккские залы"] = {
["LFDID"] = 180,
["Expansion"] = 1,
["RecLevel"] = 16,
["Raid"] = false,
["Show"] = "saved",
},
["Осада Боралуса"] = {
["Show"] = "never",
["Expansion"] = 10,
["RecLevel"] = 50,
["Raid"] = false,
["LFDID"] = 2729,
},
["Вук'лаз Землелом"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2381,
["RecLevel"] = 50,
["Raid"] = true,
},
["Руины Ан'Киража"] = {
["LFDID"] = 160,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Шлаковые шахты Кровавого Молота"] = {
["LFDID"] = 1973,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Разрушенные залы"] = {
["LFDID"] = 1014,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Цитадель Темного Молота"] = {
["LFDID"] = 2043,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 7,
["Show"] = "saved",
},
["Изумрудный Кошмар"] = {
["LFDID"] = 1350,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Экспедиции на остров Кишащий"] = {
["Show"] = "saved",
["Expansion"] = 7,
["Scenario"] = true,
["LFDID"] = 2054,
["RecLevel"] = 1,
["Random"] = true,
["Raid"] = true,
},
["Шар'тос"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1763,
["RecLevel"] = 45,
["Raid"] = true,
},
["Мор'гет"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 2456,
["RecLevel"] = 60,
["Raid"] = true,
},
["Дворец Могу'шан"] = {
["LFDID"] = 2551,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Вершина Утгард"] = {
["LFDID"] = 1020,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Тазавеш: улицы чудес"] = {
["LFDID"] = 2329,
["Expansion"] = 8,
["Raid"] = false,
["RecLevel"] = 60,
["Show"] = "saved",
},
["Кровавые катакомбы"] = {
["LFDID"] = 2117,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Чаща Темного Сердца"] = {
["LFDID"] = 2277,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье \"Времени Сумерек\" (героич.)"] = {
["LFDID"] = 434,
["Expansion"] = 3,
["Show"] = "saved",
["RecLevel"] = 35,
["Random"] = true,
["Raid"] = false,
},
["Рубиновое святилище"] = {
["LFDID"] = 294,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Та Сторона"] = {
["LFDID"] = 2118,
["Expansion"] = 8,
["RecLevel"] = 50,
["Raid"] = false,
["Show"] = "saved",
},
["Всадник без головы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 285,
},
["Королевская химическая компания"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 1,
["Raid"] = false,
["Holiday"] = true,
["LFDID"] = 288,
},
["Воспоминания Азерот: Cataclysm"] = {
["LFDID"] = 2018,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = true,
["RecLevel"] = 30,
},
["Литейная клана Черной горы"] = {
["LFDID"] = 900,
["Expansion"] = 5,
["RecLevel"] = 40,
["Raid"] = true,
["Show"] = "saved",
},
["Каменные Недра"] = {
["LFDID"] = 1148,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье Burning Crusade"] = {
["LFDID"] = 259,
["Expansion"] = 1,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Гробница Саргераса"] = {
["LFDID"] = 1527,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Испытание чемпиона"] = {
["LFDID"] = 249,
["Expansion"] = 2,
["RecLevel"] = 26,
["Raid"] = false,
["Show"] = "saved",
},
["Базрикрон"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2506,
["RecLevel"] = 70,
["Raid"] = true,
},
["Ана-Муз"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1790,
["RecLevel"] = 45,
["Raid"] = true,
},
["Цитадель Ночи"] = {
["LFDID"] = 1353,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = true,
["Show"] = "saved",
},
["Возвращение в Каражан (нижняя часть)"] = {
["LFDID"] = 1475,
["Expansion"] = 6,
["Raid"] = false,
["RecLevel"] = 45,
["Show"] = "saved",
},
["Градовый голем"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2197,
["RecLevel"] = 50,
["Raid"] = true,
},
["Мертвые копи"] = {
["LFDID"] = 2636,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Драгон Зиморожденный"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1789,
["RecLevel"] = 45,
["Raid"] = true,
},
["Нитхегг"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1749,
["RecLevel"] = 45,
["Raid"] = true,
},
["Мародон - Оскверненный грот"] = {
["LFDID"] = 272,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 10,
["Show"] = "saved",
},
["Джи'арак"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2141,
["RecLevel"] = 50,
["Raid"] = true,
},
["Святилище Господства"] = {
["LFDID"] = 2228,
["Expansion"] = 8,
["RecLevel"] = 60,
["Raid"] = true,
["Show"] = "saved",
},
["Вершина Смерча"] = {
["LFDID"] = 1147,
["Expansion"] = 3,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Четыре небожителя"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 857,
["RecLevel"] = 35,
["Raid"] = true,
},
["Галеон"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 725,
["RecLevel"] = 35,
["Raid"] = true,
},
["Госпожа Фолнуна"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2010,
["RecLevel"] = 45,
["Raid"] = true,
},
["Властитель преисподней Веролом"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 2015,
["RecLevel"] = 45,
["Raid"] = true,
},
["Струнраан"] = {
["Show"] = "saved",
["Expansion"] = 9,
["WorldBoss"] = 2515,
["RecLevel"] = 70,
["Raid"] = true,
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
["LFDID"] = 2814,
["Expansion"] = 7,
["Show"] = "saved",
["Raid"] = false,
["Бимладен - Ревущий фьорд"] = {
[23] = {
["Expires"] = 0,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:1594:23:0|h[ЗОЛОТАЯ ЖИЛА!!!]|h|r",
["ID"] = 506549080,
["Locked"] = false,
},
},
["RecLevel"] = 10,
},
["Бруталл"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1883,
["RecLevel"] = 45,
["Raid"] = true,
},
["Механар"] = {
["LFDID"] = 192,
["Expansion"] = 1,
["RecLevel"] = 21,
["Raid"] = false,
["Show"] = "saved",
},
["Обсидиановое святилище"] = {
["LFDID"] = 238,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Великая императрица Шек'зара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2378,
["RecLevel"] = 50,
["Raid"] = true,
},
["Случайное подземелье Mists of Pandaria"] = {
["LFDID"] = 463,
["Expansion"] = 4,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Приорат Священного Пламени"] = {
["LFDID"] = 2810,
["Expansion"] = 10,
["RecLevel"] = 1,
["Raid"] = false,
["Show"] = "never",
},
["Храм Сетралисс"] = {
["LFDID"] = 1695,
["Expansion"] = 7,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Глубины Черной горы"] = {
["Show"] = "saved",
["Expansion"] = 0,
["RecLevel"] = 80,
["Raid"] = true,
["Holiday"] = true,
["LFDID"] = 2754,
},
["Железные доки"] = {
["LFDID"] = 1974,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Залы Алого ордена"] = {
["LFDID"] = 2553,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Стратхольм - Главные врата"] = {
["LFDID"] = 40,
["Expansion"] = 0,
["Raid"] = false,
["RecLevel"] = 16,
["Show"] = "saved",
},
["Случайное подземелье Warlords of Draenor"] = {
["LFDID"] = 788,
["Expansion"] = 5,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Ордос"] = {
["Show"] = "saved",
["Expansion"] = 4,
["WorldBoss"] = 861,
["RecLevel"] = 35,
["Raid"] = true,
},
["Вестник войны Йенаж"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2198,
["RecLevel"] = 50,
["Raid"] = true,
},
["Гнев Тюремщика"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9006,
["RecLevel"] = 60,
["Raid"] = true,
},
["Зул'Фаррак"] = {
["LFDID"] = 2640,
["Expansion"] = 0,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Монастырь Шадо-Пан"] = {
["LFDID"] = 2545,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное героическое подземелье (1-й сезон The War Within)"] = {
["LFDID"] = 2723,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Random"] = true,
["Raid"] = false,
},
["Случайное подземелье Lich King"] = {
["LFDID"] = 261,
["Expansion"] = 2,
["Show"] = "saved",
["RecLevel"] = 10,
["Random"] = true,
["Raid"] = false,
},
["Обломок"] = {
["Show"] = "saved",
["Expansion"] = 6,
["WorldBoss"] = 1795,
["RecLevel"] = 45,
["Raid"] = true,
},
["Небесный Путь"] = {
["LFDID"] = 1977,
["Expansion"] = 5,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Освобождение Нижней Шахты"] = {
["LFDID"] = 2893,
["Expansion"] = 10,
["Show"] = "saved",
["RecLevel"] = 80,
["Бимладен - Ревущий фьорд"] = {
[14] = {
["Expires"] = 1748404803,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2769:14:15|h[Освобождение Нижней Шахты]|h|r",
["ID"] = 1177829216,
["Locked"] = true,
},
[17] = {
["Expires"] = 1748404803,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2769:17:128|h[Освобождение Нижней Шахты]|h|r",
["ID"] = 2534763085,
["Locked"] = true,
},
[15] = {
["Expires"] = 1748404803,
["Extended"] = false,
["Link"] = "|cffff8000|Hinstancelock:Player-1615-0B536A51:2769:15:15|h[Освобождение Нижней Шахты]|h|r",
["ID"] = 461442748,
["Locked"] = true,
},
},
["Raid"] = true,
},
["Случайное подземелье Battle For Azeroth (героич.)"] = {
["LFDID"] = 1671,
["Expansion"] = 7,
["Show"] = "saved",
["RecLevel"] = 50,
["Random"] = true,
["Raid"] = false,
},
["Катакомбы Сурамара"] = {
["LFDID"] = 1190,
["Expansion"] = 6,
["RecLevel"] = 45,
["Raid"] = false,
["Show"] = "saved",
},
["Случайное подземелье в героическом режиме (Dragonflight)"] = {
["LFDID"] = 2351,
["Expansion"] = 9,
["Show"] = "saved",
["RecLevel"] = 70,
["Random"] = true,
["Raid"] = false,
},
["Осада храма Нюцзао"] = {
["LFDID"] = 2547,
["Expansion"] = 4,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Логово Нелтариона"] = {
["LFDID"] = 2279,
["Expansion"] = 6,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Векемара"] = {
["Show"] = "saved",
["Expansion"] = 7,
["WorldBoss"] = 2363,
["RecLevel"] = 50,
["Raid"] = true,
},
["Орта"] = {
["Show"] = "saved",
["Expansion"] = 10,
["WorldBoss"] = 2625,
["RecLevel"] = 80,
["Raid"] = true,
},
["Огненные Недра"] = {
["LFDID"] = 48,
["Expansion"] = 0,
["Raid"] = true,
["RecLevel"] = 30,
["Show"] = "saved",
},
["Гробницы маны"] = {
["LFDID"] = 1013,
["Expansion"] = 1,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["Гундрак"] = {
["LFDID"] = 1017,
["Expansion"] = 2,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
["\"Валинор\", Светоч Эпох"] = {
["Show"] = "saved",
["Expansion"] = 8,
["WorldBoss"] = 9008,
["RecLevel"] = 60,
["Raid"] = true,
},
["Сумеречный бастион"] = {
["LFDID"] = 316,
["Expansion"] = 3,
["RecLevel"] = 35,
["Raid"] = true,
["Show"] = "saved",
},
["Наксрамас"] = {
["LFDID"] = 227,
["Expansion"] = 2,
["RecLevel"] = 30,
["Raid"] = true,
["Show"] = "saved",
},
["Нелтарий"] = {
["LFDID"] = 2440,
["Expansion"] = 9,
["RecLevel"] = 10,
["Raid"] = false,
["Show"] = "saved",
},
},
["histGeneration"] = 2855,
["Warfront"] = {
{
["contributing"] = false,
["restTime"] = 1748736549,
["captureSide"] = "Alliance",
},
{
["contributing"] = true,
["captureSide"] = "Horde",
},
},
["MinimapIcon"] = {
["showInCompartment"] = true,
["hide"] = false,
},
["Tooltip"] = {
["CurrencySortName"] = false,
["Emissary6"] = false,
["TrackBonus"] = true,
["TrackParagon"] = false,
["Currency3220"] = true,
["Currency3008"] = true,
["CombineWorldBosses"] = false,
["HistoryText"] = false,
["NewFirst"] = true,
["Currency2807"] = false,
["Currency3090"] = true,
["Currency2806"] = false,
["ShowRandom"] = false,
["Currency3010"] = false,
["Currency2917"] = true,
["TimewornMythicKey"] = true,
["Currency3110"] = true,
["TrackDeserter"] = true,
["Currency2812"] = false,
["Currency2915"] = false,
["Currency2003"] = false,
["Currency2778"] = false,
["Currency3116"] = true,
["ConnectedRealms"] = "group",
["Currency3023"] = true,
["Currency3132"] = true,
["ReverseInstances"] = false,
["Currency3216"] = true,
["CurrencyMax"] = false,
["Currency2245"] = false,
["Currency2800"] = false,
["ReportResets"] = false,
["ServerSort"] = true,
["Currency2809"] = false,
["CategorySort"] = "EXPANSION",
["ShowSoloCategory"] = false,
["ShowServer"] = false,
["NumberFormat"] = true,
["Warfront1"] = false,
["EmissaryShowCompleted"] = true,
["CombineEmissary"] = false,
["posy"] = 449.8574829101563,
["Emissary7"] = false,
["CombineCalling"] = false,
["Currency3226"] = true,
["CombineLFR"] = true,
["Scale"] = 1,
["CurrencyEarned"] = true,
["Currency3109"] = true,
["Currency2813"] = true,
["CurrencyValueColor"] = true,
["ShowCategories"] = false,
["Currency3028"] = false,
["posx"] = 856.358154296875,
["TrackWeeklyQuests"] = true,
["Currency3089"] = false,
["LimitWarn"] = true,
["Calling"] = false,
["ServerOnly"] = false,
["Currency2914"] = false,
["SelfAlways"] = false,
["TrackDailyQuests"] = true,
["AbbreviateKeystone"] = false,
["MythicKeyBest"] = true,
["Warfront2"] = false,
["Currency3108"] = true,
["Currency3218"] = true,
["KeystoneReportTarget"] = "EXPORT",
["Currency3107"] = true,
["EmissaryFullName"] = true,
["Currency3056"] = false,
["ShowExpired"] = false,
["RaidsFirst"] = true,
["CategorySpaces"] = false,
["Currency2815"] = false,
["SelfFirst"] = true,
["RowHighlight"] = 0.1,
["Currency2916"] = false,
["Currency3100"] = true,
["ShowHoliday"] = false,
["TrackLFG"] = true,
["CallingShowCompleted"] = false,
["AugmentBonus"] = true,
["TrackPlayed"] = true,
["MythicKey"] = true,
["TrackSkills"] = false,
["FitToScreen"] = true,
["ShowHints"] = true,
["Currency2803"] = false,
},
["Indicators"] = {
["R2ClassColor"] = true,
["D2Indicator"] = "BLANK",
["R7Color"] = {
1,
1,
0,
},
["R5Color"] = {
0,
0,
1,
},
["R1Text"] = "KILLED/TOTAL",
["R4Indicator"] = "BLANK",
["R1Color"] = {
0.6,
0.6,
0,
},
["R0Indicator"] = "BLANK",
["R8ClassColor"] = true,
["D2ClassColor"] = true,
["R4ClassColor"] = true,
["R6ClassColor"] = true,
["D2Color"] = {
0,
1,
0,
},
["D1Text"] = "KILLED/TOTAL",
["R5Text"] = "KILLED/TOTALL",
["R7Text"] = "KILLED/TOTALH",
["R1ClassColor"] = true,
["D3Indicator"] = "BLANK",
["R8Color"] = {
1,
0,
0,
},
["D3ClassColor"] = true,
["R6Indicator"] = "BLANK",
["R6Color"] = {
0,
1,
0,
},
["D1Color"] = {
0,
0.6,
0,
},
["R4Color"] = {
1,
0,
0,
},
["R2Text"] = "KILLED/TOTAL",
["R8Text"] = "KILLED/TOTALM",
["R8Indicator"] = "BLANK",
["R0Text"] = "KILLED/TOTAL",
["R0Color"] = {
0.6,
0.6,
0,
},
["R2Color"] = {
0.6,
0,
0,
},
["R6Text"] = "KILLED/TOTAL",
["R3Indicator"] = "BLANK",
["R7ClassColor"] = true,
["R5Indicator"] = "BLANK",
["D1ClassColor"] = true,
["R4Text"] = "KILLED/TOTALH",
["R3Color"] = {
1,
1,
0,
},
["R3ClassColor"] = true,
["R3Text"] = "KILLED/TOTALH",
["R5ClassColor"] = true,
["R1Indicator"] = "BLANK",
["D3Color"] = {
1,
0,
0,
},
["R7Indicator"] = "BLANK",
["D2Text"] = "KILLED/TOTALH",
["D3Text"] = "KILLED/TOTALM",
["R2Indicator"] = "BLANK",
["D1Indicator"] = "BLANK",
["R0ClassColor"] = true,
},
["History"] = {
["Бимладен - Ревущий фьорд:Искроварня:party:23:2854"] = {
["last"] = 1748298268,
["create"] = 1748296120,
["desc"] = "Бимладен: Искроварня - Эпохальный",
},
["Бимладен - Ревущий фьорд:Искроварня:party:8:2854"] = {
["last"] = 1748298356,
["create"] = 1748298268,
["desc"] = "Бимладен: Искроварня - Эпохальный ключ",
},
},
["DBVersion"] = 12,
["QuestDB"] = {
["Daily"] = {
[53885] = -1,
[61075] = -1,
[60762] = -1,
[61079] = -1,
[60646] = -1,
[61103] = -1,
[77165] = 2112,
[58156] = -1,
[77303] = 2112,
[53939] = -1,
[54132] = -1,
[63206] = -1,
[58168] = -1,
[54138] = -1,
[53701] = -1,
[62214] = -1,
[84222] = 2369,
[61088] = -1,
[60775] = -1,
[51982] = -1,
[54137] = -1,
[62234] = -1,
[54134] = -1,
[61104] = -1,
[54136] = -1,
[61765] = -1,
[58151] = -1,
[84286] = 2292,
[58155] = -1,
[53711] = -1,
[54135] = -1,
[84680] = 2369,
[84432] = 2369,
[60622] = -1,
[53883] = -1,
[58167] = -1,
},
["Darkmoon"] = {
["expires"] = 1747000740,
[47767] = -1,
},
["AccountDaily"] = {
[31752] = -1,
[86486] = 2369,
[56042] = -1,
[40753] = -1,
[34774] = -1,
},
["Weekly"] = {
[66937] = -1,
[62452] = -1,
[72175] = -1,
[82491] = -1,
[59019] = -1,
[80671] = -1,
[52951] = -1,
[48911] = -1,
[72719] = -1,
[78915] = -1,
[60249] = -1,
[66364] = -1,
[76169] = -1,
[72720] = -1,
[75307] = -1,
[82493] = 2339,
[57008] = -1,
[66940] = -1,
[56050] = -1,
[70613] = -1,
[78821] = -1,
[75308] = -1,
[82494] = -1,
[76394] = -1,
[60250] = -1,
[81632] = -1,
[83229] = -1,
[79173] = -1,
[66941] = -1,
[70582] = -1,
[70614] = -1,
[72722] = -1,
[70199] = -1,
[82495] = -1,
[80004] = -1,
[66942] = -1,
[81793] = -1,
[83358] = -1,
[70615] = -1,
[72723] = -1,
[70200] = -1,
[82496] = -1,
[60251] = -1,
[57728] = -1,
[70935] = -1,
[66943] = -1,
[81794] = -1,
[83359] = -1,
[70616] = -1,
[72724] = -1,
[70201] = -1,
[70233] = -1,
["expires"] = 1748404799,
[66944] = -1,
[81795] = -1,
[83360] = -1,
[70617] = -1,
[72725] = -1,
[70202] = -1,
[70234] = -1,
[56148] = -1,
[60252] = -1,
[84127] = -1,
[72438] = -1,
[66945] = -1,
[81796] = -1,
[56308] = -1,
[70618] = -1,
[82946] = 2214,
[55350] = -1,
[82499] = -1,
[82531] = -1,
[84128] = -1,
[72407] = -1,
[82659] = -1,
[82787] = -1,
[75665] = -1,
[70587] = -1,
[70619] = -1,
[72727] = -1,
[40787] = -1,
[82500] = -1,
[78444] = -1,
[60253] = -1,
[81574] = -1,
[62441] = -1,
[70620] = -1,
[72728] = -1,
[82501] = -1,
[84130] = -1,
[66884] = -1,
[52956] = -1,
[70557] = -1,
[70589] = -1,
[82502] = -1,
[60254] = -1,
[84131] = -1,
[72410] = -1,
[66949] = -1,
[83333] = 2214,
[83365] = -1,
[72155] = -1,
[78319] = -1,
[82503] = -1,
[84132] = -1,
[53436] = -1,
[66950] = -1,
[70559] = -1,
[83366] = 2339,
[72156] = -1,
[75286] = -1,
[57157] = -1,
[60255] = -1,
[84133] = -1,
[66951] = -1,
[70560] = -1,
[70592] = -1,
[72157] = -1,
[52782] = -1,
[70752] = -1,
[83240] = 2328,
[52958] = -1,
[70561] = -1,
[70593] = -1,
[72158] = -1,
[75288] = -1,
[70753] = -1,
[62284] = -1,
[60256] = -1,
[70530] = -1,
[70562] = -1,
[70594] = -1,
[72159] = -1,
[75289] = -1,
[70211] = -1,
[83529] = -1,
[62287] = -1,
[66890] = -1,
[40168] = -1,
[70531] = -1,
[70563] = -1,
[70595] = -1,
[52957] = -1,
[79346] = -1,
[70723] = -1,
[56648] = -1,
[62285] = -1,
[60257] = -1,
[52954] = -1,
[66891] = -1,
[70558] = -1,
[70532] = -1,
[70564] = -1,
[62445] = -1,
[33334] = -1,
[83531] = -1,
[66900] = -1,
[82778] = -1,
[52944] = -1,
[70533] = -1,
[70565] = -1,
[52948] = -1,
[82516] = -1,
[82414] = -1,
[56649] = -1,
[60242] = -1,
[53435] = -1,
[80562] = -1,
[62288] = -1,
[56650] = -1,
[64522] = -1,
[82511] = -1,
[66953] = -1,
[56969] = -1,
[81649] = -1,
[79158] = -1,
[70567] = -1,
[82512] = -1,
[60243] = -1,
[70568] = -1,
[82449] = -1,
[70569] = -1,
[76733] = -1,
[82482] = -1,
[60244] = -1,
[48912] = -1,
[76600] = -1,
[82706] = 2339,
[66897] = -1,
[70586] = -1,
[82504] = -1,
[83345] = -1,
[82355] = -1,
[78933] = -1,
[70591] = -1,
[82483] = -1,
[78427] = -1,
[75304] = -1,
[70750] = -1,
[86731] = -1,
[82707] = -1,
[80184] = -1,
[56064] = -1,
[79226] = -1,
[70571] = -1,
[66952] = -1,
[66363] = -1,
[75351] = -1,
[82452] = 2339,
[32640] = -1,
[78428] = -1,
[60245] = -1,
[84129] = -1,
[82507] = -1,
[82497] = 2339,
[72726] = -1,
[82508] = -1,
[80185] = -1,
[62286] = -1,
[70540] = -1,
[83347] = 2339,
[66516] = -1,
[33338] = -1,
[45563] = -1,
[82453] = -1,
[82485] = -1,
[82506] = -1,
[78972] = -1,
[83363] = 2339,
[32641] = -1,
[59016] = -1,
[55499] = -1,
[82709] = -1,
[80186] = 2339,
[40173] = -1,
[66938] = -1,
[66517] = -1,
[52952] = -1,
[80189] = -1,
[64710] = -1,
[82486] = -1,
[91205] = 2339,
[60246] = -1,
[55498] = -1,
[83362] = -1,
[82678] = 2367,
[82852] = -1,
[80187] = -1,
[83285] = -1,
[72423] = -1,
[62450] = -1,
[40786] = -1,
[70754] = -1,
[75301] = -1,
[82487] = -1,
[72810] = -1,
[62289] = -1,
[70235] = -1,
[59017] = -1,
[82679] = 2367,
[82711] = -1,
[80188] = -1,
[52949] = -1,
[72427] = -1,
[83364] = -1,
[72172] = -1,
[47148] = -1,
[82488] = -1,
[55121] = -1,
[60247] = -1,
[82492] = -1,
[82509] = -1,
[72428] = -1,
[70572] = -1,
[82712] = -1,
[78656] = -1,
[66935] = -1,
[64541] = -1,
[82505] = -1,
[62449] = -1,
[72173] = -1,
[83530] = -1,
[80672] = -1,
[82489] = -1,
[82510] = -1,
[52953] = -1,
[82498] = -1,
[59018] = -1,
[83532] = -1,
[81691] = -1,
[47523] = 111,
[52950] = -1,
[70545] = -1,
[75309] = -1,
[48910] = -1,
[79216] = -1,
[70203] = -1,
[82458] = -1,
[82490] = -1,
[60248] = -1,
[76997] = -1,
[76122] = -1,
[72686] = -1,
[80670] = 2255,
[82746] = -1,
[84776] = -1,
},
["AccountWeekly"] = {
[80592] = 2255,
[77236] = -1,
[83357] = -1,
[56492] = -1,
["expires"] = 1748404799,
[45539] = -1,
[72721] = -1,
[46292] = -1,
[58458] = -1,
[84370] = 2339,
[54186] = -1,
[72528] = -1,
},
},
["Progress"] = {
["Enable"] = {
["tww-anniversary-restored-coffer-key"] = true,
["tww-spreading-the-light"] = false,
["df-shipment-of-goods"] = false,
["emissary-of-war"] = false,
["df-fighting-is-its-own-reward"] = false,
["the-world-awaits"] = false,
["df-aiding-the-accord"] = false,
["df-trial-of-flood"] = false,
["df-services-requested"] = false,
["great-vault-pvp"] = false,
["timewalking"] = false,
["bfa-lesser-vision"] = false,
["great-vault-world"] = false,
["df-disciple-of-fyrakk"] = false,
["df-a-worthy-ally-dream-wardens"] = false,
["df-grand-hunt"] = false,
["tww-algari-treatise"] = false,
["tww-biergoth-dungeon-quest"] = false,
["df-blooming-dreamseeds"] = false,
["call-to-battle"] = false,
["df-primal-storms-elementals"] = false,
["tww-gearing-up-for-trouble"] = false,
["tww-rollin-down-in-the-deeps"] = false,
["bfa-horrific-vision"] = false,
["sl-patterns-within-patterns"] = false,
["sl-replenish-the-reservoir"] = false,
["tww-radiant-echoes"] = true,
["tww-services-requested"] = false,
["df-a-worthy-ally-loamm-niffen"] = false,
["df-researchers-under-fire"] = false,
["sl-covenant-assault"] = false,
["df-siege-on-dragonbane-keep"] = false,
["tww-archives"] = true,
["bfa-island"] = false,
["tww-brawl-weekly"] = false,
["df-time-rift"] = false,
["df-trial-of-elements"] = false,
["The Severed Threads"] = false,
["tww-siren-isle-weekly"] = true,
["call-to-delves"] = false,
["bfa-nzoth-assault"] = false,
["tww-the-call-of-the-worldsoul"] = false,
["tww-the-theater-trope"] = false,
["df-community-feast"] = false,
["df-dreamsurge"] = false,
["great-vault-raid"] = false,
["tww-special-assignments"] = false,
["tww-pvp-world"] = false,
["df-sparks-of-life"] = false,
["sl-return-lost-souls"] = false,
["df-primal-storms-core"] = false,
["sl-shaping-fate"] = false,
["tww-delves"] = true,
["tww-lesser-keyflame"] = false,
["tww-the-key-to-success"] = false,
["tww-pvp-weekly"] = false,
["df-secured-shipment"] = false,
["df-the-big-dig-traitors-rest"] = false,
["tww-weekly-cache"] = false,
["df-the-superbloom"] = false,
},
["Order"] = {
["tww-anniversary-restored-coffer-key"] = 50,
["tww-spreading-the-light"] = 50,
["df-shipment-of-goods"] = 50,
["emissary-of-war"] = 50,
["df-fighting-is-its-own-reward"] = 50,
["the-world-awaits"] = 50,
["df-aiding-the-accord"] = 50,
["df-trial-of-flood"] = 50,
["df-services-requested"] = 50,
["great-vault-pvp"] = 50,
["timewalking"] = 50,
["bfa-lesser-vision"] = 50,
["great-vault-world"] = 50,
["df-disciple-of-fyrakk"] = 50,
["df-a-worthy-ally-dream-wardens"] = 50,
["df-grand-hunt"] = 50,
["tww-algari-treatise"] = 50,
["tww-biergoth-dungeon-quest"] = 50,
["df-blooming-dreamseeds"] = 50,
["call-to-battle"] = 50,
["df-primal-storms-elementals"] = 50,
["tww-gearing-up-for-trouble"] = 50,
["tww-rollin-down-in-the-deeps"] = 50,
["bfa-horrific-vision"] = 50,
["sl-patterns-within-patterns"] = 50,
["sl-replenish-the-reservoir"] = 50,
["tww-radiant-echoes"] = 50,
["tww-services-requested"] = 50,
["df-a-worthy-ally-loamm-niffen"] = 50,
["df-researchers-under-fire"] = 50,
["sl-covenant-assault"] = 50,
["df-siege-on-dragonbane-keep"] = 50,
["tww-archives"] = 50,
["bfa-island"] = 50,
["tww-brawl-weekly"] = 50,
["df-time-rift"] = 50,
["df-trial-of-elements"] = 50,
["The Severed Threads"] = 50,
["tww-siren-isle-weekly"] = 50,
["call-to-delves"] = 50,
["bfa-nzoth-assault"] = 50,
["tww-the-call-of-the-worldsoul"] = 50,
["tww-the-theater-trope"] = 50,
["df-community-feast"] = 50,
["df-dreamsurge"] = 50,
["great-vault-raid"] = 50,
["tww-special-assignments"] = 50,
["tww-pvp-world"] = 50,
["df-sparks-of-life"] = 50,
["sl-return-lost-souls"] = 50,
["df-primal-storms-core"] = 50,
["sl-shaping-fate"] = 50,
["tww-delves"] = 50,
["tww-lesser-keyflame"] = 50,
["tww-the-key-to-success"] = 50,
["tww-pvp-weekly"] = 50,
["df-secured-shipment"] = 50,
["df-the-big-dig-traitors-rest"] = 50,
["tww-weekly-cache"] = 50,
["df-the-superbloom"] = 50,
},
["User"] = {
},
},
["DailyResetTime"] = 1748318399,
["Quests"] = {
[84370] = {
["Expires"] = 1748404799,
["Zone"] = {
["mapType"] = 3,
["mapID"] = 2339,
["name"] = "Дорногал",
["parentMapID"] = 2248,
["flags"] = 1048580,
},
["Title"] = "Ключ к успеху",
["Link"] = "|cffffff00|Hquest:84370:2838|h[Ключ к успеху]|h|r",
},
},
["RealmMap"] = {
},
}
