
LoggerHeadDB = {
["profileKeys"] = {
["Beamladen - Twisting Nether"] = "Default",
["Пва - Свежеватель Душ"] = "Default",
["Сэйвмэн - Свежеватель Душ"] = "Default",
["Мальдика - Свежеватель Душ"] = "Default",
["Вантачмэн - Ревущий фьорд"] = "Default",
["Дракобес - Свежеватель Душ"] = "Default",
["Бимладен - Ревущий фьорд"] = "Default",
["Вольтчара - Свежеватель Душ"] = "Default",
},
["profiles"] = {
["Default"] = {
["log"] = {
["party"] = {
["Каменный Свод"] = {
false,
false,
[8] = true,
[23] = false,
},
["Операция \"Мехагон\""] = {
[23] = false,
[8] = false,
},
["ЗОЛОТАЯ ЖИЛА!!!"] = {
false,
[23] = false,
[8] = false,
},
["Туманы Тирна Скитта"] = {
false,
false,
[23] = false,
[8] = true,
},
["\"Сияющий Рассвет\""] = {
false,
false,
[8] = true,
[23] = false,
},
["Искроварня"] = {
[23] = false,
[8] = false,
},
["Операция: шлюз"] = {
[23] = false,
[8] = false,
},
["Город Нитей"] = {
false,
false,
[8] = true,
[23] = false,
},
["Ара-Кара, Город Отголосков"] = {
false,
false,
[23] = false,
[8] = true,
},
["Расселина Темного Пламени"] = {
[23] = false,
[8] = false,
},
["Смертельная тризна"] = {
false,
false,
[23] = false,
[8] = true,
},
["Театр Боли"] = {
[23] = false,
[8] = false,
},
["Грим Батол"] = {
false,
false,
[23] = false,
[8] = true,
},
["Гнездовье"] = {
false,
false,
[8] = false,
[23] = false,
},
["Приорат Священного Пламени"] = {
[23] = false,
[8] = false,
},
["Осада Боралуса"] = {
false,
[8] = true,
[23] = false,
},
},
["scenario"] = {
["Шахты Землескребов"] = {
[208] = false,
},
["Грибные гадости"] = {
[208] = false,
},
},
["raid"] = {
["Неруб'арский дворец"] = {
[14] = false,
[16] = false,
[15] = false,
[17] = false,
},
["Освобождение Нижней Шахты"] = {
[14] = false,
[17] = false,
[15] = false,
},
},
},
["version"] = 3,
["minimap"] = {
["hide"] = true,
},
["chat"] = true,
},
},
}
