
VWQL = {
["Бимладен-Ревущийфьорд"] = {
["VERSION"] = 116,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[81818] = true,
[82519] = true,
[58437] = true,
[82653] = true,
[59642] = true,
[66419] = true,
[72030] = true,
[61540] = true,
[70652] = true,
[80295] = true,
[76586] = true,
[69928] = true,
[70625] = true,
[81465] = true,
[61816] = true,
[83048] = true,
[82237] = true,
[70984] = true,
[82206] = true,
[83537] = true,
[82041] = true,
[61539] = true,
[81675] = true,
[75257] = true,
[81813] = true,
[82585] = true,
[83538] = true,
[58705] = true,
[70442] = true,
[58221] = true,
[81799] = true,
[74501] = true,
[81620] = true,
},
["Filter"] = 63,
},
["Сорчистино-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Мальдика-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 115,
},
["Вольтчара-СвежевательДуш"] = {
["FilterType"] = {
["pet"] = true,
},
["Filter"] = 63,
["Quests"] = {
[76586] = true,
},
["VERSION"] = 115,
},
["DisableIconsGeneralMap947"] = true,
["DisableLFG_Popup"] = true,
["Sort"] = 5,
["VERSION"] = 116,
["Алианкано-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["Сэйвмэн-СвежевательДуш"] = {
["Filter"] = 63,
["VERSION"] = 115,
["Quests"] = {
[76586] = true,
},
["FilterType"] = {
["pet"] = true,
},
},
["Дракобес-СвежевательДуш"] = {
["VERSION"] = 115,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Топмэн-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["SortPrio"] = {
},
["Ignore"] = {
},
["Вантачмэн-Ревущийфьорд"] = {
["Filter"] = 63,
["FilterType"] = {
["pet"] = true,
},
["Quests"] = {
[69927] = true,
[50497] = true,
[74835] = true,
[82292] = true,
[70068] = true,
[73146] = true,
[71180] = true,
[54896] = true,
[55466] = true,
[71140] = true,
[58743] = true,
[75280] = true,
[66551] = true,
[58747] = true,
},
["VERSION"] = 115,
},
["Пва-СвежевательДуш"] = {
["VERSION"] = 114,
["FilterType"] = {
},
["Quests"] = {
},
["Filter"] = 63,
},
["Beamladen-TwistingNether"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 114,
},
["AzeriteFormat"] = 20,
["Прециза-СвежевательДуш"] = {
["Filter"] = 63,
["FilterType"] = {
},
["Quests"] = {
},
["VERSION"] = 112,
},
["HideLegion"] = true,
}
