
_detalhes_database = {
["savedbuffs"] = {
},
["mythic_dungeon_id"] = 0,
["tabela_historico"] = {
["tabelas"] = {
},
},
["ocd_tracker"] = {
["enabled"] = false,
["current_cooldowns"] = {
},
["lines_per_column"] = 12,
["group_frames"] = true,
["width"] = 120,
["frames"] = {
["defensive-raid"] = {
},
["main"] = {
},
["ofensive"] = {
},
["defensive-target"] = {
},
["utility"] = {
},
["defensive-personal"] = {
},
},
["show_options"] = false,
["ignored_cooldowns"] = {
},
["cooldowns"] = {
},
["height"] = 18,
["own_frame"] = {
["defensive-raid"] = false,
["ofensive"] = false,
["defensive-target"] = false,
["utility"] = false,
["defensive-personal"] = false,
},
["framme_locked"] = false,
["show_conditions"] = {
["only_inside_instance"] = true,
["only_in_group"] = true,
},
["show_title"] = true,
["filters"] = {
["itemutil"] = false,
["itempower"] = false,
["defensive-target"] = false,
["itemheal"] = false,
["defensive-personal"] = false,
["defensive-raid"] = false,
["ofensive"] = true,
["crowdcontrol"] = false,
["utility"] = false,
},
},
["last_version"] = "11.0.2 13001",
["player_stats"] = {
},
["force_font_outline"] = "",
["tabela_instancias"] = {
},
["coach"] = {
["enabled"] = false,
["welcome_panel_pos"] = {
},
["last_coach_name"] = false,
},
["local_instances_config"] = {
{
["modo"] = 2,
["sub_attribute"] = 1,
["sub_atributo_last"] = {
1,
1,
1,
1,
1,
},
["is_open"] = true,
["isLocked"] = false,
["snap"] = {
},
["segment"] = 0,
["mode"] = 2,
["attribute"] = 1,
["pos"] = {
["normal"] = {
["y"] = -469.571418762207,
["x"] = 792.3815307617188,
["w"] = 310.0000610351563,
["h"] = 157.9999847412109,
},
["solo"] = {
["y"] = 2,
["x"] = 1,
["w"] = 300,
["h"] = 200,
},
},
},
},
["cached_talents"] = {
},
["last_instance_id"] = 0,
["data_harvest_for_charsts"] = {
["players"] = {
{
["name"] = "Damage of Each Individual Player",
["playerOnly"] = true,
["playerKey"] = "total",
["combatObjectContainer"] = 1,
},
},
["totals"] = {
{
["combatObjectSubTableKey"] = 1,
["name"] = "Damage of All Player Combined",
["combatObjectSubTableName"] = "totals",
},
},
},
["announce_interrupts"] = {
["enabled"] = false,
["whisper"] = "",
["channel"] = "SAY",
["custom"] = "",
["next"] = "",
},
["announce_prepots"] = {
["enabled"] = false,
["channel"] = "SELF",
["reverse"] = false,
},
["active_profile"] = "Прециза-Свежеватель Душ",
["mythic_dungeon_currentsaved"] = {
["dungeon_name"] = "",
["started"] = false,
["segment_id"] = 0,
["ej_id"] = 0,
["started_at"] = 0,
["run_id"] = 0,
["level"] = 0,
["dungeon_zone_id"] = 0,
["previous_boss_killed_at"] = 0,
},
["benchmark_db"] = {
["frame"] = {
},
},
["combat_log"] = {
["inverse_deathlog_overalldata"] = false,
["track_hunter_frenzy"] = false,
["merge_gemstones_1007"] = false,
["merge_critical_heals"] = false,
["inverse_deathlog_raid"] = false,
["calc_evoker_damage"] = true,
["evoker_show_realtimedps"] = false,
["inverse_deathlog_mplus"] = false,
},
["data_harvested_for_charts"] = {
},
["mythic_plus_log"] = {
},
["on_death_menu"] = false,
["cached_roles"] = {
},
["nick_tag_cache"] = {
["nextreset"] = 1727093754,
["last_version"] = 16,
},
["announce_firsthit"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["ignore_nicktag"] = false,
["plugin_database"] = {
["DETAILS_PLUGIN_TINY_THREAT"] = {
["enabled"] = true,
["animate"] = false,
["hide_pull_bar"] = false,
["author"] = "Terciob",
["playercolor"] = {
1,
1,
1,
},
["usefocus"] = false,
["updatespeed"] = 1,
["disable_gouge"] = false,
["showamount"] = false,
["useplayercolor"] = false,
["absolute_mode"] = false,
["playSound"] = false,
["playSoundFile"] = "Details Threat Warning Volume 3",
["useclasscolors"] = false,
},
["DETAILS_PLUGIN_COMPARETWO_WINDOW"] = {
["enabled"] = true,
["author"] = "Terciob",
["max_compares"] = 4,
["compare_type"] = 1,
},
["DETAILS_PLUGIN_DEATH_GRAPHICS"] = {
["enabled"] = true,
["InstalledAt"] = 1725797761,
["showing_type"] = 4,
["captures"] = {
false,
true,
true,
true,
},
["max_segments_for_current"] = 2,
["last_player"] = false,
["show_icon"] = 1,
["max_deaths_for_current"] = 20,
["last_encounter_hash"] = false,
["last_segment"] = false,
["timeline_cutoff_time"] = 3,
["max_deaths_for_timeline"] = 5,
["endurance_threshold"] = 3,
["timeline_cutoff_delete_time"] = 3,
["last_boss"] = false,
["author"] = "Details! Team",
},
["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
["enabled"] = true,
["encounter_timers_bw"] = {
},
["max_emote_segments"] = 3,
["last_section_selected"] = "main",
["author"] = "Terciob",
["window_scale"] = 1,
["hide_on_combat"] = false,
["show_icon"] = 5,
["opened"] = 0,
["encounter_timers_dbm"] = {
},
},
["DETAILS_PLUGIN_RAIDCHECK"] = {
["enabled"] = true,
["food_tier1"] = true,
["mythic_1_4"] = true,
["food_tier2"] = true,
["author"] = "Terciob",
["use_report_panel"] = true,
["pre_pot_healers"] = false,
["pre_pot_tanks"] = false,
["food_tier3"] = true,
},
["DETAILS_PLUGIN_VANGUARD"] = {
["tank_block_size_height"] = 50,
["show_power_bar"] = false,
["first_run"] = false,
["aura_timer_text_size"] = 14,
["tank_block_castbar_size_height"] = 16,
["show_health_bar"] = true,
["aura_offset_y"] = 0,
["enabled"] = true,
["show_cast_bar"] = false,
["author"] = "Terciob",
["tank_block_size"] = 150,
["bar_height"] = 24,
["tank_block_texture"] = "Details Serenity",
["tank_block_height"] = 40,
["tank_block_color"] = {
0.074509,
0.035294,
0.035294,
0.832845,
},
["tank_block_powerbar_size_height"] = 10,
["show_inc_bars"] = true,
},
["DETAILS_PLUGIN_STREAM_OVERLAY"] = {
["use_square_mode"] = false,
["is_first_run"] = false,
["grow_direction"] = "right",
["arrow_color"] = {
1,
1,
1,
0.5,
},
["scale"] = 1,
["main_frame_size"] = {
309,
100,
},
["minimap"] = {
["minimapPos"] = 160,
["radius"] = 160,
["hide"] = true,
},
["point"] = "BOTTOMRIGHT",
["arrow_anchor_x"] = 0,
["y"] = 1.001531362533569,
["row_texture"] = "Melli",
["square_grow_direction"] = "right",
["font_color"] = {
1,
1,
1,
1,
},
["row_height"] = 20,
["square_amount"] = 5,
["enabled"] = true,
["arrow_size"] = 14,
["use_spark"] = false,
["row_spacement"] = 20,
["main_frame_color"] = {
0,
0,
0,
0,
},
["main_frame_strata"] = "LOW",
["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
["row_color"] = {
0.1019607931375504,
0.1019607931375504,
0.1019607931375504,
0.4000000357627869,
},
["per_second"] = {
["enabled"] = false,
["point"] = "CENTER",
["scale"] = 1,
["font_shadow"] = true,
["y"] = 0.000274658203125,
["x"] = -6.103515625e-05,
["update_speed"] = 0.05,
["size"] = 32,
["attribute_type"] = 2,
},
["x"] = -248.6214599609375,
["font_face"] = "ITCAvantGardeGothicDemi",
["square_size"] = 32,
["arrow_anchor_y"] = 0,
["font_size"] = 11,
["main_frame_locked"] = true,
["author"] = "Terciob",
},
},
["last_instance_time"] = 0,
["combat_id"] = 0,
["savedStyles"] = {
},
["last_day"] = "08",
["character_data"] = {
["logons"] = 1,
},
["announce_deaths"] = {
["enabled"] = false,
["last_hits"] = 1,
["only_first"] = 5,
["where"] = 1,
},
["tabela_overall"] = {
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
{
["tipo"] = 3,
["_ActorTable"] = {
},
},
{
["tipo"] = 7,
["_ActorTable"] = {
},
},
{
["tipo"] = 9,
["_ActorTable"] = {
},
},
{
["tipo"] = 2,
["_ActorTable"] = {
},
},
["raid_roster"] = {
},
["tempo_start"] = 440842.382,
["last_events_tables"] = {
},
["alternate_power"] = {
},
["totals_grupo"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
},
["bossTimers"] = {
},
["trinketProcs"] = {
},
["playerTalents"] = {
},
["totals"] = {
0,
0,
{
0,
[0] = 0,
["alternatepower"] = 0,
[3] = 0,
[6] = 0,
},
{
["buff_uptime"] = 0,
["ress"] = 0,
["debuff_uptime"] = 0,
["cooldowns_defensive"] = 0,
["interrupt"] = 0,
["dispell"] = 0,
["cc_break"] = 0,
["dead"] = 0,
},
["frags_total"] = 0,
["voidzone_damage"] = 0,
},
["player_last_events"] = {
},
["frags_need_refresh"] = false,
["aura_timeline"] = {
},
["data_inicio"] = 0,
["amountCasts"] = {
},
["mapId"] = 1,
["cleu_events"] = {
["n"] = 1,
},
["zoneName"] = "Калимдор",
["boss_hp"] = 1,
["is_challenge"] = false,
["frags"] = {
},
["data_fim"] = 0,
["cleu_timeline"] = {
},
["spells_cast_timeline"] = {
},
["PhaseData"] = {
{
1,
1,
},
["heal_section"] = {
},
["heal"] = {
},
["damage_section"] = {
},
["damage"] = {
},
},
["start_time"] = 0,
["TimeData"] = {
},
["combat_counter"] = 1,
},
["last_realversion"] = 160,
["combat_counter"] = 2,
["SoloTablesSaved"] = {
["Mode"] = 1,
},
["announce_cooldowns"] = {
["enabled"] = false,
["ignored_cooldowns"] = {
},
["custom"] = "",
["channel"] = "RAID",
},
["rank_window"] = {
["last_difficulty"] = 15,
["last_raid"] = "",
},
["announce_damagerecord"] = {
["enabled"] = true,
["channel"] = "SELF",
},
["cached_specs"] = {
["Player-1604-0AA7EEE7"] = 255,
},
}
