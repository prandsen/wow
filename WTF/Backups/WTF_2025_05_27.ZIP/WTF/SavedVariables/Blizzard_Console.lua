
Blizzard_Console_SavedVars = {
["version"] = 3,
["height"] = 299.9999694824219,
["messageHistory"] = {
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/25/2025 (Sun) 12:37",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 0h 52m 50s",
0,
},
{
"Level: 18d 6h 7m 4s",
0,
},
{
"Weather changed to 1, intensity 0.175630\n",
0,
},
{
"Weather changed to 2, intensity 0.282831\n",
0,
},
{
"Weather changed to 1, intensity 0.153140\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 1h 2m 57s",
0,
},
{
"Level: 18d 6h 17m 11s",
0,
},
{
"Weather changed to 1, intensity 0.163145\n",
0,
},
{
"Weather changed to 2, intensity 0.273399\n",
0,
},
{
"Weather changed to 1, intensity 0.161447\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2461.9, -2314.38, 1043.41)",
0,
},
{
"[Airlock] Preload initiated for map 2601",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2601 from previous map 2552 with translation: (0.340088, 0.820068, 1131.33)\n    Location : (2255.79, -2276.72, 564.017)\n    Location in previous map : (2255.45, -2277.54, -567.316)",
0,
},
{
"[Airlock] Swapping to preloaded map 2601 and unloading map 2552. (Map Table Size 960 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2601",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2256.26, -2270.97, -569.649)",
0,
},
{
"[Airlock] Preload initiated for map 2552",
0,
},
{
"[Airlock] Cancel Preload of MapID:2552",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2651, level 12, time 2682174",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Completed challenge mode mapID 2293, level 11, time 1589072",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 3h 1m 52s",
0,
},
{
"Level: 18d 8h 16m 6s",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 12, time 1534330",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 1594, level 12, time 1977277",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 4h 24m 26s",
0,
},
{
"Level: 18d 9h 38m 40s",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2661, level 12, time 2030728",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2649, level 12, time 1523542",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2648, level 12, time 1334471",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Completed challenge mode mapID 2648, level 12, time 1334471",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/25/2025 (Sun) 18:05",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 6h 21m 6s",
0,
},
{
"Level: 18d 11h 35m 20s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"NetClient::HandleDisconnect()\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/25/2025 (Sun) 20:18",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 6h 51m 17s",
0,
},
{
"Level: 18d 12h 5m 31s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 7h 32m 28s",
0,
},
{
"Level: 18d 12h 46m 42s",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2651, level 12, time 1318427",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 8h 46m 21s",
0,
},
{
"Level: 18d 14h 0m 35s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2649, level 10, time 2153226",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"GameTimeSync: skipping forwards 2 game minutes, (current = 5/25/2025 (Sun) 23:38, newtime = 5/25/2025 (Sun) 23:40)",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 10h 15m 56s",
0,
},
{
"Level: 18d 15h 30m 10s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"Got new connection 2",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/25/2025 (Sun) 23:47",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 10h 17m 25s",
0,
},
{
"Level: 18d 15h 31m 39s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 0.916667",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/25/2025 (Sun) 23:56",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 10h 18m 22s",
0,
},
{
"Level: 18d 15h 32m 36s",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Render scale changed to 0.75",
0,
},
{
"Render scale changed to 1",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Sorting particles normally.",
0,
},
{
"Multithreaded rendering enabled.",
0,
},
{
"Multithreaded BeginDraw enabled.",
0,
},
{
"Multithread shadows changed to 1.",
0,
},
{
"Multithreaded prepass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded opaque pass enabled.",
0,
},
{
"Multithreaded alpha M2 pass enabled.",
0,
},
{
"Multithreaded opaque WMO pass enabled.",
0,
},
{
"Multithreaded terrain pass enabled.",
0,
},
{
"Multithreaded volumetric fog enabled.",
0,
},
{
"Multithreaded Refraction Pass enabled.",
0,
},
{
"Multithreaded miscellaneous passes enabled.",
0,
},
{
"Multithreaded decal passes disabled.",
0,
},
{
"Multithreaded outline passes enabled.",
0,
},
{
"Multithreaded lightshaft passes enabled.",
0,
},
{
"Multithreaded alpha pass enabled.",
0,
},
{
"Multithreaded daynight update enabled.",
0,
},
{
"Water detail changed to 0",
0,
},
{
"Ripple detail changed to 0",
0,
},
{
"Reflection mode changed to 0",
0,
},
{
"Reflection downscale changed to 0",
0,
},
{
"Sunshafts quality changed to 0",
0,
},
{
"Refraction mode changed to 0",
0,
},
{
"Volume fog disabled.",
0,
},
{
"Particulate volumes disabled.",
0,
},
{
"Projected textures enabled.",
0,
},
{
"Spell Clutter intensity value set",
0,
},
{
"Shadow mode changed to 0 - Blob shadows",
0,
},
{
"Shadow texture size changed to 1024.",
0,
},
{
"Soft shadows changed to 0.",
0,
},
{
"Shadow cascade blending changed to 0",
0,
},
{
"Number of shadow cascades changed to 1",
0,
},
{
"Shadow RT mode changed to 0 (Disabled)",
0,
},
{
"maxLightCount must be in range 0 to 32.",
0,
},
{
"CVar 'maxLightCount' failed validation for its initial value.",
0,
},
{
"Clustered shading disabled.",
0,
},
{
"Not forcing clustered shading.",
0,
},
{
"SSAO mode set to 0",
0,
},
{
"SSAO type set to 0",
0,
},
{
"Depth Based Opacity Disabled",
0,
},
{
"SkyCloudLOD set to 0",
0,
},
{
"Texture filtering mode updated.",
0,
},
{
"Terrain mip level changed to 0.",
0,
},
{
"Outline mode changed to 2",
0,
},
{
"Physics interaction level changed to 0",
0,
},
{
"Render scale changed to 1",
0,
},
{
"Resample quality changed to 3",
0,
},
{
"MSAA set to 4 color samples, 4 coverage samples",
0,
},
{
"MSAA for alpha-test disabled.",
0,
},
{
"VALAR mode changed to 0",
0,
},
{
"lodObjectSizeScale cannot be changed.",
0,
},
{
"Volume fog enabled.",
0,
},
{
"dynamicLod enabled",
0,
},
{
"World preload object sort enabled.",
0,
},
{
"World load object sort enabled.",
0,
},
{
"World preload non critical enabled.",
0,
},
{
"World preload high res textures enabled.",
0,
},
{
"FFX: Color Blind Test Mode Disabled",
0,
},
{
"Error display disabled",
0,
},
{
"Error display shown",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Displaying errors through fatal errors",
0,
},
{
"Now filtering: all messages",
0,
},
{
"CVar 'Sound_AmbienceHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_AllyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_EnemyPlayerHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"CVar 'Sound_NPCHighpassDSPCutoff' failed validation for its initial value.",
0,
},
{
"ChromaEffects disabled",
0,
},
{
"NetClient::HandleConnect()\n",
0,
},
{
"[WowEntitlements] [BNetAccount-0-00001A5700A8] [WowAccount-0-000004F88FAF] Initialized with 21 entitlements.",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/26/2025 (Mon) 18:30",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 10h 24m 30s",
0,
},
{
"Level: 18d 15h 38m 44s",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 2, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.159806\n",
0,
},
{
"Time set to 5/26/2025 (Mon) 20:09",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 11h 47m 13s",
0,
},
{
"Level: 18d 17h 1m 27s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/26/2025 (Mon) 20:25",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 11h 47m 32s",
0,
},
{
"Level: 18d 17h 1m 46s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Attempted to register existing command: SetDifficulty",
0,
},
{
"Got new connection 3",
0,
},
{
"Proficiency in item class 2 set to 0x0000000040",
0,
},
{
"Proficiency in item class 2 set to 0x0000008040",
0,
},
{
"Proficiency in item class 4 set to 0x0000000021",
0,
},
{
"Proficiency in item class 2 set to 0x000000c040",
0,
},
{
"Proficiency in item class 2 set to 0x000000c440",
0,
},
{
"Proficiency in item class 4 set to 0x0000000025",
0,
},
{
"Proficiency in item class 2 set to 0x000000c460",
0,
},
{
"Proficiency in item class 2 set to 0x000000e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e460",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Proficiency in item class 2 set to 0x000010e470",
0,
},
{
"Proficiency in item class 4 set to 0x0000000027",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time set to 5/26/2025 (Mon) 20:42",
0,
},
{
"Gamespeed set from 0.017 to 0.017",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 11h 50m 41s",
0,
},
{
"Level: 18d 17h 4m 55s",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 12h 26m 24s",
0,
},
{
"Level: 18d 17h 40m 38s",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
{
"Test CVar test_cameraDynamicPitch has been set to 1 (default 0.000000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPad has been set to 0.4 (default 0.400000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadDownScale has been set to 0.3 (default 0.250000)",
0,
},
{
"Test CVar test_cameraDynamicPitchBaseFovPadFlying has been set to 0.7 (default 0.750000)",
0,
},
{
"Time played:",
0,
},
{
"Total: 338d 12h 55m 46s",
0,
},
{
"Level: 18d 18h 10m 0s",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 1.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 0.600000\n",
0,
},
{
"Weather changed to 5, intensity 0.600000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2097, level 9, time 1287037",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Weather changed to 5, intensity 1.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2773, level 11, time 1517382",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2552, Current MapID:2601, PreviousTransitionID:-1, Position (2389.27, -2215.5, -633.733)",
0,
},
{
"[Airlock] Preload initiated for map 2552",
0,
},
{
"Got new connection 3",
0,
},
{
"[Airlock] Loading new map 2552 from previous map 2601 with translation: (-0.340088, -0.820068, -1131.33)\n    Location : (2464.73, -2373.37, -285.186)\n    Location in previous map : (2465.07, -2372.55, 846.147)",
0,
},
{
"[Airlock] Swapping to preloaded map 2552 and unloading map 2601. (Map Table Size 288 larger than budget 8)",
0,
},
{
"[Airlock] Finished transition to new map 2552",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"[Airlock] Received PreloadMap Destination MapID:2601, Current MapID:2552, PreviousTransitionID:-1, Position (2465.09, -2371.09, 846.618)",
0,
},
{
"[Airlock] Preload initiated for map 2601",
0,
},
{
"[Airlock] Cancel Preload of MapID:2601",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Changed difficulty successfully",
0,
},
{
"Completed challenge mode mapID 2661, level 13, time 2184735",
0,
},
{
"World transfer pending...",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Got new connection 3",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"Weather changed to 1, intensity 0.000000\n",
0,
},
{
"-------------------------------------------------- Previous Session --------------------------------------------------",
0,
},
},
["isShown"] = false,
["fontHeight"] = 14,
["commandHistory"] = {
},
}
